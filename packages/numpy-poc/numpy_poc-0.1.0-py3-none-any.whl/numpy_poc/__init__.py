# numpy proof-of-concept
