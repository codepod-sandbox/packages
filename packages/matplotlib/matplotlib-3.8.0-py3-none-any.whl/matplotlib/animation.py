"""
matplotlib.animation -- Animation classes (stub implementation).

Provides FuncAnimation, ArtistAnimation, and writer stubs.
"""


class _WriterRegistry:
    """Registry of animation writer classes."""

    def __init__(self):
        self._writers = {}

    def register(self, name):
        def decorator(cls):
            self._writers[name] = cls
            return cls
        return decorator

    def is_available(self, name):
        cls = self._writers.get(name)
        if cls is None:
            return False
        return getattr(cls, 'isAvailable', lambda: False)()

    def __iter__(self):
        return iter(self._writers)

    def list(self):
        return list(self._writers)


writers = _WriterRegistry()


class AbstractMovieWriter:
    """Base class for animation writers."""

    @classmethod
    def isAvailable(cls):
        return False

    def __init__(self, fps=5, metadata=None, codec=None, bitrate=-1, **kwargs):
        self.fps = fps
        self.metadata = metadata or {}
        self.codec = codec
        self.bitrate = bitrate


@writers.register('pillow')
class PillowWriter(AbstractMovieWriter):
    """Write animations as GIFs using Pillow."""

    @classmethod
    def isAvailable(cls):
        try:
            import PIL
            return True
        except ImportError:
            return False

    def saving(self, fig, outfile, dpi, *args, **kwargs):
        return self

    def __enter__(self):
        return self

    def __exit__(self, *args):
        pass

    def grab_frame(self, **savefig_kwargs):
        pass


@writers.register('ffmpeg')
class FFMpegWriter(AbstractMovieWriter):
    """Write animations using FFmpeg."""

    @classmethod
    def isAvailable(cls):
        import shutil
        return shutil.which('ffmpeg') is not None

    def saving(self, fig, outfile, dpi, *args, **kwargs):
        return self

    def __enter__(self):
        return self

    def __exit__(self, *args):
        pass

    def grab_frame(self, **savefig_kwargs):
        pass


class Animation:
    """Base class for animations."""

    def __init__(self, fig, event_source=None, blit=False):
        self._fig = fig
        self._blit = blit
        self.event_source = event_source

    def _init_draw(self):
        pass

    def _step(self, *args):
        pass

    def save(self, filename, writer=None, fps=None, dpi=None, **kwargs):
        """Save the animation (no-op stub)."""
        pass

    def to_html5_video(self, embed_limit=None):
        """Return HTML5 video tag (stub)."""
        return '<video></video>'

    def to_jshtml(self, fps=None, embed_frames=True, default_mode='loop'):
        """Return interactive JavaScript HTML (stub)."""
        return '<div></div>'


class FuncAnimation(Animation):
    """Animation using a function to draw successive frames.

    Parameters
    ----------
    fig : Figure
    func : callable
        Called with (frame, *fargs) → iterable of artists
    frames : int or iterable, optional
        Number of frames or explicit frame values
    init_func : callable, optional
        Called once to initialize the animation
    fargs : tuple, optional
        Extra args passed to func
    interval : int, optional
        Delay between frames in milliseconds (default: 200)
    blit : bool, optional
        Whether to use blitting (default: False)
    repeat : bool, optional
        Whether to repeat animation (default: True)
    repeat_delay : int, optional
        Delay in ms before repeating
    """

    def __init__(self, fig, func, frames=None, init_func=None, fargs=None,
                 save_count=None, interval=200, repeat_delay=None,
                 repeat=True, blit=False, **kwargs):
        super().__init__(fig, blit=blit)
        self._func = func
        self._init_func = init_func
        self._fargs = fargs or ()
        self.interval = interval
        self.repeat = repeat
        self.repeat_delay = repeat_delay

        if frames is None:
            self._frames = range(100)
        elif isinstance(frames, int):
            self._frames = range(frames)
        else:
            self._frames = list(frames)

        self._save_count = save_count or len(list(self._frames))


class ArtistAnimation(Animation):
    """Animation by swapping predrawn artists frame-by-frame.

    Parameters
    ----------
    fig : Figure
    artists : list of lists
        Each inner list is the set of artists to show for that frame
    interval : int, optional
        Delay between frames in ms
    repeat : bool, optional
    blit : bool, optional
    """

    def __init__(self, fig, artists, interval=200, repeat=True,
                 repeat_delay=None, blit=False, **kwargs):
        super().__init__(fig, blit=blit)
        self._framedata = artists
        self.interval = interval
        self.repeat = repeat
        self.repeat_delay = repeat_delay
