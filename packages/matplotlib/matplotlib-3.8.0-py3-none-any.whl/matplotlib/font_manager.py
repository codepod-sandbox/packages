"""matplotlib.font_manager — FontProperties and font utilities."""


# Font size string-to-point mapping
_FONT_SIZE_MAP = {
    'xx-small': 6.0, 'x-small': 8.0, 'small': 10.0, 'medium': 12.0,
    'large': 14.0, 'x-large': 17.0, 'xx-large': 20.0,
    'larger': 14.0, 'smaller': 10.0,
}


class FontProperties:
    """A class for storing and manipulating font properties.

    Parameters
    ----------
    family : str or list, optional
        Font family, e.g., 'sans-serif', 'serif', 'monospace'.
    style : str, optional
        Font style: 'normal', 'italic', 'oblique'.
    variant : str, optional
        Font variant: 'normal', 'small-caps'.
    weight : str or int, optional
        Font weight: 'normal', 'bold', 100-900.
    stretch : str, optional
        Font stretch.
    size : float or str, optional
        Font size in points or string like 'large'.
    fname : str, optional
        Path to a font file.
    math_fontfamily : str, optional
        Font family for math text.
    """

    def __init__(self, family=None, style=None, variant=None, weight=None,
                 stretch=None, size=None, fname=None, math_fontfamily=None,
                 **kwargs):
        # Handle copy constructor
        if isinstance(family, FontProperties):
            other = family
            self._family = other._family
            self._style = other._style
            self._variant = other._variant
            self._weight = other._weight
            self._stretch = other._stretch
            self._size = other._size
            self._fname = other._fname
            return

        self._family = _normalize_family(family or 'sans-serif')
        self._style = style or 'normal'
        self._variant = variant or 'normal'
        self._weight = weight or 'normal'
        self._stretch = stretch or 'normal'
        self._fname = fname

        if size is not None:
            if isinstance(size, str):
                self._size = _FONT_SIZE_MAP.get(size, 12.0)
            else:
                self._size = float(size)
        else:
            self._size = 12.0

    # ------------------------------------------------------------------
    # Getters
    # ------------------------------------------------------------------

    def get_family(self):
        return self._family

    def get_style(self):
        return self._style

    def get_variant(self):
        return self._variant

    def get_weight(self):
        return self._weight

    def get_stretch(self):
        return self._stretch

    def get_size(self):
        return self._size

    def get_size_in_points(self):
        return self._size

    def get_file(self):
        return self._fname

    def get_name(self):
        """Return the font family name (first family)."""
        if isinstance(self._family, list):
            return self._family[0]
        return self._family

    def get_math_fontfamily(self):
        return 'dejavusans'

    # ------------------------------------------------------------------
    # Setters
    # ------------------------------------------------------------------

    def set_family(self, family):
        self._family = _normalize_family(family)

    def set_name(self, name):
        self.set_family(name)

    def set_style(self, style):
        self._style = style

    def set_variant(self, variant):
        self._variant = variant

    def set_weight(self, weight):
        self._weight = weight

    def set_stretch(self, stretch):
        self._stretch = stretch

    def set_size(self, size):
        if isinstance(size, str):
            self._size = _FONT_SIZE_MAP.get(size, 12.0)
        else:
            self._size = float(size)

    def set_file(self, fname):
        self._fname = fname

    def set_math_fontfamily(self, family):
        pass

    # ------------------------------------------------------------------
    # Misc
    # ------------------------------------------------------------------

    def copy(self):
        return FontProperties(
            family=list(self._family) if isinstance(self._family, list) else self._family,
            style=self._style,
            variant=self._variant,
            weight=self._weight,
            stretch=self._stretch,
            size=self._size,
            fname=self._fname,
        )

    def __repr__(self):
        return (f"FontProperties(family={self._family!r}, style={self._style!r}, "
                f"weight={self._weight!r}, size={self._size!r})")

    def __eq__(self, other):
        if not isinstance(other, FontProperties):
            return NotImplemented
        return (self._family == other._family and
                self._style == other._style and
                self._weight == other._weight and
                self._size == other._size)


def _normalize_family(family):
    if isinstance(family, list):
        return family
    return [family]


def findfont(prop, fontext='ttf', directory=None, fallback_to_default=True,
             rebuild_if_missing=True):
    """Find a font matching *prop*.

    This is a stub that always returns a generic font name.
    """
    if isinstance(prop, FontProperties):
        name = prop.get_name()
    else:
        name = str(prop)
    return name


def get_font_names():
    """Return a list of font names available."""
    return ['DejaVu Sans', 'DejaVu Serif', 'DejaVu Sans Mono',
            'sans-serif', 'serif', 'monospace']


# Default font manager instance (stub)
fontManager = None
