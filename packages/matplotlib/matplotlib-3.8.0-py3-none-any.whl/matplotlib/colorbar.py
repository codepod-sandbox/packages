"""matplotlib.colorbar — Colorbar artist rendered as a vertical gradient strip."""

import matplotlib.cm as _cm


class Colorbar:
    """A colorbar drawn as a gradient strip alongside an Axes.

    Created by :meth:`Figure.colorbar` or :func:`pyplot.colorbar`.
    The host axes reserves extra right-margin space; the colorbar fills it.
    """

    def __init__(self, mappable, ax=None, **kwargs):
        self.mappable = mappable
        self.ax = ax      # host axes (used for layout reference)
        self._label = ''
        self._ticks = None        # None → auto 5-tick
        self._ticklabels = None   # None → formatted from ticks

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def set_label(self, label, **kwargs):
        """Set the colorbar axis label."""
        self._label = str(label) if label is not None else ''

    def get_label(self):
        """Return the colorbar axis label."""
        return self._label

    def set_ticks(self, ticks):
        """Set explicit tick positions (values in data space)."""
        self._ticks = list(ticks) if ticks is not None else None

    def get_ticks(self):
        """Return tick positions."""
        return self._ticks

    def set_ticklabels(self, labels):
        """Set explicit tick label strings."""
        self._ticklabels = [str(l) for l in labels] if labels is not None else None

    def get_ticklabels(self):
        """Return tick label strings."""
        return self._ticklabels

    def remove(self):
        """Detach this colorbar from its host axes."""
        if self.ax is not None:
            self.ax._colorbar = None
            self.ax = None

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _get_cmap_and_clim(self):
        """Return (cmap_callable, vmin, vmax) from the mappable."""
        m = self.mappable
        cmap_name = 'viridis'
        vmin, vmax = 0.0, 1.0

        if hasattr(m, 'get_cmap') and m.get_cmap() is not None:
            cmap_name = m.get_cmap()
        elif hasattr(m, '_cmap') and m._cmap is not None:
            cmap_name = m._cmap

        if hasattr(m, 'get_clim'):
            try:
                vmin, vmax = m.get_clim()
            except Exception:
                pass
        elif hasattr(m, '_clim') and m._clim is not None:
            vmin, vmax = m._clim

        if isinstance(cmap_name, str):
            cmap = _cm.get_cmap(cmap_name)
        else:
            cmap = cmap_name  # already a callable colormap

        return cmap, float(vmin), float(vmax)

    def _auto_ticks(self, vmin, vmax, n=5):
        """Return n evenly-spaced tick values between vmin and vmax."""
        if n <= 1:
            return [(vmin + vmax) / 2]
        return [vmin + (vmax - vmin) * i / (n - 1) for i in range(n)]

    def _format_tick(self, v):
        """Format a tick value as a short string."""
        if v == int(v):
            return str(int(v))
        return f'{v:.3g}'

    # ------------------------------------------------------------------
    # Rendering
    # ------------------------------------------------------------------

    def draw(self, renderer, cb_x, cb_y, cb_w, cb_h):
        """Render the colorbar at the given pixel rectangle.

        Parameters
        ----------
        cb_x, cb_y : float  Top-left corner in device pixels (y=0 is top).
        cb_w, cb_h : float  Width and height in device pixels.
        """
        cmap, vmin, vmax = self._get_cmap_and_clim()

        # --- gradient stripes (top = vmax, bottom = vmin) ---
        n = max(40, int(cb_h))
        for i in range(n):
            t = 1.0 - i / n          # fraction: 1 at top, 0 at bottom
            rgba = cmap(t)
            color = '#{:02x}{:02x}{:02x}'.format(
                int(rgba[0] * 255), int(rgba[1] * 255), int(rgba[2] * 255))
            stripe_y = cb_y + i * cb_h / n
            stripe_h = cb_h / n + 1  # +1 pixel overlap to avoid gaps
            renderer.draw_rect(cb_x, stripe_y, cb_w, stripe_h, 'none', color)

        # --- border around the gradient ---
        renderer.draw_rect(cb_x, cb_y, cb_w, cb_h, '#000000', 'none')

        # --- tick marks and labels ---
        ticks = self._ticks if self._ticks is not None else self._auto_ticks(vmin, vmax)
        labels = self._ticklabels
        if labels is None:
            labels = [self._format_tick(t) for t in ticks]

        rng = vmax - vmin if vmax != vmin else 1.0
        for tick_val, tick_label in zip(ticks, labels):
            frac = (tick_val - vmin) / rng
            ty = cb_y + (1.0 - frac) * cb_h
            renderer.draw_line(
                [cb_x + cb_w, cb_x + cb_w + 4], [ty, ty],
                '#000000', 1.0, '-')
            renderer.draw_text(
                cb_x + cb_w + 6, ty + 4, str(tick_label),
                9, '#333333', 'left')

        # --- axis label (horizontal, below the strip) ---
        if self._label:
            renderer.draw_text(
                cb_x + cb_w / 2, cb_y + cb_h + 16,
                self._label, 10, '#333333', 'center')
