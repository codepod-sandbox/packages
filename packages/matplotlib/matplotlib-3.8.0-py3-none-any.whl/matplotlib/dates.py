"""
matplotlib.dates -- date/time utilities for matplotlib.

Provides date2num, num2date, drange, formatters, and locators.
"""

import datetime

# ---------------------------------------------------------------------------
# Epoch and conversion constants
# ---------------------------------------------------------------------------

# matplotlib epoch: days since 0001-01-01 00:00:00 UTC
_EPOCH_ORDINAL = datetime.datetime(1, 1, 1).toordinal()

EPOCH_OFFSET = float(datetime.datetime(1970, 1, 1).toordinal() - _EPOCH_ORDINAL)


def date2num(d):
    """Convert datetime or list of datetimes to float (days since matplotlib epoch)."""
    if isinstance(d, (list, tuple)):
        return [date2num(x) for x in d]
    if isinstance(d, datetime.datetime):
        ordinal = d.toordinal()
        frac = (d.hour * 3600 + d.minute * 60 + d.second + d.microsecond / 1e6) / 86400.0
        return float(ordinal - _EPOCH_ORDINAL) + frac
    if isinstance(d, datetime.date):
        return float(d.toordinal() - _EPOCH_ORDINAL)
    # Assume already a number
    return float(d)


def num2date(x, tz=None):
    """Convert float (days since matplotlib epoch) to datetime."""
    if isinstance(x, (list, tuple)):
        return [num2date(v, tz=tz) for v in x]
    x = float(x)
    ordinal = int(x) + _EPOCH_ORDINAL
    frac = x - int(x)
    dt = datetime.datetime.fromordinal(ordinal)
    seconds = int(frac * 86400)
    microseconds = int((frac * 86400 - seconds) * 1e6)
    dt = dt.replace(
        hour=seconds // 3600,
        minute=(seconds % 3600) // 60,
        second=seconds % 60,
        microsecond=microseconds,
    )
    return dt


def drange(dstart, dend, delta):
    """Create a range of evenly-spaced date values.

    Parameters
    ----------
    dstart : datetime
    dend : datetime
    delta : timedelta

    Returns
    -------
    list of float (date2num values)
    """
    result = []
    current = dstart
    while current < dend:
        result.append(date2num(current))
        current += delta
    return result


# ---------------------------------------------------------------------------
# Formatters
# ---------------------------------------------------------------------------

class DateFormatter:
    """Format dates using strftime format strings."""

    def __init__(self, fmt, tz=None):
        self.fmt = fmt

    def __call__(self, x, pos=None):
        dt = num2date(x)
        return dt.strftime(self.fmt)

    def format_data(self, value):
        return self(value)

    def format_data_short(self, value):
        return self(value)

    def set_axis(self, axis):
        self.axis = axis


class AutoDateFormatter:
    """Automatically choose date format based on axis scale."""

    def __init__(self, locator, tz=None, defaultfmt='%Y-%m-%d'):
        self.locator = locator
        self.defaultfmt = defaultfmt
        # Scale ranges -> format strings (ordered from fine to coarse)
        self.scaled = {
            365.0: '%Y',
            30.0: '%b %Y',
            1.0: '%b %d',
            1.0 / 24.0: '%H:%M',
            1.0 / (24.0 * 60.0): '%H:%M:%S',
        }

    def __call__(self, x, pos=None):
        dt = num2date(x)
        return dt.strftime(self.defaultfmt)

    def set_axis(self, axis):
        self.axis = axis


class ConciseDateFormatter:
    """Concise date formatter that minimizes text."""

    def __init__(self, locator, tz=None, formats=None, offset_formats=None,
                 zero_formats=None, show_offset=True):
        self.locator = locator
        self._fmt = '%Y-%m-%d'

    def __call__(self, x, pos=None):
        dt = num2date(x)
        return dt.strftime(self._fmt)

    def set_axis(self, axis):
        self.axis = axis


# ---------------------------------------------------------------------------
# Locators
# ---------------------------------------------------------------------------

class _DateLocatorBase:
    """Base class for date locators."""

    def __init__(self):
        self.axis = None

    def set_axis(self, axis):
        self.axis = axis

    def __call__(self):
        return []

    def tick_values(self, vmin, vmax):
        return []

    def view_limits(self, vmin, vmax):
        return vmin, vmax


class AutoDateLocator(_DateLocatorBase):
    """Automatically find appropriate date ticks."""

    def __init__(self, tz=None, minticks=5, maxticks=None, interval_multiples=True):
        super().__init__()
        self.minticks = minticks
        self.maxticks = maxticks or 10


class YearLocator(_DateLocatorBase):
    """Tick every N years."""

    def __init__(self, base=1, month=1, day=1, tz=None):
        super().__init__()
        self.base = base
        self.month = month
        self.day = day


class MonthLocator(_DateLocatorBase):
    """Tick every N months."""

    def __init__(self, bymonth=None, bymonthday=1, interval=1, tz=None):
        super().__init__()
        self.interval = interval
        self.bymonth = bymonth


class WeekdayLocator(_DateLocatorBase):
    """Tick every week on given weekday."""

    def __init__(self, byweekday=None, interval=1, tz=None):
        super().__init__()
        self.byweekday = byweekday
        self.interval = interval


class DayLocator(_DateLocatorBase):
    """Tick every N days."""

    def __init__(self, bymonthday=None, interval=1, tz=None):
        super().__init__()
        self.interval = interval
        self.bymonthday = bymonthday


class HourLocator(_DateLocatorBase):
    """Tick every N hours."""

    def __init__(self, byhour=None, interval=1, tz=None):
        super().__init__()
        self.interval = interval


class MinuteLocator(_DateLocatorBase):
    """Tick every N minutes."""

    def __init__(self, byminute=None, interval=1, tz=None):
        super().__init__()
        self.interval = interval


class SecondLocator(_DateLocatorBase):
    """Tick every N seconds."""

    def __init__(self, bysecond=None, interval=1, tz=None):
        super().__init__()
        self.interval = interval


class MicrosecondLocator(_DateLocatorBase):
    """Tick every N microseconds."""

    def __init__(self, interval=1, tz=None):
        super().__init__()
        self.interval = interval


# ---------------------------------------------------------------------------
# Weekday constants (RRuleLocator-style)
# ---------------------------------------------------------------------------

MO = 0  # Monday
TU = 1
WE = 2
TH = 3
FR = 4
SA = 5
SU = 6

MONDAY = MO
TUESDAY = TU
WEDNESDAY = WE
THURSDAY = TH
FRIDAY = FR
SATURDAY = SA
SUNDAY = SU

# Deprecated constant for compatibility
SEC_PER_DAY = 86400.0
MINUTES_PER_DAY = 1440.0
HOURS_PER_DAY = 24.0
DAYS_PER_WEEK = 7.0
DAYS_PER_MONTH = 30.0
DAYS_PER_YEAR = 365.0
