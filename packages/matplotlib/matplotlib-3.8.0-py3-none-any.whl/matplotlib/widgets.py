"""
matplotlib.widgets -- Interactive widget classes.

Provides Slider, Button, CheckButtons, RadioButtons, TextBox.
"""


class AxesWidget:
    """Base class for all widgets."""

    def __init__(self, ax):
        self.ax = ax
        self._observers = {}
        self._cnt = 0

    def connect_event(self, event, callback):
        cid = self._cnt
        self._cnt += 1
        self._observers.setdefault(event, {})[cid] = callback
        return cid

    def disconnect(self, cid):
        for observers in self._observers.values():
            observers.pop(cid, None)

    def _fire_callbacks(self, event, *args):
        for cb in list(self._observers.get(event, {}).values()):
            cb(*args)


class Slider(AxesWidget):
    """A slider widget.

    Parameters
    ----------
    ax : Axes
    label : str
    valmin : float
    valmax : float
    valinit : float, optional
    valfmt : str, optional
    closedmin, closedmax : bool, optional
    slidermin, slidermax : Slider, optional
    dragging : bool, optional
    valstep : float or array-like, optional
    orientation : {'horizontal', 'vertical'}, optional
    """

    def __init__(self, ax, label, valmin, valmax, valinit=0.5,
                 valfmt=None, closedmin=True, closedmax=True,
                 slidermin=None, slidermax=None, dragging=True,
                 valstep=None, orientation='horizontal', **kwargs):
        super().__init__(ax)
        self.valmin = valmin
        self.valmax = valmax
        self.valstep = valstep
        self.val = valinit
        self.valinit = valinit
        self.valfmt = valfmt
        self.label = label
        self.orientation = orientation
        self._changed_cids = {}

    def on_changed(self, func):
        """Register a callback for value changes."""
        cid = self.connect_event('changed', func)
        self._changed_cids[cid] = func
        return cid

    def set_val(self, val):
        """Set the slider value."""
        if self.valstep is not None:
            try:
                # snap to nearest step
                import math
                steps = [self.valmin + i * self.valstep
                         for i in range(int((self.valmax - self.valmin) / self.valstep) + 1)]
                val = min(steps, key=lambda x: abs(x - val))
            except Exception:
                pass
        val = max(self.valmin, min(self.valmax, val))
        self.val = val
        self._fire_callbacks('changed', val)

    def reset(self):
        """Reset to initial value."""
        self.set_val(self.valinit)

    def disconnect(self, cid):
        self._changed_cids.pop(cid, None)
        super().disconnect(cid)


class RangeSlider(AxesWidget):
    """A slider for a range of values."""

    def __init__(self, ax, label, valmin, valmax, valinit=None,
                 valfmt=None, orientation='horizontal', **kwargs):
        super().__init__(ax)
        self.valmin = valmin
        self.valmax = valmax
        if valinit is None:
            valinit = (valmin, valmax)
        self.val = tuple(valinit)
        self.label = label

    def on_changed(self, func):
        return self.connect_event('changed', func)

    def set_val(self, val):
        self.val = (max(self.valmin, val[0]), min(self.valmax, val[1]))
        self._fire_callbacks('changed', self.val)


class Button(AxesWidget):
    """A push button widget.

    Parameters
    ----------
    ax : Axes
    label : str
    color : str, optional
    hovercolor : str, optional
    """

    def __init__(self, ax, label, color='0.85', hovercolor='0.95', **kwargs):
        super().__init__(ax)
        self.label = label
        self.color = color
        self.hovercolor = hovercolor
        self._click_cids = {}

    def on_clicked(self, func):
        """Register callback for click events."""
        cid = self.connect_event('clicked', func)
        self._click_cids[cid] = func
        return cid

    def disconnect(self, cid):
        self._click_cids.pop(cid, None)
        super().disconnect(cid)


class CheckButtons(AxesWidget):
    """A set of checkbuttons.

    Parameters
    ----------
    ax : Axes
    labels : list of str
    actives : list of bool
    """

    def __init__(self, ax, labels, actives=None, **kwargs):
        super().__init__(ax)
        self.labels = list(labels)
        if actives is None:
            actives = [False] * len(labels)
        self._states = list(actives)
        self._click_cids = {}

    def on_clicked(self, func):
        """Register callback for toggle events."""
        cid = self.connect_event('clicked', func)
        return cid

    def get_status(self):
        """Return list of bool states."""
        return list(self._states)

    def set_active(self, index):
        """Toggle the state of checkbox at *index*."""
        self._states[index] = not self._states[index]
        self._fire_callbacks('clicked', self.labels[index])


class RadioButtons(AxesWidget):
    """Mutually exclusive radio buttons.

    Parameters
    ----------
    ax : Axes
    labels : list of str
    active : int, optional
        Index of initially active button
    """

    def __init__(self, ax, labels, active=0, activecolor='blue', **kwargs):
        super().__init__(ax)
        self.labels = list(labels)
        self.active = active
        self.activecolor = activecolor
        self.value_selected = labels[active] if labels else None

    def on_clicked(self, func):
        """Register callback for selection changes."""
        return self.connect_event('clicked', func)

    def set_active(self, index):
        """Set active button by index."""
        self.active = index
        if 0 <= index < len(self.labels):
            self.value_selected = self.labels[index]
            self._fire_callbacks('clicked', self.value_selected)


class TextBox(AxesWidget):
    """A text entry widget.

    Parameters
    ----------
    ax : Axes
    label : str
    initial : str, optional
    """

    def __init__(self, ax, label, initial='', color='0.95',
                 hovercolor='1', label_pad=0.01, textalignment='left',
                 **kwargs):
        super().__init__(ax)
        self.label = label
        self.text = initial

    def on_submit(self, func):
        """Register callback for text submission."""
        return self.connect_event('submit', func)

    def on_text_change(self, func):
        """Register callback for any text change."""
        return self.connect_event('text_change', func)

    def set_val(self, val):
        """Set the text value."""
        self.text = str(val)
        self._fire_callbacks('text_change', self.text)

    def submit(self, text):
        """Submit the current text."""
        self.text = text
        self._fire_callbacks('submit', text)


class SpanSelector(AxesWidget):
    """Select a span (range) on an axis with mouse drag."""

    def __init__(self, ax, onselect, direction, minspan=None,
                 useblit=False, rectprops=None, interactive=False,
                 drag_from_anywhere=False, ignore_event_outside=False,
                 grab_range=10, **kwargs):
        super().__init__(ax)
        self.onselect = onselect
        self.direction = direction
        self.minspan = minspan

    def on_select(self, func):
        return self.connect_event('select', func)


class RectangleSelector(AxesWidget):
    """Select a rectangle region with mouse drag."""

    def __init__(self, ax, onselect, drawtype='box', minspanx=0, minspany=0,
                 useblit=False, rectprops=None, interactive=False,
                 state_modifier_keys=None, drag_from_anywhere=False, **kwargs):
        super().__init__(ax)
        self.onselect = onselect

    def on_select(self, func):
        return self.connect_event('select', func)
