"""
matplotlib.axes --- Axes class that stores plot elements.
"""

import math

builtins_range = range  # alias so we can use 'range' as a parameter name

from matplotlib.colors import DEFAULT_CYCLE, to_hex, parse_fmt
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle, Polygon, Wedge
from matplotlib.collections import PathCollection, LineCollection, Collection
from matplotlib.container import BarContainer, ErrorbarContainer, StemContainer
from matplotlib.text import Text, Annotation
from matplotlib.backend_bases import AxesLayout
from matplotlib.ticker import FixedFormatter


class Tick:
    """Minimal tick object for compatibility."""
    def __init__(self, loc=0, label_text=''):
        self._loc = loc
        self._label_text = label_text
        self._visible = True
        self.gridline = _GridLine()
        self.label1 = _TickLabel(label_text)
        self.label2 = _TickLabel(label_text)
        self.tick1line = _TickLine()
        self.tick2line = _TickLine()

    def get_loc(self):
        return self._loc

    def get_visible(self):
        return self._visible

    def set_visible(self, b):
        self._visible = b

    def get_label(self):
        return self.label1.get_text()


class _GridLine:
    """Minimal gridline stub."""
    def __init__(self):
        self._visible = False

    def get_visible(self):
        return self._visible

    def set_visible(self, b):
        self._visible = b


class _TickLabel:
    """Minimal tick label stub."""
    def __init__(self, text=''):
        self._text = str(text)
        self._fontsize = 10
        self._color = 'black'

    def get_text(self):
        return self._text

    def set_text(self, t):
        self._text = str(t)

    def get_fontsize(self):
        return self._fontsize

    def set_fontsize(self, s):
        self._fontsize = s

    def get_color(self):
        return self._color

    def set_color(self, c):
        self._color = c

    def get_visible(self):
        return True

    def set_visible(self, b):
        pass


class _TickLine:
    """Minimal tick line stub."""
    def __init__(self):
        self._color = 'black'
        self._visible = True

    def get_color(self):
        return self._color

    def set_color(self, c):
        self._color = c

    def get_visible(self):
        return self._visible

    def set_visible(self, b):
        self._visible = b


class _OffsetText:
    """Minimal offset text stub."""
    def __init__(self):
        self._text = ''
        self._visible = True
        self._color = 'black'

    def get_text(self):
        return self._text

    def set_text(self, t):
        self._text = str(t)

    def get_visible(self):
        return self._visible

    def set_visible(self, b):
        self._visible = b

    def get_color(self):
        return self._color

    def set_color(self, c):
        self._color = c


class Axis:
    """Base class for XAxis/YAxis objects."""

    def __init__(self, axes=None, *, pickradius=15):
        from matplotlib.ticker import AutoLocator, ScalarFormatter, NullLocator, NullFormatter
        self.axes = axes
        self.figure = axes.figure if axes else None
        self._major_locator = AutoLocator()
        self._minor_locator = NullLocator()
        self._major_formatter = ScalarFormatter()
        self._minor_formatter = NullFormatter()
        self._visible = True
        self._label = _TickLabel('')
        self.label = self._label
        self.offsetText = _OffsetText()
        self.majorTicks = []
        self.minorTicks = []
        self._tick_params = {}
        self.isDefault_majfmt = True
        self.isDefault_minfmt = True
        self.isDefault_majloc = True
        self.isDefault_minloc = True
        self.pickradius = pickradius

    def set_scale(self, scale):
        """Update locator/formatter for the given Scale object."""
        from matplotlib.scale import LogScale, SymmetricalLogScale
        from matplotlib.ticker import (LogLocator, LogFormatter,
                                        SymmetricalLogLocator, AutoLocator,
                                        ScalarFormatter)
        self._scale_obj = scale
        if isinstance(scale, LogScale):
            if self.isDefault_majloc:
                self._major_locator = LogLocator(base=scale.base)
            if self.isDefault_majfmt:
                self._major_formatter = LogFormatter(base=scale.base)
        elif isinstance(scale, SymmetricalLogScale):
            if self.isDefault_majloc:
                self._major_locator = SymmetricalLogLocator(base=scale.base,
                                                             linthresh=scale.linthresh)
        else:
            # Linear or unknown — restore defaults if they were scale-set
            if self.isDefault_majloc:
                self._major_locator = AutoLocator()
            if self.isDefault_majfmt:
                self._major_formatter = ScalarFormatter()

    def get_scale(self):
        """Return the current Scale object."""
        return getattr(self, '_scale_obj', None)

    def get_major_locator(self):
        return self._major_locator

    def set_major_locator(self, locator):
        self._major_locator = locator
        self.isDefault_majloc = False

    def get_minor_locator(self):
        return self._minor_locator

    def set_minor_locator(self, locator):
        self._minor_locator = locator
        self.isDefault_minloc = False

    def get_major_formatter(self):
        return self._major_formatter

    def set_major_formatter(self, formatter):
        if callable(formatter) and not hasattr(formatter, 'set_locs'):
            from matplotlib.ticker import FuncFormatter
            formatter = FuncFormatter(formatter)
        self._major_formatter = formatter
        self.isDefault_majfmt = False

    def get_minor_formatter(self):
        return self._minor_formatter

    def set_minor_formatter(self, formatter):
        if callable(formatter) and not hasattr(formatter, 'set_locs'):
            from matplotlib.ticker import FuncFormatter
            formatter = FuncFormatter(formatter)
        self._minor_formatter = formatter
        self.isDefault_minfmt = False

    def get_visible(self):
        return self._visible

    def set_visible(self, b):
        self._visible = b

    def get_label(self):
        return self._label

    def get_label_text(self):
        return self._label.get_text()

    def set_label_text(self, text, **kwargs):
        self._label.set_text(text)
        return self._label

    def get_offset_text(self):
        return self.offsetText

    def set_label_position(self, position):
        """Set position of the axis label ('top'/'bottom' for x, 'left'/'right' for y)."""
        self._label_position = position

    def get_label_position(self):
        return getattr(self, '_label_position', 'bottom')

    def set_ticks_position(self, position):
        self._ticks_position = position

    def get_ticks_position(self):
        return getattr(self, '_ticks_position', 'default')

    def tick_top(self):
        self._ticks_position = 'top'

    def tick_bottom(self):
        self._ticks_position = 'bottom'

    def tick_left(self):
        self._ticks_position = 'left'

    def tick_right(self):
        self._ticks_position = 'right'

    def set_tick_params(self, which='major', **kwargs):
        self._tick_params.update(kwargs)

    def get_tick_params(self, which='major'):
        return dict(self._tick_params)

    def get_major_ticks(self):
        return list(self.majorTicks)

    def get_minor_ticks(self):
        return list(self.minorTicks)

    def get_ticklocs(self):
        return [t.get_loc() for t in self.majorTicks]

    def get_ticklabels(self, minor=False):
        ticks = self.minorTicks if minor else self.majorTicks
        return [t.label1 for t in ticks]

    def get_ticks(self, minor=False):
        ticks = self.minorTicks if minor else self.majorTicks
        return [t.get_loc() for t in ticks]

    def tick_values(self, vmin, vmax):
        """Return tick positions for [vmin, vmax] from the major locator."""
        loc = self._major_locator
        if loc is not None and hasattr(loc, 'tick_values'):
            return loc.tick_values(vmin, vmax)
        if loc is not None and hasattr(loc, '__call__'):
            return loc(vmin, vmax)
        return []

    def format_ticks(self, values):
        """Format a sequence of tick values using the major formatter."""
        fmt = self._major_formatter
        vals_list = list(values)
        if fmt is not None:
            if hasattr(fmt, 'set_locs'):
                if hasattr(fmt, 'axis') and fmt.axis is None:
                    if hasattr(fmt, 'create_dummy_axis'):
                        fmt.create_dummy_axis()
                if vals_list:
                    vmin, vmax = min(vals_list), max(vals_list)
                    if hasattr(fmt, 'axis') and fmt.axis is not None:
                        fmt.axis.set_view_interval(vmin, vmax)
                        fmt.axis.set_data_interval(vmin, vmax)
                fmt.set_locs(vals_list)
            return [fmt(v, i) for i, v in enumerate(vals_list)]
        return [str(v) for v in vals_list]

    def set_ticks(self, ticks, labels=None, minor=False, **kwargs):
        from matplotlib.ticker import FixedLocator, FixedFormatter
        ticks = list(ticks)
        tick_list = []
        for i, t in enumerate(ticks):
            lbl = str(labels[i]) if labels and i < len(labels) else str(t)
            tick_list.append(Tick(t, lbl))
        if minor:
            self.minorTicks = tick_list
            self._minor_locator = FixedLocator(ticks)
            if labels is not None:
                self._minor_formatter = FixedFormatter(list(labels))
        else:
            self.majorTicks = tick_list
            self._major_locator = FixedLocator(ticks)
            if labels is not None:
                self._major_formatter = FixedFormatter(list(labels))

    def set_ticklabels(self, labels, minor=False, **kwargs):
        ticks = self.minorTicks if minor else self.majorTicks
        for i, t in enumerate(ticks):
            if i < len(labels):
                lbl = labels[i]
                if hasattr(lbl, 'get_text'):
                    lbl = lbl.get_text()
                t.label1.set_text(str(lbl))
                t.label2.set_text(str(lbl))

    def get_inverted(self):
        return False

    def set_inverted(self, b):
        pass

    def is_inverted(self):
        return self.get_inverted()

    def _update_ticks(self):
        return self.majorTicks + self.minorTicks

    def get_pickradius(self):
        return self.pickradius

    def set_pickradius(self, pr):
        self.pickradius = pr


class XAxis(Axis):
    """X-axis object."""
    axis_name = 'x'

    def get_inverted(self):
        return self.axes._x_inverted if self.axes else False

    def set_inverted(self, b):
        if self.axes:
            self.axes._x_inverted = b

    def get_label_text(self):
        return self.axes.get_xlabel() if self.axes else ''

    def set_label_text(self, text, **kwargs):
        if self.axes:
            self.axes.set_xlabel(text)
        self._label.set_text(text)
        return self._label


class YAxis(Axis):
    """Y-axis object."""
    axis_name = 'y'

    def get_inverted(self):
        return self.axes._y_inverted if self.axes else False

    def set_inverted(self, b):
        if self.axes:
            self.axes._y_inverted = b

    def get_label_text(self):
        return self.axes.get_ylabel() if self.axes else ''

    def set_label_text(self, text, **kwargs):
        if self.axes:
            self.axes.set_ylabel(text)
        self._label.set_text(text)
        return self._label


class _IdentityTransform:
    """Stub transform used for transAxes and transData."""

    def transform(self, points):
        return points

    def inverted(self):
        return self

    def __add__(self, other):
        return self

    def __radd__(self, other):
        return self


class _Spine:
    """Minimal spine object supporting visibility and style settings."""

    def __init__(self):
        self._visible = True
        self._linewidth = 1.0
        self._color = 'black'

    def set_visible(self, visible):
        self._visible = visible

    def get_visible(self):
        return self._visible

    def set_linewidth(self, lw):
        self._linewidth = lw

    def set_color(self, color):
        self._color = color

    def set_position(self, position):
        pass  # no-op


class Axes:
    """A single set of axes in a Figure."""

    def __init__(self, fig, position):
        self.figure = fig
        self._position = position
        self._title = ''
        self._xlabel = ''
        self._ylabel = ''
        self._xlim = None
        self._ylim = None
        self._grid = False
        self._legend_obj = None
        self._color_idx = 0
        self._facecolor = 'white'
        self._prop_cycle = None  # custom property cycle
        self._prop_cycle_idx = 0

        # Typed artist lists
        self.lines = []
        self.collections = []
        self.patches = []
        self.containers = []
        self.texts = []
        self.images = []

        # Spines
        self.spines = {k: _Spine() for k in ('top', 'bottom', 'left', 'right')}

        # Transforms (stubs — used as identity sentinels)
        self.transAxes = _IdentityTransform()
        self.transData = _IdentityTransform()

        # Axis state
        from matplotlib.scale import LinearScale
        self._x_inverted = False
        self._y_inverted = False
        self._xscale = 'linear'
        self._yscale = 'linear'
        self._xscale_obj = LinearScale()
        self._yscale_obj = LinearScale()
        self._aspect = 'auto'

        # Shared axes
        self._shared_x = []  # list of axes sharing x-limits
        self._shared_y = []  # list of axes sharing y-limits

        # Custom tick labels (set via set_xticks/set_xticklabels)
        self._xticklabels = None
        self._yticklabels = None

        # Tick/label visibility (for label_outer)
        self._xticklabels_visible = True
        self._yticklabels_visible = True
        self._xlabel_visible = True
        self._ylabel_visible = True

        # Navigate state (for interactive backends)
        self._navigate = True
        self._navigable = True

        # XAxis / YAxis objects
        self.xaxis = XAxis(self)
        self.yaxis = YAxis(self)
        self.xaxis.set_scale(self._xscale_obj)
        self.yaxis.set_scale(self._yscale_obj)

        # Autoscale state
        self._autoscalex_on = True
        self._autoscaley_on = True

        # Stale flag
        self.stale = True

        # dataLim / viewLim (minimal Bbox-like)
        self.dataLim = _SimpleBbox(0, 0, 1, 1)
        self.viewLim = _SimpleBbox(0, 0, 1, 1)

    def _next_color(self):
        if self._prop_cycle is not None:
            colors = self._prop_cycle
            c = colors[self._prop_cycle_idx % len(colors)]
            self._prop_cycle_idx += 1
            return c
        c = DEFAULT_CYCLE[self._color_idx % len(DEFAULT_CYCLE)]
        self._color_idx += 1
        return c

    def set_prop_cycle(self, *args, **kwargs):
        """Set the property cycle for this Axes.

        Parameters
        ----------
        *args : cycler or list of colors or None
            If a single iterable of color strings, use as the color cycle.
            If None, reset to default.
        **kwargs : dict
            If 'color' keyword is given, use that as the color cycle.
        """
        if len(args) == 1 and args[0] is None:
            self._prop_cycle = None
            self._prop_cycle_idx = 0
            self._color_idx = 0
            return

        if 'color' in kwargs:
            colors = kwargs['color']
            if isinstance(colors, str):
                colors = [colors]
            self._prop_cycle = list(colors)
            self._prop_cycle_idx = 0
            return

        if len(args) == 1:
            arg = args[0]
            if hasattr(arg, '__iter__') and not isinstance(arg, str):
                # Could be a cycler or list of colors
                if hasattr(arg, 'by_key'):
                    # It's a cycler object
                    keys = arg.by_key()
                    if 'color' in keys:
                        self._prop_cycle = list(keys['color'])
                    else:
                        self._prop_cycle = None
                else:
                    self._prop_cycle = list(arg)
                self._prop_cycle_idx = 0
                return

        if len(args) >= 2:
            # (key, values) form: set_prop_cycle('color', [...])
            key = args[0]
            values = args[1]
            if key == 'color':
                self._prop_cycle = list(values)
                self._prop_cycle_idx = 0
                return

    # ------------------------------------------------------------------
    # Plot types
    # ------------------------------------------------------------------

    def plot(self, *args, **kwargs):
        """Line plot.

        Accepts:
        - ``plot(y)``
        - ``plot(x, y)``
        - ``plot(x, y, fmt)``
        - ``plot(x1, y1, fmt1, x2, y2, fmt2, ...)`` (multi-line)
        - ``plot(x1, y1, x2, y2, ...)``
        """
        # Check for multi-group calls
        groups = _parse_plot_args_multi(args)

        all_lines = []
        for x, y, fmt in groups:
            # Convert datetime x/y values to numeric
            if x is not None and hasattr(x, '__iter__') and not isinstance(x, str):
                x_list = list(x)
                if x_list and hasattr(x_list[0], 'toordinal'):
                    import matplotlib.dates as _mdates
                    x = [_mdates.date2num(v) for v in x_list]
            if y is not None and hasattr(y, '__iter__') and not isinstance(y, str):
                y_list = list(y)
                if y_list and hasattr(y_list[0], 'toordinal'):
                    import matplotlib.dates as _mdates
                    y = [_mdates.date2num(v) for v in y_list]
            color_fmt, marker, linestyle = parse_fmt(fmt)
            color = kwargs.get('color') or kwargs.get('c')
            if color is None:
                color = color_fmt
            if color is None:
                color = self._next_color()
            color = to_hex(color)
            label = kwargs.get('label')
            linewidth = kwargs.get('linewidth', kwargs.get('lw', 1.5))
            if linestyle is None:
                linestyle = kwargs.get('linestyle', kwargs.get('ls', '-'))
            # Forward extra kwargs
            mkw = {}
            for mk in ('markersize', 'ms', 'markeredgecolor', 'mec',
                        'markerfacecolor', 'mfc', 'markeredgewidth', 'mew',
                        'markevery', 'fillstyle', 'drawstyle',
                        'antialiased', 'aa',
                        'solid_capstyle', 'solid_joinstyle',
                        'dash_capstyle', 'dash_joinstyle',
                        'alpha', 'zorder'):
                if mk in kwargs:
                    mkw[mk] = kwargs[mk]

            # Resolve marker: explicit kwarg overrides fmt
            final_marker = marker
            if 'marker' in kwargs:
                final_marker = kwargs['marker']
            if final_marker is None:
                final_marker = 'None'

            # Create Line2D artist
            line = Line2D(
                x, y,
                color=color,
                linewidth=linewidth,
                linestyle=linestyle,
                marker=final_marker,
                label=label,
                **mkw,
            )
            line.axes = self
            line.figure = self.figure

            # Store in typed list
            self.lines.append(line)
            all_lines.append(line)

        return all_lines

    def scatter(self, x, y, s=20, c=None, marker=None, cmap=None,
                norm=None, vmin=None, vmax=None, alpha=None,
                edgecolors=None, **kwargs):
        """Scatter plot.

        Parameters
        ----------
        c : color or array-like of float
            If a sequence of numbers, they are mapped through *cmap*.
        cmap : str or Colormap, optional
        norm : Normalize, optional
        vmin, vmax : float, optional
        """
        from matplotlib.cm import get_cmap, ScalarMappable
        from matplotlib.colors import Normalize as Norm, to_rgba

        label = kwargs.get('label')
        color_kw = kwargs.get('color')

        x_list = list(x)
        y_list = list(y)
        offsets = list(zip(x_list, y_list))

        # Validate sizes
        if isinstance(s, str):
            raise ValueError("'s' must be a float or array-like of float, "
                             "not a string")
        if hasattr(s, '__iter__'):
            sizes = list(s)
            if len(sizes) != len(x_list):
                raise ValueError("s must be the same size as x and y")
        else:
            sizes = [s]

        # Resolve colors
        facecolors = []
        mappable = None
        c_is_array = False

        if c is not None:
            # Check if c is array of numeric values for colormap mapping
            if hasattr(c, '__iter__') and not isinstance(c, str):
                c_list = list(c)
                if c_list and isinstance(c_list[0], (int, float)):
                    c_is_array = True
                    # Map through colormap
                    if cmap is None:
                        cmap = 'viridis'
                    cmap_obj = get_cmap(cmap) if isinstance(cmap, str) else cmap
                    if norm is None:
                        _vmin = vmin if vmin is not None else min(c_list)
                        _vmax = vmax if vmax is not None else max(c_list)
                        norm_obj = Norm(vmin=_vmin, vmax=_vmax)
                    else:
                        norm_obj = norm
                    for val in c_list:
                        nv = norm_obj(val)
                        rgba = cmap_obj(nv)
                        facecolors.append(to_hex(rgba))
                    # Create ScalarMappable for colorbar support
                    mappable = ScalarMappable(norm=norm_obj, cmap=cmap_obj)
                    mappable.set_array(c_list)
                else:
                    # List of color specs
                    facecolors = [to_hex(ci) for ci in c_list]
            else:
                facecolors = [to_hex(c)]
        elif color_kw is not None:
            facecolors = [to_hex(color_kw)]
        else:
            facecolors = [to_hex(self._next_color())]

        # Extract pass-through kwargs for PathCollection (e.g., zorder, visible)
        pc_kwargs = {}
        for k in ('zorder', 'visible', 'rasterized', 'url', 'gid', 'snap'):
            if k in kwargs:
                pc_kwargs[k] = kwargs[k]

        # Create PathCollection
        pc = PathCollection(
            offsets=offsets,
            sizes=sizes,
            facecolors=facecolors,
            label=label,
            marker=marker,
            **pc_kwargs,
        )
        if edgecolors is not None:
            if isinstance(edgecolors, str):
                pc.set_edgecolor([edgecolors])
            else:
                pc.set_edgecolor(list(edgecolors))
        if alpha is not None:
            pc.set_alpha(alpha)
        pc.axes = self
        pc.figure = self.figure

        # Attach ScalarMappable properties for colorbar
        if mappable is not None:
            pc._norm = mappable._norm
            pc._cmap = mappable._cmap
            pc._A = mappable._A
            pc.get_array = lambda: pc._A
            pc.get_clim = lambda: (pc._norm.vmin, pc._norm.vmax)
            pc.set_clim = lambda vmin=None, vmax=None: None

        # Store in typed list
        self.collections.append(pc)

        return pc

    def bar(self, x, height, width=0.8, **kwargs):
        """Bar chart."""
        # Color handling: facecolor takes precedence over color
        facecolor = kwargs.get('facecolor')
        edgecolor = kwargs.get('edgecolor')
        color = kwargs.get('color')
        alpha = kwargs.get('alpha')
        label = kwargs.get('label')
        bottom = kwargs.get('bottom', 0)

        if facecolor is None:
            if color is not None:
                facecolor = color
            else:
                facecolor = self._next_color()

        if edgecolor is None:
            edgecolor = 'black'

        # Convert x and height to lists (broadcast scalar height)
        if isinstance(x, (str, int, float)):
            x_vals = [x]
        else:
            x_vals = list(x)
        if not hasattr(height, '__iter__'):
            h_vals = [height] * len(x_vals)
        else:
            h_vals = list(height)

        # Handle label: list vs scalar
        if isinstance(label, list):
            if len(label) != len(x_vals):
                raise ValueError(
                    f"'label' must have the same length as 'x' "
                    f"({len(label)} != {len(x_vals)})")
            bar_labels = label
            container_label = '_nolegend_'
        else:
            bar_labels = ['_nolegend_'] * len(x_vals)
            container_label = label

        # Handle bottom as list or scalar
        if hasattr(bottom, '__iter__'):
            b_vals = list(bottom)
        else:
            b_vals = [bottom] * len(x_vals)

        # Handle width as list or scalar
        if hasattr(width, '__iter__'):
            w_vals = list(width)
        else:
            w_vals = [width] * len(x_vals)

        # Map string or datetime x values to numeric positions
        if x_vals and isinstance(x_vals[0], str):
            x_numeric = list(range(len(x_vals)))
        elif x_vals and hasattr(x_vals[0], 'toordinal'):
            import matplotlib.dates as mdates
            x_numeric = [mdates.date2num(v) for v in x_vals]
        else:
            x_numeric = x_vals

        # Expand per-bar facecolor list
        is_color_list = (isinstance(facecolor, (list, tuple)) and
                         len(facecolor) > 0 and
                         not isinstance(facecolor[0], (int, float)))
        fc_list = facecolor if is_color_list else [facecolor] * len(x_vals)

        # Create Rectangle patches for each bar
        rect_patches = []
        for i in range(len(x_vals)):
            x_center = x_numeric[i]
            h = h_vals[i]
            b = b_vals[i]
            w = w_vals[i] if i < len(w_vals) else w_vals[-1]
            bar_fc = fc_list[i] if i < len(fc_list) else fc_list[-1]
            rect = Rectangle(
                (x_center - w / 2, b),
                w,
                h,
                facecolor=bar_fc,
                edgecolor=edgecolor,
            )
            if alpha is not None:
                rect.set_alpha(alpha)
            rect.set_label(bar_labels[i])
            rect.axes = self
            rect.figure = self.figure
            self.patches.append(rect)
            rect_patches.append(rect)

        # Create BarContainer
        bc = BarContainer(rect_patches, label=container_label)
        self.containers.append(bc)

        return bc

    def hist(self, x, bins=10, range=None, density=False, weights=None,
             cumulative=False, bottom=None, histtype='bar', align='mid',
             orientation='vertical', rwidth=None, log=False, color=None,
             label=None, stacked=False, **kwargs):
        """Histogram --- compute bins, store as bar chart.

        Parameters
        ----------
        histtype : {'bar', 'barstacked', 'step', 'stepfilled'}
        stacked : bool
        range : (float, float), optional
        """
        # Backwards compat: pull from kwargs if passed there
        if label is None:
            label = kwargs.get('label')
        if color is None:
            color = kwargs.get('color')
        if not density:
            density = kwargs.get('density', False)

        # Check for list-of-lists (multiple datasets)
        multi = False
        datasets = []
        if hasattr(x, '__iter__') and not isinstance(x, str):
            x_check = list(x)
            if x_check and hasattr(x_check[0], '__iter__') and not isinstance(x_check[0], str):
                multi = True
                datasets = [list(ds) for ds in x_check]

        if not multi:
            datasets = [list(x)]

        # Resolve bins
        all_data = []
        for ds in datasets:
            all_data.extend(ds)

        if isinstance(bins, str) and bins == 'auto':
            bins = _auto_bins(all_data)

        # Handle empty data
        if not all_data:
            c = color or self._next_color()
            c = to_hex(c)
            n_bins = bins if isinstance(bins, int) else 10
            counts = [0] * n_bins
            edges = list(builtins_range(n_bins + 1))
            bc = BarContainer([], label=label)
            self.containers.append(bc)
            if multi:
                return [counts for _ in datasets], edges, bc
            return counts, edges, bc

        # Compute bin edges
        import numpy as np_hist
        if hasattr(bins, '__len__') and not isinstance(bins, str):
            # bins is an array/list of edges
            edges = list(bins)
            n_bins = len(edges) - 1
        else:
            n_bins = int(bins)
            if range is not None:
                lo, hi = float(range[0]), float(range[1])
            else:
                lo = min(all_data)
                hi = max(all_data)
            if lo == hi:
                hi = lo + 1
            bin_width = (hi - lo) / n_bins
            edges = [lo + i * bin_width for i in builtins_range(n_bins + 1)]

        # Compute counts for each dataset
        all_counts = []
        for ds in datasets:
            counts = [0] * n_bins
            bw = edges[-1] - edges[0]
            for v in ds:
                if v < edges[0] or v > edges[-1]:
                    continue
                idx = int((v - edges[0]) / (bw / n_bins))
                if idx >= n_bins:
                    idx = n_bins - 1
                if weights is not None:
                    # Find index in original ds
                    pass
                counts[idx] += 1
            all_counts.append(counts)

        # Density normalization
        if density:
            for ci in builtins_range(len(all_counts)):
                n = sum(all_counts[ci])
                if n > 0:
                    for bi in builtins_range(n_bins):
                        bw = edges[bi + 1] - edges[bi]
                        all_counts[ci][bi] = all_counts[ci][bi] / (n * bw) if bw > 0 else 0

        # Cumulative
        if cumulative:
            for ci in builtins_range(len(all_counts)):
                for bi in builtins_range(1, n_bins):
                    all_counts[ci][bi] += all_counts[ci][bi - 1]

        # Stacked: accumulate counts
        if stacked and len(all_counts) > 1:
            for ci in builtins_range(1, len(all_counts)):
                for bi in builtins_range(n_bins):
                    all_counts[ci][bi] += all_counts[ci - 1][bi]

        # Determine colors
        if color is None:
            colors_list = [to_hex(self._next_color()) for _ in datasets]
        elif isinstance(color, (list, tuple)) and len(color) == len(datasets):
            colors_list = [to_hex(c) for c in color]
        else:
            colors_list = [to_hex(color)] * len(datasets)

        # Build visual elements
        rect_patches = []
        all_lines = []

        if histtype in ('bar', 'barstacked'):
            rw = rwidth if rwidth is not None else 0.9
            for di in builtins_range(len(datasets)):
                counts = all_counts[di]
                clr = colors_list[di]
                for bi in builtins_range(n_bins):
                    bw = (edges[bi + 1] - edges[bi]) * rw
                    center = (edges[bi] + edges[bi + 1]) / 2
                    bot = 0
                    if stacked and di > 0:
                        bot = all_counts[di - 1][bi]
                        h = counts[bi] - bot
                    else:
                        h = counts[bi]
                    rect = Rectangle(
                        (center - bw / 2, bot), bw, h,
                        facecolor=clr, edgecolor='black',
                    )
                    rect.axes = self
                    rect.figure = self.figure
                    self.patches.append(rect)
                    rect_patches.append(rect)

        elif histtype == 'step':
            for di in builtins_range(len(datasets)):
                counts = all_counts[di]
                clr = colors_list[di]
                xs, ys = [], []
                for bi in builtins_range(n_bins):
                    xs.extend([edges[bi], edges[bi + 1]])
                    ys.extend([counts[bi], counts[bi]])
                line = Line2D(xs, ys, color=clr,
                              linewidth=kwargs.get('linewidth', kwargs.get('lw', 1.5)))
                line.axes = self
                line.figure = self.figure
                self.lines.append(line)
                all_lines.append(line)

        elif histtype == 'stepfilled':
            for di in builtins_range(len(datasets)):
                counts = all_counts[di]
                clr = colors_list[di]
                verts = []
                verts.append((edges[0], 0))
                for bi in builtins_range(n_bins):
                    verts.append((edges[bi], counts[bi]))
                    verts.append((edges[bi + 1], counts[bi]))
                verts.append((edges[-1], 0))
                poly = Polygon(verts, facecolor=clr, edgecolor='black')
                poly.axes = self
                poly.figure = self.figure
                self.patches.append(poly)
                rect_patches.append(poly)

        lbl = label if not multi else (label[0] if isinstance(label, list) else label)
        bc = BarContainer(rect_patches, label=lbl)
        self.containers.append(bc)

        if multi:
            return all_counts, edges, bc
        return all_counts[0], edges, bc

    def hist2d(self, x, y, bins=10, range=None, density=False,
               weights=None, cmin=None, cmax=None, **kwargs):
        """2-D histogram rendered as a heatmap via imshow.

        Returns (h, xedges, yedges, image).
        """
        from matplotlib.image import AxesImage
        import builtins

        x_list = list(x)
        y_list = list(y)

        # Compute bin edges
        if isinstance(bins, int):
            nx = ny = bins
        else:
            try:
                nx, ny = bins
            except (TypeError, ValueError):
                nx = ny = int(bins)

        if range is not None:
            (xmin, xmax), (ymin, ymax) = range
        else:
            xmin, xmax = min(x_list), max(x_list)
            ymin, ymax = min(y_list), max(y_list)
            # Add tiny padding to include max value
            if xmin == xmax:
                xmin -= 0.5; xmax += 0.5
            if ymin == ymax:
                ymin -= 0.5; ymax += 0.5

        dx = (xmax - xmin) / nx
        dy = (ymax - ymin) / ny
        xedges = [xmin + i * dx for i in builtins.range(nx + 1)]
        yedges = [ymin + i * dy for i in builtins.range(ny + 1)]

        # Count occurrences
        h = [[0] * nx for _ in builtins.range(ny)]
        for xi, yi in zip(x_list, y_list):
            ix = int((xi - xmin) / dx)
            iy = int((yi - ymin) / dy)
            ix = max(0, min(nx - 1, ix))
            iy = max(0, min(ny - 1, iy))
            h[iy][ix] += 1

        if density:
            total = len(x_list) * dx * dy
            if total > 0:
                h = [[v / total for v in row] for row in h]

        cmap = kwargs.get('cmap', 'viridis')
        vmin = kwargs.get('vmin')
        vmax = kwargs.get('vmax')

        im = AxesImage(self, cmap=cmap, origin='lower')
        im._data = h
        im._extent = (xmin, xmax, ymin, ymax)
        all_vals = [v for row in h for v in row]
        im.set_clim(vmin if vmin is not None else min(all_vals),
                    vmax if vmax is not None else max(all_vals))
        im.axes = self
        im.figure = self.figure
        self.images.append(im)
        self._update_axislim(xmin, xmax, ymin, ymax)

        return h, xedges, yedges, im

    def hexbin(self, x, y, C=None, gridsize=100, bins=None,
               xscale='linear', yscale='linear', extent=None,
               cmap='viridis', **kwargs):
        """Hexagonal binning plot.

        Rendered as a scatter of hexagonal markers sized/colored by count.
        Returns a PolyCollection.
        """
        from matplotlib.collections import PolyCollection
        import math

        x_list = list(x)
        y_list = list(y)

        if not x_list:
            pc = PolyCollection([])
            pc.axes = self
            pc.figure = self.figure
            self.collections.append(pc)
            return pc

        xmin, xmax = min(x_list), max(x_list)
        ymin, ymax = min(y_list), max(y_list)
        if xmin == xmax:
            xmin -= 0.5; xmax += 0.5
        if ymin == ymax:
            ymin -= 0.5; ymax += 0.5

        # Discretise into hex grid (approx square hex cells)
        ncols = min(gridsize, 30)  # cap for performance
        nrows = ncols
        dx = (xmax - xmin) / ncols
        dy = (ymax - ymin) / nrows

        counts = {}
        for xi, yi in zip(x_list, y_list):
            col = int((xi - xmin) / dx)
            row = int((yi - ymin) / dy)
            col = max(0, min(ncols - 1, col))
            row = max(0, min(nrows - 1, row))
            key = (col, row)
            counts[key] = counts.get(key, 0) + 1

        if not counts:
            max_count = 1
        else:
            max_count = max(counts.values())

        # Build hexagon polygons
        hex_r = min(dx, dy) * 0.5
        verts = []
        fc = []
        from matplotlib.cm import ScalarMappable
        from matplotlib.colors import to_hex as _to_hex
        sm = ScalarMappable(cmap=cmap)
        sm.set_clim(0, max_count)

        for (col, row), cnt in counts.items():
            cx = xmin + (col + 0.5) * dx
            cy = ymin + (row + 0.5) * dy
            # Six vertices of a hexagon
            pts = [(cx + hex_r * math.cos(math.radians(60 * i + 30)),
                    cy + hex_r * math.sin(math.radians(60 * i + 30)))
                   for i in range(6)]
            verts.append(pts)
            color_rgba = sm.to_rgba(cnt)
            fc.append(_to_hex(color_rgba))

        pc = PolyCollection(verts)
        pc._facecolors = fc
        pc.axes = self
        pc.figure = self.figure
        self.collections.append(pc)
        self._update_axislim(xmin, xmax, ymin, ymax)
        return pc

    def barh(self, y, width, height=0.8, **kwargs):
        """Horizontal bar chart."""
        color = kwargs.get('color') or self._next_color()
        label = kwargs.get('label')
        y_vals = list(y)
        if not hasattr(width, '__iter__'):
            w_vals = [width] * len(y_vals)
        else:
            w_vals = list(width)

        # Handle per-bar color list
        is_color_list = (isinstance(color, (list, tuple)) and
                         len(color) > 0 and
                         not isinstance(color[0], (int, float)))
        color_list = color if is_color_list else [color] * len(y_vals)

        # Map string y values to numeric positions
        if y_vals and isinstance(y_vals[0], str):
            y_numeric = list(range(len(y_vals)))
        else:
            y_numeric = y_vals

        rect_patches = []
        for i in range(len(y_vals)):
            y_center = y_numeric[i]
            w = w_vals[i]
            bar_color = color_list[i] if i < len(color_list) else color_list[-1]
            rect = Rectangle(
                (0, y_center - height / 2), w, height,
                facecolor=bar_color, edgecolor='black',
            )
            rect.axes = self
            rect.figure = self.figure
            self.patches.append(rect)
            rect_patches.append(rect)

        bc = BarContainer(rect_patches, label=label)
        self.containers.append(bc)

        return bc

    def broken_barh(self, xranges, yrange, **kwargs):
        """A sequence of horizontal bars with gaps (Gantt-chart style).

        Parameters
        ----------
        xranges : sequence of (xmin, xwidth) pairs
        yrange  : (ymin, ywidth) pair
        """
        facecolors = kwargs.get('facecolors') or kwargs.get('color') or self._next_color()
        edgecolors = kwargs.get('edgecolors', 'black')
        alpha = kwargs.get('alpha', 1.0)
        label = kwargs.get('label')

        if isinstance(facecolors, str):
            facecolors = to_hex(facecolors)
        ymin, ywidth = yrange

        patches = []
        for xmin, xwidth in xranges:
            rect = Rectangle(
                (xmin, ymin), xwidth, ywidth,
                facecolor=facecolors, edgecolor=edgecolors,
                alpha=alpha,
            )
            rect.axes = self
            rect.figure = self.figure
            self.patches.append(rect)
            patches.append(rect)

        if label:
            if patches:
                patches[0].set_label(label)

        return patches

    def errorbar(self, x, y, yerr=None, xerr=None, **kwargs):
        """Error bar plot."""
        color = kwargs.get('color') or self._next_color()
        color = to_hex(color)
        label = kwargs.get('label')
        fmt = kwargs.get('fmt', '')

        x_list = list(x)
        y_list = list(y)

        # Create the data line (suppressed when fmt='none' or 'None')
        if fmt.lower() == 'none':
            data_line = None
        else:
            data_line = Line2D(x_list, y_list, color=color, label=label)
            data_line.axes = self
            data_line.figure = self.figure
            self.lines.append(data_line)

        # Create ErrorbarContainer
        has_yerr = yerr is not None
        has_xerr = xerr is not None
        ec = ErrorbarContainer(
            (data_line, [], []),
            has_xerr=has_xerr,
            has_yerr=has_yerr,
            label=label,
        )
        self.containers.append(ec)

        # Store error data on the container for rendering
        ec._yerr_data = (x_list, y_list, yerr) if yerr is not None else None
        ec._xerr_data = (x_list, y_list, xerr) if xerr is not None else None

        return ec

    def fill_between(self, x, y1, y2=0, **kwargs):
        """Fill between two curves."""
        # Validate 2D inputs
        _validate_1d(x, 'x')
        _validate_1d(y1, 'y1')
        if hasattr(y2, '__iter__'):
            _validate_1d(y2, 'y2')

        color = kwargs.get('color') or self._next_color()
        color = to_hex(color)
        label = kwargs.get('label')
        alpha = kwargs.get('alpha', 0.5)

        x_list = list(x)
        y1_list = list(y1)
        y2_list = list(y2) if hasattr(y2, '__iter__') else [y2] * len(x_list)

        # Build polygon: forward along y1, backward along y2
        verts = []
        for i in range(len(x_list)):
            verts.append((x_list[i], y1_list[i]))
        for i in range(len(x_list) - 1, -1, -1):
            verts.append((x_list[i], y2_list[i]))

        poly = Polygon(verts, facecolor=color, edgecolor='none')
        poly.set_alpha(alpha)
        if label:
            poly.set_label(label)
        poly.axes = self
        poly.figure = self.figure
        self.patches.append(poly)

        return poly

    def fill_betweenx(self, y, x1, x2=0, **kwargs):
        """Fill between two curves in the x-direction."""
        # Validate 2D inputs
        _validate_1d(y, 'y')
        _validate_1d(x1, 'x1')
        if hasattr(x2, '__iter__'):
            _validate_1d(x2, 'x2')

        color = kwargs.get('color') or self._next_color()
        color = to_hex(color)
        label = kwargs.get('label')
        alpha = kwargs.get('alpha', 0.5)

        y_list = list(y)
        x1_list = list(x1)
        x2_list = list(x2) if hasattr(x2, '__iter__') else [x2] * len(y_list)

        verts = []
        for i in range(len(y_list)):
            verts.append((x1_list[i], y_list[i]))
        for i in range(len(y_list) - 1, -1, -1):
            verts.append((x2_list[i], y_list[i]))

        poly = Polygon(verts, facecolor=color, edgecolor='none')
        poly.set_alpha(alpha)
        if label:
            poly.set_label(label)
        poly.axes = self
        poly.figure = self.figure
        self.patches.append(poly)

        return poly

    def arrow(self, x, y, dx, dy, **kwargs):
        """Add an arrow patch from (x, y) to (x+dx, y+dy)."""
        from matplotlib.patches import Arrow
        # Consume known kwargs to avoid passing to Arrow
        width = kwargs.pop('width', 0.001)
        kwargs.pop('head_width', None)
        kwargs.pop('head_length', None)
        kwargs.pop('length_includes_head', None)
        fc = kwargs.pop('fc', kwargs.pop('facecolor', 'black'))
        kwargs.pop('ec', kwargs.pop('edgecolor', None))
        patch = Arrow(x, y, dx, dy, width=width, color=fc)
        self.add_patch(patch)
        return patch

    def axhline(self, y=0, **kwargs):
        """Add a horizontal line across the axes."""
        color = kwargs.get('color') or kwargs.get('c', 'black')
        color = to_hex(color)
        linestyle = kwargs.get('linestyle', kwargs.get('ls', '-'))
        linewidth = kwargs.get('linewidth', kwargs.get('lw', 1.0))
        label = kwargs.get('label')

        # Create a Line2D (with sentinel x-data for axhline)
        line = Line2D(
            [0], [y],
            color=color,
            linewidth=linewidth,
            linestyle=linestyle,
            label=label,
        )
        line._spanning = 'horizontal'
        line.axes = self
        line.figure = self.figure
        self.lines.append(line)

        return line

    def axvline(self, x=0, **kwargs):
        """Add a vertical line across the axes."""
        color = kwargs.get('color') or kwargs.get('c', 'black')
        color = to_hex(color)
        linestyle = kwargs.get('linestyle', kwargs.get('ls', '-'))
        linewidth = kwargs.get('linewidth', kwargs.get('lw', 1.0))
        label = kwargs.get('label')

        # Create a Line2D (with sentinel y-data for axvline)
        line = Line2D(
            [x], [0],
            color=color,
            linewidth=linewidth,
            linestyle=linestyle,
            label=label,
        )
        line._spanning = 'vertical'
        line.axes = self
        line.figure = self.figure
        self.lines.append(line)

        return line

    def hlines(self, y, xmin, xmax, **kwargs):
        """Plot horizontal lines at each *y* from *xmin* to *xmax*."""
        color = kwargs.get('colors', kwargs.get('color', 'black'))
        linewidth = kwargs.get('linewidth', kwargs.get('lw', 1.0))
        linestyle = kwargs.get('linestyle', kwargs.get('ls', '-'))
        label = kwargs.get('label')

        if not hasattr(y, '__iter__'):
            y = [y]
        y_list = list(y)

        if not hasattr(xmin, '__iter__'):
            xmin = [xmin] * len(y_list)
        if not hasattr(xmax, '__iter__'):
            xmax = [xmax] * len(y_list)
        xmin_list = list(xmin)
        xmax_list = list(xmax)

        # Normalize colors — may be a single color or list of colors
        is_color_list = (isinstance(color, (list, tuple)) and
                         len(color) > 0 and
                         not (len(color) in (3, 4) and
                              isinstance(color[0], (int, float))))
        color_list = color if is_color_list else [color] * len(y_list)

        lines = []
        for i, yv in enumerate(y_list):
            c = color_list[i] if i < len(color_list) else color_list[-1]
            line = Line2D([xmin_list[i], xmax_list[i]], [yv, yv],
                          color=to_hex(c), linewidth=linewidth,
                          linestyle=linestyle)
            if label and i == 0:
                line.set_label(label)
            else:
                line.set_label('_nolegend_')
            line.axes = self
            line.figure = self.figure
            self.lines.append(line)
            lines.append(line)
        return lines

    def vlines(self, x, ymin, ymax, **kwargs):
        """Plot vertical lines at each *x* from *ymin* to *ymax*."""
        color = kwargs.get('colors', kwargs.get('color', 'black'))
        linewidth = kwargs.get('linewidth', kwargs.get('lw', 1.0))
        linestyle = kwargs.get('linestyle', kwargs.get('ls', '-'))
        label = kwargs.get('label')

        if not hasattr(x, '__iter__'):
            x = [x]
        x_list = list(x)

        if not hasattr(ymin, '__iter__'):
            ymin = [ymin] * len(x_list)
        if not hasattr(ymax, '__iter__'):
            ymax = [ymax] * len(x_list)
        ymin_list = list(ymin)
        ymax_list = list(ymax)

        lines = []
        for i, xv in enumerate(x_list):
            line = Line2D([xv, xv], [ymin_list[i], ymax_list[i]],
                          color=to_hex(color), linewidth=linewidth,
                          linestyle=linestyle)
            if label and i == 0:
                line.set_label(label)
            else:
                line.set_label('_nolegend_')
            line.axes = self
            line.figure = self.figure
            self.lines.append(line)
            lines.append(line)
        return lines

    def step(self, x, y, where='pre', **kwargs):
        """Step plot."""
        x_list = list(x)
        y_list = list(y)
        n = len(x_list)
        if n < 2:
            return self.plot(x_list, y_list, **kwargs)

        if where == 'pre':
            xs, ys = [x_list[0]], [y_list[0]]
            for i in range(1, n):
                xs.extend([x_list[i], x_list[i]])
                ys.extend([y_list[i - 1], y_list[i]])
        elif where == 'post':
            xs, ys = [x_list[0]], [y_list[0]]
            for i in range(1, n):
                xs.extend([x_list[i - 1], x_list[i]])
                ys.extend([y_list[i], y_list[i]])
        elif where == 'mid':
            xs, ys = [x_list[0]], [y_list[0]]
            for i in range(1, n):
                mid = (x_list[i - 1] + x_list[i]) / 2
                xs.extend([mid, mid, x_list[i]])
                ys.extend([y_list[i - 1], y_list[i], y_list[i]])
        else:
            raise ValueError(
                f"'where' must be 'pre', 'post', or 'mid', not {where!r}")

        return self.plot(xs, ys, **kwargs)

    def stairs(self, values, edges=None, **kwargs):
        """Staircase plot for pre-binned data."""
        vals = list(values)
        n = len(vals)
        if edges is None:
            edg = list(range(n + 1))
        else:
            edg = list(edges)

        xs, ys = [], []
        for i in range(n):
            xs.extend([edg[i], edg[i + 1]])
            ys.extend([vals[i], vals[i]])

        color = kwargs.pop('color', None) or self._next_color()
        line = Line2D(xs, ys,
                      color=color,
                      linewidth=kwargs.pop('linewidth', kwargs.pop('lw', 1.5)),
                      linestyle=kwargs.pop('linestyle', '-'),
                      label=kwargs.pop('label', None))
        line.axes = self
        line.figure = self.figure
        self.lines.append(line)
        return line

    def stackplot(self, x, *args, labels=None, colors=None, baseline='zero',
                  **kwargs):
        """Stacked area plot.

        Parameters
        ----------
        baseline : {'zero', 'sym', 'wiggle', 'weighted_wiggle'}
        """
        x_list = list(x)
        ys = [list(a) for a in args]
        n = len(x_list)
        m = len(ys)

        if labels is None:
            labels = ['_nolegend_'] * m
        if colors is None:
            colors = [self._next_color() for _ in ys]
        else:
            colors = [to_hex(c) for c in colors]

        alpha = kwargs.get('alpha', 0.5)

        # Compute baselines
        if baseline == 'zero':
            base = [0.0] * n
        elif baseline == 'sym':
            # Symmetric: center the stack around zero
            totals = [sum(ys[k][j] for k in range(m)) for j in range(n)]
            base = [-t / 2.0 for t in totals]
        elif baseline == 'wiggle':
            # ThemeRiver / wiggle: minimize derivative of baseline
            base = [0.0] * n
            if m > 0:
                for j in range(n):
                    s = sum(ys[k][j] for k in range(m))
                    base[j] = -s / 2.0
        elif baseline == 'weighted_wiggle':
            base = [0.0] * n
            if m > 0:
                for j in range(n):
                    s = sum(ys[k][j] for k in range(m))
                    base[j] = -s / 2.0
        else:
            raise ValueError(f"Unknown baseline: {baseline!r}")

        cur_base = list(base)
        polys = []
        for i, y_data in enumerate(ys):
            top = [cur_base[j] + y_data[j] for j in range(n)]
            verts = []
            for j in range(n):
                verts.append((x_list[j], top[j]))
            for j in range(n - 1, -1, -1):
                verts.append((x_list[j], cur_base[j]))

            poly = Polygon(verts, facecolor=colors[i], edgecolor='none')
            poly.set_alpha(alpha)
            poly.set_label(labels[i])
            poly.axes = self
            poly.figure = self.figure
            self.patches.append(poly)
            polys.append(poly)
            cur_base = top

        return polys

    def stem(self, *args, linefmt=None, markerfmt=None, basefmt=None,
             bottom=0, label=None, orientation='vertical', **kwargs):
        """Stem plot (lollipop chart)."""
        if len(args) == 0:
            raise TypeError(
                "stem() requires at least 1 positional argument, "
                "but 0 were given")

        # Parse positional args: stem(y), stem(x, y), stem(y, fmt),
        # stem(x, y, fmt)
        if len(args) == 1:
            y_list = list(args[0])
            x_list = list(range(len(y_list)))
        elif len(args) == 2:
            if isinstance(args[1], str):
                # stem(y, fmt)
                y_list = list(args[0])
                x_list = list(range(len(y_list)))
                if linefmt is None:
                    linefmt = args[1]
            else:
                x_list = list(args[0])
                y_list = list(args[1])
        elif len(args) == 3:
            x_list = list(args[0])
            y_list = list(args[1])
            if isinstance(args[2], str) and linefmt is None:
                linefmt = args[2]
        else:
            raise TypeError(
                f"stem() takes 1-3 positional args, got {len(args)}")

        # Validate data is 1-D
        if hasattr(args[0], 'ndim'):
            if args[0].ndim > 1:
                raise ValueError("x or y must be 1-D")
        elif hasattr(args[0], '__iter__') and not isinstance(args[0], str):
            d = list(args[0])
            if d and hasattr(d[0], '__iter__') and not isinstance(d[0], str):
                raise ValueError("x or y must be 1-D")
        if len(args) >= 2 and not isinstance(args[1], str):
            if hasattr(args[1], 'ndim'):
                if args[1].ndim > 1:
                    raise ValueError("x or y must be 1-D")
            elif hasattr(args[1], '__iter__') and not isinstance(args[1], str):
                d = list(args[1])
                if d and hasattr(d[0], '__iter__') and not isinstance(d[0], str):
                    raise ValueError("x or y must be 1-D")

        # Parse line format string for color
        line_color = None
        if linefmt:
            fmt_color, _, fmt_ls = parse_fmt(linefmt)
            if fmt_color:
                line_color = to_hex(fmt_color)

        color = line_color or self._next_color()

        # Determine marker color and style from markerfmt
        marker_color = color
        marker_marker = 'o'
        if markerfmt is not None:
            if markerfmt in ('', ' '):
                marker_marker = 'None'
            else:
                mfmt_color, mfmt_marker, _ = parse_fmt(markerfmt)
                if mfmt_color:
                    marker_color = to_hex(mfmt_color)
                if mfmt_marker:
                    marker_marker = mfmt_marker
        # If no markerfmt color, inherit from line color
        if markerfmt is not None and marker_color == color:
            mfmt_color, _, _ = parse_fmt(markerfmt) if markerfmt not in ('', ' ') else (None, None, None)
            if not mfmt_color:
                marker_color = color

        is_horiz = orientation == 'horizontal'

        stemlines = []
        for i in range(len(x_list)):
            if is_horiz:
                sl = Line2D([bottom, y_list[i]], [x_list[i], x_list[i]],
                            color=color, linewidth=1.0, linestyle='-')
            else:
                sl = Line2D([x_list[i], x_list[i]], [bottom, y_list[i]],
                            color=color, linewidth=1.0, linestyle='-')
            sl.set_label('_nolegend_')
            sl.axes = self
            sl.figure = self.figure
            self.lines.append(sl)
            stemlines.append(sl)

        if is_horiz:
            markerline = Line2D(y_list, x_list, color=marker_color,
                                linewidth=0, linestyle='None',
                                marker=marker_marker)
        else:
            markerline = Line2D(x_list, y_list, color=marker_color,
                                linewidth=0, linestyle='None',
                                marker=marker_marker)
        markerline.set_label('_nolegend_')
        markerline.axes = self
        markerline.figure = self.figure
        self.lines.append(markerline)

        if is_horiz:
            baseline = Line2D([bottom, bottom], [min(x_list), max(x_list)],
                              color='C3', linewidth=1.0, linestyle='-')
        else:
            baseline = Line2D([min(x_list), max(x_list)], [bottom, bottom],
                              color='C3', linewidth=1.0, linestyle='-')
        baseline.set_label('_nolegend_')
        baseline.axes = self
        baseline.figure = self.figure
        self.lines.append(baseline)

        # Store color on stemlines collection for markerfmt test access
        class _StemlineCollection:
            """Lightweight proxy so stemlines.get_color() works."""
            def __init__(self, lines, color):
                self._lines = lines
                self._color = color
            def get_color(self):
                return self._color
            def __len__(self):
                return len(self._lines)
            def __iter__(self):
                return iter(self._lines)

        stemlines_coll = _StemlineCollection(stemlines, color)

        sc = StemContainer((markerline, stemlines_coll, baseline), label=label)
        self.containers.append(sc)
        return sc

    # ------------------------------------------------------------------
    # fill  (polygon fill)
    # ------------------------------------------------------------------

    def fill(self, *args, **kwargs):
        """Fill polygons.

        Call signatures::

            fill(y)
            fill(x, y)
            fill(x, y, color)
            fill(x1, y1, x2, y2, ...)

        Returns a list of :class:`~matplotlib.patches.Polygon` instances.
        """
        from matplotlib.patches import Polygon as _Polygon

        polys = []
        i = 0
        while i < len(args):
            x = list(args[i])
            y = list(args[i + 1])
            i += 2
            # Peek for optional positional color string
            fc = None
            if i < len(args) and isinstance(args[i], str):
                fc = args[i]
                i += 1
            if fc is None:
                fc = kwargs.get('color') or kwargs.get('facecolor') or kwargs.get('fc')
            if fc is None:
                fc = self._next_color()
            fc = to_hex(fc)
            ec = kwargs.get('edgecolor') or kwargs.get('ec') or 'none'
            if ec != 'none':
                ec = to_hex(ec)
            alpha = kwargs.get('alpha', 1.0)
            pts = list(zip([float(v) for v in x], [float(v) for v in y]))
            poly = _Polygon(pts, closed=True, facecolor=fc, edgecolor=ec)
            poly.set_alpha(alpha)
            poly.axes = self
            poly.figure = self.figure
            self.patches.append(poly)
            polys.append(poly)
        return polys

    # ------------------------------------------------------------------
    # quiver  (vector field arrows)
    # ------------------------------------------------------------------

    def quiver(self, *args, **kwargs):
        """Plot a 2D field of arrows.

        Call signatures::

            quiver(U, V)
            quiver(U, V, C)
            quiver(X, Y, U, V)
            quiver(X, Y, U, V, C)
        """
        import math as _math

        # Parse arguments
        if len(args) >= 4:
            X, Y, U, V = args[0], args[1], args[2], args[3]
        elif len(args) >= 2:
            U, V = args[0], args[1]
            # Build meshgrid indices
            def _shape(a):
                if hasattr(a, 'shape'):
                    return a.shape
                if hasattr(a, '__len__') and hasattr(a[0], '__len__'):
                    return (len(a), len(a[0]))
                return (len(a),)
            sh = _shape(U)
            if len(sh) == 2:
                nr, nc = sh
                X = [[float(j) for j in range(nc)] for _ in range(nr)]
                Y = [[float(i) for i in range(nr)] for _ in range(nr)]
            else:
                X = list(range(len(U) if hasattr(U, '__len__') else 1))
                Y = [0.0] * len(X)
        else:
            raise TypeError(f"quiver() requires 2 or 4 positional arguments")

        def _flat(a):
            if hasattr(a, 'flat'):
                return [float(v) for v in a.flat]
            result = []
            for row in a:
                if hasattr(row, '__iter__') and not isinstance(row, (int, float)):
                    result.extend(float(v) for v in row)
                else:
                    result.append(float(row))
            return result

        xs = _flat(X)
        ys = _flat(Y)
        us = _flat(U)
        vs = _flat(V)

        color = kwargs.get('color', kwargs.get('C', None))
        scale = kwargs.get('scale', None)

        q = _Quiver(self, xs, ys, us, vs, color=color, scale=scale)
        q.axes = self
        q.figure = self.figure
        self.collections.append(q)
        return q

    def quiverkey(self, Q, X, Y, U, label, **kwargs):
        """Add a key to a quiver plot.

        Parameters
        ----------
        Q : Quiver
            The Quiver instance to reference.
        X, Y : float
            Position of the key in axes fraction coordinates.
        U : float
            Length/magnitude of the key arrow.
        label : str
            Label string for the key.
        """
        from matplotlib.text import Text
        # Store as annotation text; we don't render a real arrow for simplicity
        txt = Text(float(X), float(Y), f'{label}', fontsize=10, ha='left',
                   transform=self.transAxes)
        txt.axes = self
        txt.figure = self.figure
        self.texts.append(txt)
        return txt

    def streamplot(self, x, y, u, v, density=1, linewidth=None, color=None,
                   cmap=None, norm=None, arrowsize=1, arrowstyle='-|>',
                   minlength=0.1, maxlength=4.0, integration_direction='both',
                   **kwargs):
        """Draw streamlines of a vector flow.

        Simplified stub that draws a regular grid of arrows to represent
        the vector field. Not a true streamline algorithm.
        """
        from matplotlib.collections import LineCollection as _LC

        def _to_list(a):
            if hasattr(a, 'tolist'):
                return a.tolist()
            return list(a)

        x_vals = _to_list(x)
        y_vals = _to_list(y)

        # Flatten u, v
        def _flat2d(arr):
            if hasattr(arr, 'tolist'):
                arr = arr.tolist()
            result = []
            for row in arr:
                if hasattr(row, '__iter__') and not isinstance(row, (int, float)):
                    result.append([float(v) for v in row])
                else:
                    result.append([float(row)])
            return result

        u_grid = _flat2d(u)
        v_grid = _flat2d(v)

        # Sample a subset of grid points based on density
        step = max(1, int(1.0 / density))
        segments = []
        arrow_color = color if color is not None else '#1f77b4'

        for iy in range(0, len(y_vals), step):
            for ix in range(0, len(x_vals), step):
                if iy < len(u_grid) and ix < len(u_grid[iy]):
                    ui = u_grid[iy][ix]
                    vi = v_grid[iy][ix]
                    mag = (ui**2 + vi**2)**0.5
                    if mag > 0:
                        scale = 0.5 / mag
                        x0, y0 = float(x_vals[ix]), float(y_vals[iy])
                        x1 = x0 + ui * scale
                        y1 = y0 + vi * scale
                        segments.append([(x0, y0), (x1, y1)])

        lc = _LC(segments, color=arrow_color,
                 linewidth=linewidth if linewidth is not None else 1.0)
        lc.axes = self
        lc.figure = self.figure
        self.collections.append(lc)

        return type('StreamplotSet', (), {'lines': lc, 'arrows': lc})()

    # ------------------------------------------------------------------
    # eventplot
    # ------------------------------------------------------------------

    def eventplot(self, positions, orientation='horizontal', lineoffsets=1,
                  linelengths=1, linewidths=None, colors=None, **kwargs):
        """Plot identical parallel lines at specific positions.

        *positions* may be a single array or a list of arrays (one per row).
        Returns an :class:`~matplotlib.collections.EventCollection` or a list.
        """
        from matplotlib.collections import EventCollection as _EC

        # Normalise to list-of-arrays
        if not hasattr(positions, '__iter__'):
            positions = [[float(positions)]]
        elif len(positions) > 0 and not hasattr(positions[0], '__iter__'):
            positions = [positions]

        result = []
        for idx, pos_arr in enumerate(positions):
            pos_list = [float(p) for p in pos_arr]
            offset = (lineoffsets[idx] if hasattr(lineoffsets, '__iter__')
                      else float(lineoffsets) * (idx + 1))
            length = (linelengths[idx] if hasattr(linelengths, '__iter__')
                      else float(linelengths))
            lw = (linewidths[idx] if linewidths and hasattr(linewidths, '__iter__')
                  else linewidths)
            col_color = None
            if colors is not None:
                col_color = (colors[idx] if hasattr(colors, '__iter__') and
                             not isinstance(colors, str) else colors)
            if col_color is None:
                col_color = self._next_color()
            col_color = to_hex(col_color)

            ec = _EC(pos_list, orientation=orientation,
                     lineoffset=offset, linelength=length,
                     linewidth=lw, color=col_color)
            ec.axes = self
            ec.figure = self.figure
            self.collections.append(ec)
            result.append(ec)

        if len(result) == 1:
            return result[0]
        return result

    # ------------------------------------------------------------------
    # spy  (sparsity pattern)
    # ------------------------------------------------------------------

    def spy(self, Z, precision=0, marker=None, markersize=None,
            aspect='equal', **kwargs):
        """Plot the sparsity pattern of a 2D array *Z*.

        Non-zero (or abs > precision) entries are shown as filled squares.
        Returns an :class:`~matplotlib.image.AxesImage`.
        """
        from matplotlib.image import AxesImage as _AI

        if hasattr(Z, 'tolist'):
            data = Z.tolist()
        else:
            data = [list(row) for row in Z]

        nrows = len(data)
        ncols = len(data[0]) if nrows > 0 else 0

        # Build binary image (255 = present, 0 = absent)
        binary = []
        for row in data:
            brow = []
            for v in row:
                val = abs(float(v)) if not isinstance(v, bool) else float(v)
                brow.append(0.0 if val > precision else 1.0)
            binary.append(brow)

        im = _AI(self, data=binary,
                 extent=(-0.5, ncols - 0.5, nrows - 0.5, -0.5),
                 cmap='binary')
        im.axes = self
        im.figure = self.figure
        self.images.append(im)
        self.set_aspect(aspect)
        self.set_xlim(-0.5, ncols - 0.5)
        self.set_ylim(nrows - 0.5, -0.5)
        return im

    # ------------------------------------------------------------------
    # matshow  (matrix visualisation — basically imshow with integer ticks)
    # ------------------------------------------------------------------

    def matshow(self, Z, **kwargs):
        """Display array *Z* as a matrix image with integer axis ticks.

        Returns an :class:`~matplotlib.image.AxesImage`.
        """
        if hasattr(Z, 'tolist'):
            data = Z.tolist()
        else:
            data = [list(row) for row in Z]

        nrows = len(data)
        ncols = len(data[0]) if nrows > 0 else 0

        im = self.imshow(Z, **kwargs)

        # Set integer ticks
        self.set_xticks(list(range(ncols)))
        self.set_yticks(list(range(nrows)))
        self.xaxis.tick_top()
        return im

    def pie(self, x, labels=None, colors=None, explode=None,
            autopct=None, startangle=0, counterclock=True, **kwargs):
        """Pie chart."""
        vals = list(x)
        n = len(vals)

        # Validate: no non-finite values
        for v in vals:
            if math.isnan(v) or math.isinf(v):
                raise ValueError(
                    "Wedge sizes must be finite numbers")

        # Validate: no negative values
        for v in vals:
            if v < 0:
                raise ValueError(
                    "Wedge sizes must be non-negative; got negative value(s)")
        total = sum(vals)
        if total == 0:
            raise ValueError("All wedge sizes are zero")

        # Validate labels and explode lengths
        if labels is not None and len(labels) != n:
            raise ValueError(
                f"'labels' must have length {n}, got {len(labels)}")
        if explode is not None and len(explode) != n:
            raise ValueError(
                f"'explode' must have length {n}, got {len(explode)}")

        if colors is None:
            colors = [DEFAULT_CYCLE[i % len(DEFAULT_CYCLE)] for i in range(n)]
        if labels is None:
            labels = [None] * n
        if explode is None:
            explode = [0.0] * n

        self.set_aspect('equal')

        cx, cy = 0.0, 0.0
        radius = 1.0

        wedges = []
        texts = []
        autotexts = [] if autopct else None

        angle = startangle
        for i in range(n):
            frac = vals[i] / total
            sweep = frac * 360.0
            if not counterclock:
                sweep = -sweep

            theta1 = angle
            theta2 = angle + sweep

            # Explode offset
            if explode[i] != 0:
                mid_angle = math.radians((theta1 + theta2) / 2)
                dx = explode[i] * math.cos(mid_angle)
                dy = explode[i] * math.sin(mid_angle)
            else:
                dx, dy = 0, 0

            w = Wedge((cx + dx, cy + dy), radius, theta1, theta2,
                      facecolor=colors[i], edgecolor='white')
            w.axes = self
            w.figure = self.figure
            self.patches.append(w)
            wedges.append(w)

            # Label text at 1.2 * radius
            if labels[i] is not None:
                mid_angle = math.radians((theta1 + theta2) / 2)
                lx = cx + dx + 1.2 * radius * math.cos(mid_angle)
                ly = cy + dy + 1.2 * radius * math.sin(mid_angle)
                ha = 'left' if math.cos(mid_angle) >= 0 else 'right'
                t = Text(lx, ly, labels[i], ha=ha, va='center', fontsize=11)
                t.axes = self
                t.figure = self.figure
                self.texts.append(t)
                texts.append(t)

            # Autopct text at 0.6 * radius
            if autopct is not None:
                pct = frac * 100
                mid_angle = math.radians((theta1 + theta2) / 2)
                px = cx + dx + 0.6 * radius * math.cos(mid_angle)
                py = cy + dy + 0.6 * radius * math.sin(mid_angle)
                if callable(autopct):
                    pct_text = autopct(pct)
                else:
                    pct_text = autopct % pct
                at = Text(px, py, pct_text, ha='center', va='center',
                          fontsize=10)
                at.axes = self
                at.figure = self.figure
                self.texts.append(at)
                autotexts.append(at)

            angle = theta2

        if autopct is not None:
            return wedges, texts, autotexts
        return wedges, texts

    def boxplot(self, x, vert=True, widths=None, showfliers=True,
                showmeans=False, **kwargs):
        """Box-and-whisker plot."""
        import numpy as np
        x_arr = np.asarray(x) if not isinstance(x, (list, tuple)) else x
        empty = (len(x_arr) == 0) if hasattr(x_arr, '__len__') else (not x_arr)
        if empty:
            return {'boxes': [], 'medians': [], 'whiskers': [],
                    'caps': [], 'fliers': [], 'means': []}
        # Normalize input: always a list of datasets
        # A 1D array is a single dataset; a list of arrays is multiple datasets
        first = x_arr[0] if hasattr(x_arr, '__getitem__') else None
        if first is not None and hasattr(first, '__iter__') and not isinstance(first, str):
            datasets = [list(d) for d in x_arr]
        else:
            datasets = [list(x_arr)]

        n = len(datasets)
        if widths is None:
            widths = [0.5] * n
        elif not hasattr(widths, '__iter__'):
            widths = [widths] * n

        result = {
            'boxes': [],
            'medians': [],
            'whiskers': [],
            'caps': [],
            'fliers': [],
            'means': [],
        }

        for i, data in enumerate(datasets):
            pos = i + 1
            w = widths[i]
            sorted_data = sorted(data)

            q1 = _percentile(sorted_data, 25)
            med = _median(sorted_data)
            q3 = _percentile(sorted_data, 75)
            iqr = q3 - q1

            whisker_lo = q1 - 1.5 * iqr
            whisker_hi = q3 + 1.5 * iqr
            actual_lo = min(v for v in sorted_data if v >= whisker_lo)
            actual_hi = max(v for v in sorted_data if v <= whisker_hi)

            if vert:
                # Box
                box = Rectangle((pos - w / 2, q1), w, q3 - q1,
                                facecolor='white', edgecolor='black')
                box.set_label('_nolegend_')
                box.axes = self
                box.figure = self.figure
                self.patches.append(box)
                result['boxes'].append(box)

                # Median line
                med_line = Line2D([pos - w / 2, pos + w / 2], [med, med],
                                  color='orange', linewidth=2.0)
                med_line.set_label('_nolegend_')
                med_line.axes = self
                med_line.figure = self.figure
                self.lines.append(med_line)
                result['medians'].append(med_line)

                # Whiskers
                lo_whisker = Line2D([pos, pos], [actual_lo, q1],
                                    color='black', linewidth=1.0, linestyle='--')
                lo_whisker.set_label('_nolegend_')
                lo_whisker.axes = self
                lo_whisker.figure = self.figure
                self.lines.append(lo_whisker)

                hi_whisker = Line2D([pos, pos], [q3, actual_hi],
                                    color='black', linewidth=1.0, linestyle='--')
                hi_whisker.set_label('_nolegend_')
                hi_whisker.axes = self
                hi_whisker.figure = self.figure
                self.lines.append(hi_whisker)
                result['whiskers'].extend([lo_whisker, hi_whisker])

                # Caps
                lo_cap = Line2D([pos - w / 4, pos + w / 4],
                                [actual_lo, actual_lo],
                                color='black', linewidth=1.0)
                lo_cap.set_label('_nolegend_')
                lo_cap.axes = self
                lo_cap.figure = self.figure
                self.lines.append(lo_cap)

                hi_cap = Line2D([pos - w / 4, pos + w / 4],
                                [actual_hi, actual_hi],
                                color='black', linewidth=1.0)
                hi_cap.set_label('_nolegend_')
                hi_cap.axes = self
                hi_cap.figure = self.figure
                self.lines.append(hi_cap)
                result['caps'].extend([lo_cap, hi_cap])

                # Fliers
                if showfliers:
                    flier_pts = [v for v in sorted_data
                                 if v < actual_lo or v > actual_hi]
                    if flier_pts:
                        flier_x = [pos] * len(flier_pts)
                        pc = PathCollection(
                            offsets=list(zip(flier_x, flier_pts)),
                            sizes=[20], facecolors=['black'])
                        pc.set_label('_nolegend_')
                        pc.axes = self
                        pc.figure = self.figure
                        self.collections.append(pc)
                        result['fliers'].append(pc)

                # Means
                if showmeans:
                    mean_val = sum(data) / len(data)
                    mean_pc = PathCollection(
                        offsets=[(pos, mean_val)],
                        sizes=[50], facecolors=['green'])
                    mean_pc.set_label('_nolegend_')
                    mean_pc.axes = self
                    mean_pc.figure = self.figure
                    self.collections.append(mean_pc)
                    result['means'].append(mean_pc)

            else:
                # Horizontal boxplot: swap x and y
                box = Rectangle((q1, pos - w / 2), q3 - q1, w,
                                facecolor='white', edgecolor='black')
                box.set_label('_nolegend_')
                box.axes = self
                box.figure = self.figure
                self.patches.append(box)
                result['boxes'].append(box)

                med_line = Line2D([med, med], [pos - w / 2, pos + w / 2],
                                  color='orange', linewidth=2.0)
                med_line.set_label('_nolegend_')
                med_line.axes = self
                med_line.figure = self.figure
                self.lines.append(med_line)
                result['medians'].append(med_line)

                lo_whisker = Line2D([actual_lo, q1], [pos, pos],
                                    color='black', linewidth=1.0, linestyle='--')
                lo_whisker.set_label('_nolegend_')
                lo_whisker.axes = self
                lo_whisker.figure = self.figure
                self.lines.append(lo_whisker)

                hi_whisker = Line2D([q3, actual_hi], [pos, pos],
                                    color='black', linewidth=1.0, linestyle='--')
                hi_whisker.set_label('_nolegend_')
                hi_whisker.axes = self
                hi_whisker.figure = self.figure
                self.lines.append(hi_whisker)
                result['whiskers'].extend([lo_whisker, hi_whisker])

                lo_cap = Line2D([actual_lo, actual_lo],
                                [pos - w / 4, pos + w / 4],
                                color='black', linewidth=1.0)
                lo_cap.set_label('_nolegend_')
                lo_cap.axes = self
                lo_cap.figure = self.figure
                self.lines.append(lo_cap)

                hi_cap = Line2D([actual_hi, actual_hi],
                                [pos - w / 4, pos + w / 4],
                                color='black', linewidth=1.0)
                hi_cap.set_label('_nolegend_')
                hi_cap.axes = self
                hi_cap.figure = self.figure
                self.lines.append(hi_cap)
                result['caps'].extend([lo_cap, hi_cap])

                if showfliers:
                    flier_pts = [v for v in sorted_data
                                 if v < actual_lo or v > actual_hi]
                    if flier_pts:
                        flier_y = [pos] * len(flier_pts)
                        pc = PathCollection(
                            offsets=list(zip(flier_pts, flier_y)),
                            sizes=[20], facecolors=['black'])
                        pc.set_label('_nolegend_')
                        pc.axes = self
                        pc.figure = self.figure
                        self.collections.append(pc)
                        result['fliers'].append(pc)

        return result

    def violinplot(self, dataset, positions=None, vert=True, widths=0.5,
                   showmeans=False, showmedians=False, showextrema=True,
                   **kwargs):
        """Violin plot."""
        # Check for empty dataset (handle numpy arrays and lists)
        try:
            is_empty = len(dataset) == 0
        except TypeError:
            is_empty = False
        if is_empty:
            return {'bodies': [], 'cmeans': [], 'cmedians': [],
                    'cmins': [], 'cmaxes': [], 'cbars': []}
        # Normalize: always list of datasets
        if not hasattr(dataset[0], '__iter__'):
            datasets = [list(dataset)]
        else:
            datasets = [list(d) for d in dataset]

        n = len(datasets)
        if positions is None:
            positions = list(range(1, n + 1))

        if not hasattr(widths, '__iter__'):
            widths = [widths] * n

        result = {
            'bodies': [],
            'cmeans': [],
            'cmedians': [],
            'cmins': [],
            'cmaxes': [],
            'cbars': [],
        }

        for i, data in enumerate(datasets):
            pos = positions[i]
            w = widths[i]
            color = self._next_color()

            kde_pos, kde_dens = _gaussian_kde(data, n_points=50)
            if not kde_dens:
                continue

            max_d = max(kde_dens) if kde_dens else 1.0
            scale = (w / 2) / max_d if max_d > 0 else 1.0

            if vert:
                verts = []
                for j in range(len(kde_pos)):
                    verts.append((pos + kde_dens[j] * scale, kde_pos[j]))
                for j in range(len(kde_pos) - 1, -1, -1):
                    verts.append((pos - kde_dens[j] * scale, kde_pos[j]))
            else:
                verts = []
                for j in range(len(kde_pos)):
                    verts.append((kde_pos[j], pos + kde_dens[j] * scale))
                for j in range(len(kde_pos) - 1, -1, -1):
                    verts.append((kde_pos[j], pos - kde_dens[j] * scale))

            poly = Polygon(verts, facecolor=color, edgecolor='black')
            poly.set_alpha(0.5)
            poly.set_label('_nolegend_')
            poly.axes = self
            poly.figure = self.figure
            self.patches.append(poly)
            result['bodies'].append(poly)

            sorted_data = sorted(data)
            data_min = sorted_data[0]
            data_max = sorted_data[-1]
            data_mean = sum(data) / len(data)
            data_med = _median(data)

            if showextrema:
                if vert:
                    bar = Line2D([pos, pos], [data_min, data_max],
                                 color='black', linewidth=1.0)
                    bar.set_label('_nolegend_')
                    bar.axes = self
                    bar.figure = self.figure
                    self.lines.append(bar)
                    result['cbars'].append(bar)

                    min_line = Line2D([pos - w / 4, pos + w / 4],
                                     [data_min, data_min],
                                     color='black', linewidth=1.0)
                    min_line.set_label('_nolegend_')
                    min_line.axes = self
                    min_line.figure = self.figure
                    self.lines.append(min_line)
                    result['cmins'].append(min_line)

                    max_line = Line2D([pos - w / 4, pos + w / 4],
                                     [data_max, data_max],
                                     color='black', linewidth=1.0)
                    max_line.set_label('_nolegend_')
                    max_line.axes = self
                    max_line.figure = self.figure
                    self.lines.append(max_line)
                    result['cmaxes'].append(max_line)
                else:
                    bar = Line2D([data_min, data_max], [pos, pos],
                                 color='black', linewidth=1.0)
                    bar.set_label('_nolegend_')
                    bar.axes = self
                    bar.figure = self.figure
                    self.lines.append(bar)
                    result['cbars'].append(bar)

                    min_line = Line2D([data_min, data_min],
                                     [pos - w / 4, pos + w / 4],
                                     color='black', linewidth=1.0)
                    min_line.set_label('_nolegend_')
                    min_line.axes = self
                    min_line.figure = self.figure
                    self.lines.append(min_line)
                    result['cmins'].append(min_line)

                    max_line = Line2D([data_max, data_max],
                                     [pos - w / 4, pos + w / 4],
                                     color='black', linewidth=1.0)
                    max_line.set_label('_nolegend_')
                    max_line.axes = self
                    max_line.figure = self.figure
                    self.lines.append(max_line)
                    result['cmaxes'].append(max_line)

            if showmeans:
                if vert:
                    m = Line2D([pos - w / 4, pos + w / 4],
                               [data_mean, data_mean],
                               color='red', linewidth=1.5)
                else:
                    m = Line2D([data_mean, data_mean],
                               [pos - w / 4, pos + w / 4],
                               color='red', linewidth=1.5)
                m.set_label('_nolegend_')
                m.axes = self
                m.figure = self.figure
                self.lines.append(m)
                result['cmeans'].append(m)

            if showmedians:
                if vert:
                    m = Line2D([pos - w / 4, pos + w / 4],
                               [data_med, data_med],
                               color='blue', linewidth=1.5)
                else:
                    m = Line2D([data_med, data_med],
                               [pos - w / 4, pos + w / 4],
                               color='blue', linewidth=1.5)
                m.set_label('_nolegend_')
                m.axes = self
                m.figure = self.figure
                self.lines.append(m)
                result['cmedians'].append(m)

        return result

    def text(self, x, y, s, **kwargs):
        """Add text to the axes."""
        t = Text(x, y, str(s), **kwargs)
        t.axes = self
        t.figure = self.figure
        self.texts.append(t)

        return t

    def annotate(self, text, xy, xytext=None, arrowprops=None, **kwargs):
        """Add an annotation to the axes."""
        ann = Annotation(text, xy, xytext=xytext, arrowprops=arrowprops,
                         **kwargs)
        ann.axes = self
        ann.figure = self.figure
        self.texts.append(ann)

        return ann

    # ------------------------------------------------------------------
    # Convenience scale methods
    # ------------------------------------------------------------------

    def loglog(self, *args, **kwargs):
        """Log-log plot: set both axes to log scale, then plot."""
        self.set_xscale('log')
        self.set_yscale('log')
        return self.plot(*args, **kwargs)

    def semilogx(self, *args, **kwargs):
        """Semi-log plot: set x-axis to log scale, then plot."""
        self.set_xscale('log')
        return self.plot(*args, **kwargs)

    def semilogy(self, *args, **kwargs):
        """Semi-log plot: set y-axis to log scale, then plot."""
        self.set_yscale('log')
        return self.plot(*args, **kwargs)

    # ------------------------------------------------------------------
    # Margins
    # ------------------------------------------------------------------

    def margins(self, *args, **kwargs):
        """Set or get margins.

        - ``margins()`` returns (xmargin, ymargin).
        - ``margins(m)`` sets both margins.
        - ``margins(x=mx, y=my)`` sets individually.
        """
        if not args and not kwargs:
            return (getattr(self, '_xmargin', 0.05),
                    getattr(self, '_ymargin', 0.05))

        # Validate: cannot pass both positional and keyword
        if args and kwargs:
            if len(args) > 0 and ('x' in kwargs or 'y' in kwargs):
                raise TypeError("Cannot pass both positional and keyword "
                                "arguments for margins.")

        if args:
            if len(args) == 1:
                m = args[0]
                if m is not None and m < -0.5:
                    raise ValueError("margin must be greater than -0.5, "
                                     f"not {m}")
                self._xmargin = args[0]
                self._ymargin = args[0]
            elif len(args) == 2:
                for m in args:
                    if m is not None and m < -0.5:
                        raise ValueError("margin must be greater than -0.5, "
                                         f"not {m}")
                self._xmargin = args[0]
                self._ymargin = args[1]
            else:
                raise TypeError("margins takes at most 2 positional arguments")
        if 'x' in kwargs:
            m = kwargs['x']
            if m is not None and m < -0.5:
                raise ValueError("margin must be greater than -0.5, "
                                 f"not {m}")
            self._xmargin = m
        if 'y' in kwargs:
            m = kwargs['y']
            if m is not None and m < -0.5:
                raise ValueError("margin must be greater than -0.5, "
                                 f"not {m}")
            self._ymargin = m

    def get_xmargin(self):
        """Return the x-margin."""
        return getattr(self, '_xmargin', 0.05)

    def get_ymargin(self):
        """Return the y-margin."""
        return getattr(self, '_ymargin', 0.05)

    def get_autoscalex_on(self):
        """Return whether autoscaling is on for the x-axis."""
        return self._autoscalex_on

    def set_autoscalex_on(self, b):
        """Set whether autoscaling is on for the x-axis."""
        self._autoscalex_on = b

    def get_autoscaley_on(self):
        """Return whether autoscaling is on for the y-axis."""
        return self._autoscaley_on

    def set_autoscaley_on(self, b):
        """Set whether autoscaling is on for the y-axis."""
        self._autoscaley_on = b

    def get_autoscale_on(self):
        """Return whether autoscaling for both axes is on."""
        return self._autoscalex_on and self._autoscaley_on

    def set_autoscale_on(self, b):
        """Set autoscaling on both axes."""
        self._autoscalex_on = b
        self._autoscaley_on = b

    # ------------------------------------------------------------------
    # Bounds
    # ------------------------------------------------------------------

    def set_xbound(self, lower=None, upper=None):
        """Set the x-axis bounds (always ordered lower < upper)."""
        old_lo, old_hi = self.get_xbound()
        if lower is None:
            lower = old_lo
        if upper is None:
            upper = old_hi
        if lower > upper:
            lower, upper = upper, lower
        if self._x_inverted:
            self.set_xlim(upper, lower)
        else:
            self.set_xlim(lower, upper)

    def get_xbound(self):
        """Return (lower, upper) for x-axis, always lower <= upper."""
        lo, hi = self.get_xlim()
        if lo > hi:
            lo, hi = hi, lo
        return (lo, hi)

    def set_ybound(self, lower=None, upper=None):
        """Set the y-axis bounds (always ordered lower < upper)."""
        old_lo, old_hi = self.get_ybound()
        if lower is None:
            lower = old_lo
        if upper is None:
            upper = old_hi
        if lower > upper:
            lower, upper = upper, lower
        if self._y_inverted:
            self.set_ylim(upper, lower)
        else:
            self.set_ylim(lower, upper)

    def get_ybound(self):
        """Return (lower, upper) for y-axis, always lower <= upper."""
        lo, hi = self.get_ylim()
        if lo > hi:
            lo, hi = hi, lo
        return (lo, hi)

    # ------------------------------------------------------------------
    # Artist management
    # ------------------------------------------------------------------

    def add_artist(self, artist):
        """Add an Artist to the axes.

        The artist is placed in the appropriate typed list based on its type.
        """
        from matplotlib.lines import Line2D as _Line2D
        from matplotlib.collections import Collection as _Coll
        from matplotlib.text import Text as _Text

        artist.axes = self
        artist.figure = self.figure

        if isinstance(artist, _Line2D):
            self.lines.append(artist)
        elif isinstance(artist, _Coll):
            self.collections.append(artist)
        elif isinstance(artist, _Text):
            self.texts.append(artist)
        else:
            # Default: try patches
            self.patches.append(artist)
        return artist

    def add_line(self, line):
        """Add a Line2D to the axes."""
        line.axes = self
        line.figure = self.figure
        self.lines.append(line)
        return line

    def add_patch(self, patch):
        """Add a Patch to the axes."""
        patch.axes = self
        patch.figure = self.figure
        self.patches.append(patch)
        return patch

    def add_collection(self, collection, autolim=True):
        """Add a Collection to the axes."""
        collection.axes = self
        collection.figure = self.figure
        self.collections.append(collection)
        return collection

    def add_container(self, container):
        """Add a Container to the axes."""
        self.containers.append(container)
        return container

    def add_image(self, image):
        """Add an AxesImage to the axes."""
        image.axes = self
        image.figure = self.figure
        self.images.append(image)
        return image

    # --- Getters for typed lists ---

    def get_lines(self):
        """Return a list of lines in the axes."""
        return list(self.lines)

    def get_images(self):
        """Return a list of images in the axes."""
        return list(self.images)

    # --- relim / autoscale ---

    def relim(self, visible_only=False):
        """Recompute the auto-limits from data (no-op: limits are always auto-computed)."""
        # In our implementation, limits are always computed from data.
        # Clear any manual limits so they get recomputed.
        pass

    def autoscale(self, enable=True, axis='both', tight=None):
        """Auto-scale the axes based on data.

        Parameters
        ----------
        enable : bool, default True
        axis : {'both', 'x', 'y'}
        tight : bool, optional
        """
        if enable:
            if axis in ('both', 'x'):
                self._xlim = None
            if axis in ('both', 'y'):
                self._ylim = None

    def autoscale_view(self, tight=None, scalex=True, scaley=True):
        """Autoscale the view based on data limits."""
        if scalex:
            self._xlim = None
        if scaley:
            self._ylim = None

    def can_pan(self):
        """Return whether the axes can be panned."""
        return True

    def can_zoom(self):
        """Return whether the axes can be zoomed."""
        return True

    def has_data(self):
        """Return whether the axes has any data."""
        return bool(self.lines or self.collections or self.patches or self.images)

    def _remove_artist(self, artist):
        """Remove an artist from this axes' typed lists."""
        if artist in self.lines:
            self.lines.remove(artist)
        elif artist in self.collections:
            self.collections.remove(artist)
        elif artist in self.patches:
            self.patches.remove(artist)
        elif artist in self.texts:
            self.texts.remove(artist)
        artist.axes = None
        artist.figure = None

    def get_legend(self):
        """Return the legend for this axes, or None if no legend is set."""
        return getattr(self, '_legend_obj', None)

    def get_legend_handles_labels(self):
        """Return (handles, labels) for all artists with non-underscore labels."""
        handles = []
        labels = []

        # Collect from all artist lists
        all_artists = (
            list(self.lines) +
            list(self.collections) +
            list(self.containers) +
            list(self.patches)
        )

        seen_labels = set()
        for artist in all_artists:
            lbl = artist.get_label() if hasattr(artist, 'get_label') else ''
            if lbl and not lbl.startswith('_') and lbl not in seen_labels:
                handles.append(artist)
                labels.append(lbl)
                seen_labels.add(lbl)

        return handles, labels

    # ------------------------------------------------------------------
    # Labels / config
    # ------------------------------------------------------------------

    def set_title(self, s, **kwargs):
        self._title = s
        # Store title object for position queries
        if not hasattr(self, 'title'):
            self.title = type('_Title', (), {
                'get_position': lambda self_: (0.5, 1.0),
                'set_position': lambda self_, p: None,
                'get_text': lambda self_: self_._text,
                '_text': s,
            })()
        self.title._text = s
        return self.title

    def get_title(self):
        return self._title

    def set_xlabel(self, s, **kwargs):
        self._xlabel = s

    def get_xlabel(self):
        return self._xlabel

    def set_ylabel(self, s, **kwargs):
        self._ylabel = s

    def get_ylabel(self):
        return self._ylabel

    def set_xlim(self, left=None, right=None, *, emit=True, auto=None, _propagating=False):
        # Handle tuple/list input
        if left is not None and right is None and hasattr(left, '__len__'):
            left, right = left
        # When only one side is given, preserve the existing other side
        if left is None and right is not None:
            left = self.get_xlim()[0]
        elif right is None and left is not None:
            right = self.get_xlim()[1]
        # Validate: reject NaN or Inf (only for numeric types)
        for val, name in [(left, 'left'), (right, 'right')]:
            if val is not None and isinstance(val, (int, float)):
                fval = float(val)
                if math.isnan(fval):
                    raise ValueError(
                        f"Axis limits cannot be NaN: {name}={val}")
                if math.isinf(fval):
                    raise ValueError(
                        f"Axis limits cannot be Inf: {name}={val}")
        self._xlim = (left, right)
        if auto is not None:
            self._autoscalex_on = auto
        # Propagate to shared axes
        if not _propagating:
            for other in self._shared_x:
                if other is not self:
                    other.set_xlim(left, right, _propagating=True)
        return (left, right)

    def get_xlim(self):
        if self._xlim is not None and self._xlim[0] is not None and self._xlim[1] is not None:
            lo, hi = self._xlim
            if self._x_inverted:
                return (hi, lo)
            return (lo, hi)
        # Auto-calculate from data
        lo, hi = self._auto_xlim()
        if self._x_inverted:
            return (hi, lo)
        return (lo, hi)

    def set_ylim(self, bottom=None, top=None, *, emit=True, auto=None, _propagating=False):
        # Handle tuple/list input
        if bottom is not None and top is None and hasattr(bottom, '__len__'):
            bottom, top = bottom
        # When only one side is given, preserve the existing other side
        if bottom is None and top is not None:
            bottom = self.get_ylim()[0]
        elif top is None and bottom is not None:
            top = self.get_ylim()[1]
        for val, name in [(bottom, 'bottom'), (top, 'top')]:
            if val is not None and isinstance(val, (int, float)):
                fval = float(val)
                if math.isnan(fval):
                    raise ValueError(
                        f"Axis limits cannot be NaN: {name}={val}")
                if math.isinf(fval):
                    raise ValueError(
                        f"Axis limits cannot be Inf: {name}={val}")
        self._ylim = (bottom, top)
        if auto is not None:
            self._autoscaley_on = auto
        if not _propagating:
            for other in self._shared_y:
                if other is not self:
                    other.set_ylim(bottom, top, _propagating=True)
        return (bottom, top)

    def get_ylim(self):
        if self._ylim is not None and self._ylim[0] is not None and self._ylim[1] is not None:
            lo, hi = self._ylim
            if self._y_inverted:
                return (hi, lo)
            return (lo, hi)
        # Auto-calculate from data
        lo, hi = self._auto_ylim()
        if self._y_inverted:
            return (hi, lo)
        return (lo, hi)

    def _auto_xlim(self):
        """Auto-calculate x limits from data in lines, collections, and patches.

        If this axes shares the x-axis with others, collect data from all.
        """
        # Collect from all shared axes (including self)
        axes_to_check = self._shared_x if self._shared_x else [self]
        xs = []
        for ax in axes_to_check:
            xs.extend(ax._collect_x_data())
        if not xs:
            return (0.0, 1.0)
        return (min(xs), max(xs))

    def _collect_x_data(self):
        """Collect all x data points from this axes' artists."""
        xs = []
        for line in self.lines:
            spanning = getattr(line, '_spanning', None)
            if spanning == 'horizontal':
                continue  # axhline doesn't contribute to x range
            xs.extend(line.get_xdata())
        for coll in self.collections:
            for pt in coll.get_offsets():
                xs.append(pt[0])
        for patch in self.patches:
            if hasattr(patch, '_xy') and hasattr(patch, '_width'):
                xs.append(patch._xy[0])
                xs.append(patch._xy[0] + patch._width)
            elif hasattr(patch, '_xy') and isinstance(patch._xy, list):
                for pt in patch._xy:
                    xs.append(pt[0])
            elif hasattr(patch, '_center') and hasattr(patch, '_r'):
                xs.append(patch._center[0] - patch._r)
                xs.append(patch._center[0] + patch._r)
        return xs

    def _auto_ylim(self):
        """Auto-calculate y limits from data in lines, collections, and patches.

        If this axes shares the y-axis with others, collect data from all.
        """
        axes_to_check = self._shared_y if self._shared_y else [self]
        ys = []
        for ax in axes_to_check:
            ys.extend(ax._collect_y_data())
        if not ys:
            return (0.0, 1.0)
        return (min(ys), max(ys))

    def _collect_y_data(self):
        """Collect all y data points from this axes' artists."""
        ys = []
        for line in self.lines:
            spanning = getattr(line, '_spanning', None)
            if spanning == 'vertical':
                continue  # axvline doesn't contribute to y range
            ys.extend(line.get_ydata())
        for coll in self.collections:
            for pt in coll.get_offsets():
                ys.append(pt[1])
        for patch in self.patches:
            if hasattr(patch, '_xy') and hasattr(patch, '_height'):
                ys.append(patch._xy[1])
                ys.append(patch._xy[1] + patch._height)
            elif hasattr(patch, '_xy') and isinstance(patch._xy, list):
                for pt in patch._xy:
                    ys.append(pt[1])
            elif hasattr(patch, '_center') and hasattr(patch, '_r'):
                ys.append(patch._center[1] - patch._r)
                ys.append(patch._center[1] + patch._r)
        # Bars typically start from 0
        if ys and any(hasattr(p, '_height') for p in self.patches):
            ys.append(0)
        return ys

    def set_xticks(self, ticks, labels=None, **kwargs):
        from matplotlib.ticker import FixedLocator
        self.xaxis.set_major_locator(FixedLocator(ticks))
        self.xaxis.set_ticks(ticks, labels)
        if labels is not None:
            self._xticklabels = list(labels)

    def get_xticks(self):
        return self.xaxis.get_ticks()

    def set_yticks(self, ticks, labels=None, **kwargs):
        from matplotlib.ticker import FixedLocator
        self.yaxis.set_major_locator(FixedLocator(ticks))
        self.yaxis.set_ticks(ticks, labels)
        if labels is not None:
            self._yticklabels = list(labels)

    def get_yticks(self):
        return self.yaxis.get_ticks()

    def get_xticklabels(self):
        """Return the x-axis tick labels."""
        if self._xticklabels is not None:
            return list(self._xticklabels)
        return []

    def set_xticklabels(self, labels, **kwargs):
        self._xticklabels = list(labels)
        self.xaxis.set_major_formatter(FixedFormatter(list(labels)))

    def get_yticklabels(self):
        """Return the y-axis tick labels."""
        if self._yticklabels is not None:
            return list(self._yticklabels)
        return []

    def set_yticklabels(self, labels, **kwargs):
        self._yticklabels = list(labels)
        self.yaxis.set_major_formatter(FixedFormatter(list(labels)))

    def tick_params(self, axis='both', **kwargs):
        """Change the appearance of ticks, tick labels, and gridlines.

        Parameters
        ----------
        axis : {'x', 'y', 'both'}, default 'both'
            Which axis to apply to.
        **kwargs
            Tick parameters: direction, length, width, color, pad,
            labelsize, labelcolor, labeltop, labelbottom, labelleft,
            labelright, labelrotation, grid_color, grid_alpha,
            grid_linewidth, grid_linestyle, bottom, top, left, right,
            which ('major', 'minor', 'both').
        """
        if not hasattr(self, '_tick_params'):
            self._tick_params = {'x': {}, 'y': {}}

        if axis == 'both':
            self._tick_params['x'].update(kwargs)
            self._tick_params['y'].update(kwargs)
        elif axis == 'x':
            self._tick_params['x'].update(kwargs)
        elif axis == 'y':
            self._tick_params['y'].update(kwargs)

    def get_tick_params(self, axis='x'):
        """Return the tick parameters for *axis*."""
        if not hasattr(self, '_tick_params'):
            self._tick_params = {'x': {}, 'y': {}}
        return dict(self._tick_params.get(axis, {}))

    def minorticks_on(self):
        """Turn on minor ticks (no-op)."""
        pass

    def minorticks_off(self):
        """Turn off minor ticks (no-op)."""
        pass

    def set_visible(self, b):
        """Set whether the axes is visible."""
        self._visible = b

    def get_visible(self):
        """Return whether the axes is visible."""
        return getattr(self, '_visible', True)

    def set_clip_on(self, b):
        """Set whether clipping is applied to this axes."""
        self._clip_on = b

    def get_clip_on(self):
        """Return whether clipping is applied."""
        return getattr(self, '_clip_on', True)

    def legend(self, *args, **kwargs):
        """Add a legend to the axes.

        Returns a Legend object with get_texts(), get_title(), set_title().
        """
        from matplotlib.legend import Legend

        if len(args) > 2:
            raise TypeError(
                f"legend() takes at most 2 positional arguments "
                f"({len(args)} given)")

        handles = None
        labels = None

        if len(args) == 2:
            handles, labels = args
        elif len(args) == 1:
            # Single arg: list of labels
            labels = list(args[0])

        if handles is None:
            handles = kwargs.pop('handles', None)
        if labels is None:
            labels = kwargs.pop('labels', None)

        # Collect from lines/patches/collections if not provided
        if handles is None and labels is None:
            h, l = self.get_legend_handles_labels()
            handles = h
            labels = l
        elif handles is not None and labels is None:
            labels = [h.get_label() for h in handles]
        elif labels is not None and handles is None:
            h, _ = self.get_legend_handles_labels()
            handles = h[:len(labels)]

        loc = kwargs.pop('loc', 'best')
        title = kwargs.pop('title', '')

        leg = Legend(self, handles or [], labels or [],
                     loc=loc, title=title, **kwargs)
        self._legend_obj = leg
        self._legend = True
        return leg

    def grid(self, visible=True, **kwargs):
        self._grid = visible

    # ------------------------------------------------------------------
    # Axis inversion
    # ------------------------------------------------------------------

    def invert_xaxis(self):
        """Invert the x-axis."""
        self._x_inverted = not self._x_inverted

    def invert_yaxis(self):
        """Invert the y-axis."""
        self._y_inverted = not self._y_inverted

    def xaxis_inverted(self):
        """Return whether the x-axis is inverted."""
        return self._x_inverted

    def yaxis_inverted(self):
        """Return whether the y-axis is inverted."""
        return self._y_inverted

    # ------------------------------------------------------------------
    # Scale
    # ------------------------------------------------------------------

    def set_xscale(self, scale, **kwargs):
        """Set the x-axis scale ('linear', 'log', 'symlog', or a Scale object)."""
        from matplotlib.scale import (LinearScale, LogScale,
                                       SymmetricalLogScale, FuncScale)
        if isinstance(scale, str):
            if scale == 'linear':
                scale_obj = LinearScale()
            elif scale == 'log':
                scale_obj = LogScale(base=kwargs.get('base', 10.0),
                                     nonpositive=kwargs.get('nonpositive', 'mask'))
            elif scale == 'symlog':
                scale_obj = SymmetricalLogScale(
                    base=kwargs.get('base', 10.0),
                    linthresh=kwargs.get('linthresh', 2.0),
                    linscale=kwargs.get('linscale', 1.0))
            else:
                raise ValueError(f"Unknown scale: {scale!r}")
        elif isinstance(scale, (LinearScale, LogScale,
                                 SymmetricalLogScale, FuncScale)):
            scale_obj = scale
        else:
            raise TypeError(f"scale must be a string or Scale object, "
                            f"got {type(scale)}")
        self._xscale = scale if isinstance(scale, str) else 'custom'
        self._xscale_obj = scale_obj
        self.xaxis.set_scale(scale_obj)

    def set_yscale(self, scale, **kwargs):
        """Set the y-axis scale ('linear', 'log', 'symlog', or a Scale object)."""
        from matplotlib.scale import (LinearScale, LogScale,
                                       SymmetricalLogScale, FuncScale)
        if isinstance(scale, str):
            if scale == 'linear':
                scale_obj = LinearScale()
            elif scale == 'log':
                scale_obj = LogScale(base=kwargs.get('base', 10.0),
                                     nonpositive=kwargs.get('nonpositive', 'mask'))
            elif scale == 'symlog':
                scale_obj = SymmetricalLogScale(
                    base=kwargs.get('base', 10.0),
                    linthresh=kwargs.get('linthresh', 2.0),
                    linscale=kwargs.get('linscale', 1.0))
            else:
                raise ValueError(f"Unknown scale: {scale!r}")
        elif isinstance(scale, (LinearScale, LogScale,
                                 SymmetricalLogScale, FuncScale)):
            scale_obj = scale
        else:
            raise TypeError(f"scale must be a string or Scale object, "
                            f"got {type(scale)}")
        self._yscale = scale if isinstance(scale, str) else 'custom'
        self._yscale_obj = scale_obj
        self.yaxis.set_scale(scale_obj)

    def get_xscale(self):
        """Return the x-axis scale."""
        return self._xscale

    def get_yscale(self):
        """Return the y-axis scale."""
        return self._yscale

    # ------------------------------------------------------------------
    # Aspect
    # ------------------------------------------------------------------

    def set_aspect(self, aspect, adjustable=None, anchor=None, share=False):
        """Set the axes aspect ratio."""
        if aspect != 'auto' and aspect != 'equal':
            aspect = float(aspect)
            if aspect <= 0 or not math.isfinite(aspect):
                raise ValueError("aspect must be finite and positive, "
                                 f"not {aspect}")
        self._aspect = aspect
        if adjustable is not None:
            self._adjustable = adjustable
        if anchor is not None:
            self._anchor = anchor

    def get_aspect(self):
        """Return the axes aspect ratio."""
        return self._aspect

    def set_adjustable(self, adjustable, share=False):
        """Set how the axes adjusts to achieve the required aspect."""
        self._adjustable = adjustable

    def get_adjustable(self):
        """Return the adjustable setting."""
        return getattr(self, '_adjustable', 'box')

    def set_anchor(self, anchor, share=False):
        """Set the anchor position."""
        self._anchor = anchor

    def get_anchor(self):
        """Return the anchor position."""
        return getattr(self, '_anchor', 'C')

    def set_box_aspect(self, aspect=None):
        """Set the box aspect ratio (height/width)."""
        self._box_aspect = aspect

    def get_box_aspect(self):
        """Return the box aspect ratio."""
        return getattr(self, '_box_aspect', None)

    # ------------------------------------------------------------------
    # Axis utility
    # ------------------------------------------------------------------

    def axis(self, option=None):
        """Set or get axis properties.

        Parameters
        ----------
        option : str, optional
            - 'square': set equal aspect with matched limits
            - 'equal': set equal aspect
            - 'off'/'on': toggle visibility
        """
        if option is None:
            xlim = self.get_xlim()
            ylim = self.get_ylim()
            return xlim + ylim
        if isinstance(option, (list, tuple)) and len(option) == 4:
            xmin, xmax, ymin, ymax = option
            self.set_xlim(xmin, xmax)
            self.set_ylim(ymin, ymax)
            return (xmin, xmax, ymin, ymax)
        if option == 'square':
            self.set_aspect('equal')
            xlim = self.get_xlim()
            ylim = self.get_ylim()
            lo = min(xlim[0], ylim[0])
            hi = max(xlim[1], ylim[1])
            self.set_xlim(lo, hi)
            self.set_ylim(lo, hi)
        elif option == 'equal':
            self.set_aspect('equal')
        elif option == 'off':
            pass  # axes visibility not implemented yet
        elif option == 'on':
            pass

    def set_axis_off(self):
        """Turn off the axis lines and labels."""
        self._axis_off = True

    def set_axis_on(self):
        """Turn on the axis lines and labels."""
        self._axis_off = False

    # ------------------------------------------------------------------
    # Label outer
    # ------------------------------------------------------------------

    def label_outer(self):
        """Only show outer labels and tick labels for subplots.

        Hides x-axis labels/ticks if this is not a bottom-row subplot,
        and y-axis labels/ticks if this is not a left-column subplot.
        """
        pos = self._position
        # Determine grid position from (nrows, ncols, index) tuple
        if isinstance(pos, tuple) and len(pos) == 3:
            nrows, ncols, index = pos
            row = (index - 1) // ncols
            col = (index - 1) % ncols
            is_bottom = (row == nrows - 1)
            is_left = (col == 0)
        else:
            # Non-grid axes — keep all labels
            is_bottom = True
            is_left = True

        if not is_bottom:
            self._xticklabels_visible = False
            self._xlabel_visible = False

        if not is_left:
            self._yticklabels_visible = False
            self._ylabel_visible = False

    # ------------------------------------------------------------------
    # Twin axes
    # ------------------------------------------------------------------

    def twinx(self):
        """Create a twin Axes sharing the x-axis."""
        ax2 = Axes(self.figure, self._position)
        self.figure._axes.append(ax2)
        # Share x-axis
        shared = self._shared_x if self._shared_x else [self]
        shared.append(ax2)
        for a in shared:
            a._shared_x = shared
        # Copy current x-limits
        if self._xlim is not None:
            ax2._xlim = self._xlim
        return ax2

    def twiny(self):
        """Create a twin Axes sharing the y-axis."""
        ax2 = Axes(self.figure, self._position)
        self.figure._axes.append(ax2)
        # Share y-axis
        shared = self._shared_y if self._shared_y else [self]
        shared.append(ax2)
        for a in shared:
            a._shared_y = shared
        # Copy current y-limits
        if self._ylim is not None:
            ax2._ylim = self._ylim
        return ax2

    def inset_axes(self, bounds, **kwargs):
        """Add a child axes at *bounds* = [x0, y0, width, height] in axes-fraction coords.

        Returns a new Axes instance drawn on top of this axes.
        """
        ax2 = Axes(self.figure, self._position)
        # Store the inset bounds for layout (x0, y0, w, h in axes-fraction)
        ax2._inset_bounds = list(bounds)
        ax2._inset_parent = self
        self.figure._axes.append(ax2)
        return ax2

    # ------------------------------------------------------------------
    # Batch setter
    # ------------------------------------------------------------------

    def set(self, **kwargs):
        """Batch property setter."""
        for k, v in kwargs.items():
            setter = getattr(self, f'set_{k}', None)
            if setter is not None:
                if isinstance(v, (tuple, list)) and k in ('xlim', 'ylim'):
                    setter(*v)
                else:
                    setter(v)

    # ------------------------------------------------------------------
    # Renderer draw path
    # ------------------------------------------------------------------

    def _compute_layout(self, fig_w_px, fig_h_px):
        # Use proportional margins: 15% left, 5% right, 10% top, 12% bottom
        # but clamp to reasonable pixel ranges
        ml = max(5, min(70, int(fig_w_px * 0.15)))
        # Reserve extra right margin when a colorbar is attached
        if getattr(self, '_colorbar', None) is not None:
            mr = max(50, min(120, int(fig_w_px * 0.18)))
        else:
            mr = max(3, min(20, int(fig_w_px * 0.05)))
        mt = max(3, min(40, int(fig_h_px * 0.10)))
        mb = max(3, min(50, int(fig_h_px * 0.12)))
        plot_x = ml
        plot_y = mt
        plot_w = fig_w_px - ml - mr
        plot_h = fig_h_px - mt - mb
        if plot_w <= 0 or plot_h <= 0:
            return None

        xmin, xmax = self.get_xlim()
        ymin, ymax = self.get_ylim()

        # Padding (same as current backends)
        dx = (xmax - xmin) or 1.0
        dy = (ymax - ymin) or 1.0
        xmin -= dx * 0.05
        xmax += dx * 0.05
        ymin -= dy * 0.05
        ymax += dy * 0.05

        return AxesLayout(plot_x, plot_y, plot_w, plot_h, xmin, xmax, ymin, ymax,
                          xscale=self._xscale_obj,
                          yscale=self._yscale_obj)

    def draw(self, renderer):
        layout = self._compute_layout(renderer.width, renderer.height)
        if layout is None:
            return
        self._last_layout = layout  # saved for colorbar positioning

        px, py, pw, ph = layout.plot_x, layout.plot_y, layout.plot_w, layout.plot_h

        # Frame border
        renderer.draw_rect(px, py, pw, ph, '#000000', 'none')

        # Compute tick positions ONCE — used for both grid and tick marks
        xtick_vals = self.xaxis.tick_values(layout.xmin, layout.xmax)
        ytick_vals = self.yaxis.tick_values(layout.ymin, layout.ymax)
        xtick_labels = self.xaxis.format_ticks(xtick_vals)
        ytick_labels = self.yaxis.format_ticks(ytick_vals)

        # Grid
        if self._grid:
            for t in xtick_vals:
                tx = layout.sx(t)
                if px < tx < px + pw:
                    renderer.draw_line([tx, tx], [py, py + ph],
                                       '#dddddd', 0.5, '--')
            for t in ytick_vals:
                ty = layout.sy(t)
                if py < ty < py + ph:
                    renderer.draw_line([px, px + pw], [ty, ty],
                                       '#dddddd', 0.5, '--')

        # Tick marks + labels
        for t, label in zip(xtick_vals, xtick_labels):
            tx = layout.sx(t)
            if px <= tx <= px + pw:
                renderer.draw_line([tx, tx], [py + ph, py + ph + 5],
                                   '#000000', 1.0, '-')
                if self._xticklabels_visible:
                    renderer.draw_text(tx, py + ph + 18, label,
                                       11, '#333333', 'center')
        for t, label in zip(ytick_vals, ytick_labels):
            ty = layout.sy(t)
            if py <= ty <= py + ph:
                renderer.draw_line([px - 5, px], [ty, ty],
                                   '#000000', 1.0, '-')
                if self._yticklabels_visible:
                    renderer.draw_text(px - 8, ty + 4, label,
                                       11, '#333333', 'right')

        # Clip for data area
        renderer.set_clip_rect(px, py, pw, ph)

        # Render images (drawn before other artists)
        self._draw_images(renderer, px, py, pw, ph)

        # Collect + sort all artists by zorder
        all_artists = []
        for img in self.images:
            all_artists.append(img)
        for line in self.lines:
            all_artists.append(line)
        for patch in self.patches:
            all_artists.append(patch)
        for coll in self.collections:
            all_artists.append(coll)
        for txt in self.texts:
            all_artists.append(txt)
        all_artists.sort(key=lambda a: a.get_zorder())

        for artist in all_artists:
            spanning = getattr(artist, '_spanning', None)
            if spanning:
                continue  # drawn separately below
            if hasattr(artist, 'draw') and callable(artist.draw):
                artist.draw(renderer, layout)

        # Spanning lines (axhline/axvline)
        for line in self.lines:
            if not line.get_visible():
                continue
            spanning = getattr(line, '_spanning', None)
            if spanning == 'horizontal':
                y_val = line._ydata[0]
                py_val = layout.sy(y_val)
                color = to_hex(line._color)
                renderer.draw_line([float(px), float(px + pw)], [py_val, py_val],
                                   color, float(line._linewidth), line._linestyle)
            elif spanning == 'vertical':
                x_val = line._xdata[0]
                px_val = layout.sx(x_val)
                color = to_hex(line._color)
                renderer.draw_line([px_val, px_val], [float(py), float(py + ph)],
                                   color, float(line._linewidth), line._linestyle)

        # Errorbar whiskers
        for container in self.containers:
            yerr_data = getattr(container, '_yerr_data', None)
            if yerr_data:
                x_list, y_list, yerr = yerr_data
                yerr_list = list(yerr) if hasattr(yerr, '__iter__') else [yerr] * len(x_list)
                color = '#000000'
                if hasattr(container, 'lines') and container.lines[0]:
                    color = to_hex(container.lines[0]._color)
                for i in range(len(x_list)):
                    err = yerr_list[i] if i < len(yerr_list) else yerr_list[-1]
                    cx = layout.sx(x_list[i])
                    y_lo = layout.sy(y_list[i] - err)
                    y_hi = layout.sy(y_list[i] + err)
                    renderer.draw_line([cx, cx], [y_lo, y_hi], color, 1.0, '-')
                    cap = 3
                    renderer.draw_line([cx - cap, cx + cap], [y_lo, y_lo], color, 1.0, '-')
                    renderer.draw_line([cx - cap, cx + cap], [y_hi, y_hi], color, 1.0, '-')

            xerr_data = getattr(container, '_xerr_data', None)
            if xerr_data:
                x_list, y_list, xerr = xerr_data
                xerr_list = list(xerr) if hasattr(xerr, '__iter__') else [xerr] * len(x_list)
                color = '#000000'
                if hasattr(container, 'lines') and container.lines[0]:
                    color = to_hex(container.lines[0]._color)
                for i in range(len(x_list)):
                    err = xerr_list[i] if i < len(xerr_list) else xerr_list[-1]
                    cy = layout.sy(y_list[i])
                    x_lo = layout.sx(x_list[i] - err)
                    x_hi = layout.sx(x_list[i] + err)
                    renderer.draw_line([x_lo, x_hi], [cy, cy], color, 1.0, '-')
                    cap = 3
                    renderer.draw_line([x_lo, x_lo], [cy - cap, cy + cap], color, 1.0, '-')
                    renderer.draw_line([x_hi, x_hi], [cy - cap, cy + cap], color, 1.0, '-')

        renderer.clear_clip()

        # Title
        if self._title:
            renderer.draw_text(px + pw / 2, py - 10, self._title,
                               14, '#000000', 'center')

        # Axis labels
        if self._xlabel and self._xlabel_visible:
            renderer.draw_text(px + pw / 2, renderer.height - 5,
                               self._xlabel, 12, '#333333', 'center')
        if self._ylabel and self._ylabel_visible:
            ty = py + ph / 2
            renderer.draw_text(15, ty, self._ylabel, 12, '#333333', 'center')

        # Legend
        if self._legend_obj is not None:
            self._legend_obj.draw(renderer, layout)

    def imshow(self, X, cmap=None, vmin=None, vmax=None, origin='upper', aspect='auto'):
        """Display an image on the axes."""
        import matplotlib.cm as _cm

        rows = list(X)
        if not rows:
            return
        first_row = list(rows[0])
        if not first_row:
            return
        first_cell = first_row[0]
        is_scalar = not hasattr(first_cell, '__len__')

        if is_scalar:
            if cmap is None:
                cmap = 'viridis'
            colormap = _cm.get_cmap(cmap)
            flat_vals = [float(v) for row in rows for v in row]
            lo = vmin if vmin is not None else min(flat_vals)
            hi = vmax if vmax is not None else max(flat_vals)
            rng = (hi - lo) if hi != lo else 1.0
            rgba_array = []
            for row in rows:
                rgba_row = []
                for v in row:
                    t = max(0.0, min(1.0, (float(v) - lo) / rng))
                    rgba = colormap(t)
                    rgba_row.append((
                        int(rgba[0] * 255), int(rgba[1] * 255),
                        int(rgba[2] * 255), int(rgba[3] * 255)
                    ))
                rgba_array.append(rgba_row)
        else:
            rgba_array = []
            for row in rows:
                rgba_row = []
                for px in row:
                    px = list(px)
                    if len(px) == 3:
                        rgba_row.append((int(px[0]), int(px[1]), int(px[2]), 255))
                    else:
                        rgba_row.append((int(px[0]), int(px[1]), int(px[2]), int(px[3])))
                rgba_array.append(rgba_row)

        if origin == 'lower':
            rgba_array = list(reversed(rgba_array))

        self._images = getattr(self, '_images', [])
        self._images.append(rgba_array)
        self._needs_draw = True

    def _draw_images(self, renderer, plot_x, plot_y, plot_w, plot_h):
        """Render all pending images onto renderer."""
        images = getattr(self, '_images', [])
        if not images:
            return
        for rgba_array in images:
            renderer.draw_image(plot_x, plot_y, plot_w, plot_h, rgba_array)
        self._images = []

    # ------------------------------------------------------------------
    # Remove
    # ------------------------------------------------------------------

    def remove(self):
        """Remove this axes from its figure."""
        if self.figure is not None:
            self.figure.delaxes(self)

    # ------------------------------------------------------------------
    # Clear
    # ------------------------------------------------------------------

    def cla(self):
        """Clear the axes."""
        self._title = ''
        self._xlabel = ''
        self._ylabel = ''
        self._xlim = None
        self._ylim = None
        self.xaxis = XAxis(self)
        self.yaxis = YAxis(self)
        self._grid = False
        self._legend_obj = None
        self._legend = False
        self._color_idx = 0
        self._facecolor = 'white'
        # Clear typed artist lists
        self.lines.clear()
        self.collections.clear()
        self.patches.clear()
        self.containers.clear()
        self.texts.clear()
        self.images.clear()
        # Reset axis state
        self._x_inverted = False
        self._y_inverted = False
        from matplotlib.scale import LinearScale
        self._xscale = 'linear'
        self._yscale = 'linear'
        self._xscale_obj = LinearScale()
        self._yscale_obj = LinearScale()
        self._aspect = 'auto'
        # Note: do NOT reset _shared_x/_shared_y — shared axes persist across cla()
        self._xticklabels_visible = True
        self._yticklabels_visible = True
        self._xlabel_visible = True
        self._ylabel_visible = True
        # Reset tick params
        self._tick_params = {'x': {}, 'y': {}}
        # Reset axis objects
        self.xaxis = XAxis(self)
        self.yaxis = YAxis(self)
        self.xaxis.set_scale(self._xscale_obj)
        self.yaxis.set_scale(self._yscale_obj)
        # Reset autoscale
        self._autoscalex_on = True
        self._autoscaley_on = True

    def clear(self):
        self.cla()

    # ------------------------------------------------------------------
    # axhspan / axvspan
    # ------------------------------------------------------------------

    def axhspan(self, ymin, ymax, xmin=0, xmax=1, **kwargs):
        """Add a horizontal span (rectangle) across the axes.

        Parameters
        ----------
        ymin, ymax : float
            Y-coordinates of the span in data coordinates.
        xmin, xmax : float, default 0..1
            X-coordinates of the span in axes fraction (0..1).
        **kwargs
            Additional kwargs passed to Rectangle (facecolor, alpha, etc.).
        """
        facecolor = kwargs.pop('facecolor', kwargs.pop('fc', None))
        if facecolor is None:
            facecolor = self._next_color()
        edgecolor = kwargs.pop('edgecolor', kwargs.pop('ec', 'none'))
        alpha = kwargs.pop('alpha', 0.5)
        label = kwargs.pop('label', '_nolegend_')

        rect = Rectangle(
            (xmin, ymin), xmax - xmin, ymax - ymin,
            facecolor=facecolor, edgecolor=edgecolor,
        )
        rect.set_alpha(alpha)
        rect.set_label(label)
        rect._spanning = 'hspan'
        rect.axes = self
        rect.figure = self.figure
        self.patches.append(rect)
        return rect

    def axvspan(self, xmin, xmax, ymin=0, ymax=1, **kwargs):
        """Add a vertical span (rectangle) across the axes.

        Parameters
        ----------
        xmin, xmax : float
            X-coordinates of the span in data coordinates.
        ymin, ymax : float, default 0..1
            Y-coordinates of the span in axes fraction (0..1).
        **kwargs
            Additional kwargs passed to Rectangle (facecolor, alpha, etc.).
        """
        facecolor = kwargs.pop('facecolor', kwargs.pop('fc', None))
        if facecolor is None:
            facecolor = self._next_color()
        edgecolor = kwargs.pop('edgecolor', kwargs.pop('ec', 'none'))
        alpha = kwargs.pop('alpha', 0.5)
        label = kwargs.pop('label', '_nolegend_')

        rect = Rectangle(
            (xmin, ymin), xmax - xmin, ymax - ymin,
            facecolor=facecolor, edgecolor=edgecolor,
        )
        rect.set_alpha(alpha)
        rect.set_label(label)
        rect._spanning = 'vspan'
        rect.axes = self
        rect.figure = self.figure
        self.patches.append(rect)
        return rect

    # ------------------------------------------------------------------
    # bar_label
    # ------------------------------------------------------------------

    def bar_label(self, container, labels=None, fmt='%g', label_type='edge',
                  padding=0, **kwargs):
        """Add labels to bars in *container*.

        Parameters
        ----------
        container : BarContainer
        labels : list of str, optional
        fmt : str or callable
        label_type : {'edge', 'center'}
        padding : float or array-like
        """
        bars = container.patches

        # Validate fmt
        if not isinstance(fmt, (str, type(lambda: None))) and not callable(fmt):
            raise TypeError("fmt must be a str or callable, not %s" %
                            type(fmt).__name__)

        # Validate padding
        if hasattr(padding, '__iter__'):
            padding_list = list(padding)
            if len(padding_list) != len(bars):
                raise ValueError(
                    f"padding must be of length {len(bars)}, "
                    f"but has length {len(padding_list)}")
        else:
            padding_list = [padding] * len(bars)

        annotations = []
        for i, bar in enumerate(bars):
            # Determine the data value
            if labels is not None:
                text = str(labels[i])
            else:
                # Determine value from bar geometry
                # For vertical bars, value = height; for horizontal, value = width
                x0, y0 = bar.get_xy()
                w = bar.get_width()
                h = bar.get_height()

                # Detect orientation: vertical if abs(h) >= abs(w) or width ~ standard bar width
                is_vertical = True
                if hasattr(container, '_orientation'):
                    is_vertical = container._orientation == 'vertical'
                else:
                    # Heuristic: if all bars have x-extent < y-extent, horizontal
                    # Check if bar was created by barh (width > height typically)
                    if abs(w) > abs(h) and y0 != 0:
                        is_vertical = False

                if is_vertical:
                    value = h
                else:
                    value = w

                # Format the value
                if math.isnan(value):
                    text = ''
                elif isinstance(fmt, str):
                    if '%' in fmt:
                        text = fmt % value
                    else:
                        text = format(value, fmt)
                elif callable(fmt):
                    text = fmt(value)
                else:
                    text = str(value)

            pad = padding_list[i]
            x0, y0 = bar.get_xy()
            w = bar.get_width()
            h = bar.get_height()

            if label_type == 'center':
                # Place at center of bar in axes coordinates (0.5, 0.5)
                ann = Annotation(
                    text, xy=(0.5, 0.5),
                    ha='center', va='center',
                )
                ann.xyann = (pad, pad)
            else:
                # 'edge' — place at the end of the bar
                # Detect orientation
                is_vertical = abs(h) >= abs(w) or (y0 == 0 and x0 != 0) or (abs(w) < 2)
                # Better heuristic: check if this came from bar() or barh()
                # bar(): xy = (x - w/2, bottom), height = value
                # barh(): xy = (0, y - h/2), width = value
                if x0 == 0 or (abs(w) > abs(h) and abs(h) < 2):
                    # Horizontal bar (barh)
                    is_vertical = False

                if is_vertical:
                    x_pos = x0 + w / 2
                    h_val = h if not math.isnan(h) else 0
                    if h_val >= 0 or math.isnan(h):
                        y_pos = y0 + h_val
                        va = 'bottom'
                    else:
                        y_pos = y0 + h_val
                        va = 'top'
                    ann = Annotation(text, xy=(x_pos, y_pos),
                                     ha='center', va=va)
                    ann.xyann = (0, pad)
                else:
                    w_val = w if not math.isnan(w) else 0
                    y_pos = y0 + h / 2
                    if w_val >= 0 or math.isnan(w):
                        x_pos = x0 + w_val
                        ha = 'left'
                    else:
                        x_pos = x0 + w_val
                        ha = 'right'
                    ann = Annotation(text, xy=(x_pos, y_pos),
                                     ha=ha, va='center')
                    ann.xyann = (pad, 0)

            ann.axes = self
            ann.figure = self.figure
            self.texts.append(ann)
            annotations.append(ann)

        return annotations

    # ------------------------------------------------------------------
    # Facecolor
    # ------------------------------------------------------------------

    def set_facecolor(self, color):
        """Set the axes background color."""
        self._facecolor = color

    def get_facecolor(self):
        """Return the axes background color as an RGBA tuple."""
        from matplotlib.colors import to_rgba
        return to_rgba(self._facecolor)

    # alias used by upstream
    set_fc = set_facecolor
    get_fc = get_facecolor

    # ------------------------------------------------------------------
    # Position
    # ------------------------------------------------------------------

    def get_position(self):
        """Return the axes position.

        Returns a Bbox-like object with x0, y0, width, height attributes.
        For subplot positions (nrows, ncols, index), computes the position.
        """
        pos = self._position
        if isinstance(pos, tuple) and len(pos) == 3:
            nrows, ncols, index = pos
            row = (index - 1) // ncols
            col = (index - 1) % ncols
            w = 1.0 / ncols
            h = 1.0 / nrows
            x0 = col * w
            y0 = 1.0 - (row + 1) * h
            return _BboxLike(x0, y0, w, h)
        if isinstance(pos, (tuple, list)) and len(pos) == 4:
            return _BboxLike(pos[0], pos[1], pos[2], pos[3])
        return _BboxLike(0, 0, 1, 1)

    def set_position(self, pos):
        """Set the axes position."""
        if isinstance(pos, (tuple, list)) and len(pos) == 4:
            self._position = tuple(pos)
        elif hasattr(pos, 'bounds'):
            self._position = pos.bounds

    # ------------------------------------------------------------------
    # Navigate
    # ------------------------------------------------------------------

    def set_navigate(self, b):
        """Set whether the axes responds to navigation commands."""
        self._navigate = b

    def get_navigate(self):
        """Return whether the axes responds to navigation commands."""
        return self._navigate

    def get_navigate_mode(self):
        """Return the navigation mode."""
        return getattr(self, '_navigate_mode', None)

    def set_navigate_mode(self, b):
        """Set the navigation mode."""
        self._navigate_mode = b

    def format_coord(self, x, y):
        """Return a format string for the (x, y) coordinate."""
        return f'x={x:g}, y={y:g}'

    def get_frame_on(self):
        """Return whether the axes frame is drawn."""
        return getattr(self, '_frame_on', True)

    def set_frame_on(self, b):
        """Set whether the axes frame is drawn."""
        self._frame_on = b

    def get_axisbelow(self):
        """Return whether axis ticks are below artists."""
        return getattr(self, '_axisbelow', True)

    def set_axisbelow(self, b):
        """Set whether axis ticks are below artists."""
        self._axisbelow = b

    # ------------------------------------------------------------------
    # imshow
    # ------------------------------------------------------------------

    def imshow(self, X, cmap=None, norm=None, aspect=None, interpolation=None,
               alpha=None, vmin=None, vmax=None, origin=None, extent=None,
               **kwargs):
        """Display data as an image.

        Parameters
        ----------
        X : array-like
            The image data. Can be 2D (grayscale) or 3D (RGB/RGBA).
        extent : (x0, x1, y0, y1), optional
            The bounding box in data coordinates.
        """
        from matplotlib.image import AxesImage

        # Determine shape from numpy or list
        if hasattr(X, 'shape') and hasattr(X, 'ndim'):
            shape = X.shape
            nrows = shape[0]
            ncols = shape[1] if len(shape) > 1 else 1
            data = X.tolist() if hasattr(X, 'tolist') else X
        elif hasattr(X, 'tolist'):
            data = X.tolist()
            nrows = len(data)
            ncols = len(data[0]) if nrows > 0 and hasattr(data[0], '__len__') else 1
        else:
            data = [list(row) if hasattr(row, '__iter__') else [row] for row in X]
            nrows = len(data)
            ncols = len(data[0]) if nrows > 0 else 0

        if extent is not None:
            x0, x1, y0, y1 = extent
        else:
            x0, x1 = -0.5, ncols - 0.5
            y0, y1 = nrows - 0.5, -0.5

        im = AxesImage(self, data=data, extent=(x0, x1, y0, y1),
                        cmap=cmap, norm=norm, interpolation=interpolation)
        if alpha is not None:
            im.set_alpha(alpha)

        label = kwargs.get('label')
        if label is not None:
            im.set_label(label)

        im.axes = self
        im.figure = self.figure
        self.images.append(im)

        # Set aspect to 'equal' by default for imshow (like upstream)
        if aspect is None:
            self.set_aspect('equal')
        else:
            self.set_aspect(aspect)

        return im

    # ------------------------------------------------------------------
    # pcolormesh (simplified)
    # ------------------------------------------------------------------

    def pcolormesh(self, *args, **kwargs):
        """Render a 2-D array as colored cells using a colormap.

        Signatures:
          pcolormesh(C)           — C is (nrows, ncols), cells on a unit grid
          pcolormesh(X, Y, C)     — X, Y are (nrows+1, ncols+1) or (nrows, ncols) edges/centers
        """
        from matplotlib.image import AxesImage

        if len(args) == 1:
            C = args[0]
            # Normalize to list-of-lists
            if hasattr(C, 'tolist'):
                data = C.tolist()
            else:
                data = [list(row) for row in C]
            nrows = len(data)
            ncols = len(data[0]) if nrows > 0 else 0
            x0, x1, y0, y1 = 0, ncols, 0, nrows
        elif len(args) == 3:
            X, Y, C = args
            if hasattr(C, 'tolist'):
                data = C.tolist()
            else:
                data = [list(row) for row in C]
            nrows = len(data)
            ncols = len(data[0]) if nrows > 0 else 0

            def _to_flat(M):
                if hasattr(M, 'flat'):
                    return list(M.flat)
                result = []
                for row in M:
                    if hasattr(row, '__iter__') and not isinstance(row, (str, float, int)):
                        result.extend(row)
                    else:
                        result.append(row)
                return result

            x_flat = _to_flat(X)
            y_flat = _to_flat(Y)
            x0, x1 = min(x_flat), max(x_flat)
            y0, y1 = min(y_flat), max(y_flat)
        else:
            raise TypeError(f"pcolormesh takes 1 or 3 positional args, got {len(args)}")

        cmap_name = kwargs.get('cmap', 'viridis')
        vmin = kwargs.get('vmin')
        vmax = kwargs.get('vmax')
        alpha = kwargs.get('alpha', 1.0)
        label = kwargs.get('label')

        # Compute vmin/vmax from data
        all_vals = [v for row in data for v in row if v is not None]
        if not all_vals:
            all_vals = [0.0, 1.0]
        if vmin is None:
            vmin = min(all_vals)
        if vmax is None:
            vmax = max(all_vals)

        # Use AxesImage to leverage existing colormap + rendering infrastructure
        im = AxesImage(self, cmap=cmap_name, origin='upper')
        im._data = data
        im._extent = (x0, x1, y0, y1)
        im.set_clim(vmin, vmax)
        if alpha is not None:
            im.set_alpha(alpha)
        if label:
            im.set_label(label)
        im.axes = self
        im.figure = self.figure
        self.images.append(im)
        self._update_axislim(x0, x1, y0, y1)
        return im

    def pcolor(self, *args, **kwargs):
        """Plot a pcolor (alias for pcolormesh with default shading)."""
        return self.pcolormesh(*args, **kwargs)

    def _update_axislim(self, x0, x1, y0, y1):
        """Expand axis limits to include the given bounding box."""
        if self._xlim is None:
            self._xlim = (x0, x1)
        else:
            self._xlim = (min(self._xlim[0], x0), max(self._xlim[1], x1))
        if self._ylim is None:
            self._ylim = (y0, y1)
        else:
            self._ylim = (min(self._ylim[0], y0), max(self._ylim[1], y1))

    # ------------------------------------------------------------------
    # table
    # ------------------------------------------------------------------

    def table(self, **kwargs):
        """Add a table to the axes.

        Returns a Table object.
        """
        from matplotlib.table import table as _table_func
        tbl = _table_func(self, **kwargs)
        return tbl

    # ------------------------------------------------------------------
    # contour / contourf (stub)
    # ------------------------------------------------------------------

    def contour(self, *args, **kwargs):
        """Stub contour that stores data but doesn't compute contour lines."""
        return _ContourStub(self, args, kwargs)

    def contourf(self, *args, **kwargs):
        """Stub contourf that stores data but doesn't compute contour fills."""
        return _ContourStub(self, args, kwargs)

    def clabel(self, cs, *args, **kwargs):
        """Add labels to contour lines. Stub that does nothing."""
        return []

    def plot_date(self, x, y, fmt='o', **kwargs):
        """Plot with dates on x axis (same as plot for stub purposes)."""
        return self.plot(x, y, **kwargs)

    # ------------------------------------------------------------------
    # __repr__
    # ------------------------------------------------------------------

    def __repr__(self):
        """Return a string representation of the Axes."""
        parts = []
        label = getattr(self, '_label_str', '')
        if label:
            parts.append(f"label='{label}'")
        if self._title:
            parts.append(f"title={{'center': '{self._title}'}}")
        if self._xlabel:
            parts.append(f"xlabel='{self._xlabel}'")
        if self._ylabel:
            parts.append(f"ylabel='{self._ylabel}'")
        inner = ', '.join(parts)
        if inner:
            return f"<Axes: {inner}>"
        return "<Axes: >"

    def set_label(self, s):
        """Set the axes label (for repr, not axis label)."""
        self._label_str = str(s) if s is not None else ''

    def get_label(self):
        """Get the axes label."""
        return getattr(self, '_label_str', '')

    # ------------------------------------------------------------------
    # get_children
    # ------------------------------------------------------------------

    def get_children(self):
        """Return a list of all artists contained in the Axes."""
        children = []
        children.extend(self.lines)
        children.extend(self.patches)
        children.extend(self.texts)
        children.extend(self.collections)
        children.extend(self.images)
        return children

    def findobj(self, match=None, include_self=True):
        """Find artist objects matching a criterion.

        Parameters
        ----------
        match : None, class, or callable
            If None, match all artists.
            If a class, match isinstance.
            If callable, match where callable returns True.
        include_self : bool
            Whether to include self.
        """
        result = []
        if include_self:
            if match is None:
                result.append(self)
            elif isinstance(match, type) and isinstance(self, match):
                result.append(self)
            elif callable(match) and not isinstance(match, type) and match(self):
                result.append(self)
        for child in self.get_children():
            if hasattr(child, 'findobj'):
                result.extend(child.findobj(match, include_self=True))
            else:
                if match is None:
                    result.append(child)
                elif isinstance(match, type) and isinstance(child, match):
                    result.append(child)
                elif callable(match) and not isinstance(match, type) and match(child):
                    result.append(child)
        return result

    # ------------------------------------------------------------------
    # Polar axes methods (stubs — ignored for non-polar axes)
    # ------------------------------------------------------------------

    def set_rlim(self, rmin=None, rmax=None, **kwargs):
        """Set the radial limits (polar axes stub)."""
        if rmin is not None and rmax is not None:
            self.set_ylim(rmin, rmax)

    def get_rlim(self):
        """Get the radial limits."""
        return self.get_ylim()

    def set_rticks(self, ticks, **kwargs):
        """Set the radial tick locations (polar axes stub)."""
        self.set_yticks(ticks)

    def set_rmax(self, rmax):
        """Set the maximum radial value."""
        self.set_ylim(top=rmax)

    def set_rmin(self, rmin):
        """Set the minimum radial value."""
        self.set_ylim(bottom=rmin)

    def get_rmax(self):
        """Get the maximum radial value."""
        lo, hi = self.get_ylim()
        return hi

    def get_rmin(self):
        """Get the minimum radial value."""
        lo, hi = self.get_ylim()
        return lo

    def set_rgrids(self, radii, labels=None, angle=None, fmt=None, **kwargs):
        """Set the radial grid lines (polar axes stub)."""
        self.set_yticks(list(radii))

    def set_thetagrids(self, angles, labels=None, fmt=None, **kwargs):
        """Set the theta grid lines (polar axes stub)."""
        pass

    def set_thetalim(self, thetamin=None, thetamax=None, **kwargs):
        """Set the theta limits (polar axes stub)."""
        pass

    def get_thetalim(self):
        """Get the theta limits."""
        return (0, 2 * 3.14159265358979)

    def set_theta_zero_location(self, loc, offset=0.0):
        """Set the direction of theta=0 (polar axes stub)."""
        self._theta_zero_location = loc

    def set_theta_direction(self, direction):
        """Set the direction of increasing theta (polar axes stub)."""
        self._theta_direction = direction

    def set_theta_offset(self, offset):
        """Set the offset for theta (polar axes stub)."""
        self._theta_offset = offset

    def get_theta_offset(self):
        """Get the theta offset."""
        return getattr(self, '_theta_offset', 0.0)

    def set_rlabel_position(self, value):
        """Update the theta position of the radius labels (polar axes stub)."""
        self._rlabel_position = value

    def get_rlabel_position(self):
        """Get the theta position of the radius labels."""
        return getattr(self, '_rlabel_position', 22.5)

    def set_rscale(self, rscale):
        """Set the radial scale (polar axes stub)."""
        pass

    def set_rorigin(self, rorigin):
        """Set the r-origin (polar axes stub)."""
        self._rorigin = rorigin

    def get_rorigin(self):
        """Get the r-origin."""
        return getattr(self, '_rorigin', 0)


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------

def _percentile(data, pct):
    """Simple percentile calculation (linear interpolation)."""
    sorted_d = sorted(data)
    n = len(sorted_d)
    if n == 0:
        return 0
    if n == 1:
        return sorted_d[0]
    k = (n - 1) * pct / 100.0
    f = int(k)
    c = f + 1
    if c >= n:
        return sorted_d[-1]
    return sorted_d[f] + (k - f) * (sorted_d[c] - sorted_d[f])


def _median(data):
    """Simple median calculation."""
    return _percentile(data, 50)


def _gaussian_kde(data, n_points=100):
    """Simple Gaussian kernel density estimate using Silverman's rule."""
    n = len(data)
    if n == 0:
        return [], []

    mean = sum(data) / n
    var = sum((v - mean) ** 2 for v in data) / n
    std = math.sqrt(var) if var > 0 else 1.0

    bw = 1.06 * std * (n ** -0.2) if std > 0 else 1.0

    lo = min(data) - 3 * bw
    hi = max(data) + 3 * bw
    step = (hi - lo) / (n_points - 1) if n_points > 1 else 1.0
    positions = [lo + i * step for i in range(n_points)]

    densities = []
    coeff = 1.0 / (n * bw * math.sqrt(2 * math.pi))
    for p in positions:
        total = 0.0
        for d in data:
            z = (p - d) / bw
            total += math.exp(-0.5 * z * z)
        densities.append(total * coeff)

    return positions, densities


def _parse_plot_args(args):
    """Parse positional args for plot(): (y,), (x, y), (x, y, fmt)."""
    fmt = ''
    if len(args) == 1:
        y = list(args[0])
        x = list(range(len(y)))
    elif len(args) >= 2:
        first, second = args[0], args[1]
        if isinstance(second, str):
            # plot(y, fmt)
            y = list(first)
            x = list(range(len(y)))
            fmt = second
        else:
            x = list(first)
            y = list(second)
            if len(x) != len(y):
                raise ValueError(
                    f"x and y must have same first dimension, "
                    f"but have shapes ({len(x)},) and ({len(y)},)")
            if len(args) >= 3 and isinstance(args[2], str):
                fmt = args[2]
    else:
        x, y = [], []
    return x, y, fmt


def _is_data_like(arg):
    """Return True if arg looks like array data (not a format string)."""
    if isinstance(arg, str):
        return False
    if hasattr(arg, '__iter__'):
        return True
    return isinstance(arg, (int, float))


def _parse_plot_args_multi(args):
    """Parse multi-group plot() args: x1,y1,[fmt1,] x2,y2,[fmt2,] ...

    Returns list of (x, y, fmt) tuples.
    """
    if len(args) == 0:
        return [([], [], '')]

    # Quick check: if only 1-3 args and they match simple forms, use old parser
    if len(args) <= 3:
        x, y, fmt = _parse_plot_args(args)
        return [(x, y, fmt)]

    # Multi-group parsing
    groups = []
    i = 0
    remaining = list(args)

    while i < len(remaining):
        # Try to consume one group: x, y, [fmt]
        if i >= len(remaining):
            break

        arg0 = remaining[i]

        # Single array left: plot(y)
        if i == len(remaining) - 1 and _is_data_like(arg0):
            y = list(arg0)
            x = list(range(len(y)))
            groups.append((x, y, ''))
            break

        # Two items: could be (y, fmt), (x, y), or start of longer group
        if i + 1 < len(remaining):
            arg1 = remaining[i + 1]

            if isinstance(arg1, str):
                # (y, fmt)
                y = list(arg0)
                x = list(range(len(y)))
                groups.append((x, y, arg1))
                i += 2
                continue
            elif _is_data_like(arg1):
                # (x, y, ...) — check if next is fmt
                x = list(arg0)
                y = list(arg1)
                if len(x) != len(y):
                    raise ValueError(
                        f"x and y must have same first dimension, "
                        f"but have shapes ({len(x)},) and ({len(y)},)")
                if i + 2 < len(remaining) and isinstance(remaining[i + 2], str):
                    fmt = remaining[i + 2]
                    groups.append((x, y, fmt))
                    i += 3
                else:
                    groups.append((x, y, ''))
                    i += 2
                continue

        # Single data item
        if _is_data_like(arg0):
            y = list(arg0)
            x = list(range(len(y)))
            groups.append((x, y, ''))
            i += 1
        else:
            i += 1

    if not groups:
        return [([], [], '')]
    return groups


def _auto_bins(data):
    """Compute automatic bin count using Sturges' rule."""
    n = len(data)
    if n == 0:
        return 10
    import math as _math
    return max(1, int(_math.ceil(_math.log2(n) + 1)))


def _validate_1d(data, name):
    """Raise ValueError if data has ndim > 1 (is a 2D array)."""
    if hasattr(data, 'ndim'):
        if data.ndim > 1:
            raise ValueError(
                f"'{name}' must be 1D, but has ndim={data.ndim}")
    elif hasattr(data, '__iter__') and not isinstance(data, str):
        # Check if it looks like a list of lists
        data_list = list(data)
        if data_list and hasattr(data_list[0], '__iter__') and not isinstance(data_list[0], str):
            raise ValueError(
                f"'{name}' must be 1D, but appears to be 2D")


class _SimpleBbox:
    """Minimal Bbox-like for dataLim/viewLim."""

    def __init__(self, x0, y0, x1, y1):
        self.x0 = x0
        self.y0 = y0
        self.x1 = x1
        self.y1 = y1

    @property
    def width(self):
        return self.x1 - self.x0

    @property
    def height(self):
        return self.y1 - self.y0

    @property
    def bounds(self):
        return (self.x0, self.y0, self.width, self.height)

    def __repr__(self):
        return (f"Bbox([[{self.x0}, {self.y0}], "
                f"[{self.x1}, {self.y1}]])")


class _BboxLike:
    """Lightweight Bbox stand-in returned by Axes.get_position()."""

    def __init__(self, x0, y0, width, height):
        self.x0 = x0
        self.y0 = y0
        self.x1 = x0 + width
        self.y1 = y0 + height
        self.width = width
        self.height = height
        self.bounds = (x0, y0, width, height)
        self.p0 = (x0, y0)
        self.p1 = (x0 + width, y0 + height)
        self.extents = (x0, y0, x0 + width, y0 + height)

    def __iter__(self):
        return iter(self.bounds)

    def __repr__(self):
        return (f"Bbox([[{self.x0}, {self.y0}], "
                f"[{self.x1}, {self.y1}]])")


class _ContourStub:
    """Minimal stub for contour/contourf return values."""

    def __init__(self, ax, args, kwargs):
        self.ax = ax
        self.levels = kwargs.get('levels', [])
        self.collections = []


class _Quiver:
    """Render a 2-D field of arrows (used by Axes.quiver)."""

    zorder = 2

    def __init__(self, ax, xs, ys, us, vs, color=None, scale=None):
        self._xs = xs
        self._ys = ys
        self._us = us
        self._vs = vs
        self._color = color
        self._scale = scale
        self.axes = ax
        self.figure = getattr(ax, 'figure', None)
        self._visible = True

    def get_visible(self):
        return self._visible

    def set_visible(self, v):
        self._visible = v

    def get_zorder(self):
        return self.zorder

    def get_alpha(self):
        return None

    def get_label(self):
        return ''

    def get_offsets(self):
        """Return (x, y) pairs for limit computation."""
        return list(zip(self._xs, self._ys))

    def draw(self, renderer, layout):
        if not self._visible:
            return
        if not self._xs:
            return

        # Auto-scale: largest arrow = 10% of data range
        max_mag = max((u * u + v * v) ** 0.5 for u, v in zip(self._us, self._vs))
        if max_mag == 0:
            max_mag = 1.0
        if self._scale is not None:
            scale = self._scale
        else:
            dx_data = (layout.xmax - layout.xmin) * 0.1 or 1.0
            scale = max_mag / dx_data

        color = '#1f77b4'
        if self._color is not None:
            try:
                from matplotlib.colors import to_hex
                color = to_hex(self._color)
            except Exception:
                color = str(self._color)

        for x, y, u, v in zip(self._xs, self._ys, self._us, self._vs):
            x2 = x + u / scale
            y2 = y + v / scale
            px1 = layout.sx(x)
            py1 = layout.sy(y)
            px2 = layout.sx(x2)
            py2 = layout.sy(y2)
            renderer.draw_arrow(px1, py1, px2, py2, '->', color, 1.0)
