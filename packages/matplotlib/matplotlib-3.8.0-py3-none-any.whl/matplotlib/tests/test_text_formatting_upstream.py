"""Tests for text formatting, LaTeX-like strings, and annotations."""

import pytest
import numpy as np
import matplotlib.pyplot as plt


class TestTextBasic:
    def test_text_basic(self):
        """ax.text() does not raise."""
        fig, ax = plt.subplots()
        ax.text(0.5, 0.5, 'hello')
        plt.close('all')

    def test_text_with_fontsize(self):
        """ax.text() with fontsize does not raise."""
        fig, ax = plt.subplots()
        ax.text(0.5, 0.5, 'large text', fontsize=16)
        plt.close('all')

    def test_text_with_color(self):
        """ax.text() with color does not raise."""
        fig, ax = plt.subplots()
        ax.text(0.5, 0.5, 'colored', color='red')
        plt.close('all')

    def test_text_with_ha_va(self):
        """ax.text() with ha/va does not raise."""
        fig, ax = plt.subplots()
        ax.text(0.5, 0.5, 'centered', ha='center', va='center')
        plt.close('all')

    def test_text_rotation(self):
        """ax.text() with rotation does not raise."""
        fig, ax = plt.subplots()
        ax.text(0.5, 0.5, 'rotated', rotation=45)
        plt.close('all')

    def test_text_transform(self):
        """ax.text() with transform does not raise."""
        fig, ax = plt.subplots()
        ax.text(0.5, 0.5, 'axes coords', transform=ax.transAxes)
        plt.close('all')

    def test_text_wrap(self):
        """ax.text() with wrap does not raise."""
        fig, ax = plt.subplots()
        ax.text(0.5, 0.5, 'long text that wraps', wrap=True)
        plt.close('all')

    def test_text_bbox(self):
        """ax.text() with bbox does not raise."""
        fig, ax = plt.subplots()
        ax.text(0.5, 0.5, 'boxed', bbox=dict(boxstyle='round', facecolor='wheat'))
        plt.close('all')

    def test_text_multline(self):
        """ax.text() with multi-line string does not raise."""
        fig, ax = plt.subplots()
        ax.text(0.5, 0.5, 'line1\nline2\nline3', ha='center')
        plt.close('all')


class TestMathText:
    def test_mathtext_simple(self):
        """ax.text() with simple math string does not raise."""
        fig, ax = plt.subplots()
        ax.text(0.5, 0.5, r'$y = mx + b$')
        plt.close('all')

    def test_mathtext_fraction(self):
        """ax.text() with fraction does not raise."""
        fig, ax = plt.subplots()
        ax.text(0.5, 0.5, r'$\frac{a}{b}$')
        plt.close('all')

    def test_mathtext_greek(self):
        """ax.text() with Greek letters does not raise."""
        fig, ax = plt.subplots()
        ax.text(0.5, 0.5, r'$\alpha + \beta = \gamma$')
        plt.close('all')

    def test_mathtext_superscript(self):
        """ax.text() with superscript does not raise."""
        fig, ax = plt.subplots()
        ax.text(0.5, 0.5, r'$x^2 + y^2 = r^2$')
        plt.close('all')

    def test_mathtext_subscript(self):
        """ax.text() with subscript does not raise."""
        fig, ax = plt.subplots()
        ax.text(0.5, 0.5, r'$x_0, x_1, x_n$')
        plt.close('all')

    def test_mathtext_in_labels(self):
        """Labels with math strings do not raise."""
        fig, ax = plt.subplots()
        ax.set_xlabel(r'$\theta$ (radians)')
        ax.set_ylabel(r'$\sin(\theta)$')
        ax.set_title(r'$y = \sin(x)$')
        plt.close('all')

    def test_mathtext_in_legend(self):
        """Legend with math labels does not raise."""
        fig, ax = plt.subplots()
        ax.plot([1, 2], [1, 2], label=r'$y = x$')
        ax.plot([1, 2], [2, 4], label=r'$y = 2x$')
        ax.legend()
        plt.close('all')


class TestAnnotate:
    def test_annotate_basic(self):
        """ax.annotate() does not raise."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 4, 2])
        ax.annotate('max', xy=(2, 4))
        plt.close('all')

    def test_annotate_with_arrow(self):
        """ax.annotate() with arrowprops does not raise."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 4, 2])
        ax.annotate('max', xy=(2, 4), xytext=(2.5, 3.5),
                    arrowprops=dict(arrowstyle='->'))
        plt.close('all')

    def test_annotate_xycoords(self):
        """ax.annotate() with xycoords does not raise."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3])
        ax.annotate('note', xy=(0.5, 0.5), xycoords='axes fraction')
        plt.close('all')

    def test_annotate_fontsize(self):
        """ax.annotate() with fontsize does not raise."""
        fig, ax = plt.subplots()
        ax.annotate('big note', xy=(1, 1), fontsize=14, color='blue')
        plt.close('all')

    def test_annotate_bbox(self):
        """ax.annotate() with bbox does not raise."""
        fig, ax = plt.subplots()
        ax.annotate('boxed note', xy=(1, 1),
                    bbox=dict(boxstyle='round', facecolor='lightblue'))
        plt.close('all')


class TestTitleLabel:
    def test_title_multline(self):
        """Multi-line title does not raise."""
        fig, ax = plt.subplots()
        ax.set_title('Line 1\nLine 2')
        plt.close('all')

    def test_xlabel_rotation(self):
        """Tick labels with rotation do not raise."""
        fig, ax = plt.subplots()
        ax.set_xticks([1, 2, 3])
        ax.set_xticklabels(['alpha', 'beta', 'gamma'], rotation=45)
        plt.close('all')

    def test_ylabel_pad(self):
        """set_ylabel with labelpad does not raise."""
        fig, ax = plt.subplots()
        ax.set_ylabel('Y axis', labelpad=15)
        plt.close('all')

    def test_xlabel_fontdict(self):
        """set_xlabel with fontdict does not raise."""
        fig, ax = plt.subplots()
        ax.set_xlabel('X axis', fontdict={'size': 14, 'color': 'blue'})
        plt.close('all')
