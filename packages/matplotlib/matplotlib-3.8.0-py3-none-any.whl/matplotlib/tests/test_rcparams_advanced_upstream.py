"""Tests for rcParams, styles, and plot configuration."""

import pytest
import numpy as np
import matplotlib.pyplot as plt
import matplotlib


class TestRcParams:
    def test_rc_linewidth(self):
        """Setting rcParams line.linewidth does not raise."""
        original = matplotlib.rcParams['lines.linewidth']
        matplotlib.rcParams['lines.linewidth'] = 2.0
        matplotlib.rcParams['lines.linewidth'] = original
        plt.close('all')

    def test_rc_context_manager(self):
        """rc_context temporarily changes rcParams."""
        from matplotlib import rc_context
        with rc_context({'lines.linewidth': 3.0}):
            assert matplotlib.rcParams['lines.linewidth'] == 3.0

    def test_rc_context_restores(self):
        """rc_context restores original rcParams on exit."""
        from matplotlib import rc_context
        original = matplotlib.rcParams.get('lines.linewidth', 1.5)
        with rc_context({'lines.linewidth': 5.0}):
            pass
        assert matplotlib.rcParams['lines.linewidth'] == original

    def test_rcdefaults(self):
        """rcdefaults restores default params."""
        matplotlib.rcParams['lines.linewidth'] = 99.0
        matplotlib.rcdefaults()
        # Should be back to default
        plt.close('all')

    def test_plt_rc(self):
        """plt.rc() sets parameters."""
        plt.rc('lines', linewidth=2.0)
        # Reset
        matplotlib.rcdefaults()

    def test_rcparams_figsize(self):
        """Setting figure.figsize via rcParams does not raise."""
        matplotlib.rcParams['figure.figsize'] = (8, 6)
        matplotlib.rcdefaults()

    def test_rcparams_dpi(self):
        """Setting figure.dpi via rcParams does not raise."""
        matplotlib.rcParams['figure.dpi'] = 150
        matplotlib.rcdefaults()

    def test_rcparams_font_size(self):
        """Setting font.size via rcParams does not raise."""
        matplotlib.rcParams['font.size'] = 14
        matplotlib.rcdefaults()

    def test_rcparams_axes_color(self):
        """Setting axes.edgecolor via rcParams does not raise."""
        matplotlib.rcParams['axes.edgecolor'] = 'gray'
        matplotlib.rcdefaults()

    def test_rcparams_grid(self):
        """Setting axes.grid via rcParams does not raise."""
        matplotlib.rcParams['axes.grid'] = True
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3])
        matplotlib.rcdefaults()
        plt.close('all')

    def test_rcparams_dict_access(self):
        """rcParams supports dict-like access."""
        val = matplotlib.rcParams['lines.linewidth']
        assert val is not None

    def test_rcparams_items(self):
        """rcParams.items() is iterable."""
        items = list(matplotlib.rcParams.items())
        assert len(items) > 0

    def test_rcparams_keys(self):
        """rcParams.keys() returns keys."""
        keys = list(matplotlib.rcParams.keys())
        assert 'lines.linewidth' in keys


class TestStyleUsage:
    def test_plot_respects_rcparams(self):
        """Plots use rcParams line width."""
        matplotlib.rcParams['lines.linewidth'] = 3.0
        fig, ax = plt.subplots()
        lines = ax.plot([1, 2, 3])
        # Line should have been created (we don't check the actual width)
        assert len(lines) == 1
        matplotlib.rcdefaults()
        plt.close('all')

    def test_figure_rcparams_figsize(self):
        """plt.figure() uses rcParams figsize."""
        matplotlib.rcParams['figure.figsize'] = (10, 5)
        fig = plt.figure()
        # Size should be set from rcParams
        matplotlib.rcdefaults()
        plt.close('all')

    def test_rc_context_in_plot(self):
        """Plotting inside rc_context uses modified params."""
        from matplotlib import rc_context
        with rc_context({'lines.linewidth': 4.0, 'axes.grid': True}):
            fig, ax = plt.subplots()
            ax.plot([1, 2, 3])
            plt.close('all')
