"""Tests for statistical plot patterns used by LLMs."""

import pytest
import numpy as np
import matplotlib.pyplot as plt


class TestHistogramAdvanced:
    def test_hist_bins_int(self):
        fig, ax = plt.subplots()
        data = [1.0, 2.0, 2.5, 3.0, 3.5, 4.0, 4.5, 5.0]
        n, bins, patches = ax.hist(data, bins=5)
        assert len(n) == 5
        plt.close('all')

    def test_hist_bins_list(self):
        fig, ax = plt.subplots()
        data = [1.0, 2.0, 3.0, 4.0, 5.0]
        n, bins, patches = ax.hist(data, bins=[0, 2, 4, 6])
        assert len(n) == 3
        plt.close('all')

    def test_hist_density(self):
        fig, ax = plt.subplots()
        data = [1.0, 2.0, 2.5, 3.0, 3.5, 4.0]
        n, bins, patches = ax.hist(data, density=True)
        assert n is not None
        plt.close('all')

    def test_hist_cumulative(self):
        fig, ax = plt.subplots()
        data = [1.0, 2.0, 3.0, 4.0, 5.0]
        n, bins, patches = ax.hist(data, cumulative=True)
        assert n is not None
        plt.close('all')

    def test_hist_histtype_step(self):
        fig, ax = plt.subplots()
        data = [1.0, 2.0, 3.0, 4.0, 5.0]
        ax.hist(data, histtype='step')
        plt.close('all')

    def test_hist_histtype_stepfilled(self):
        fig, ax = plt.subplots()
        data = [1.0, 2.0, 3.0, 4.0, 5.0]
        ax.hist(data, histtype='stepfilled')
        plt.close('all')

    def test_hist_alpha(self):
        fig, ax = plt.subplots()
        data = [1.0, 2.0, 3.0]
        ax.hist(data, alpha=0.7)
        plt.close('all')

    def test_hist_color(self):
        fig, ax = plt.subplots()
        data = [1.0, 2.0, 3.0]
        ax.hist(data, color='green')
        plt.close('all')

    def test_hist_label_legend(self):
        fig, ax = plt.subplots()
        data = [1.0, 2.0, 3.0]
        ax.hist(data, label='distribution')
        ax.legend()
        plt.close('all')

    def test_hist_multiple_datasets(self):
        fig, ax = plt.subplots()
        data1 = [1.0, 2.0, 3.0, 4.0]
        data2 = [2.0, 3.0, 4.0, 5.0]
        ax.hist([data1, data2], bins=4)
        plt.close('all')

    def test_hist_stacked(self):
        fig, ax = plt.subplots()
        data1 = [1.0, 2.0, 3.0]
        data2 = [2.0, 3.0, 4.0]
        ax.hist([data1, data2], stacked=True)
        plt.close('all')

    def test_hist_orientation_horizontal(self):
        fig, ax = plt.subplots()
        data = [1.0, 2.0, 3.0, 4.0]
        ax.hist(data, orientation='horizontal')
        plt.close('all')


class TestKDE:
    def test_hist_with_kde_overlay(self):
        """Histogram with KDE-style line overlay."""
        fig, ax = plt.subplots()
        data = [1.0, 2.0, 2.5, 3.0, 3.5, 4.0, 4.5, 5.0]
        ax.hist(data, bins=5, density=True, alpha=0.7)
        plt.close('all')


class TestStem:
    def test_stem_basic(self):
        fig, ax = plt.subplots()
        x = [1.0, 2.0, 3.0, 4.0, 5.0]
        y = [1.0, 4.0, 2.0, 5.0, 3.0]
        markerline, stemlines, baseline = ax.stem(x, y)
        assert markerline is not None
        plt.close('all')

    def test_stem_y_only(self):
        fig, ax = plt.subplots()
        y = [1.0, 4.0, 2.0, 5.0, 3.0]
        ax.stem(y)
        plt.close('all')

    def test_stem_markerfmt(self):
        fig, ax = plt.subplots()
        y = [1.0, 2.0, 3.0]
        ax.stem(y, markerfmt='ro')
        plt.close('all')

    def test_stem_linefmt(self):
        fig, ax = plt.subplots()
        y = [1.0, 2.0, 3.0]
        ax.stem(y, linefmt='b-')
        plt.close('all')

    def test_plt_stem(self):
        fig, ax = plt.subplots()
        plt.stem([1.0, 2.0, 3.0])
        plt.close('all')


class TestStep:
    def test_step_pre(self):
        fig, ax = plt.subplots()
        x = [0.0, 1.0, 2.0, 3.0]
        y = [0.0, 1.0, 0.0, 1.0]
        ax.step(x, y, where='pre')
        plt.close('all')

    def test_step_post(self):
        fig, ax = plt.subplots()
        x = [0.0, 1.0, 2.0, 3.0]
        y = [0.0, 1.0, 0.0, 1.0]
        ax.step(x, y, where='post')
        plt.close('all')

    def test_step_mid(self):
        fig, ax = plt.subplots()
        x = [0.0, 1.0, 2.0, 3.0]
        y = [0.0, 1.0, 0.0, 1.0]
        ax.step(x, y, where='mid')
        plt.close('all')

    def test_step_label(self):
        fig, ax = plt.subplots()
        ax.step([0.0, 1.0, 2.0], [0.0, 1.0, 0.0], label='step')
        ax.legend()
        plt.close('all')

    def test_plt_step(self):
        fig, ax = plt.subplots()
        plt.step([0.0, 1.0, 2.0], [1.0, 2.0, 1.0])
        plt.close('all')


class TestBarh:
    def test_barh_basic(self):
        fig, ax = plt.subplots()
        ax.barh([0.0, 1.0, 2.0], [3.0, 1.0, 5.0])
        plt.close('all')

    def test_barh_height(self):
        fig, ax = plt.subplots()
        ax.barh([0.0, 1.0, 2.0], [3.0, 1.0, 5.0], height=0.5)
        plt.close('all')

    def test_barh_labels(self):
        fig, ax = plt.subplots()
        categories = ['A', 'B', 'C']
        values = [3.0, 1.0, 5.0]
        ax.barh(categories, values)
        plt.close('all')

    def test_plt_barh(self):
        fig, ax = plt.subplots()
        plt.barh([0.0, 1.0], [2.0, 3.0])
        plt.close('all')
