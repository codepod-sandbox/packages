"""
Upstream tests for data science workflow patterns commonly used by LLMs.
These test end-to-end patterns that combine multiple matplotlib features.
"""

import pytest
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec


class TestExploratoryDataAnalysis:
    """Tests for EDA plot patterns."""

    def teardown_method(self):
        plt.close('all')

    def test_distribution_overview(self):
        """Plot histogram + KDE-like overlay."""
        rng = np.random.default_rng(42)
        data = rng.normal(0, 1, 200)
        fig, ax = plt.subplots()
        ax.hist(data, bins=20, density=True, alpha=0.7, color='steelblue')
        # Simple gaussian overlay
        x = np.linspace(-4, 4, 100)
        ax.plot(x, np.exp(-x**2/2) / np.sqrt(2*np.pi), 'r-', lw=2)
        ax.set_title('Distribution with Normal Fit')
        ax.set_xlabel('Value')
        ax.set_ylabel('Density')

    def test_scatter_with_regression(self):
        """Scatter plot with regression line."""
        rng = np.random.default_rng(42)
        x = rng.uniform(0, 10, 50)
        y = 2 * x + 1 + rng.normal(0, 2, 50)
        fig, ax = plt.subplots()
        ax.scatter(x, y, alpha=0.6, label='Data')
        m, b = np.polyfit(x, y, 1)
        x_line = np.linspace(x.min(), x.max(), 100)
        ax.plot(x_line, m * x_line + b, 'r-', label=f'y={m:.1f}x+{b:.1f}')
        ax.legend()
        ax.set_title('Scatter with Linear Regression')

    def test_time_series_plot(self):
        """Time series with multiple signals."""
        t = np.linspace(0, 4 * np.pi, 200)
        signal1 = np.sin(t) + 0.1 * np.random.randn(200)
        signal2 = np.cos(t) * 0.5 + 0.5
        fig, ax = plt.subplots(figsize=(10, 4))
        ax.plot(t, signal1, label='Signal 1', lw=1.5)
        ax.plot(t, signal2, label='Signal 2', lw=1.5, linestyle='--')
        ax.fill_between(t, signal1, 0, alpha=0.1)
        ax.legend()
        ax.set_xlabel('Time (s)')
        ax.set_ylabel('Amplitude')
        ax.grid(True, alpha=0.3)

    def test_grouped_bar_chart(self):
        """Grouped bar chart for comparing categories."""
        categories = ['A', 'B', 'C', 'D']
        group1 = np.array([3.5, 4.2, 2.8, 3.9])
        group2 = np.array([4.0, 3.8, 3.2, 4.5])
        x = np.arange(len(categories))
        width = 0.35
        fig, ax = plt.subplots()
        ax.bar(x - width/2, group1, width, label='Method 1', color='steelblue')
        ax.bar(x + width/2, group2, width, label='Method 2', color='tomato')
        ax.set_xticks(list(x))
        ax.set_xticklabels(categories)
        ax.legend()
        ax.set_ylabel('Score')

    def test_residual_plot(self):
        """Residual plot for regression diagnostics."""
        rng = np.random.default_rng(42)
        x = rng.uniform(0, 10, 50)
        y_true = 2 * x + 1
        y_pred = y_true + rng.normal(0, 1.5, 50)
        residuals = y_true - y_pred
        fig, ax = plt.subplots()
        ax.scatter(x, residuals, alpha=0.6)
        ax.axhline(0, color='red', linestyle='--')
        ax.set_xlabel('Fitted values')
        ax.set_ylabel('Residuals')
        ax.set_title('Residual Plot')

    def test_multi_panel_eda(self):
        """Multi-panel EDA dashboard."""
        rng = np.random.default_rng(42)
        data1 = rng.normal(0, 1, 100)
        data2 = rng.normal(2, 1.5, 100)
        x = rng.uniform(0, 10, 50)
        y = 2 * x + rng.normal(0, 2, 50)

        fig = plt.figure(figsize=(12, 8))
        gs = gridspec.GridSpec(2, 2, figure=fig, hspace=0.4, wspace=0.3)

        # Histogram
        ax1 = fig.add_subplot(gs[0, 0])
        ax1.hist(data1, bins=15, alpha=0.7, label='Group 1')
        ax1.hist(data2, bins=15, alpha=0.7, label='Group 2')
        ax1.legend()
        ax1.set_title('Distributions')

        # Boxplot
        ax2 = fig.add_subplot(gs[0, 1])
        ax2.boxplot([data1, data2], labels=['Group 1', 'Group 2'])
        ax2.set_title('Box Plots')

        # Scatter
        ax3 = fig.add_subplot(gs[1, 0])
        ax3.scatter(x, y, alpha=0.6)
        ax3.set_title('Scatter')

        # Line
        ax4 = fig.add_subplot(gs[1, 1])
        ax4.plot(data1[:50], lw=1.5)
        ax4.set_title('Time Series')

        fig.suptitle('EDA Dashboard', fontsize=14)

    def test_cumulative_distribution(self):
        """Empirical CDF plot."""
        rng = np.random.default_rng(42)
        data = rng.normal(0, 1, 200)
        sorted_data = np.sort(data)
        cdf = np.arange(1, len(data) + 1) / len(data)
        fig, ax = plt.subplots()
        ax.step(sorted_data, cdf, where='post')
        ax.set_xlabel('Value')
        ax.set_ylabel('CDF')
        ax.set_title('Empirical CDF')

    def test_two_y_axes_comparison(self):
        """Compare two metrics with different y-scales."""
        t = np.linspace(0, 10, 100)
        revenue = 1000 * np.exp(0.2 * t)
        growth_rate = 20 + 2 * np.sin(t)
        fig, ax1 = plt.subplots()
        color1 = 'steelblue'
        ax1.plot(t, revenue, color=color1, label='Revenue')
        ax1.set_ylabel('Revenue ($)', color=color1)
        ax1.tick_params(axis='y', labelcolor=color1)
        ax2 = ax1.twinx()
        color2 = 'tomato'
        ax2.plot(t, growth_rate, color=color2, linestyle='--', label='Growth %')
        ax2.set_ylabel('Growth Rate (%)', color=color2)
        ax2.tick_params(axis='y', labelcolor=color2)
        ax1.set_xlabel('Quarter')

    def test_annotated_time_series(self):
        """Time series with event annotations."""
        t = np.arange(0, 24)
        values = np.random.rand(24) * 100
        events = [(5, 'Launch'), (12, 'Update'), (18, 'Promo')]
        fig, ax = plt.subplots(figsize=(10, 4))
        ax.plot(t, values, 'b-', lw=2)
        for event_t, label in events:
            ax.axvline(x=event_t, color='red', linestyle='--', alpha=0.7)
            ax.text(event_t, ax.get_ylim()[1] * 0.95, label,
                    ha='center', fontsize=9, color='red')
        ax.set_title('Sales Timeline')
        ax.set_xlabel('Hour')


class TestMLVisualization:
    """Tests for ML-related visualization patterns."""

    def teardown_method(self):
        plt.close('all')

    def test_loss_curve(self):
        """Training/validation loss curve."""
        epochs = np.arange(1, 51)
        train_loss = 2.0 * np.exp(-0.1 * epochs) + 0.1
        val_loss = 2.2 * np.exp(-0.08 * epochs) + 0.15
        fig, ax = plt.subplots()
        ax.plot(epochs, train_loss, label='Train Loss', lw=2)
        ax.plot(epochs, val_loss, label='Val Loss', lw=2, linestyle='--')
        ax.legend()
        ax.set_xlabel('Epoch')
        ax.set_ylabel('Loss')
        ax.set_title('Training Curve')

    def test_roc_curve(self):
        """ROC curve visualization."""
        fpr = np.linspace(0, 1, 50)
        tpr = np.sqrt(fpr) * 0.9 + 0.1 * fpr
        tpr = np.clip(tpr, 0, 1)
        fig, ax = plt.subplots()
        ax.plot(fpr, tpr, lw=2, label='ROC (AUC=0.85)')
        ax.plot([0, 1], [0, 1], 'k--', label='Random')
        ax.set_xlabel('False Positive Rate')
        ax.set_ylabel('True Positive Rate')
        ax.legend()
        ax.set_title('ROC Curve')

    def test_feature_importance(self):
        """Horizontal bar chart for feature importance."""
        features = ['Feature A', 'Feature B', 'Feature C', 'Feature D', 'Feature E']
        importance = np.array([0.35, 0.25, 0.20, 0.15, 0.05])
        y_pos = np.arange(len(features))
        fig, ax = plt.subplots()
        ax.barh(y_pos, importance)
        ax.set_yticks(list(y_pos))
        ax.set_yticklabels(features)
        ax.set_xlabel('Importance')
        ax.set_title('Feature Importance')
        plt.tight_layout()

    def test_confusion_matrix_heatmap(self):
        """Full confusion matrix visualization with annotations."""
        cm = np.array([[85, 5, 10], [3, 90, 7], [8, 4, 88]])
        classes = ['Cat', 'Dog', 'Bird']
        fig, ax = plt.subplots()
        im = ax.imshow(cm, cmap='Blues')
        ax.set_xticks(range(3))
        ax.set_yticks(range(3))
        ax.set_xticklabels(classes, rotation=45)
        ax.set_yticklabels(classes)
        for i in range(3):
            for j in range(3):
                ax.text(j, i, str(cm[i, j]), ha='center', va='center')
        fig.colorbar(im, ax=ax)
        ax.set_title('Confusion Matrix')
        plt.tight_layout()
