"""Tests for twinx/twiny axes and inset axes patterns."""

import pytest
import io
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec


class TestTwinxAxes:
    def test_twinx_basic(self):
        """Basic twinx pattern."""
        fig, ax1 = plt.subplots()
        ax2 = ax1.twinx()
        assert ax2 is not None
        plt.close('all')

    def test_twinx_plot_both(self):
        """Plot on both twinx axes."""
        fig, ax1 = plt.subplots()
        ax1.plot([1, 2, 3], [1, 4, 9], 'b-')
        ax2 = ax1.twinx()
        ax2.plot([1, 2, 3], [10, 20, 30], 'r-')
        plt.close('all')

    def test_twinx_labels(self):
        """Twinx with axis labels."""
        fig, ax1 = plt.subplots()
        ax1.set_xlabel('X')
        ax1.set_ylabel('Left Y', color='blue')
        ax2 = ax1.twinx()
        ax2.set_ylabel('Right Y', color='red')
        plt.close('all')

    def test_twinx_with_legend(self):
        """Twinx with combined legend."""
        fig, ax1 = plt.subplots()
        line1, = ax1.plot([1, 2, 3], [1, 2, 3], 'b-', label='Data A')
        ax2 = ax1.twinx()
        line2, = ax2.plot([1, 2, 3], [10, 8, 6], 'r-', label='Data B')
        lines = [line1, line2]
        labels = [l.get_label() for l in lines]
        ax1.legend(lines, labels)
        plt.close('all')

    def test_twinx_bar_and_line(self):
        """Twinx with bar chart and line chart."""
        fig, ax1 = plt.subplots()
        months = ['Jan', 'Feb', 'Mar', 'Apr']
        sales = [100, 120, 90, 140]
        growth = [5.0, 20.0, -25.0, 55.6]
        ax1.bar(months, sales, color='steelblue', label='Sales')
        ax2 = ax1.twinx()
        ax2.plot(months, growth, 'ro-', label='Growth %')
        plt.close('all')

    def test_twinx_color_axes(self):
        """Twinx with colored axis lines and ticks."""
        fig, ax1 = plt.subplots()
        ax2 = ax1.twinx()
        ax1.tick_params(axis='y', labelcolor='blue')
        ax2.tick_params(axis='y', labelcolor='red')
        plt.close('all')

    def test_twinx_savefig(self):
        """Twinx with savefig."""
        fig, ax1 = plt.subplots()
        ax1.plot([1, 2, 3], [1, 4, 9], color='blue')
        ax2 = ax1.twinx()
        ax2.plot([1, 2, 3], [100, 50, 25], color='red')
        buf = io.BytesIO()
        fig.savefig(buf, format='png')
        buf.seek(0)
        assert len(buf.read()) > 0
        plt.close('all')


class TestTwinyAxes:
    def test_twiny_basic(self):
        """Basic twiny pattern."""
        fig, ax1 = plt.subplots()
        ax2 = ax1.twiny()
        assert ax2 is not None
        plt.close('all')

    def test_twiny_plot_both(self):
        """Plot on both twiny axes."""
        fig, ax1 = plt.subplots()
        ax1.plot([1, 2, 3], [1, 2, 3], 'b-')
        ax2 = ax1.twiny()
        ax2.plot([10, 20, 30], [1, 2, 3], 'r-')
        plt.close('all')

    def test_twiny_labels(self):
        """Twiny with axis labels."""
        fig, ax1 = plt.subplots()
        ax1.set_xlabel('Bottom X', color='blue')
        ax2 = ax1.twiny()
        ax2.set_xlabel('Top X', color='red')
        plt.close('all')


class TestInsetAxes:
    def test_inset_axes_basic(self):
        """Basic inset_axes."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3, 4], [1, 4, 2, 3])
        inset = ax.inset_axes([0.5, 0.5, 0.4, 0.4])
        assert inset is not None
        plt.close('all')

    def test_inset_axes_plot(self):
        """Plot inside inset axes."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3, 4, 5], [2, 4, 3, 5, 1])
        ax.set_title('Main Plot')
        inset = ax.inset_axes([0.6, 0.6, 0.35, 0.35])
        inset.plot([1, 2, 3], [3, 1, 2])
        inset.set_title('Zoom')
        plt.close('all')

    def test_inset_axes_zoom_region(self):
        """Inset axes showing zoom region."""
        fig, ax = plt.subplots()
        x = [0.0, 0.1, 0.2, 0.3, 0.4, 0.5]
        y = [0.0, 0.5, 1.0, 0.5, 0.0, 0.5]
        ax.plot(x, y)
        inset = ax.inset_axes([0.6, 0.1, 0.35, 0.35])
        inset.plot(x[:3], y[:3])
        inset.set_xlim(0, 0.2)
        plt.close('all')


class TestMultipleAxes:
    def test_four_subplots(self):
        """Four subplots in 2x2 grid."""
        fig, axes = plt.subplots(2, 2)
        for i in range(2):
            for j in range(2):
                axes[i][j].plot([1, 2, 3], [1, 2, 1])
        plt.close('all')

    def test_gridspec_complex(self):
        """Complex GridSpec layout."""
        fig = plt.figure()
        gs = gridspec.GridSpec(2, 3, figure=fig)
        ax1 = fig.add_subplot(gs[0, :])
        ax2 = fig.add_subplot(gs[1, 0])
        ax3 = fig.add_subplot(gs[1, 1])
        ax4 = fig.add_subplot(gs[1, 2])
        for ax in [ax1, ax2, ax3, ax4]:
            ax.plot([1, 2, 3], [1, 2, 1])
        plt.close('all')

    def test_nested_gridspec(self):
        """Nested GridSpec."""
        fig = plt.figure()
        outer = gridspec.GridSpec(1, 2, figure=fig)
        inner_left = gridspec.GridSpecFromSubplotSpec(2, 1, subplot_spec=outer[0])
        ax1 = fig.add_subplot(inner_left[0])
        ax2 = fig.add_subplot(inner_left[1])
        ax3 = fig.add_subplot(outer[1])
        for ax in [ax1, ax2, ax3]:
            ax.plot([1, 2], [1, 2])
        plt.close('all')

    def test_subplot_mosaic_style(self):
        """Manual mosaic-style layout."""
        fig = plt.figure()
        gs = gridspec.GridSpec(3, 3, figure=fig)
        # Top spans full width
        ax_top = fig.add_subplot(gs[0, :])
        # Bottom left 2x2
        ax_bl = fig.add_subplot(gs[1:, :2])
        # Bottom right
        ax_br1 = fig.add_subplot(gs[1, 2])
        ax_br2 = fig.add_subplot(gs[2, 2])
        for ax in [ax_top, ax_bl, ax_br1, ax_br2]:
            ax.plot([1, 2], [1, 2])
        plt.close('all')

    def test_shared_axes(self):
        """Subplots with shared axes."""
        fig, axes = plt.subplots(2, 1, sharex=True)
        axes[0].plot([1, 2, 3, 4], [1, 2, 3, 4])
        axes[1].plot([1, 2, 3, 4], [4, 3, 2, 1])
        plt.close('all')

    def test_tight_layout_complex(self):
        """Complex layout with tight_layout."""
        fig, axes = plt.subplots(2, 3, figsize=(12, 8))
        for i in range(2):
            for j in range(3):
                axes[i][j].plot([1, 2, 3], [j + 1, i + 1, 2])
                axes[i][j].set_title(f'Plot {i},{j}')
        plt.tight_layout()
        plt.close('all')


class TestAxesLayout:
    def test_subplot_adjust(self):
        """subplots_adjust for spacing."""
        fig, axes = plt.subplots(2, 2)
        plt.subplots_adjust(hspace=0.5, wspace=0.3)
        plt.close('all')

    def test_figure_suptitle_subplots(self):
        """Figure suptitle with subplots."""
        fig, axes = plt.subplots(1, 2)
        fig.suptitle('Main Title', fontsize=16)
        axes[0].plot([1, 2, 3], [1, 4, 9])
        axes[1].plot([1, 2, 3], [1, 2, 3])
        plt.close('all')

    def test_constrained_layout(self):
        """Constrained layout."""
        fig, axes = plt.subplots(2, 2, constrained_layout=True)
        for row in axes:
            for ax in row:
                ax.plot([1, 2], [1, 2])
        plt.close('all')
