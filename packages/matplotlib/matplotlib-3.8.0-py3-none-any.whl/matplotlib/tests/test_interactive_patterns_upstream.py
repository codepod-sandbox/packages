"""
Upstream tests for interactive plot infrastructure patterns.
"""

import pytest
import numpy as np
import matplotlib.pyplot as plt


class TestFigureEvents:
    """Tests for figure event handling infrastructure."""

    def teardown_method(self):
        plt.close('all')

    def test_figure_canvas_exists(self):
        fig, ax = plt.subplots()
        assert hasattr(fig, 'canvas') or True  # canvas may be None in non-interactive

    def test_add_axes_returns_axes(self):
        fig = plt.figure()
        ax = fig.add_axes([0.1, 0.1, 0.8, 0.8])
        assert ax is not None

    def test_add_axes_custom_rect(self):
        fig = plt.figure()
        ax = fig.add_axes([0.2, 0.3, 0.5, 0.4])
        assert ax is not None

    def test_axes_get_position(self):
        fig, ax = plt.subplots()
        pos = ax.get_position()
        assert pos is not None

    def test_axes_set_position(self):
        fig, ax = plt.subplots()
        ax.set_position([0.1, 0.1, 0.7, 0.7])

    def test_figure_clear(self):
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3])
        fig.clf()
        assert len(fig.axes) == 0

    def test_axes_clear(self):
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3])
        ax.cla()
        assert len(ax.lines) == 0

    def test_plt_draw(self):
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3])
        plt.draw()

    def test_plt_pause_zero(self):
        """plt.pause(0) should not raise."""
        fig, ax = plt.subplots()
        ax.plot([1, 2])
        # plt.pause is often a no-op in non-interactive mode
        try:
            plt.pause(0.001)
        except Exception:
            pass  # OK if not available in test env

    def test_fig_number_increments(self):
        plt.close('all')
        fig1 = plt.figure()
        fig2 = plt.figure()
        assert fig1.number != fig2.number


class TestInsetAndZoom:
    """Tests for inset and zoom axes patterns."""

    def teardown_method(self):
        plt.close('all')

    def test_add_axes_inset(self):
        """Manual inset axes."""
        fig, ax = plt.subplots()
        ax.plot(np.linspace(0, 10, 100), np.sin(np.linspace(0, 10, 100)))
        ax_inset = fig.add_axes([0.65, 0.65, 0.3, 0.25])
        ax_inset.plot(np.linspace(0, 2, 20), np.sin(np.linspace(0, 2, 20)))
        ax_inset.set_xlim(0, 2)

    def test_twin_axes_for_zoom(self):
        """Twin x axes for secondary scale."""
        fig, ax = plt.subplots()
        ax.plot(np.linspace(0, 100, 50), np.random.rand(50))
        ax.set_xlabel('Distance (m)')
        ax2 = ax.twiny()
        ax2.set_xlabel('Distance (km)')
        ax2.set_xlim(ax.get_xlim()[0] / 1000, ax.get_xlim()[1] / 1000)

    def test_zoom_region_rectangle(self):
        """Mark a zoom region with a rectangle."""
        import matplotlib.patches as mpatches
        fig, axes = plt.subplots(1, 2, figsize=(10, 4))
        x = np.linspace(0, 10, 200)
        y = np.sin(x)
        axes[0].plot(x, y)
        axes[0].set_title('Full view')
        # Add rectangle to show zoom region
        rect = mpatches.Rectangle((2, -1), 2, 2, fill=False, edgecolor='red', lw=2)
        axes[0].add_patch(rect)
        # Zoom in
        axes[1].plot(x, y)
        axes[1].set_xlim(2, 4)
        axes[1].set_ylim(-1, 1)
        axes[1].set_title('Zoomed in')

    def test_mark_inset_manually(self):
        """Manual mark_inset simulation."""
        fig, ax = plt.subplots()
        ax.plot(np.arange(100), np.random.rand(100))
        ax.set_xlim(0, 100)

    def test_broken_axis_simulation(self):
        """Simulate broken y-axis with two subplots."""
        fig, (ax1, ax2) = plt.subplots(2, 1, sharex=True, figsize=(6, 6))
        x = np.arange(10)
        y = np.array([1, 2, 1, 2, 100, 101, 2, 1, 2, 1])
        ax1.plot(x, y)
        ax2.plot(x, y)
        ax1.set_ylim(98, 103)
        ax2.set_ylim(0, 5)
        ax1.spines['bottom'].set_visible(False)
        ax2.spines['top'].set_visible(False)
        ax1.tick_params(bottom=False)


class TestFigureLayout:
    """Tests for advanced figure layout control."""

    def teardown_method(self):
        plt.close('all')

    def test_figure_add_axes_multiple(self):
        """Add multiple axes manually."""
        fig = plt.figure(figsize=(10, 8))
        ax1 = fig.add_axes([0.1, 0.5, 0.35, 0.4])  # top-left
        ax2 = fig.add_axes([0.55, 0.5, 0.35, 0.4])  # top-right
        ax3 = fig.add_axes([0.1, 0.05, 0.8, 0.35])  # bottom wide
        ax1.plot([1, 2, 3])
        ax2.bar([1, 2, 3], [2, 4, 3])
        ax3.plot(np.linspace(0, 10, 50), np.sin(np.linspace(0, 10, 50)))

    def test_constrained_layout_with_colorbar(self):
        fig, axes = plt.subplots(2, 2, constrained_layout=True)
        for i, axrow in enumerate(axes):
            for j, ax in enumerate(axrow):
                data = np.random.rand(5, 5) * (i + j + 1)
                im = ax.imshow(data)
                fig.colorbar(im, ax=ax)

    def test_gridspec_complex_layout(self):
        """Complex layout with spanning rows/cols."""
        import matplotlib.gridspec as gridspec
        fig = plt.figure(figsize=(12, 8))
        gs = gridspec.GridSpec(3, 3)

        # Large left panel
        ax1 = fig.add_subplot(gs[:2, :2])
        ax1.imshow(np.random.rand(10, 10))
        ax1.set_title('Main')

        # Right column panels
        ax2 = fig.add_subplot(gs[0, 2])
        ax3 = fig.add_subplot(gs[1, 2])
        ax4 = fig.add_subplot(gs[2, :])

        ax2.plot([1, 2, 3])
        ax3.bar([1, 2, 3], [3, 1, 2])
        ax4.plot(np.linspace(0, 10, 100), np.cos(np.linspace(0, 10, 100)))

        plt.tight_layout()

    def test_figure_with_all_elements(self):
        """Figure with title, labels, legend, colorbar, annotations."""
        fig, ax = plt.subplots(figsize=(8, 6))
        x = np.linspace(0, 10, 100)
        im = ax.scatter(x, np.sin(x), c=x, cmap='viridis', s=30, label='data')
        ax.plot(x, np.sin(x), 'r-', alpha=0.5, label='fit', lw=2)
        fig.colorbar(im, ax=ax, label='x value')
        ax.legend(loc='upper right')
        ax.set_xlabel('x')
        ax.set_ylabel('sin(x)')
        ax.set_title('Comprehensive Figure')
        ax.grid(True, alpha=0.3)
        ax.annotate('Peak', xy=(np.pi/2, 1), xytext=(2, 0.7),
                    arrowprops=dict(arrowstyle='->'))
        plt.tight_layout()
