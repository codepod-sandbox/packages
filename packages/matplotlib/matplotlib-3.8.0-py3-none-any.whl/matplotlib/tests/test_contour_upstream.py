"""Tests for contour/contourf patterns used by LLMs."""

import pytest
import numpy as np
import matplotlib.pyplot as plt


def make_grid():
    x = np.linspace(-3.0, 3.0, 10)
    y = np.linspace(-3.0, 3.0, 10)
    X, Y = np.meshgrid(x, y)
    Z = np.sin(X) * np.cos(Y)
    return X, Y, Z


class TestContourBasic:
    def test_contour_basic(self):
        fig, ax = plt.subplots()
        X, Y, Z = make_grid()
        cs = ax.contour(X, Y, Z)
        assert cs is not None
        plt.close('all')

    def test_contourf_basic(self):
        fig, ax = plt.subplots()
        X, Y, Z = make_grid()
        cs = ax.contourf(X, Y, Z)
        assert cs is not None
        plt.close('all')

    def test_contour_levels_int(self):
        fig, ax = plt.subplots()
        X, Y, Z = make_grid()
        cs = ax.contour(X, Y, Z, levels=5)
        assert cs is not None
        plt.close('all')

    def test_contour_levels_list(self):
        fig, ax = plt.subplots()
        X, Y, Z = make_grid()
        cs = ax.contour(X, Y, Z, levels=[-0.5, 0.0, 0.5])
        assert cs is not None
        plt.close('all')

    def test_contourf_levels(self):
        fig, ax = plt.subplots()
        X, Y, Z = make_grid()
        cs = ax.contourf(X, Y, Z, levels=8)
        assert cs is not None
        plt.close('all')

    def test_contour_colors(self):
        fig, ax = plt.subplots()
        X, Y, Z = make_grid()
        cs = ax.contour(X, Y, Z, colors='black')
        assert cs is not None
        plt.close('all')

    def test_contour_cmap(self):
        fig, ax = plt.subplots()
        X, Y, Z = make_grid()
        cs = ax.contour(X, Y, Z, cmap='viridis')
        assert cs is not None
        plt.close('all')

    def test_contourf_cmap(self):
        fig, ax = plt.subplots()
        X, Y, Z = make_grid()
        cs = ax.contourf(X, Y, Z, cmap='RdBu')
        assert cs is not None
        plt.close('all')

    def test_contour_linewidths(self):
        fig, ax = plt.subplots()
        X, Y, Z = make_grid()
        cs = ax.contour(X, Y, Z, linewidths=2.0)
        assert cs is not None
        plt.close('all')

    def test_contour_linestyles(self):
        fig, ax = plt.subplots()
        X, Y, Z = make_grid()
        cs = ax.contour(X, Y, Z, linestyles='dashed')
        assert cs is not None
        plt.close('all')


class TestContourLabels:
    def test_clabel(self):
        fig, ax = plt.subplots()
        X, Y, Z = make_grid()
        cs = ax.contour(X, Y, Z)
        ax.clabel(cs)
        plt.close('all')

    def test_clabel_inline(self):
        fig, ax = plt.subplots()
        X, Y, Z = make_grid()
        cs = ax.contour(X, Y, Z)
        ax.clabel(cs, inline=True)
        plt.close('all')

    def test_clabel_fontsize(self):
        fig, ax = plt.subplots()
        X, Y, Z = make_grid()
        cs = ax.contour(X, Y, Z)
        ax.clabel(cs, fontsize=8)
        plt.close('all')

    def test_clabel_fmt(self):
        fig, ax = plt.subplots()
        X, Y, Z = make_grid()
        cs = ax.contour(X, Y, Z)
        ax.clabel(cs, fmt='%.1f')
        plt.close('all')


class TestContourColorbar:
    def test_contourf_colorbar(self):
        fig, ax = plt.subplots()
        X, Y, Z = make_grid()
        cs = ax.contourf(X, Y, Z)
        fig.colorbar(cs, ax=ax)
        plt.close('all')

    def test_contourf_alpha(self):
        fig, ax = plt.subplots()
        X, Y, Z = make_grid()
        cs = ax.contourf(X, Y, Z, alpha=0.7)
        assert cs is not None
        plt.close('all')

    def test_contour_and_contourf(self):
        fig, ax = plt.subplots()
        X, Y, Z = make_grid()
        cff = ax.contourf(X, Y, Z, alpha=0.5)
        cs = ax.contour(X, Y, Z, colors='k')
        plt.close('all')


class TestContourArrayOnly:
    def test_contour_z_only(self):
        fig, ax = plt.subplots()
        Z = np.array([[1.0, 2.0, 3.0], [4.0, 5.0, 6.0], [7.0, 8.0, 9.0]])
        cs = ax.contour(Z)
        assert cs is not None
        plt.close('all')

    def test_contourf_z_only(self):
        fig, ax = plt.subplots()
        Z = np.array([[1.0, 2.0, 3.0], [4.0, 5.0, 6.0], [7.0, 8.0, 9.0]])
        cs = ax.contourf(Z)
        assert cs is not None
        plt.close('all')

    def test_contourf_vmin_vmax(self):
        fig, ax = plt.subplots()
        X, Y, Z = make_grid()
        cs = ax.contourf(X, Y, Z, vmin=-0.5, vmax=0.5)
        assert cs is not None
        plt.close('all')

    def test_plt_contourf(self):
        fig, ax = plt.subplots()
        X, Y, Z = make_grid()
        cs = plt.contourf(X, Y, Z)
        assert cs is not None
        plt.close('all')
