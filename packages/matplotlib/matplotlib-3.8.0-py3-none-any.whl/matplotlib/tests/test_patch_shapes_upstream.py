"""
Upstream tests for patch shapes and artists commonly used by LLMs.
"""

import pytest
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.path as mpath
import numpy as np


class TestBasicPatches:
    """Tests for basic patch shapes."""

    def teardown_method(self):
        plt.close('all')

    def test_rectangle(self):
        fig, ax = plt.subplots()
        rect = mpatches.Rectangle((0.1, 0.1), 0.5, 0.3)
        ax.add_patch(rect)
        assert rect.get_width() == 0.5
        assert rect.get_height() == 0.3

    def test_rectangle_color(self):
        fig, ax = plt.subplots()
        rect = mpatches.Rectangle((0, 0), 1, 1, color='blue')
        ax.add_patch(rect)

    def test_rectangle_facecolor_edgecolor(self):
        fig, ax = plt.subplots()
        rect = mpatches.Rectangle((0, 0), 1, 1, facecolor='cyan', edgecolor='black')
        ax.add_patch(rect)
        assert rect.get_facecolor() is not None

    def test_circle(self):
        fig, ax = plt.subplots()
        circle = mpatches.Circle((0.5, 0.5), 0.3)
        ax.add_patch(circle)
        assert circle.get_radius() == 0.3

    def test_circle_color(self):
        fig, ax = plt.subplots()
        circle = mpatches.Circle((0.5, 0.5), 0.2, color='red', alpha=0.5)
        ax.add_patch(circle)

    def test_ellipse(self):
        fig, ax = plt.subplots()
        ell = mpatches.Ellipse((0.5, 0.5), 0.4, 0.2)
        ax.add_patch(ell)
        assert ell.width == 0.4
        assert ell.height == 0.2

    def test_ellipse_angle(self):
        fig, ax = plt.subplots()
        ell = mpatches.Ellipse((0, 0), 2, 1, angle=45)
        ax.add_patch(ell)
        assert ell.get_angle() == 45

    def test_polygon(self):
        fig, ax = plt.subplots()
        verts = [[0, 0], [1, 0], [0.5, 1]]
        poly = mpatches.Polygon(verts, closed=True)
        ax.add_patch(poly)

    def test_polygon_numpy(self):
        fig, ax = plt.subplots()
        theta = np.linspace(0, 2 * np.pi, 6, endpoint=False)
        verts = np.column_stack([np.cos(theta), np.sin(theta)])
        poly = mpatches.Polygon(verts, closed=True, facecolor='lightblue')
        ax.add_patch(poly)

    def test_wedge(self):
        fig, ax = plt.subplots()
        wedge = mpatches.Wedge((0.5, 0.5), 0.3, 0, 90)
        ax.add_patch(wedge)

    def test_arrow(self):
        fig, ax = plt.subplots()
        arrow = mpatches.Arrow(0.1, 0.1, 0.3, 0.3, width=0.05)
        ax.add_patch(arrow)

    def test_arrow_patch(self):
        fig, ax = plt.subplots()
        arrow = mpatches.Arrow(0, 0, 0.4, 0.4, width=0.1)
        ax.add_patch(arrow)

    def test_arc(self):
        fig, ax = plt.subplots()
        arc = mpatches.Arc((0.5, 0.5), 0.4, 0.4, angle=0, theta1=0, theta2=180)
        ax.add_patch(arc)


class TestPatchProperties:
    """Tests for patch property access."""

    def teardown_method(self):
        plt.close('all')

    def test_rectangle_xy(self):
        rect = mpatches.Rectangle((2.0, 3.0), 1, 1)
        xy = rect.get_xy()
        assert xy[0] == 2.0
        assert xy[1] == 3.0

    def test_rectangle_set_xy(self):
        rect = mpatches.Rectangle((0, 0), 1, 1)
        rect.set_xy((5.0, 6.0))
        xy = rect.get_xy()
        assert xy[0] == 5.0

    def test_circle_center(self):
        circle = mpatches.Circle((3, 4), 1)
        center = circle.get_center()
        assert center[0] == 3
        assert center[1] == 4

    def test_patch_alpha(self):
        rect = mpatches.Rectangle((0, 0), 1, 1, alpha=0.5)
        assert rect.get_alpha() == 0.5

    def test_patch_visible(self):
        rect = mpatches.Rectangle((0, 0), 1, 1)
        assert rect.get_visible() is True
        rect.set_visible(False)
        assert rect.get_visible() is False

    def test_patch_linewidth(self):
        rect = mpatches.Rectangle((0, 0), 1, 1, linewidth=2.0)
        assert rect.get_linewidth() == 2.0

    def test_patch_linestyle(self):
        rect = mpatches.Rectangle((0, 0), 1, 1, linestyle='--')
        # linestyle may be normalized
        ls = rect.get_linestyle()
        assert ls is not None

    def test_patch_zorder(self):
        rect = mpatches.Rectangle((0, 0), 1, 1)
        rect.set_zorder(5)
        assert rect.get_zorder() == 5

    def test_patch_label(self):
        rect = mpatches.Rectangle((0, 0), 1, 1, label='my rect')
        assert rect.get_label() == 'my rect'


class TestPatchInPlots:
    """Tests for patches in actual plots."""

    def teardown_method(self):
        plt.close('all')

    def test_add_rectangle_to_axes(self):
        fig, ax = plt.subplots()
        ax.set_xlim(0, 10)
        ax.set_ylim(0, 10)
        rect = mpatches.Rectangle((2, 3), 4, 2, facecolor='yellow', edgecolor='black')
        ax.add_patch(rect)
        assert rect in ax.patches

    def test_add_circle_to_axes(self):
        fig, ax = plt.subplots()
        circle = mpatches.Circle((5, 5), 2, color='blue')
        ax.add_patch(circle)
        assert circle in ax.patches

    def test_multiple_patches(self):
        fig, ax = plt.subplots()
        ax.set_xlim(0, 10)
        ax.set_ylim(0, 10)
        for i in range(5):
            rect = mpatches.Rectangle((i, 0), 0.8, i + 1, facecolor=f'C{i}')
            ax.add_patch(rect)
        assert len(ax.patches) == 5

    def test_highlight_region_with_patch(self):
        """Common LLM pattern: highlight a region with a transparent rectangle."""
        fig, ax = plt.subplots()
        ax.plot(range(10))
        highlight = mpatches.Rectangle((2, 0), 4, 10, alpha=0.2, facecolor='yellow')
        ax.add_patch(highlight)

    def test_annotate_with_circle(self):
        """Mark a data point with a circle."""
        fig, ax = plt.subplots()
        x = [1, 2, 3, 4, 5]
        y = [1, 4, 2, 5, 3]
        ax.plot(x, y, 'o')
        # Highlight max value
        max_y = max(y)
        max_x = x[y.index(max_y)]
        circle = mpatches.Circle((max_x, max_y), 0.3,
                                  fill=False, edgecolor='red', linewidth=2)
        ax.add_patch(circle)

    def test_bar_with_annotation_box(self):
        """Annotate a bar chart with a rectangle."""
        fig, ax = plt.subplots()
        bars = ax.bar([1, 2, 3], [3, 6, 4])
        # Add a border around the tallest bar
        rect = mpatches.Rectangle((1.6, 0), 0.8, 6, fill=False, edgecolor='red', lw=2)
        ax.add_patch(rect)

    def test_fancy_bbox_patch(self):
        fig, ax = plt.subplots()
        fancy = mpatches.FancyBboxPatch((0.1, 0.1), 0.5, 0.3,
                                         boxstyle='round,pad=0.05')
        ax.add_patch(fancy)

    def test_patches_legend(self):
        """Use patches as legend handles."""
        fig, ax = plt.subplots()
        red_patch = mpatches.Patch(color='red', label='Red area')
        blue_patch = mpatches.Patch(color='blue', label='Blue area')
        ax.legend(handles=[red_patch, blue_patch])
