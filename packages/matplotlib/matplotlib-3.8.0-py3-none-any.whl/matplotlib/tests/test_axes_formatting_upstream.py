"""
Upstream tests for axes formatting patterns commonly used by LLMs.
"""

import pytest
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np


class TestAxisScaling:
    """Tests for axis scale types."""

    def teardown_method(self):
        plt.close('all')

    def test_set_xscale_log(self):
        fig, ax = plt.subplots()
        ax.set_xscale('log')
        assert ax.get_xscale() == 'log'

    def test_set_yscale_log(self):
        fig, ax = plt.subplots()
        ax.set_yscale('log')
        assert ax.get_yscale() == 'log'

    def test_set_xscale_linear(self):
        fig, ax = plt.subplots()
        ax.set_xscale('linear')
        assert ax.get_xscale() == 'linear'

    def test_loglog_plot(self):
        fig, ax = plt.subplots()
        x = np.logspace(0, 2, 20)
        ax.loglog(x, x ** 2)
        assert ax.get_xscale() == 'log'
        assert ax.get_yscale() == 'log'

    def test_semilogy_plot(self):
        fig, ax = plt.subplots()
        x = np.linspace(0, 5, 20)
        ax.semilogy(x, np.exp(x))
        assert ax.get_yscale() == 'log'

    def test_semilogx_plot(self):
        fig, ax = plt.subplots()
        x = np.logspace(0, 2, 20)
        ax.semilogx(x, np.log(x))
        assert ax.get_xscale() == 'log'

    def test_set_xscale_symlog(self):
        fig, ax = plt.subplots()
        ax.set_xscale('symlog')
        scale = ax.get_xscale()
        assert scale == 'symlog'

    def test_log_scale_with_data(self):
        fig, ax = plt.subplots()
        ax.set_yscale('log')
        ax.plot([1, 10, 100], [1, 10, 100])


class TestTickFormatters:
    """Tests for tick formatters."""

    def teardown_method(self):
        plt.close('all')

    def test_fixed_formatter(self):
        fig, ax = plt.subplots()
        ax.xaxis.set_major_formatter(ticker.FixedFormatter(['a', 'b', 'c']))
        ax.xaxis.set_major_locator(ticker.FixedLocator([0, 1, 2]))

    def test_func_formatter(self):
        fig, ax = plt.subplots()
        ax.xaxis.set_major_formatter(ticker.FuncFormatter(lambda x, p: f'{x:.1f}'))

    def test_percent_formatter(self):
        fig, ax = plt.subplots()
        ax.yaxis.set_major_formatter(ticker.PercentFormatter(xmax=1))

    def test_scalar_formatter(self):
        fig, ax = plt.subplots()
        formatter = ticker.ScalarFormatter()
        ax.yaxis.set_major_formatter(formatter)

    def test_null_formatter(self):
        fig, ax = plt.subplots()
        ax.xaxis.set_major_formatter(ticker.NullFormatter())

    def test_log_formatter(self):
        fig, ax = plt.subplots()
        ax.set_yscale('log')
        ax.yaxis.set_major_formatter(ticker.LogFormatter())

    def test_format_str_formatter(self):
        fig, ax = plt.subplots()
        ax.xaxis.set_major_formatter(ticker.FormatStrFormatter('%.2f'))

    def test_multiple_formatter(self):
        """Apply different formatters to major and minor ticks."""
        fig, ax = plt.subplots()
        ax.xaxis.set_major_formatter(ticker.FuncFormatter(lambda x, p: f'{x:.0f}'))
        ax.xaxis.set_minor_formatter(ticker.NullFormatter())


class TestTickLocators:
    """Tests for tick locators."""

    def teardown_method(self):
        plt.close('all')

    def test_multiple_locator(self):
        fig, ax = plt.subplots()
        ax.xaxis.set_major_locator(ticker.MultipleLocator(5))
        ax.set_xlim(0, 25)

    def test_fixed_locator(self):
        fig, ax = plt.subplots()
        ax.xaxis.set_major_locator(ticker.FixedLocator([1, 3, 5, 7, 9]))

    def test_max_n_locator(self):
        fig, ax = plt.subplots()
        ax.xaxis.set_major_locator(ticker.MaxNLocator(5))

    def test_auto_locator(self):
        fig, ax = plt.subplots()
        ax.xaxis.set_major_locator(ticker.AutoLocator())

    def test_linear_locator(self):
        fig, ax = plt.subplots()
        ax.xaxis.set_major_locator(ticker.LinearLocator(numticks=5))
        ax.set_xlim(0, 10)

    def test_log_locator(self):
        fig, ax = plt.subplots()
        ax.set_xscale('log')
        ax.xaxis.set_major_locator(ticker.LogLocator())

    def test_null_locator(self):
        fig, ax = plt.subplots()
        ax.xaxis.set_minor_locator(ticker.NullLocator())

    def test_auto_minor_locator(self):
        fig, ax = plt.subplots()
        ax.xaxis.set_minor_locator(ticker.AutoMinorLocator())


class TestSpinesAndEdges:
    """Tests for axis spines."""

    def teardown_method(self):
        plt.close('all')

    def test_spine_visibility(self):
        fig, ax = plt.subplots()
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)

    def test_all_spines_visible(self):
        fig, ax = plt.subplots()
        for spine in ax.spines.values():
            assert spine.get_visible() is True

    def test_spine_linewidth(self):
        fig, ax = plt.subplots()
        ax.spines['bottom'].set_linewidth(2)
        ax.spines['left'].set_linewidth(2)

    def test_spine_color(self):
        fig, ax = plt.subplots()
        ax.spines['bottom'].set_color('gray')

    def test_spine_position(self):
        fig, ax = plt.subplots()
        ax.spines['left'].set_position(('axes', 0.5))  # Center spine

    def test_clean_axes_style(self):
        """Common LLM pattern: clean axes with only bottom/left spines."""
        fig, ax = plt.subplots()
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        ax.plot([1, 2, 3])


class TestAxisLabelsAndTicks:
    """Tests for axis label and tick manipulation."""

    def teardown_method(self):
        plt.close('all')

    def test_tick_rotation(self):
        fig, ax = plt.subplots()
        ax.set_xticks([1, 2, 3])
        ax.set_xticklabels(['a', 'b', 'c'], rotation=45)

    def test_tick_rotation_vertical(self):
        fig, ax = plt.subplots()
        ax.set_xticks([0, 1, 2])
        ax.set_xticklabels(['x', 'y', 'z'], rotation='vertical')

    def test_tick_ha_alignment(self):
        fig, ax = plt.subplots()
        ax.set_xticks([0, 1, 2])
        ax.set_xticklabels(['long label', 'short', 'medium'], rotation=45, ha='right')

    def test_disable_x_ticks(self):
        fig, ax = plt.subplots()
        ax.set_xticks([])

    def test_disable_y_ticks(self):
        fig, ax = plt.subplots()
        ax.set_yticks([])

    def test_tick_direction_in(self):
        fig, ax = plt.subplots()
        ax.tick_params(direction='in')

    def test_tick_direction_out(self):
        fig, ax = plt.subplots()
        ax.tick_params(direction='out')

    def test_tick_both_direction(self):
        fig, ax = plt.subplots()
        ax.tick_params(direction='inout')

    def test_minor_ticks_visible(self):
        fig, ax = plt.subplots()
        ax.minorticks_on()

    def test_minor_ticks_off(self):
        fig, ax = plt.subplots()
        ax.minorticks_on()
        ax.minorticks_off()

    def test_get_xticklabels(self):
        fig, ax = plt.subplots()
        ax.set_xticks([0, 1, 2])
        ax.set_xticklabels(['A', 'B', 'C'])
        labels = ax.get_xticklabels()
        # Labels may be Text objects or strings depending on implementation
        texts = [l.get_text() if hasattr(l, 'get_text') else l for l in labels]
        assert 'A' in texts
        assert 'B' in texts

    def test_get_yticklabels(self):
        fig, ax = plt.subplots()
        ax.set_yticks([0, 5, 10])
        ax.set_yticklabels(['low', 'mid', 'high'])
        labels = ax.get_yticklabels()
        # May return empty list if labels not rendered yet — just test no error
        assert labels is not None
