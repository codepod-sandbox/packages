"""Tests for inset_axes, log scale, imshow features, scatter+colorbar, and misc axes features."""

import pytest
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.axes import Axes


# ---------------------------------------------------------------------------
# ax.inset_axes()
# ---------------------------------------------------------------------------

class TestInsetAxes:
    def test_inset_returns_axes(self):
        """inset_axes returns a new Axes."""
        fig, ax = plt.subplots()
        axins = ax.inset_axes([0.5, 0.5, 0.4, 0.4])
        assert isinstance(axins, Axes)
        plt.close('all')

    def test_inset_is_distinct_from_parent(self):
        """inset_axes returns a different axes."""
        fig, ax = plt.subplots()
        axins = ax.inset_axes([0.5, 0.5, 0.4, 0.4])
        assert axins is not ax
        plt.close('all')

    def test_inset_can_plot(self):
        """can plot on inset axes without error."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        axins = ax.inset_axes([0.5, 0.5, 0.4, 0.4])
        axins.plot([0, 0.5], [0, 0.5])
        plt.close('all')

    def test_inset_svg_renders(self):
        """figure with inset renders to SVG."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2], [1, 4, 9])
        axins = ax.inset_axes([0.1, 0.6, 0.35, 0.35])
        axins.plot([0, 0.5], [0, 0.25])
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_inset_added_to_figure(self):
        """inset axes is registered in figure._axes."""
        fig, ax = plt.subplots()
        n_before = len(fig.get_axes())
        ax.inset_axes([0.5, 0.5, 0.4, 0.4])
        assert len(fig.get_axes()) == n_before + 1
        plt.close('all')

    def test_inset_imshow(self):
        """inset axes can render imshow."""
        fig, ax = plt.subplots()
        ax.imshow([[1, 2], [3, 4]])
        axins = ax.inset_axes([0.5, 0.5, 0.4, 0.4])
        axins.imshow([[1, 0], [0, 1]])
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')


# ---------------------------------------------------------------------------
# Log scale
# ---------------------------------------------------------------------------

class TestLogScale:
    def test_set_xscale_log(self):
        """set_xscale('log') does not raise."""
        fig, ax = plt.subplots()
        ax.plot([1, 10, 100], [1, 2, 3])
        ax.set_xscale('log')
        plt.close('all')

    def test_set_yscale_log(self):
        """set_yscale('log') does not raise."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 10, 100])
        ax.set_yscale('log')
        plt.close('all')

    def test_set_xscale_linear(self):
        """set_xscale('linear') does not raise."""
        fig, ax = plt.subplots()
        ax.set_xscale('linear')
        plt.close('all')

    def test_log_scale_svg_renders(self):
        """log scale plot renders to SVG."""
        fig, ax = plt.subplots()
        ax.plot([1, 10, 100], [1, 2, 3])
        ax.set_xscale('log')
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_plt_xscale(self):
        """plt.xscale() wrapper works."""
        plt.figure()
        plt.plot([1, 10, 100], [1, 2, 3])
        plt.xscale('log')
        plt.close('all')

    def test_plt_yscale(self):
        """plt.yscale() wrapper works."""
        plt.figure()
        plt.plot([1, 2, 3], [1, 10, 100])
        plt.yscale('log')
        plt.close('all')


# ---------------------------------------------------------------------------
# imshow features
# ---------------------------------------------------------------------------

class TestImshowFeatures:
    def test_imshow_extent(self):
        """imshow with extent parameter."""
        fig, ax = plt.subplots()
        im = ax.imshow([[1, 2], [3, 4]], extent=[0, 10, 0, 5])
        ext = im.get_extent()
        assert ext[1] == pytest.approx(10)
        assert ext[3] == pytest.approx(5)
        plt.close('all')

    def test_imshow_aspect_auto(self):
        """imshow with aspect='auto' does not raise."""
        fig, ax = plt.subplots()
        ax.imshow([[1, 2, 3], [4, 5, 6]], aspect='auto')
        plt.close('all')

    def test_imshow_origin_lower(self):
        """imshow with origin='lower' does not raise."""
        fig, ax = plt.subplots()
        ax.imshow([[1, 2], [3, 4]], origin='lower')
        plt.close('all')

    def test_imshow_get_set_clim(self):
        """imshow set_clim / get_clim round-trip."""
        fig, ax = plt.subplots()
        im = ax.imshow([[0, 50], [100, 200]])
        im.set_clim(0, 200)
        vmin, vmax = im.get_clim()
        assert vmin == pytest.approx(0)
        assert vmax == pytest.approx(200)
        plt.close('all')

    def test_imshow_different_cmaps(self):
        """imshow with various colormaps."""
        for cmap in ['viridis', 'plasma', 'hot', 'coolwarm', 'gray']:
            fig, ax = plt.subplots()
            ax.imshow([[1, 2], [3, 4]], cmap=cmap)
            svg = fig.to_svg()
            assert len(svg) > 0
            plt.close('all')

    def test_imshow_alpha(self):
        """imshow with alpha does not raise."""
        fig, ax = plt.subplots()
        ax.imshow([[1, 2], [3, 4]], alpha=0.5)
        plt.close('all')

    def test_imshow_grayscale_float(self):
        """imshow with float grayscale data."""
        fig, ax = plt.subplots()
        data = np.linspace(0, 1, 16).reshape(4, 4).tolist()
        im = ax.imshow(data, cmap='gray')
        assert im is not None
        plt.close('all')


# ---------------------------------------------------------------------------
# scatter with colormap + colorbar
# ---------------------------------------------------------------------------

class TestScatterColorbar:
    def test_scatter_with_c_array(self):
        """scatter(x, y, c=array) maps colors through colormap."""
        fig, ax = plt.subplots()
        sc = ax.scatter([1, 2, 3], [1, 4, 9], c=[1, 2, 3], cmap='viridis')
        assert sc is not None
        plt.close('all')

    def test_scatter_colorbar(self):
        """scatter with colorbar does not raise."""
        fig, ax = plt.subplots()
        sc = ax.scatter([1, 2, 3], [1, 4, 9], c=[10, 20, 30])
        cb = fig.colorbar(sc, ax=ax)
        assert cb is not None
        plt.close('all')

    def test_scatter_colorbar_svg(self):
        """scatter + colorbar renders to SVG."""
        fig, ax = plt.subplots()
        sc = ax.scatter([1, 2, 3], [1, 4, 9], c=[1, 2, 3], cmap='plasma')
        fig.colorbar(sc, ax=ax)
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_scatter_sizes_array(self):
        """scatter with s=array of sizes."""
        fig, ax = plt.subplots()
        sc = ax.scatter([1, 2, 3], [1, 2, 3], s=[10, 100, 500])
        assert sc is not None
        plt.close('all')

    def test_scatter_alpha(self):
        """scatter with alpha."""
        fig, ax = plt.subplots()
        ax.scatter([1, 2, 3], [1, 2, 3], alpha=0.5)
        plt.close('all')


# ---------------------------------------------------------------------------
# tick_params and label formatting
# ---------------------------------------------------------------------------

class TestTickParams:
    def test_tick_params_labelsize(self):
        """tick_params with labelsize does not raise."""
        fig, ax = plt.subplots()
        ax.tick_params(axis='x', labelsize=8)
        plt.close('all')

    def test_tick_params_both_axes(self):
        """tick_params with axis='both' does not raise."""
        fig, ax = plt.subplots()
        ax.tick_params(axis='both', labelsize=10)
        plt.close('all')

    def test_tick_params_rotation(self):
        """tick_params with labelrotation does not raise."""
        fig, ax = plt.subplots()
        ax.tick_params(axis='x', labelrotation=45)
        plt.close('all')

    def test_set_xticklabels_rotation(self):
        """set_xticklabels with rotation does not raise."""
        fig, ax = plt.subplots()
        ax.set_xticks([1, 2, 3])
        ax.set_xticklabels(['A', 'B', 'C'], rotation=45)
        plt.close('all')

    def test_set_xlabel_fontsize(self):
        """set_xlabel with fontsize does not raise."""
        fig, ax = plt.subplots()
        ax.set_xlabel('X Axis', fontsize=14)
        plt.close('all')

    def test_set_title_fontsize(self):
        """set_title with fontsize does not raise."""
        fig, ax = plt.subplots()
        ax.set_title('My Title', fontsize=16)
        plt.close('all')


# ---------------------------------------------------------------------------
# ax.set_visible() / ax.axis()
# ---------------------------------------------------------------------------

class TestAxesVisibility:
    def test_axis_off(self):
        """ax.axis('off') does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        ax.axis('off')
        plt.close('all')

    def test_axis_on(self):
        """ax.axis('on') does not raise."""
        fig, ax = plt.subplots()
        ax.axis('on')
        plt.close('all')

    def test_axis_equal(self):
        """ax.axis('equal') does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        ax.axis('equal')
        plt.close('all')

    def test_axis_off_svg(self):
        """axis('off') still renders SVG."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        ax.axis('off')
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_plt_axis(self):
        """plt.axis() wrapper works."""
        plt.figure()
        plt.plot([0, 1], [0, 1])
        plt.axis('off')
        plt.close('all')


# ---------------------------------------------------------------------------
# Multiple subplots layouts
# ---------------------------------------------------------------------------

class TestSubplotLayouts:
    def test_subplots_1x3(self):
        """plt.subplots(1, 3) creates 3 axes."""
        fig, axes = plt.subplots(1, 3)
        assert len(axes) == 3
        plt.close('all')

    def test_subplots_2x2(self):
        """plt.subplots(2, 2) creates 2x2 grid."""
        fig, axes = plt.subplots(2, 2)
        # axes is a list-of-lists
        assert len(axes) == 2
        assert len(axes[0]) == 2
        plt.close('all')

    def test_subplots_shared_x(self):
        """plt.subplots(2, 1, sharex=True) does not raise."""
        fig, (ax1, ax2) = plt.subplots(2, 1, sharex=True)
        ax1.plot([1, 2, 3], [1, 2, 3])
        ax2.plot([1, 2, 3], [3, 2, 1])
        plt.close('all')

    def test_subplots_shared_y(self):
        """plt.subplots(1, 2, sharey=True) does not raise."""
        fig, (ax1, ax2) = plt.subplots(1, 2, sharey=True)
        ax1.plot([1, 2], [1, 4])
        ax2.plot([1, 2], [2, 8])
        plt.close('all')

    def test_subplots_all_render(self):
        """all axes in a grid render to SVG."""
        fig, axes = plt.subplots(2, 2)
        all_axes = [ax for row in axes for ax in row]
        for i, ax in enumerate(all_axes):
            ax.plot([0, 1], [i, i + 1])
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_subplots_figsize(self):
        """plt.subplots with figsize does not raise."""
        fig, ax = plt.subplots(figsize=(10, 6))
        ax.plot([0, 1], [0, 1])
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')
