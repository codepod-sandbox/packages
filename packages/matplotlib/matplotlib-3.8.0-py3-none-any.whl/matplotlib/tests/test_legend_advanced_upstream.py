"""Tests for advanced legend customization patterns used by LLMs."""

import pytest
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.lines as mlines


class TestLegendBasic:
    def test_legend_default(self):
        """ax.legend() with labeled artists."""
        fig, ax = plt.subplots()
        ax.plot([1, 2], [1, 2], label='line1')
        leg = ax.legend()
        assert leg is not None
        plt.close('all')

    def test_legend_loc_string(self):
        """legend(loc='upper right') and other string locs."""
        fig, ax = plt.subplots()
        ax.plot([1], label='a')
        for loc in ['upper right', 'upper left', 'lower left', 'lower right',
                    'center', 'best']:
            leg = ax.legend(loc=loc)
            assert leg is not None
        plt.close('all')

    def test_legend_loc_int(self):
        """legend(loc=1) with integer location."""
        fig, ax = plt.subplots()
        ax.plot([1], label='a')
        leg = ax.legend(loc=1)
        assert leg is not None
        plt.close('all')

    def test_legend_title(self):
        """legend(title=...) sets title."""
        fig, ax = plt.subplots()
        ax.plot([1], label='data')
        leg = ax.legend(title='My Legend')
        assert leg is not None
        plt.close('all')

    def test_legend_ncol(self):
        """legend(ncol=2) arranges in columns."""
        fig, ax = plt.subplots()
        for i in range(4):
            ax.plot([i], label=f'item{i}')
        leg = ax.legend(ncol=2)
        assert leg is not None
        plt.close('all')

    def test_legend_ncols(self):
        """legend(ncols=2) — alias for ncol."""
        fig, ax = plt.subplots()
        for i in range(4):
            ax.plot([i], label=f'item{i}')
        leg = ax.legend(ncols=2)
        assert leg is not None
        plt.close('all')

    def test_legend_fontsize(self):
        """legend(fontsize=...) sets font size."""
        fig, ax = plt.subplots()
        ax.plot([1], label='data')
        leg = ax.legend(fontsize=12)
        assert leg is not None
        plt.close('all')

    def test_legend_frameon(self):
        """legend(frameon=False) removes frame."""
        fig, ax = plt.subplots()
        ax.plot([1], label='a')
        leg = ax.legend(frameon=False)
        assert leg is not None
        plt.close('all')


class TestLegendHandles:
    def test_legend_handles_labels(self):
        """legend(handles=..., labels=...) explicit control."""
        fig, ax = plt.subplots()
        line, = ax.plot([1, 2], [1, 2])
        leg = ax.legend(handles=[line], labels=['custom'])
        assert leg is not None
        plt.close('all')

    def test_legend_patch_handle(self):
        """Custom patch handles in legend."""
        fig, ax = plt.subplots()
        red_patch = mpatches.Patch(color='red', label='Red')
        blue_patch = mpatches.Patch(color='blue', label='Blue')
        leg = ax.legend(handles=[red_patch, blue_patch])
        assert leg is not None
        plt.close('all')

    def test_legend_line_handle(self):
        """Custom line handles in legend."""
        fig, ax = plt.subplots()
        line = mlines.Line2D([], [], color='red', label='Red line')
        leg = ax.legend(handles=[line])
        assert leg is not None
        plt.close('all')

    def test_legend_get_set_visible(self):
        """legend.set_visible / get_visible."""
        fig, ax = plt.subplots()
        ax.plot([1], label='a')
        leg = ax.legend()
        leg.set_visible(False)
        assert leg.get_visible() is False
        leg.set_visible(True)
        assert leg.get_visible() is True
        plt.close('all')

    def test_legend_remove(self):
        """legend.remove() removes it from axes."""
        fig, ax = plt.subplots()
        ax.plot([1], label='a')
        leg = ax.legend()
        leg.remove()
        plt.close('all')


class TestLegendPositioning:
    def test_legend_bbox_to_anchor(self):
        """legend(bbox_to_anchor=...) positions outside axes."""
        fig, ax = plt.subplots()
        ax.plot([1], label='a')
        leg = ax.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
        assert leg is not None
        plt.close('all')

    def test_legend_bbox_transform(self):
        """legend with bbox_to_anchor and figure transform."""
        fig, ax = plt.subplots()
        ax.plot([1], label='a')
        leg = ax.legend(bbox_to_anchor=(0.5, -0.1), loc='upper center',
                        bbox_transform=fig.transFigure)
        assert leg is not None
        plt.close('all')

    def test_legend_borderaxespad(self):
        """legend(borderaxespad=...) does not raise."""
        fig, ax = plt.subplots()
        ax.plot([1], label='a')
        leg = ax.legend(borderaxespad=0.5)
        assert leg is not None
        plt.close('all')

    def test_fig_legend(self):
        """fig.legend() creates figure-level legend."""
        fig, axes = plt.subplots(1, 2)
        axes[0].plot([1], label='line1')
        axes[1].plot([2], label='line2')
        leg = fig.legend(loc='lower center', ncol=2)
        assert leg is not None
        plt.close('all')

    def test_plt_legend(self):
        """plt.legend() after plotting."""
        fig, ax = plt.subplots()
        ax.plot([1, 2], label='data')
        leg = plt.legend()
        assert leg is not None
        plt.close('all')


class TestLegendStyling:
    def test_legend_alpha(self):
        """legend(framealpha=...) sets frame transparency."""
        fig, ax = plt.subplots()
        ax.plot([1], label='a')
        leg = ax.legend(framealpha=0.5)
        assert leg is not None
        plt.close('all')

    def test_legend_edgecolor(self):
        """legend(edgecolor=...) does not raise."""
        fig, ax = plt.subplots()
        ax.plot([1], label='a')
        leg = ax.legend(edgecolor='black')
        assert leg is not None
        plt.close('all')

    def test_legend_facecolor(self):
        """legend(facecolor=...) does not raise."""
        fig, ax = plt.subplots()
        ax.plot([1], label='a')
        leg = ax.legend(facecolor='lightyellow')
        assert leg is not None
        plt.close('all')

    def test_legend_markerscale(self):
        """legend(markerscale=...) does not raise."""
        fig, ax = plt.subplots()
        ax.scatter([1], [1], label='point')
        leg = ax.legend(markerscale=2.0)
        assert leg is not None
        plt.close('all')

    def test_legend_handlelength(self):
        """legend(handlelength=...) does not raise."""
        fig, ax = plt.subplots()
        ax.plot([1], label='a')
        leg = ax.legend(handlelength=4)
        assert leg is not None
        plt.close('all')

    def test_legend_labelspacing(self):
        """legend(labelspacing=...) does not raise."""
        fig, ax = plt.subplots()
        ax.plot([1], label='a')
        leg = ax.legend(labelspacing=0.5)
        assert leg is not None
        plt.close('all')
