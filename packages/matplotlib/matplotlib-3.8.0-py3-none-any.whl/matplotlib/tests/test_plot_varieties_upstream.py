"""Tests for hlines/vlines, step, more plot varieties."""

import pytest
import numpy as np
import matplotlib.pyplot as plt


# ---------------------------------------------------------------------------
# ax.hlines() / ax.vlines()
# ---------------------------------------------------------------------------

class TestHlinesVlines:
    def test_hlines_basic(self):
        """hlines does not raise."""
        fig, ax = plt.subplots()
        ax.hlines(y=0.5, xmin=0, xmax=1)
        plt.close('all')

    def test_hlines_multiple(self):
        """hlines with multiple y values does not raise."""
        fig, ax = plt.subplots()
        ax.hlines(y=[0.25, 0.5, 0.75], xmin=0, xmax=1)
        plt.close('all')

    def test_hlines_styled(self):
        """hlines with color/linestyle does not raise."""
        fig, ax = plt.subplots()
        ax.hlines(y=0.5, xmin=0, xmax=1, color='red', linestyle='--', linewidth=2)
        plt.close('all')

    def test_vlines_basic(self):
        """vlines does not raise."""
        fig, ax = plt.subplots()
        ax.vlines(x=0.5, ymin=0, ymax=1)
        plt.close('all')

    def test_vlines_multiple(self):
        """vlines with multiple x values does not raise."""
        fig, ax = plt.subplots()
        ax.vlines(x=[0.25, 0.5, 0.75], ymin=0, ymax=1)
        plt.close('all')

    def test_hlines_vlines_svg(self):
        """hlines + vlines renders to SVG."""
        fig, ax = plt.subplots()
        ax.hlines([0.3, 0.7], 0, 1, color='red')
        ax.vlines([0.3, 0.7], 0, 1, color='blue')
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_plt_hlines(self):
        """plt.hlines() wrapper does not raise."""
        plt.figure()
        plt.hlines(0.5, 0, 1)
        plt.close('all')

    def test_plt_vlines(self):
        """plt.vlines() wrapper does not raise."""
        plt.figure()
        plt.vlines(0.5, 0, 1)
        plt.close('all')


# ---------------------------------------------------------------------------
# ax.step()
# ---------------------------------------------------------------------------

class TestStep:
    def test_step_basic(self):
        """step() does not raise."""
        fig, ax = plt.subplots()
        ax.step([0, 1, 2, 3], [1, 2, 1, 3])
        plt.close('all')

    def test_step_where_pre(self):
        """step with where='pre' does not raise."""
        fig, ax = plt.subplots()
        ax.step([0, 1, 2, 3], [1, 2, 1, 3], where='pre')
        plt.close('all')

    def test_step_where_post(self):
        """step with where='post' does not raise."""
        fig, ax = plt.subplots()
        ax.step([0, 1, 2, 3], [1, 2, 1, 3], where='post')
        plt.close('all')

    def test_step_where_mid(self):
        """step with where='mid' does not raise."""
        fig, ax = plt.subplots()
        ax.step([0, 1, 2, 3], [1, 2, 1, 3], where='mid')
        plt.close('all')

    def test_step_styled(self):
        """step with color/linewidth does not raise."""
        fig, ax = plt.subplots()
        ax.step([0, 1, 2], [1, 3, 2], color='green', linewidth=2)
        plt.close('all')

    def test_step_svg_renders(self):
        """step renders to SVG."""
        fig, ax = plt.subplots()
        ax.step([0, 1, 2, 3, 4], [1, 3, 2, 4, 1])
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_plt_step(self):
        """plt.step() wrapper does not raise."""
        plt.figure()
        plt.step([0, 1, 2], [1, 3, 2])
        plt.close('all')


# ---------------------------------------------------------------------------
# ax.pie() features
# ---------------------------------------------------------------------------

class TestPie:
    def test_pie_basic(self):
        """pie() does not raise."""
        fig, ax = plt.subplots()
        ax.pie([1, 2, 3])
        plt.close('all')

    def test_pie_labels(self):
        """pie with labels does not raise."""
        fig, ax = plt.subplots()
        ax.pie([30, 45, 25], labels=['A', 'B', 'C'])
        plt.close('all')

    def test_pie_autopct(self):
        """pie with autopct does not raise."""
        fig, ax = plt.subplots()
        ax.pie([30, 45, 25], autopct='%.1f%%')
        plt.close('all')

    def test_pie_explode(self):
        """pie with explode does not raise."""
        fig, ax = plt.subplots()
        ax.pie([30, 45, 25], explode=[0, 0.1, 0])
        plt.close('all')

    def test_pie_startangle(self):
        """pie with startangle does not raise."""
        fig, ax = plt.subplots()
        ax.pie([30, 45, 25], startangle=90)
        plt.close('all')

    def test_pie_colors(self):
        """pie with colors does not raise."""
        fig, ax = plt.subplots()
        ax.pie([30, 45, 25], colors=['red', 'blue', 'green'])
        plt.close('all')

    def test_pie_svg_renders(self):
        """pie renders to SVG."""
        fig, ax = plt.subplots()
        ax.pie([10, 20, 30, 40], labels=['Q1', 'Q2', 'Q3', 'Q4'])
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_pie_returns_tuple(self):
        """pie returns (patches, texts) or more tuple."""
        fig, ax = plt.subplots()
        result = ax.pie([1, 2, 3])
        assert result is not None
        plt.close('all')

    def test_plt_pie(self):
        """plt.pie() wrapper does not raise."""
        plt.figure()
        plt.pie([25, 35, 40])
        plt.close('all')


# ---------------------------------------------------------------------------
# ax.violinplot() features
# ---------------------------------------------------------------------------

class TestViolinplot:
    def test_violinplot_basic(self):
        """violinplot with single dataset does not raise."""
        import random
        random.seed(42)
        fig, ax = plt.subplots()
        data = [random.gauss(0, 1) for _ in range(50)]
        ax.violinplot(data)
        plt.close('all')

    def test_violinplot_multiple(self):
        """violinplot with multiple datasets does not raise."""
        import random
        random.seed(42)
        fig, ax = plt.subplots()
        data = [[random.gauss(i, 1) for _ in range(30)] for i in range(3)]
        ax.violinplot(data)
        plt.close('all')

    def test_violinplot_showmeans(self):
        """violinplot with showmeans=True does not raise."""
        import random
        random.seed(42)
        fig, ax = plt.subplots()
        data = [random.gauss(0, 1) for _ in range(50)]
        ax.violinplot(data, showmeans=True)
        plt.close('all')

    def test_violinplot_showmedians(self):
        """violinplot with showmedians=True does not raise."""
        import random
        random.seed(42)
        fig, ax = plt.subplots()
        data = [random.gauss(0, 1) for _ in range(50)]
        ax.violinplot(data, showmedians=True)
        plt.close('all')

    def test_violinplot_svg_renders(self):
        """violinplot renders to SVG."""
        import random
        random.seed(42)
        fig, ax = plt.subplots()
        data = [[random.gauss(i, 1) for _ in range(30)] for i in range(4)]
        ax.violinplot(data)
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')


# ---------------------------------------------------------------------------
# Named color testing with plots
# ---------------------------------------------------------------------------

class TestNamedColors:
    def test_plot_with_css_colors(self):
        """plot with various CSS color names does not raise."""
        fig, ax = plt.subplots()
        css_colors = ['red', 'blue', 'green', 'orange', 'purple', 'cyan', 'magenta']
        for color in css_colors:
            ax.plot([0, 1], [0, 1], color=color)
        plt.close('all')

    def test_plot_with_hex_colors(self):
        """plot with hex color strings does not raise."""
        fig, ax = plt.subplots()
        hex_colors = ['#ff0000', '#00ff00', '#0000ff', '#ffff00']
        for color in hex_colors:
            ax.plot([0, 1], [0, 1], color=color)
        plt.close('all')

    def test_plot_with_rgb_tuples(self):
        """plot with (r,g,b) tuples does not raise."""
        fig, ax = plt.subplots()
        rgb_colors = [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0)]
        for color in rgb_colors:
            ax.plot([0, 1], [0, 1], color=color)
        plt.close('all')

    def test_plot_with_rgba_tuples(self):
        """plot with (r,g,b,a) tuples does not raise."""
        fig, ax = plt.subplots()
        rgba_colors = [(1, 0, 0, 0.5), (0, 1, 0, 0.7), (0, 0, 1, 0.9)]
        for color in rgba_colors:
            ax.plot([0, 1], [0, 1], color=color)
        plt.close('all')

    def test_scatter_with_single_color(self):
        """scatter with single color does not raise."""
        fig, ax = plt.subplots()
        ax.scatter([1, 2, 3], [1, 2, 3], color='navy')
        plt.close('all')

    def test_bar_with_rgba_color(self):
        """bar with RGBA color tuple does not raise."""
        fig, ax = plt.subplots()
        ax.bar([1, 2, 3], [3, 7, 5], color=(0.2, 0.4, 0.8, 0.7))
        plt.close('all')


# ---------------------------------------------------------------------------
# ax.stackplot() with baseline
# ---------------------------------------------------------------------------

class TestStackplotBaseline:
    def test_stackplot_baseline_zero(self):
        """stackplot with baseline='zero' does not raise."""
        fig, ax = plt.subplots()
        x = [0, 1, 2, 3]
        ax.stackplot(x, [1, 2, 3, 4], [2, 1, 2, 1], baseline='zero')
        plt.close('all')

    def test_stackplot_baseline_sym(self):
        """stackplot with baseline='sym' does not raise."""
        fig, ax = plt.subplots()
        x = [0, 1, 2, 3]
        ax.stackplot(x, [1, 2, 3, 4], [2, 1, 2, 1], baseline='sym')
        plt.close('all')

    def test_stackplot_returns_artist_list(self):
        """stackplot returns a list of artists."""
        fig, ax = plt.subplots()
        result = ax.stackplot([0, 1, 2], [1, 2, 3], [2, 1, 2])
        assert result is not None
        plt.close('all')
