"""Tests for artist property patterns used by LLMs."""

import pytest
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.lines as mlines
import matplotlib.patches as mpatches


class TestLine2DProperties:
    def test_line_get_xdata(self):
        """line.get_xdata() returns x values."""
        fig, ax = plt.subplots()
        line, = ax.plot([1, 2, 3], [4, 5, 6])
        xdata = line.get_xdata()
        assert list(xdata) == [1, 2, 3]
        plt.close('all')

    def test_line_get_ydata(self):
        """line.get_ydata() returns y values."""
        fig, ax = plt.subplots()
        line, = ax.plot([1, 2, 3], [4, 5, 6])
        ydata = line.get_ydata()
        assert list(ydata) == [4, 5, 6]
        plt.close('all')

    def test_line_set_xdata(self):
        """line.set_xdata() updates x values."""
        fig, ax = plt.subplots()
        line, = ax.plot([1, 2, 3])
        line.set_xdata([4, 5, 6])
        assert list(line.get_xdata()) == [4, 5, 6]
        plt.close('all')

    def test_line_set_ydata(self):
        """line.set_ydata() updates y values."""
        fig, ax = plt.subplots()
        line, = ax.plot([1, 2, 3], [4, 5, 6])
        line.set_ydata([7, 8, 9])
        assert list(line.get_ydata()) == [7, 8, 9]
        plt.close('all')

    def test_line_get_color(self):
        """line.get_color() returns color."""
        fig, ax = plt.subplots()
        line, = ax.plot([1, 2], color='red')
        assert line.get_color() is not None
        plt.close('all')

    def test_line_set_color(self):
        """line.set_color() updates color."""
        fig, ax = plt.subplots()
        line, = ax.plot([1, 2])
        line.set_color('blue')
        plt.close('all')

    def test_line_get_linewidth(self):
        """line.get_linewidth() returns width."""
        fig, ax = plt.subplots()
        line, = ax.plot([1, 2], linewidth=3.0)
        assert line.get_linewidth() == 3.0
        plt.close('all')

    def test_line_set_linewidth(self):
        """line.set_linewidth() updates width."""
        fig, ax = plt.subplots()
        line, = ax.plot([1, 2])
        line.set_linewidth(2.0)
        assert line.get_linewidth() == 2.0
        plt.close('all')

    def test_line_get_linestyle(self):
        """line.get_linestyle() returns style."""
        fig, ax = plt.subplots()
        line, = ax.plot([1, 2], linestyle='--')
        ls = line.get_linestyle()
        assert ls is not None
        plt.close('all')

    def test_line_set_linestyle(self):
        """line.set_linestyle() updates style."""
        fig, ax = plt.subplots()
        line, = ax.plot([1, 2])
        line.set_linestyle(':')
        plt.close('all')

    def test_line_get_alpha(self):
        """line.get_alpha() returns alpha."""
        fig, ax = plt.subplots()
        line, = ax.plot([1, 2], alpha=0.5)
        assert line.get_alpha() == 0.5
        plt.close('all')

    def test_line_set_alpha(self):
        """line.set_alpha() updates alpha."""
        fig, ax = plt.subplots()
        line, = ax.plot([1, 2])
        line.set_alpha(0.3)
        assert line.get_alpha() == 0.3
        plt.close('all')

    def test_line_get_label(self):
        """line.get_label() returns label."""
        fig, ax = plt.subplots()
        line, = ax.plot([1, 2], label='my line')
        assert line.get_label() == 'my line'
        plt.close('all')

    def test_line_set_label(self):
        """line.set_label() updates label."""
        fig, ax = plt.subplots()
        line, = ax.plot([1, 2])
        line.set_label('updated')
        assert line.get_label() == 'updated'
        plt.close('all')

    def test_line_get_visible(self):
        """line.get_visible()."""
        fig, ax = plt.subplots()
        line, = ax.plot([1, 2])
        assert line.get_visible() is True
        plt.close('all')

    def test_line_set_visible(self):
        """line.set_visible() toggles visibility."""
        fig, ax = plt.subplots()
        line, = ax.plot([1, 2])
        line.set_visible(False)
        assert line.get_visible() is False
        plt.close('all')

    def test_line_get_marker(self):
        """line.get_marker() returns marker."""
        fig, ax = plt.subplots()
        line, = ax.plot([1, 2], marker='o')
        m = line.get_marker()
        assert m is not None
        plt.close('all')

    def test_line_set_marker(self):
        """line.set_marker() updates marker."""
        fig, ax = plt.subplots()
        line, = ax.plot([1, 2])
        line.set_marker('s')
        plt.close('all')

    def test_line_get_markersize(self):
        """line.get_markersize()."""
        fig, ax = plt.subplots()
        line, = ax.plot([1, 2], markersize=10)
        assert line.get_markersize() == 10
        plt.close('all')


class TestArtistCollection:
    def test_remove_line(self):
        """line.remove() removes from axes."""
        fig, ax = plt.subplots()
        line, = ax.plot([1, 2])
        assert len(ax.lines) == 1
        line.remove()
        assert len(ax.lines) == 0
        plt.close('all')

    def test_get_children(self):
        """ax.get_children() returns list."""
        fig, ax = plt.subplots()
        ax.plot([1, 2])
        children = ax.get_children()
        assert isinstance(children, list)
        plt.close('all')

    def test_lines_list(self):
        """ax.lines is list of lines."""
        fig, ax = plt.subplots()
        ax.plot([1, 2])
        ax.plot([3, 4])
        assert len(ax.lines) == 2
        plt.close('all')

    def test_patches_list(self):
        """ax.patches is list of patches."""
        fig, ax = plt.subplots()
        rect = mpatches.Rectangle((0, 0), 1, 1)
        ax.add_patch(rect)
        assert len(ax.patches) >= 1
        plt.close('all')
