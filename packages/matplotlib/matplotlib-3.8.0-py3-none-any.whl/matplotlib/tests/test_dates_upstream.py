"""Tests for matplotlib.dates patterns used by LLMs."""

import pytest
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from datetime import datetime, timedelta


def make_dates(n=5):
    """Create n datetime objects starting from 2024-01-01."""
    start = datetime(2024, 1, 1)
    return [start + timedelta(days=i) for i in range(n)]


class TestDatePlotting:
    def test_plot_dates(self):
        """ax.plot_date() with datetime x values."""
        fig, ax = plt.subplots()
        dates = make_dates(5)
        values = [1.0, 2.0, 3.0, 2.5, 4.0]
        ax.plot_date(dates, values)
        plt.close('all')

    def test_plot_with_dates(self):
        """ax.plot() with datetime x values."""
        fig, ax = plt.subplots()
        dates = make_dates(5)
        values = [1.0, 2.0, 3.0, 2.5, 4.0]
        ax.plot(dates, values)
        plt.close('all')

    def test_bar_with_dates(self):
        """bar chart with datetime x."""
        fig, ax = plt.subplots()
        dates = make_dates(3)
        values = [1.0, 2.0, 3.0]
        ax.bar(dates, values)
        plt.close('all')


class TestDateFormatters:
    def test_date_formatter(self):
        """DateFormatter with format string."""
        fig, ax = plt.subplots()
        dates = make_dates(5)
        ax.plot(dates, [1.0, 2.0, 3.0, 2.5, 4.0])
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d'))
        plt.close('all')

    def test_date_formatter_month(self):
        """DateFormatter with month format."""
        fig, ax = plt.subplots()
        dates = make_dates(5)
        ax.plot(dates, [1.0, 2.0, 3.0, 2.5, 4.0])
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%b %Y'))
        plt.close('all')

    def test_auto_date_formatter(self):
        """AutoDateFormatter does not raise."""
        fig, ax = plt.subplots()
        dates = make_dates(5)
        ax.plot(dates, [1.0, 2.0, 3.0, 2.5, 4.0])
        formatter = mdates.AutoDateFormatter(ax.xaxis.get_major_locator())
        ax.xaxis.set_major_formatter(formatter)
        plt.close('all')

    def test_concise_date_formatter(self):
        """ConciseDateFormatter does not raise."""
        fig, ax = plt.subplots()
        dates = make_dates(5)
        ax.plot(dates, [1.0, 2.0, 3.0, 2.5, 4.0])
        locator = mdates.AutoDateLocator()
        ax.xaxis.set_major_locator(locator)
        ax.xaxis.set_major_formatter(mdates.ConciseDateFormatter(locator))
        plt.close('all')


class TestDateLocators:
    def test_auto_date_locator(self):
        """AutoDateLocator for automatic date ticks."""
        fig, ax = plt.subplots()
        dates = make_dates(10)
        ax.plot(dates, [float(i) for i in range(10)])
        ax.xaxis.set_major_locator(mdates.AutoDateLocator())
        plt.close('all')

    def test_day_locator(self):
        """DayLocator for daily ticks."""
        fig, ax = plt.subplots()
        dates = make_dates(7)
        ax.plot(dates, [float(i) for i in range(7)])
        ax.xaxis.set_major_locator(mdates.DayLocator(interval=1))
        plt.close('all')

    def test_week_day_locator(self):
        """WeekdayLocator does not raise."""
        fig, ax = plt.subplots()
        dates = make_dates(14)
        ax.plot(dates, [float(i) for i in range(14)])
        ax.xaxis.set_major_locator(mdates.WeekdayLocator())
        plt.close('all')

    def test_month_locator(self):
        """MonthLocator for monthly ticks."""
        fig, ax = plt.subplots()
        start = datetime(2024, 1, 1)
        dates = [start + timedelta(days=30 * i) for i in range(6)]
        ax.plot(dates, [float(i) for i in range(6)])
        ax.xaxis.set_major_locator(mdates.MonthLocator())
        plt.close('all')

    def test_year_locator(self):
        """YearLocator for yearly ticks."""
        fig, ax = plt.subplots()
        start = datetime(2020, 1, 1)
        dates = [start + timedelta(days=365 * i) for i in range(5)]
        ax.plot(dates, [float(i) for i in range(5)])
        ax.xaxis.set_major_locator(mdates.YearLocator())
        plt.close('all')

    def test_hour_locator(self):
        """HourLocator for hourly ticks."""
        fig, ax = plt.subplots()
        start = datetime(2024, 1, 1, 0, 0)
        dates = [start + timedelta(hours=i) for i in range(6)]
        ax.plot(dates, [float(i) for i in range(6)])
        ax.xaxis.set_major_locator(mdates.HourLocator(interval=1))
        plt.close('all')


class TestDateConversions:
    def test_date2num(self):
        """mdates.date2num converts datetime."""
        dt = datetime(2024, 1, 1)
        num = mdates.date2num(dt)
        assert isinstance(num, float)

    def test_num2date(self):
        """mdates.num2date converts float back."""
        dt = datetime(2024, 1, 1)
        num = mdates.date2num(dt)
        back = mdates.num2date(num)
        assert back is not None

    def test_date_range_rotation(self):
        """Date x-axis with rotation."""
        fig, ax = plt.subplots()
        dates = make_dates(5)
        ax.plot(dates, [1.0, 2.0, 3.0, 2.5, 4.0])
        plt.gcf().autofmt_xdate()
        plt.close('all')

    def test_autofmt_xdate(self):
        """fig.autofmt_xdate() does not raise."""
        fig, ax = plt.subplots()
        dates = make_dates(5)
        ax.plot(dates, [1.0, 2.0, 3.0, 2.5, 4.0])
        fig.autofmt_xdate(rotation=45)
        plt.close('all')
