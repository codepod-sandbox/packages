"""Tests for axes property getter/setter patterns used by LLMs."""

import pytest
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches


class TestAxesVisibility:
    def test_set_visible_true(self):
        """Axes can be shown."""
        fig, ax = plt.subplots()
        ax.set_visible(True)
        assert ax.get_visible() is True
        plt.close('all')

    def test_set_visible_false(self):
        """Axes can be hidden."""
        fig, ax = plt.subplots()
        ax.set_visible(False)
        assert ax.get_visible() is False
        plt.close('all')

    def test_axis_on_off(self):
        """Turn axis on and off."""
        fig, ax = plt.subplots()
        ax.axis('off')
        ax.axis('on')
        plt.close('all')


class TestAxesFaceColor:
    def test_set_facecolor(self):
        """Set axes background color."""
        fig, ax = plt.subplots()
        ax.set_facecolor('lightgray')
        plt.close('all')

    def test_set_facecolor_hex(self):
        """Set axes background hex color."""
        fig, ax = plt.subplots()
        ax.set_facecolor('#f0f0f0')
        plt.close('all')

    def test_get_facecolor(self):
        """Get axes background color."""
        fig, ax = plt.subplots()
        fc = ax.get_facecolor()
        assert fc is not None
        plt.close('all')

    def test_figure_facecolor(self):
        """Figure background color."""
        fig, ax = plt.subplots()
        fig.set_facecolor('white')
        assert fig.get_facecolor() == 'white'
        plt.close('all')


class TestAxesGrid:
    def test_grid_on(self):
        """Enable grid."""
        fig, ax = plt.subplots()
        ax.grid(True)
        plt.close('all')

    def test_grid_off(self):
        """Disable grid."""
        fig, ax = plt.subplots()
        ax.grid(False)
        plt.close('all')

    def test_grid_axis_x(self):
        """Grid on x-axis only."""
        fig, ax = plt.subplots()
        ax.grid(True, axis='x')
        plt.close('all')

    def test_grid_axis_y(self):
        """Grid on y-axis only."""
        fig, ax = plt.subplots()
        ax.grid(True, axis='y')
        plt.close('all')

    def test_grid_both(self):
        """Grid on both axes."""
        fig, ax = plt.subplots()
        ax.grid(True, axis='both')
        plt.close('all')

    def test_grid_style(self):
        """Grid with style."""
        fig, ax = plt.subplots()
        ax.grid(True, linestyle='--', alpha=0.5, color='gray')
        plt.close('all')

    def test_grid_which_major(self):
        """Grid for major ticks."""
        fig, ax = plt.subplots()
        ax.grid(True, which='major')
        plt.close('all')

    def test_grid_which_both(self):
        """Grid for both major and minor ticks."""
        fig, ax = plt.subplots()
        ax.grid(True, which='both', linestyle=':')
        plt.close('all')


class TestAxesSpines:
    def test_spine_visibility(self):
        """Spine visibility."""
        fig, ax = plt.subplots()
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        plt.close('all')

    def test_spine_color(self):
        """Spine color."""
        fig, ax = plt.subplots()
        ax.spines['bottom'].set_color('blue')
        plt.close('all')

    def test_spine_linewidth(self):
        """Spine linewidth."""
        fig, ax = plt.subplots()
        for spine in ax.spines.values():
            spine.set_linewidth(2)
        plt.close('all')

    def test_clean_style(self):
        """Clean style: remove top/right spines."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3])
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        ax.xaxis.set_ticks_position('bottom')
        ax.yaxis.set_ticks_position('left')
        plt.close('all')


class TestAxesTransforms:
    def test_transaxes_text(self):
        """Text in axes coordinates."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3])
        ax.text(0.05, 0.95, 'Corner label', transform=ax.transAxes,
                ha='left', va='top')
        plt.close('all')

    def test_transdata_text(self):
        """Text in data coordinates."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3])
        ax.text(2, 2, 'Data point', transform=ax.transData)
        plt.close('all')

    def test_transfigure_text(self):
        """Text in figure coordinates."""
        fig, ax = plt.subplots()
        fig.text(0.5, 0.02, 'Footer', ha='center', transform=fig.transFigure)
        plt.close('all')


class TestAxesMargins:
    def test_margins_default(self):
        """Default margins."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3])
        m = ax.margins()
        assert m is not None
        plt.close('all')

    def test_set_margins(self):
        """Set margins."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3])
        ax.margins(0.1)
        plt.close('all')

    def test_set_margins_xy(self):
        """Set x and y margins separately."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3])
        ax.margins(x=0.1, y=0.2)
        plt.close('all')

    def test_autoscale(self):
        """Autoscale axes."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3])
        ax.autoscale()
        plt.close('all')

    def test_autoscale_view(self):
        """Autoscale view."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3])
        ax.autoscale_view()
        plt.close('all')


class TestPatchesOnAxes:
    def test_ax_patches_list(self):
        """Axes patches list."""
        fig, ax = plt.subplots()
        rect = mpatches.Rectangle((0, 0), 1, 1, color='blue')
        ax.add_patch(rect)
        assert len(ax.patches) >= 1
        plt.close('all')

    def test_ax_texts_list(self):
        """Axes texts list."""
        fig, ax = plt.subplots()
        ax.text(0.5, 0.5, 'Test')
        assert len(ax.texts) >= 1
        plt.close('all')

    def test_ax_images_list(self):
        """Axes images list."""
        fig, ax = plt.subplots()
        data = [[1.0, 2.0], [3.0, 4.0]]
        ax.imshow(data)
        assert len(ax.images) >= 1
        plt.close('all')

    def test_ax_collections_list(self):
        """Axes collections list."""
        fig, ax = plt.subplots()
        ax.scatter([1.0, 2.0], [1.0, 2.0])
        assert len(ax.collections) >= 1
        plt.close('all')
