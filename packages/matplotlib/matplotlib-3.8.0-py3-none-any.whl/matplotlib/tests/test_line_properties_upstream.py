"""Tests for Line2D properties and markers."""

import pytest
import io
import matplotlib.pyplot as plt
import matplotlib.lines as mlines


class TestLineStyling:
    def test_linestyle_solid(self):
        """Solid line style."""
        fig, ax = plt.subplots()
        line, = ax.plot([1, 2, 3], [1, 2, 3], linestyle='-')
        assert line.get_linestyle() in ['-', 'solid']
        plt.close('all')

    def test_linestyle_dashed(self):
        """Dashed line style."""
        fig, ax = plt.subplots()
        line, = ax.plot([1, 2, 3], [1, 2, 3], linestyle='--')
        plt.close('all')

    def test_linestyle_dotted(self):
        """Dotted line style."""
        fig, ax = plt.subplots()
        line, = ax.plot([1, 2, 3], [1, 2, 3], linestyle=':')
        plt.close('all')

    def test_linestyle_dash_dot(self):
        """Dash-dot line style."""
        fig, ax = plt.subplots()
        line, = ax.plot([1, 2, 3], [1, 2, 3], linestyle='-.')
        plt.close('all')

    def test_linestyle_none(self):
        """No line (markers only)."""
        fig, ax = plt.subplots()
        line, = ax.plot([1, 2, 3], [1, 2, 3], linestyle='None', marker='o')
        plt.close('all')

    def test_linewidth(self):
        """Line width."""
        fig, ax = plt.subplots()
        line, = ax.plot([1, 2, 3], [1, 2, 3], linewidth=3.5)
        assert abs(line.get_linewidth() - 3.5) < 0.01
        plt.close('all')

    def test_color_hex(self):
        """Hex color."""
        fig, ax = plt.subplots()
        line, = ax.plot([1, 2, 3], [1, 2, 3], color='#FF5500')
        plt.close('all')

    def test_color_rgb(self):
        """RGB tuple color."""
        fig, ax = plt.subplots()
        line, = ax.plot([1, 2, 3], [1, 2, 3], color=(0.2, 0.8, 0.4))
        plt.close('all')

    def test_alpha(self):
        """Line alpha."""
        fig, ax = plt.subplots()
        line, = ax.plot([1, 2, 3], [1, 2, 3], alpha=0.5)
        assert abs(line.get_alpha() - 0.5) < 0.01
        plt.close('all')

    def test_label(self):
        """Line label."""
        fig, ax = plt.subplots()
        line, = ax.plot([1, 2, 3], [1, 2, 3], label='My Line')
        assert line.get_label() == 'My Line'
        plt.close('all')

    def test_zorder(self):
        """Line z-order."""
        fig, ax = plt.subplots()
        line, = ax.plot([1, 2, 3], [1, 2, 3], zorder=5)
        assert line.get_zorder() == 5
        plt.close('all')


class TestMarkers:
    def test_marker_circle(self):
        """Circle marker."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3], marker='o')
        plt.close('all')

    def test_marker_square(self):
        """Square marker."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3], marker='s')
        plt.close('all')

    def test_marker_triangle(self):
        """Triangle marker."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3], marker='^')
        plt.close('all')

    def test_marker_diamond(self):
        """Diamond marker."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3], marker='D')
        plt.close('all')

    def test_marker_plus(self):
        """Plus marker."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3], marker='+')
        plt.close('all')

    def test_marker_x(self):
        """X marker."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3], marker='x')
        plt.close('all')

    def test_marker_star(self):
        """Star marker."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3], marker='*')
        plt.close('all')

    def test_marker_size(self):
        """Marker size."""
        fig, ax = plt.subplots()
        line, = ax.plot([1, 2, 3], [1, 2, 3], marker='o', markersize=10)
        assert abs(line.get_markersize() - 10) < 0.01
        plt.close('all')

    def test_marker_color(self):
        """Marker colors."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3], marker='o', markerfacecolor='red',
                markeredgecolor='black', markeredgewidth=2)
        plt.close('all')

    def test_marker_every(self):
        """Marker every N points."""
        fig, ax = plt.subplots()
        x = list(range(20))
        y = [float(i) * 0.5 for i in x]
        ax.plot(x, y, marker='o', markevery=5)
        plt.close('all')


class TestLineFormats:
    def test_format_string_bo(self):
        """Format string 'bo' (blue circles)."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3], 'bo')
        plt.close('all')

    def test_format_string_r_dash(self):
        """Format string 'r--' (red dashed)."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3], 'r--')
        plt.close('all')

    def test_format_string_g_s(self):
        """Format string 'gs' (green squares)."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3], 'gs')
        plt.close('all')

    def test_format_string_k_dot(self):
        """Format string 'k:' (black dotted)."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3], 'k:')
        plt.close('all')

    def test_format_string_c0_to_c9(self):
        """C0 through C4 color cycle."""
        fig, ax = plt.subplots()
        for i in range(5):
            ax.plot([1, 2, 3], [i, i+1, i+2], f'C{i}')
        plt.close('all')

    def test_multiple_lines_formatting(self):
        """Multiple lines with different formats."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3], 'r-', linewidth=2, label='Line A')
        ax.plot([1, 2, 3], [3, 2, 1], 'b--', linewidth=1.5, label='Line B')
        ax.plot([1, 2, 3], [2, 2, 2], 'g:', linewidth=1, label='Line C')
        ax.legend()
        plt.close('all')


class TestLine2DProperties:
    def test_get_xdata(self):
        """Get x data from line."""
        fig, ax = plt.subplots()
        line, = ax.plot([1, 2, 3, 4], [5, 6, 7, 8])
        xdata = line.get_xdata()
        assert list(xdata) == [1, 2, 3, 4]
        plt.close('all')

    def test_get_ydata(self):
        """Get y data from line."""
        fig, ax = plt.subplots()
        line, = ax.plot([1, 2, 3], [10, 20, 30])
        ydata = line.get_ydata()
        assert list(ydata) == [10, 20, 30]
        plt.close('all')

    def test_set_xdata(self):
        """Set x data on existing line."""
        fig, ax = plt.subplots()
        line, = ax.plot([1, 2, 3], [1, 2, 3])
        line.set_xdata([4, 5, 6])
        assert list(line.get_xdata()) == [4, 5, 6]
        plt.close('all')

    def test_set_ydata(self):
        """Set y data on existing line."""
        fig, ax = plt.subplots()
        line, = ax.plot([1, 2, 3], [1, 2, 3])
        line.set_ydata([10, 20, 30])
        assert list(line.get_ydata()) == [10, 20, 30]
        plt.close('all')

    def test_line2d_get_visible(self):
        """Get/set line visibility."""
        fig, ax = plt.subplots()
        line, = ax.plot([1, 2, 3], [1, 2, 3])
        assert line.get_visible() is True
        line.set_visible(False)
        assert line.get_visible() is False
        plt.close('all')

    def test_ax_lines_list(self):
        """Axes lines list."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3])
        ax.plot([1, 2, 3], [3, 2, 1])
        assert len(ax.lines) == 2
        plt.close('all')
