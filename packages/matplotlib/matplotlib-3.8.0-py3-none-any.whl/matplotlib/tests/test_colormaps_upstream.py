"""Tests for colormap patterns used by LLMs."""

import pytest
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.cm as cm
from matplotlib.colors import (
    Normalize, LogNorm, BoundaryNorm, TwoSlopeNorm,
    ListedColormap, LinearSegmentedColormap, to_hex, to_rgba, to_rgb,
)


class TestColormapLookup:
    def test_get_cmap(self):
        cmap = cm.get_cmap('viridis')
        assert cmap is not None

    def test_get_cmap_reversed(self):
        cmap = cm.get_cmap('viridis_r')
        assert cmap is not None

    def test_get_cmap_named(self):
        for name in ['plasma', 'inferno', 'magma', 'cividis', 'hot', 'cool',
                     'RdBu', 'seismic', 'bwr', 'jet', 'Blues', 'Greens']:
            cmap = cm.get_cmap(name)
            assert cmap is not None, f"cmap '{name}' not found"

    def test_cmap_call(self):
        """cmap(value) returns RGBA tuple."""
        cmap = cm.get_cmap('viridis')
        rgba = cmap(0.5)
        assert len(rgba) == 4

    def test_cmap_call_array(self):
        """cmap(array) maps values to colors."""
        cmap = cm.get_cmap('viridis')
        vals = [0.0, 0.5, 1.0]
        colors = [cmap(v) for v in vals]
        assert len(colors) == 3

    def test_plt_get_cmap(self):
        """plt.get_cmap() shortcut."""
        cmap = plt.get_cmap('hot')
        assert cmap is not None

    def test_cm_colormaps_registry(self):
        """cm has viridis attribute."""
        assert hasattr(cm, 'viridis')


class TestNormalize:
    def test_normalize_basic(self):
        norm = Normalize(vmin=0, vmax=10)
        val = norm(5)
        assert val == 0.5

    def test_normalize_clip(self):
        norm = Normalize(vmin=0, vmax=10, clip=True)
        val = norm(15)
        assert val == 1.0

    def test_normalize_no_args(self):
        """Normalize with no args uses data range."""
        norm = Normalize()
        assert norm is not None

    def test_log_norm(self):
        norm = LogNorm(vmin=1, vmax=100)
        val = norm(10)
        assert val is not None

    def test_two_slope_norm(self):
        norm = TwoSlopeNorm(vcenter=0, vmin=-1, vmax=1)
        assert norm is not None

    def test_boundary_norm(self):
        import matplotlib.cm as cm
        cmap = cm.get_cmap('viridis')
        norm = BoundaryNorm([0, 1, 2, 3], ncolors=cmap.N)
        assert norm is not None


class TestListedColormap:
    def test_listed_colormap(self):
        colors = ['red', 'green', 'blue']
        cmap = ListedColormap(colors)
        assert cmap is not None

    def test_listed_colormap_call(self):
        colors = ['red', 'green', 'blue']
        cmap = ListedColormap(colors)
        rgba = cmap(0.5)
        assert len(rgba) == 4

    def test_linear_segmented_colormap(self):
        """LinearSegmentedColormap.from_list() creates gradient."""
        cmap = LinearSegmentedColormap.from_list('custom', ['blue', 'white', 'red'])
        assert cmap is not None

    def test_linear_segmented_call(self):
        cmap = LinearSegmentedColormap.from_list('test', ['black', 'white'])
        rgba = cmap(0.0)
        assert len(rgba) == 4


class TestColorConversions:
    def test_to_hex_named(self):
        assert to_hex('red') == '#ff0000'

    def test_to_hex_rgb(self):
        h = to_hex((1.0, 0.0, 0.0))
        assert h == '#ff0000'

    def test_to_rgba_named(self):
        rgba = to_rgba('blue')
        assert rgba == (0.0, 0.0, 1.0, 1.0)

    def test_to_rgba_with_alpha(self):
        rgba = to_rgba('red', alpha=0.5)
        assert rgba[3] == 0.5

    def test_to_rgb(self):
        rgb = to_rgb('green')
        assert len(rgb) == 3

    def test_color_cycle(self):
        """C0, C1, C2 work as colors."""
        for i in range(10):
            h = to_hex(f'C{i}')
            assert h.startswith('#')

    def test_to_hex_hex_input(self):
        h = to_hex('#ff0000')
        assert h == '#ff0000'


class TestScalarMappable:
    def test_scalar_mappable(self):
        """ScalarMappable can be created for colorbar."""
        from matplotlib.cm import ScalarMappable
        norm = Normalize(vmin=0, vmax=1)
        cmap = cm.get_cmap('viridis')
        sm = ScalarMappable(norm=norm, cmap=cmap)
        sm.set_array([])
        assert sm is not None

    def test_imshow_get_cmap(self):
        """imshow returns object with get_cmap."""
        fig, ax = plt.subplots()
        data = [[1.0, 2.0], [3.0, 4.0]]
        im = ax.imshow(data)
        assert im.get_cmap() is not None
        plt.close('all')
