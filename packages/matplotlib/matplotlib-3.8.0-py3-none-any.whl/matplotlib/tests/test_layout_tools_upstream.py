"""
Upstream tests for tight_layout, subplots_adjust, suptitle, and constrained layout.
"""

import numpy as np
import pytest
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec


class TestTightLayout:
    def teardown_method(self):
        plt.close('all')

    def test_tight_layout_basic(self):
        fig, ax = plt.subplots()
        ax.set_title('Title')
        ax.set_xlabel('X')
        ax.set_ylabel('Y')
        plt.tight_layout()

    def test_tight_layout_fig_method(self):
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3])
        fig.tight_layout()

    def test_tight_layout_pad(self):
        fig, ax = plt.subplots()
        fig.tight_layout(pad=2.0)

    def test_tight_layout_multiplot(self):
        fig, axes = plt.subplots(2, 2)
        for row in axes:
            for ax in row:
                ax.plot([1, 2])
        fig.tight_layout()

    def test_tight_layout_rect(self):
        fig, ax = plt.subplots()
        fig.tight_layout(rect=[0, 0, 1, 0.9])

    def test_tight_layout_h_pad_w_pad(self):
        fig, axes = plt.subplots(2, 2)
        fig.tight_layout(h_pad=1.0, w_pad=1.0)


class TestSubplotsAdjust:
    def teardown_method(self):
        plt.close('all')

    def test_subplots_adjust_basic(self):
        fig, ax = plt.subplots()
        plt.subplots_adjust(left=0.1, right=0.9, top=0.9, bottom=0.1)

    def test_subplots_adjust_fig_method(self):
        fig, ax = plt.subplots()
        fig.subplots_adjust(left=0.15, right=0.85)

    def test_subplots_adjust_hspace(self):
        fig, axes = plt.subplots(2, 1)
        plt.subplots_adjust(hspace=0.5)

    def test_subplots_adjust_wspace(self):
        fig, axes = plt.subplots(1, 2)
        plt.subplots_adjust(wspace=0.3)

    def test_subplots_adjust_all_params(self):
        fig, axes = plt.subplots(2, 2)
        plt.subplots_adjust(
            left=0.1, right=0.95,
            top=0.9, bottom=0.1,
            hspace=0.4, wspace=0.3
        )

    def test_subplots_adjust_after_suptitle(self):
        fig, ax = plt.subplots()
        fig.suptitle('Main Title')
        plt.subplots_adjust(top=0.88)


class TestSuptitle:
    def teardown_method(self):
        plt.close('all')

    def test_suptitle_basic(self):
        fig, ax = plt.subplots()
        fig.suptitle('My Figure Title')

    def test_suptitle_fontsize(self):
        fig, ax = plt.subplots()
        fig.suptitle('Title', fontsize=16)

    def test_suptitle_fontweight(self):
        fig, ax = plt.subplots()
        fig.suptitle('Title', fontweight='bold')

    def test_suptitle_y_position(self):
        fig, ax = plt.subplots()
        fig.suptitle('Title', y=1.02)

    def test_suptitle_x_position(self):
        fig, ax = plt.subplots()
        fig.suptitle('Title', x=0.5)

    def test_suptitle_ha(self):
        fig, ax = plt.subplots()
        fig.suptitle('Title', ha='center')

    def test_suptitle_multirow(self):
        fig, axes = plt.subplots(2, 3)
        fig.suptitle('Analysis Results', fontsize=14, fontweight='bold')
        fig.tight_layout()

    def test_plt_suptitle(self):
        fig, ax = plt.subplots()
        plt.suptitle('Figure Title')

    def test_suptitle_returns_text(self):
        fig, ax = plt.subplots()
        t = fig.suptitle('Title')
        assert t is not None
        assert t.get_text() == 'Title'


class TestConstrainedLayout:
    def teardown_method(self):
        plt.close('all')

    def test_constrained_layout_figure(self):
        fig, ax = plt.subplots(constrained_layout=True)
        ax.set_title('Title')
        ax.set_xlabel('X')

    def test_constrained_layout_multiplot(self):
        fig, axes = plt.subplots(2, 2, constrained_layout=True)
        for row in axes:
            for ax in row:
                ax.plot([1, 2])
                ax.set_title('Panel')

    def test_constrained_layout_with_colorbar(self):
        fig, ax = plt.subplots(constrained_layout=True)
        im = ax.imshow([[1, 2], [3, 4]])
        fig.colorbar(im, ax=ax)

    def test_layout_engine_tight(self):
        fig = plt.figure(layout='tight')
        ax = fig.add_subplot(111)
        ax.plot([1, 2])

    def test_layout_engine_constrained(self):
        fig = plt.figure(layout='constrained')
        ax = fig.add_subplot(111)
        ax.plot([1, 2])


class TestGridSpecLayout:
    def teardown_method(self):
        plt.close('all')

    def test_gridspec_figure_tight_layout(self):
        fig = plt.figure()
        gs = gridspec.GridSpec(2, 2, figure=fig)
        ax1 = fig.add_subplot(gs[0, 0])
        ax2 = fig.add_subplot(gs[0, 1])
        ax3 = fig.add_subplot(gs[1, :])
        ax1.plot([1, 2])
        ax2.plot([3, 4])
        ax3.plot([1, 2, 3, 4])
        plt.tight_layout()

    def test_gridspec_hspace_wspace(self):
        fig = plt.figure()
        gs = gridspec.GridSpec(2, 2, hspace=0.5, wspace=0.3)
        fig.add_subplot(gs[0, 0])
        fig.add_subplot(gs[0, 1])
        fig.add_subplot(gs[1, 0])
        fig.add_subplot(gs[1, 1])
