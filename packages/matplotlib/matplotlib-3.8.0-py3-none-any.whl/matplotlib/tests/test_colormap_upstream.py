"""Tests for colormaps, normalization, and colorbar features."""

import pytest
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.cm as cm
import matplotlib.colors as mcolors


# ---------------------------------------------------------------------------
# Built-in colormap access
# ---------------------------------------------------------------------------

class TestColormapAccess:
    def test_get_cmap_viridis(self):
        """get_cmap('viridis') returns a colormap."""
        cmap = cm.get_cmap('viridis')
        assert cmap is not None

    def test_get_cmap_plasma(self):
        """get_cmap('plasma') returns a colormap."""
        cmap = cm.get_cmap('plasma')
        assert cmap is not None

    def test_get_cmap_inferno(self):
        """get_cmap('inferno') returns a colormap."""
        cmap = cm.get_cmap('inferno')
        assert cmap is not None

    def test_get_cmap_magma(self):
        """get_cmap('magma') returns a colormap."""
        cmap = cm.get_cmap('magma')
        assert cmap is not None

    def test_get_cmap_hot(self):
        """get_cmap('hot') returns a colormap."""
        cmap = cm.get_cmap('hot')
        assert cmap is not None

    def test_get_cmap_cool(self):
        """get_cmap('cool') returns a colormap."""
        cmap = cm.get_cmap('cool')
        assert cmap is not None

    def test_get_cmap_gray(self):
        """get_cmap('gray') returns a colormap."""
        cmap = cm.get_cmap('gray')
        assert cmap is not None

    def test_get_cmap_jet(self):
        """get_cmap('jet') returns a colormap."""
        cmap = cm.get_cmap('jet')
        assert cmap is not None

    def test_get_cmap_blues(self):
        """get_cmap('Blues') returns a colormap."""
        cmap = cm.get_cmap('Blues')
        assert cmap is not None

    def test_get_cmap_rdbu(self):
        """get_cmap('RdBu') returns a colormap."""
        cmap = cm.get_cmap('RdBu')
        assert cmap is not None

    def test_cmap_callable(self):
        """colormap called with [0, 1] returns RGBA tuples."""
        cmap = cm.get_cmap('viridis')
        rgba = cmap(0.5)
        assert len(rgba) == 4
        assert all(0 <= v <= 1 for v in rgba)

    def test_cmap_array(self):
        """colormap applied to array of values."""
        cmap = cm.get_cmap('plasma')
        values = [0.0, 0.25, 0.5, 0.75, 1.0]
        colors = [cmap(v) for v in values]
        assert len(colors) == 5


# ---------------------------------------------------------------------------
# Colormap via matplotlib.colormaps
# ---------------------------------------------------------------------------

class TestColormapRegistry:
    def test_colormaps_registry_access(self):
        """matplotlib.colormaps['viridis'] returns a colormap."""
        import matplotlib
        cmap = matplotlib.colormaps['viridis']
        assert cmap is not None

    def test_colormaps_get_cmap(self):
        """matplotlib.colormaps.get_cmap works."""
        import matplotlib
        cmap = matplotlib.colormaps.get_cmap('plasma')
        assert cmap is not None


# ---------------------------------------------------------------------------
# Normalization
# ---------------------------------------------------------------------------

class TestNormalization:
    def test_normalize_basic(self):
        """Normalize maps [vmin, vmax] to [0, 1]."""
        norm = mcolors.Normalize(vmin=0, vmax=10)
        assert norm(5) == pytest.approx(0.5)
        assert norm(0) == pytest.approx(0.0)
        assert norm(10) == pytest.approx(1.0)

    def test_lognorm(self):
        """LogNorm maps logarithmically."""
        norm = mcolors.LogNorm(vmin=1, vmax=1000)
        assert norm is not None
        val = norm(10)
        assert val is not None

    def test_boundarynorm(self):
        """BoundaryNorm with explicit boundaries."""
        boundaries = [0, 1, 2, 4, 8]
        norm = mcolors.BoundaryNorm(boundaries, ncolors=256)
        assert norm is not None

    def test_twoslope_norm(self):
        """TwoSlopeNorm maps around a center value."""
        norm = mcolors.TwoSlopeNorm(vmin=-10, vcenter=0, vmax=5)
        assert norm is not None

    def test_norm_with_imshow(self):
        """imshow with norm does not raise."""
        fig, ax = plt.subplots()
        data = [[0, 50, 100], [25, 75, 150]]
        norm = mcolors.Normalize(vmin=0, vmax=150)
        ax.imshow(data, norm=norm, cmap='viridis')
        plt.close('all')


# ---------------------------------------------------------------------------
# ScalarMappable
# ---------------------------------------------------------------------------

class TestScalarMappable:
    def test_scalar_mappable_creation(self):
        """ScalarMappable can be created."""
        sm = cm.ScalarMappable(cmap='viridis',
                               norm=mcolors.Normalize(0, 1))
        assert sm is not None

    def test_scalar_mappable_set_array(self):
        """ScalarMappable.set_array does not raise."""
        sm = cm.ScalarMappable(cmap='viridis',
                               norm=mcolors.Normalize(0, 1))
        sm.set_array([0.1, 0.5, 0.9])

    def test_scalar_mappable_colorbar(self):
        """ScalarMappable used with colorbar does not raise."""
        fig, ax = plt.subplots()
        sm = cm.ScalarMappable(cmap='viridis',
                               norm=mcolors.Normalize(0, 100))
        sm.set_array([])
        fig.colorbar(sm, ax=ax)
        plt.close('all')

    def test_scalar_mappable_to_rgba(self):
        """ScalarMappable.to_rgba converts values."""
        sm = cm.ScalarMappable(cmap='viridis',
                               norm=mcolors.Normalize(0, 10))
        sm.set_array([0, 5, 10])
        rgba = sm.to_rgba([0, 5, 10])
        assert len(rgba) == 3


# ---------------------------------------------------------------------------
# Colormap usage in plots
# ---------------------------------------------------------------------------

class TestColormapInPlots:
    def test_scatter_cmap(self):
        """scatter with cmap does not raise."""
        rng = np.random.default_rng(42)
        x = rng.random(20)
        y = rng.random(20)
        c = rng.random(20)
        fig, ax = plt.subplots()
        ax.scatter(x, y, c=c, cmap='viridis')
        plt.close('all')

    def test_imshow_cmap(self):
        """imshow with various cmaps does not raise."""
        data = [[1, 2, 3], [4, 5, 6]]
        for cmap_name in ['viridis', 'plasma', 'hot', 'gray', 'Blues']:
            fig, ax = plt.subplots()
            ax.imshow(data, cmap=cmap_name)
            plt.close('all')

    def test_pcolormesh_cmap(self):
        """pcolormesh with cmap does not raise."""
        x = np.linspace(0, 1, 5)
        y = np.linspace(0, 1, 5)
        X, Y = np.meshgrid(x, y)
        Z = X + Y
        fig, ax = plt.subplots()
        ax.pcolormesh(X, Y, Z, cmap='plasma')
        plt.close('all')
