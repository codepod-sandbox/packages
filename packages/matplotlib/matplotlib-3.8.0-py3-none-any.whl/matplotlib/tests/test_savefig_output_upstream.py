"""Tests for savefig to various formats and file objects."""

import pytest
import io
import numpy as np
import matplotlib.pyplot as plt


class TestSavefigSVG:
    def test_savefig_svg_string_path(self, tmp_path):
        """savefig to SVG file path does not raise."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3])
        path = str(tmp_path / 'test.svg')
        fig.savefig(path)
        plt.close('all')

    def test_savefig_svg_bytesio(self):
        """savefig to BytesIO in SVG does not raise."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3])
        buf = io.BytesIO()
        fig.savefig(buf, format='svg')
        assert buf.tell() > 0
        plt.close('all')

    def test_savefig_svg_stringio(self):
        """savefig to StringIO in SVG does not raise."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3])
        buf = io.StringIO()
        fig.savefig(buf, format='svg')
        assert buf.tell() > 0
        plt.close('all')

    def test_to_svg_method(self):
        """fig.to_svg() returns an SVG string."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3])
        svg = fig.to_svg()
        assert isinstance(svg, str)
        assert '<svg' in svg or len(svg) > 0
        plt.close('all')

    def test_to_svg_contains_lines(self):
        """SVG output for a line plot contains path or line elements."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2], [0, 1, 0], 'b-')
        svg = fig.to_svg()
        assert len(svg) > 100
        plt.close('all')


class TestSavefigPNG:
    def test_savefig_png_bytesio(self):
        """savefig to BytesIO in PNG does not raise."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3])
        buf = io.BytesIO()
        fig.savefig(buf, format='png')
        assert buf.tell() > 0
        plt.close('all')

    def test_savefig_png_dpi(self):
        """savefig with dpi parameter does not raise."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3])
        buf = io.BytesIO()
        fig.savefig(buf, format='png', dpi=72)
        assert buf.tell() > 0
        plt.close('all')

    def test_savefig_png_tight(self):
        """savefig with bbox_inches='tight' does not raise."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3])
        buf = io.BytesIO()
        fig.savefig(buf, format='png', bbox_inches='tight')
        assert buf.tell() > 0
        plt.close('all')

    def test_savefig_png_facecolor(self):
        """savefig with facecolor does not raise."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3])
        buf = io.BytesIO()
        fig.savefig(buf, format='png', facecolor='white')
        assert buf.tell() > 0
        plt.close('all')


class TestSavefigComplex:
    def test_savefig_subplots(self):
        """savefig with multiple subplots does not raise."""
        fig, axes = plt.subplots(2, 2)
        for i, row in enumerate(axes):
            for j, ax in enumerate(row):
                ax.plot([0, 1], [i, j])
        buf = io.BytesIO()
        fig.savefig(buf, format='png')
        assert buf.tell() > 0
        plt.close('all')

    def test_savefig_with_colorbar(self):
        """savefig with colorbar does not raise."""
        fig, ax = plt.subplots()
        data = np.random.rand(5, 5)
        im = ax.imshow(data)
        fig.colorbar(im)
        buf = io.BytesIO()
        fig.savefig(buf, format='png')
        assert buf.tell() > 0
        plt.close('all')

    def test_savefig_with_legend(self):
        """savefig with legend does not raise."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], label='line 1')
        ax.legend()
        buf = io.BytesIO()
        fig.savefig(buf, format='png')
        assert buf.tell() > 0
        plt.close('all')

    def test_plt_savefig(self):
        """plt.savefig() does not raise."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3])
        buf = io.BytesIO()
        plt.savefig(buf, format='png')
        assert buf.tell() > 0
        plt.close('all')

    def test_savefig_svg_with_title(self):
        """savefig with suptitle to SVG does not raise."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3])
        fig.suptitle('Test Title')
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')
