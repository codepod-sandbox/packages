"""
Upstream tests — batch 27.
Focus: More complete coverage of existing functionality including
       text properties, line properties, matplotlib module attributes,
       and comprehensive plot type verification.
Adapted from matplotlib upstream tests (no canvas rendering, no image comparison).
"""
import math
import pytest
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
from matplotlib.figure import Figure
from matplotlib.lines import Line2D
from matplotlib.text import Text
from matplotlib.patches import Rectangle, Circle, Ellipse, Polygon
from matplotlib.collections import LineCollection
from matplotlib.transforms import Bbox, Affine2D
from matplotlib.colors import Normalize, to_rgba, to_hex
from matplotlib.legend import Legend
import matplotlib.cm as cm
import matplotlib.ticker as ticker


def close(a, b, tol=1e-9):
    """Check approximate equality."""
    if b == 0:
        return abs(a) < tol
    return abs(a - b) / abs(b) < tol


# ------------------------------------------------------------------
# Text property tests
# ------------------------------------------------------------------

class TestTextProperties:
    def test_text_x(self):
        t = Text(3, 4, 'hello')
        assert close(t.get_position()[0], 3)

    def test_text_y(self):
        t = Text(3, 4, 'hello')
        assert close(t.get_position()[1], 4)

    def test_text_ha_default(self):
        t = Text(0, 0, 'hello')
        ha = t.get_ha()
        assert ha in ('left', 'center', 'right')

    def test_text_va_default(self):
        t = Text(0, 0, 'hello')
        va = t.get_va()
        assert va in ('top', 'center', 'bottom', 'baseline', 'center_baseline')

    def test_text_rotation_default(self):
        t = Text(0, 0, 'hello')
        r = t.get_rotation()
        assert isinstance(r, (int, float))

    def test_text_fontsize_numeric(self):
        t = Text(0, 0, 'test', fontsize=16)
        assert close(t.get_fontsize(), 16)

    def test_text_color_tuple(self):
        t = Text(0, 0, 'test', color=(0.5, 0.5, 0.5))
        c = t.get_color()
        assert c is not None

    def test_text_color_hex(self):
        t = Text(0, 0, 'test', color='#ff0000')
        c = t.get_color()
        assert c is not None

    def test_text_visible_default(self):
        t = Text(0, 0, 'test')
        assert t.get_visible()

    def test_text_alpha_none_default(self):
        t = Text(0, 0, 'test')
        assert t.get_alpha() is None

    def test_text_set_ha(self):
        t = Text(0, 0, 'test')
        t.set_ha('right')
        assert t.get_ha() == 'right'

    def test_text_set_va(self):
        t = Text(0, 0, 'test')
        t.set_va('top')
        assert t.get_va() == 'top'

    def test_text_set_rotation(self):
        t = Text(0, 0, 'test')
        t.set_rotation(45)
        assert close(t.get_rotation(), 45)

    def test_text_set_fontsize(self):
        t = Text(0, 0, 'test')
        t.set_fontsize(12)
        assert close(t.get_fontsize(), 12)

    def test_text_set_color(self):
        t = Text(0, 0, 'test')
        t.set_color('blue')
        c = t.get_color()
        assert c is not None

    def test_text_in_axes_visible(self):
        fig, ax = plt.subplots()
        t = ax.text(0.5, 0.5, 'hello')
        assert t.get_visible()
        t.set_visible(False)
        assert not t.get_visible()

    def test_text_in_axes_alpha(self):
        fig, ax = plt.subplots()
        t = ax.text(0.5, 0.5, 'hello')
        t.set_alpha(0.7)
        assert close(t.get_alpha(), 0.7)


# ------------------------------------------------------------------
# Line2D property tests
# ------------------------------------------------------------------

class TestLine2DProperties:
    def test_linestyle_solid(self):
        line = Line2D([0, 1], [0, 1], linestyle='solid')
        ls = line.get_linestyle()
        assert ls is not None

    def test_linestyle_dashed(self):
        line = Line2D([0, 1], [0, 1], linestyle='dashed')
        ls = line.get_linestyle()
        assert ls is not None

    def test_linestyle_dashdot(self):
        line = Line2D([0, 1], [0, 1], linestyle='dashdot')
        ls = line.get_linestyle()
        assert ls is not None

    def test_linestyle_dotted(self):
        line = Line2D([0, 1], [0, 1], linestyle='dotted')
        ls = line.get_linestyle()
        assert ls is not None

    def test_marker_types(self):
        markers = ['o', 's', 'D', '^', 'v', '<', '>', 'p', '*', '+', 'x', '.', ',']
        for m in markers:
            line = Line2D([0, 1], [0, 1], marker=m)
            assert line.get_marker() is not None

    def test_get_xydata_shape(self):
        line = Line2D([0, 1, 2, 3], [0, 1, 4, 9])
        xy = line.get_xydata()
        assert len(xy) == 4
        assert len(xy[0]) == 2

    def test_fillstyle(self):
        line = Line2D([0, 1], [0, 1], fillstyle='full')
        fs = line.get_fillstyle()
        assert fs is not None

    def test_drawstyle_default(self):
        line = Line2D([0, 1], [0, 1])
        ds = line.get_drawstyle()
        assert ds in ('default', 'steps', 'steps-pre', 'steps-post', 'steps-mid')

    def test_solid_capstyle(self):
        line = Line2D([0, 1], [0, 1], solid_capstyle='round')
        assert line is not None

    def test_dash_capstyle(self):
        line = Line2D([0, 1], [0, 1], dash_capstyle='butt')
        assert line is not None

    def test_line2d_data_after_set(self):
        line = Line2D([0], [0])
        line.set_xdata([1, 2, 3, 4, 5])
        line.set_ydata([1, 4, 9, 16, 25])
        assert len(line.get_xdata()) == 5
        assert len(line.get_ydata()) == 5

    def test_markersize_set_get(self):
        line = Line2D([0, 1], [0, 1])
        line.set_markersize(10)
        assert close(line.get_markersize(), 10)

    def test_markeredgewidth_set_get(self):
        line = Line2D([0, 1], [0, 1])
        line.set_markeredgewidth(2)
        assert close(line.get_markeredgewidth(), 2)


# ------------------------------------------------------------------
# Patch property tests
# ------------------------------------------------------------------

class TestPatchProperties:
    def test_rectangle_bounds_correct(self):
        r = Rectangle((2, 3), 5, 7)
        assert close(r.get_xy()[0], 2)
        assert close(r.get_xy()[1], 3)
        assert close(r.get_width(), 5)
        assert close(r.get_height(), 7)
        assert close(r.get_x(), 2)
        assert close(r.get_y(), 3)

    def test_circle_center_radius(self):
        c = Circle((1, 2), radius=3)
        ctr = c.get_center()
        assert close(ctr[0], 1)
        assert close(ctr[1], 2)
        assert close(c.get_radius(), 3)

    def test_ellipse_all_props(self):
        e = Ellipse((5, 6), width=10, height=4, angle=30)
        ctr = e.get_center()
        assert close(ctr[0], 5)
        assert close(ctr[1], 6)
        assert close(e.get_width(), 10)
        assert close(e.get_height(), 4)
        assert close(e.get_angle(), 30)

    def test_polygon_set_color(self):
        p = Polygon([(0, 0), (1, 0), (0.5, 1)], facecolor='blue')
        fc = p.get_facecolor()
        assert len(fc) == 4

    def test_patch_update_dict(self):
        r = Rectangle((0, 0), 1, 1)
        r.update({'facecolor': 'red', 'linewidth': 3})
        assert close(r.get_linewidth(), 3)

    def test_rectangle_is_patch(self):
        from matplotlib.patches import Patch
        r = Rectangle((0, 0), 1, 1)
        assert isinstance(r, Patch)

    def test_circle_is_patch(self):
        from matplotlib.patches import Patch
        c = Circle((0, 0), 1)
        assert isinstance(c, Patch)

    def test_ellipse_set_angle(self):
        e = Ellipse((0, 0), width=4, height=2)
        e.set_angle(60)
        assert close(e.get_angle(), 60)

    def test_ellipse_set_center(self):
        e = Ellipse((0, 0), width=4, height=2)
        e.set_center((3, 4))
        ctr = e.get_center()
        assert close(ctr[0], 3)
        assert close(ctr[1], 4)


# ------------------------------------------------------------------
# Axes find/children tests
# ------------------------------------------------------------------

class TestAxesFindChildren:
    def test_findobj_all(self):
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        ax.text(0.5, 0.5, 'hello')
        objs = ax.findobj()
        assert len(objs) >= 2

    def test_findobj_match_class(self):
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        lines = ax.findobj(Line2D)
        assert len(lines) >= 1

    def test_findobj_match_text(self):
        fig, ax = plt.subplots()
        t = ax.text(0.5, 0.5, 'hello')
        texts = ax.findobj(Text)
        assert len(texts) >= 1

    def test_get_children_has_artists(self):
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        children = ax.get_children()
        assert len(children) >= 1

    def test_get_children_includes_texts(self):
        fig, ax = plt.subplots()
        t = ax.text(0.5, 0.5, 'hello')
        children = ax.get_children()
        assert t in children

    def test_get_children_includes_lines(self):
        fig, ax = plt.subplots()
        line, = ax.plot([0, 1], [0, 1])
        children = ax.get_children()
        assert line in children


# ------------------------------------------------------------------
# matplotlib module attributes
# ------------------------------------------------------------------

class TestMatplotlibModule:
    def test_version_string(self):
        assert isinstance(matplotlib.__version__, str)
        # Should be semantic version
        parts = matplotlib.__version__.split('.')
        assert len(parts) >= 2

    def test_rcparams_type(self):
        from matplotlib.rcsetup import RcParams
        assert isinstance(matplotlib.rcParams, RcParams)

    def test_rc_modifies_params(self):
        original = matplotlib.rcParams.get('lines.linewidth', 1.5)
        matplotlib.rc('lines', linewidth=3.0)
        assert matplotlib.rcParams['lines.linewidth'] == 3.0
        # Restore
        matplotlib.rcParams['lines.linewidth'] = original

    def test_is_interactive_default(self):
        assert not matplotlib.is_interactive()

    def test_rc_context_restores(self):
        from matplotlib.rcsetup import rc_context
        original_lw = matplotlib.rcParams.get('lines.linewidth', 1.5)
        with rc_context({'lines.linewidth': 5.0}):
            assert matplotlib.rcParams['lines.linewidth'] == 5.0
        assert matplotlib.rcParams.get('lines.linewidth') == original_lw


# ------------------------------------------------------------------
# pyplot advanced
# ------------------------------------------------------------------

class TestPylotAdvanced:
    def test_pyplot_bar(self):
        fig, ax = plt.subplots()
        bc = plt.bar([0, 1, 2], [3, 5, 2])
        assert bc is not None
        plt.close('all')

    def test_pyplot_scatter(self):
        fig, ax = plt.subplots()
        sc = plt.scatter([1, 2, 3], [4, 5, 6])
        assert sc is not None
        plt.close('all')

    def test_pyplot_hist(self):
        fig, ax = plt.subplots()
        result = plt.hist([1, 2, 2, 3, 3, 3])
        assert result is not None
        plt.close('all')

    def test_pyplot_errorbar(self):
        fig, ax = plt.subplots()
        ec = plt.errorbar([1, 2, 3], [1, 4, 9], yerr=[0.1, 0.2, 0.3])
        assert ec is not None
        plt.close('all')

    def test_pyplot_fill_between(self):
        fig, ax = plt.subplots()
        poly = plt.fill_between([0, 1, 2], [0, 1, 0], [1, 2, 1])
        assert poly is not None
        plt.close('all')

    def test_pyplot_xticks(self):
        fig, ax = plt.subplots()
        plt.xticks([0, 1, 2, 3])
        assert list(ax.get_xticks()) == [0, 1, 2, 3]
        plt.close('all')

    def test_pyplot_yticks(self):
        fig, ax = plt.subplots()
        plt.yticks([0, 0.5, 1.0])
        assert list(ax.get_yticks()) == [0, 0.5, 1.0]
        plt.close('all')

    def test_pyplot_loglog(self):
        fig, ax = plt.subplots()
        plt.loglog([1, 10, 100], [1, 10, 100])
        assert plt.gca().get_xscale() == 'log'
        plt.close('all')

    def test_pyplot_semilogx(self):
        fig, ax = plt.subplots()
        plt.semilogx([1, 10, 100], [1, 2, 3])
        assert plt.gca().get_xscale() == 'log'
        plt.close('all')

    def test_pyplot_semilogy(self):
        fig, ax = plt.subplots()
        plt.semilogy([1, 2, 3], [1, 10, 100])
        assert plt.gca().get_yscale() == 'log'
        plt.close('all')

    def test_pyplot_step(self):
        fig, ax = plt.subplots()
        lines = plt.step([0, 1, 2, 3], [0, 1, 0, 1])
        assert len(lines) >= 1
        plt.close('all')

    def test_pyplot_hlines(self):
        fig, ax = plt.subplots()
        plt.hlines(y=0.5, xmin=0, xmax=1)
        plt.close('all')

    def test_pyplot_vlines(self):
        fig, ax = plt.subplots()
        plt.vlines(x=0.5, ymin=0, ymax=1)
        plt.close('all')

    def test_pyplot_pie(self):
        fig, ax = plt.subplots()
        result = plt.pie([30, 40, 30])
        assert result is not None
        plt.close('all')


# ------------------------------------------------------------------
# Normalization with numpy arrays
# ------------------------------------------------------------------

class TestNormWithArrays:
    def test_normalize_numpy_array(self):
        norm = Normalize(vmin=0, vmax=10)
        data = [0, 2, 5, 8, 10]
        result = norm(data)
        assert len(result) == 5
        assert abs(result[0] - 0.0) < 1e-9
        assert abs(result[2] - 0.5) < 1e-9
        assert abs(result[4] - 1.0) < 1e-9

    def test_normalize_clip_list(self):
        norm = Normalize(vmin=0, vmax=10, clip=True)
        result = norm([-5, 0, 5, 10, 15])
        assert abs(result[0] - 0.0) < 1e-9  # clipped
        assert abs(result[4] - 1.0) < 1e-9  # clipped

    def test_log_norm_list(self):
        norm = LogNorm(vmin=1, vmax=1000)
        result = norm([1, 10, 100, 1000])
        assert len(result) == 4
        assert result[0] < result[1] < result[2] < result[3]


from matplotlib.colors import LogNorm
