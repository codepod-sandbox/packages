"""
Upstream tests for colorbar patterns commonly used by LLMs.
"""

import numpy as np
import pytest
import matplotlib.pyplot as plt
import matplotlib.cm as cm


class TestColorbarBasic:
    """Basic colorbar patterns."""

    def teardown_method(self):
        plt.close('all')

    def test_colorbar_from_imshow(self):
        fig, ax = plt.subplots()
        im = ax.imshow([[1, 2], [3, 4]])
        cbar = fig.colorbar(im, ax=ax)
        assert cbar is not None

    def test_colorbar_from_scatter(self):
        fig, ax = plt.subplots()
        sc = ax.scatter([1, 2, 3], [4, 5, 6], c=[1, 2, 3])
        cbar = fig.colorbar(sc, ax=ax)
        assert cbar is not None

    def test_colorbar_from_pcolormesh(self):
        fig, ax = plt.subplots()
        x = [0, 1, 2]
        y = [0, 1]
        z = [[1, 2], [3, 4]]
        pc = ax.pcolormesh(x, y, z)
        cbar = fig.colorbar(pc, ax=ax)
        assert cbar is not None

    def test_colorbar_from_contourf(self):
        x = [0, 1, 2]
        y = [0, 1, 2]
        z = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
        fig, ax = plt.subplots()
        cs = ax.contourf(x, y, z)
        cbar = fig.colorbar(cs, ax=ax)
        assert cbar is not None

    def test_colorbar_label(self):
        fig, ax = plt.subplots()
        im = ax.imshow([[1, 2], [3, 4]])
        cbar = fig.colorbar(im, ax=ax)
        cbar.set_label('Intensity')

    def test_colorbar_label_fontsize(self):
        fig, ax = plt.subplots()
        im = ax.imshow([[1, 2], [3, 4]])
        cbar = fig.colorbar(im, ax=ax)
        cbar.set_label('Value', fontsize=12)

    def test_colorbar_orientation_vertical(self):
        fig, ax = plt.subplots()
        im = ax.imshow([[1, 2], [3, 4]])
        cbar = fig.colorbar(im, ax=ax, orientation='vertical')
        assert cbar is not None

    def test_colorbar_orientation_horizontal(self):
        fig, ax = plt.subplots()
        im = ax.imshow([[1, 2], [3, 4]])
        cbar = fig.colorbar(im, ax=ax, orientation='horizontal')
        assert cbar is not None

    def test_colorbar_shrink(self):
        fig, ax = plt.subplots()
        im = ax.imshow([[1, 2], [3, 4]])
        cbar = fig.colorbar(im, ax=ax, shrink=0.8)
        assert cbar is not None

    def test_colorbar_aspect(self):
        fig, ax = plt.subplots()
        im = ax.imshow([[1, 2], [3, 4]])
        cbar = fig.colorbar(im, ax=ax, aspect=10)
        assert cbar is not None

    def test_colorbar_pad(self):
        fig, ax = plt.subplots()
        im = ax.imshow([[1, 2], [3, 4]])
        cbar = fig.colorbar(im, ax=ax, pad=0.05)
        assert cbar is not None

    def test_colorbar_fraction(self):
        fig, ax = plt.subplots()
        im = ax.imshow([[1, 2], [3, 4]])
        cbar = fig.colorbar(im, ax=ax, fraction=0.046)
        assert cbar is not None

    def test_plt_colorbar(self):
        fig, ax = plt.subplots()
        im = ax.imshow([[1, 2], [3, 4]])
        cbar = plt.colorbar(im, ax=ax)
        assert cbar is not None

    def test_colorbar_ticks(self):
        fig, ax = plt.subplots()
        im = ax.imshow([[1, 2], [3, 4]])
        cbar = fig.colorbar(im, ax=ax)
        cbar.set_ticks([1, 2, 3, 4])

    def test_colorbar_ticklabels(self):
        fig, ax = plt.subplots()
        im = ax.imshow([[1, 2], [3, 4]])
        cbar = fig.colorbar(im, ax=ax)
        cbar.set_ticks([1, 2, 3, 4])
        cbar.set_ticklabels(['low', 'mid-low', 'mid-high', 'high'])

    def test_colorbar_tick_params(self):
        fig, ax = plt.subplots()
        im = ax.imshow([[1, 2], [3, 4]])
        cbar = fig.colorbar(im, ax=ax)
        cbar.ax.tick_params(labelsize=8)


class TestColorbarMultiPanel:
    """Tests for colorbar in multi-panel layouts."""

    def teardown_method(self):
        plt.close('all')

    def test_colorbar_shared_across_panels(self):
        fig, axes = plt.subplots(1, 2)
        im1 = axes[0].imshow([[1, 2], [3, 4]])
        im2 = axes[1].imshow([[5, 6], [7, 8]])
        # Single colorbar for both
        cbar = fig.colorbar(im1, ax=axes.tolist() if hasattr(axes, 'tolist') else list(axes))
        assert cbar is not None

    def test_colorbar_each_panel(self):
        fig, axes = plt.subplots(1, 2)
        for i, ax in enumerate(axes):
            im = ax.imshow([[i, i+1], [i+2, i+3]])
            fig.colorbar(im, ax=ax)

    def test_colorbar_outside_plot(self):
        fig, ax = plt.subplots()
        im = ax.imshow([[1, 2, 3], [4, 5, 6]])
        cbar = fig.colorbar(im, ax=ax, pad=0.1)
        cbar.set_label('Scale')
        plt.tight_layout()

    def test_colorbar_extend_both(self):
        fig, ax = plt.subplots()
        im = ax.imshow([[1, 2], [3, 4]])
        cbar = fig.colorbar(im, ax=ax, extend='both')
        assert cbar is not None

    def test_colorbar_extend_min(self):
        fig, ax = plt.subplots()
        im = ax.imshow([[1, 2], [3, 4]])
        cbar = fig.colorbar(im, ax=ax, extend='min')
        assert cbar is not None

    def test_colorbar_extend_max(self):
        fig, ax = plt.subplots()
        im = ax.imshow([[1, 2], [3, 4]])
        cbar = fig.colorbar(im, ax=ax, extend='max')
        assert cbar is not None
