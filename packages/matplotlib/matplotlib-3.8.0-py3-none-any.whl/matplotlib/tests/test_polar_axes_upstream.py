"""Tests for polar axes."""

import pytest
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches


class TestPolarBasic:
    def test_polar_subplot(self):
        """Creating a polar subplot does not raise."""
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='polar')
        assert ax is not None
        plt.close('all')

    def test_polar_plot(self):
        """Plotting on polar axes does not raise."""
        fig, ax = plt.subplots(subplot_kw={'projection': 'polar'})
        theta = np.linspace(0, 2 * np.pi, 100)
        r = np.ones(100)
        ax.plot(theta, r)
        plt.close('all')

    def test_polar_scatter(self):
        """Scatter on polar axes does not raise."""
        fig, ax = plt.subplots(subplot_kw={'projection': 'polar'})
        theta = np.array([0, np.pi/2, np.pi, 3*np.pi/2])
        r = np.array([1, 2, 1.5, 0.5])
        ax.scatter(theta, r)
        plt.close('all')

    def test_polar_bar(self):
        """bar on polar axes does not raise."""
        fig, ax = plt.subplots(subplot_kw={'projection': 'polar'})
        N = 8
        theta = np.linspace(0.0, 2 * np.pi, N, endpoint=False)
        radii = np.random.default_rng(1).uniform(1, 10, N)
        width = 2 * np.pi / N
        ax.bar(theta, radii, width=width, bottom=0.0)
        plt.close('all')

    def test_polar_fill(self):
        """fill on polar axes does not raise."""
        fig, ax = plt.subplots(subplot_kw={'projection': 'polar'})
        theta = np.linspace(0, 2 * np.pi, 50)
        r = 1 + 0.3 * np.sin(4 * theta)
        ax.fill(theta, r, alpha=0.3)
        plt.close('all')

    def test_polar_set_rlim(self):
        """ax.set_rlim() does not raise."""
        fig, ax = plt.subplots(subplot_kw={'projection': 'polar'})
        ax.plot([0, np.pi], [1, 2])
        ax.set_rlim(0, 3)
        plt.close('all')

    def test_polar_set_rticks(self):
        """ax.set_rticks() does not raise."""
        fig, ax = plt.subplots(subplot_kw={'projection': 'polar'})
        ax.plot([0, np.pi], [1, 2])
        ax.set_rticks([0.5, 1.0, 1.5, 2.0])
        plt.close('all')

    def test_polar_set_thetalim(self):
        """ax.set_thetalim() does not raise."""
        fig, ax = plt.subplots(subplot_kw={'projection': 'polar'})
        ax.plot([0, np.pi], [1, 2])
        ax.set_thetalim(0, np.pi)
        plt.close('all')

    def test_polar_set_theta_zero_location(self):
        """ax.set_theta_zero_location() does not raise."""
        fig, ax = plt.subplots(subplot_kw={'projection': 'polar'})
        ax.set_theta_zero_location('N')
        plt.close('all')

    def test_polar_set_theta_direction(self):
        """ax.set_theta_direction(-1) does not raise."""
        fig, ax = plt.subplots(subplot_kw={'projection': 'polar'})
        ax.set_theta_direction(-1)
        plt.close('all')

    def test_polar_set_rlabel_position(self):
        """ax.set_rlabel_position() does not raise."""
        fig, ax = plt.subplots(subplot_kw={'projection': 'polar'})
        ax.set_rlabel_position(45)
        plt.close('all')

    def test_polar_svg(self):
        """Polar plot renders to SVG."""
        fig, ax = plt.subplots(subplot_kw={'projection': 'polar'})
        theta = np.linspace(0, 2 * np.pi, 10)
        ax.plot(theta, np.ones(10))
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_polar_via_subplot_kw(self):
        """subplots with subplot_kw works."""
        fig, ax = plt.subplots(1, 1, subplot_kw=dict(projection='polar'))
        assert ax is not None
        plt.close('all')

    def test_polar_multiple_plots(self):
        """Multiple plots on polar axes do not raise."""
        fig, ax = plt.subplots(subplot_kw={'projection': 'polar'})
        theta = np.linspace(0, 2 * np.pi, 50)
        ax.plot(theta, np.sin(theta) + 1)
        ax.plot(theta, np.cos(theta) + 1, 'r--')
        plt.close('all')

    def test_polar_grid(self):
        """Grid on polar axes does not raise."""
        fig, ax = plt.subplots(subplot_kw={'projection': 'polar'})
        ax.grid(True)
        plt.close('all')

    def test_polar_title(self):
        """Title on polar axes does not raise."""
        fig, ax = plt.subplots(subplot_kw={'projection': 'polar'})
        ax.set_title('Polar Plot')
        plt.close('all')
