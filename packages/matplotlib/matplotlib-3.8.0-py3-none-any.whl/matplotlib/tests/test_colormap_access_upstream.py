"""Tests for colormap access (plt.cm, matplotlib.cm), norms, and ScalarMappable."""

import pytest
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.cm as cm
import matplotlib.colors as mcolors
from matplotlib.colors import Normalize, LogNorm


# ---------------------------------------------------------------------------
# plt.cm attribute access
# ---------------------------------------------------------------------------

class TestPltCmAccess:
    def test_plt_cm_viridis(self):
        """plt.cm.viridis returns a colormap."""
        cmap = plt.cm.viridis
        assert cmap is not None
        assert cmap.name == 'viridis'

    def test_plt_cm_plasma(self):
        """plt.cm.plasma returns a colormap."""
        cmap = plt.cm.plasma
        assert cmap is not None

    def test_plt_cm_hot(self):
        """plt.cm.hot returns a colormap."""
        cmap = plt.cm.hot
        assert cmap is not None

    def test_plt_cm_coolwarm(self):
        """plt.cm.coolwarm returns a colormap."""
        cmap = plt.cm.coolwarm
        assert cmap is not None

    def test_plt_cm_gray(self):
        """plt.cm.gray returns a colormap."""
        cmap = plt.cm.gray
        assert cmap is not None

    def test_cmap_callable(self):
        """colormap can be called with a float 0-1."""
        cmap = plt.cm.viridis
        rgba = cmap(0.5)
        assert len(rgba) == 4  # (r, g, b, a)
        assert all(0.0 <= v <= 1.0 for v in rgba)

    def test_cmap_returns_different_colors(self):
        """cmap(0.0) and cmap(1.0) return different colors."""
        cmap = plt.cm.viridis
        c0 = cmap(0.0)
        c1 = cmap(1.0)
        assert c0 != c1

    def test_cm_get_cmap(self):
        """cm.get_cmap() returns a colormap."""
        cmap = cm.get_cmap('viridis')
        assert cmap is not None
        assert cmap.name == 'viridis'

    def test_cm_module_attribute(self):
        """cm.viridis returns same as get_cmap('viridis')."""
        cmap_attr = cm.viridis
        cmap_fn = cm.get_cmap('viridis')
        assert cmap_attr.name == cmap_fn.name


# ---------------------------------------------------------------------------
# matplotlib.colors.Normalize
# ---------------------------------------------------------------------------

class TestNormalize:
    def test_normalize_basic(self):
        """Normalize maps [vmin, vmax] to [0, 1]."""
        norm = Normalize(vmin=0, vmax=10)
        assert norm(0) == pytest.approx(0.0)
        assert norm(10) == pytest.approx(1.0)
        assert norm(5) == pytest.approx(0.5)

    def test_normalize_clipping(self):
        """Normalize clamps values outside [vmin, vmax]."""
        norm = Normalize(vmin=0, vmax=10, clip=True)
        assert norm(-5) == pytest.approx(0.0)
        assert norm(15) == pytest.approx(1.0)

    def test_normalize_auto_from_array(self):
        """Normalize can autoscale from a list."""
        norm = Normalize()
        norm.autoscale([0, 50, 100])
        assert norm.vmin == pytest.approx(0.0)
        assert norm.vmax == pytest.approx(100.0)

    def test_lognorm_basic(self):
        """LogNorm maps log-scale values."""
        norm = LogNorm(vmin=1, vmax=1000)
        # log10(1)=0, log10(1000)=3 → normalized to [0,1]
        assert norm(1) == pytest.approx(0.0)
        assert norm(1000) == pytest.approx(1.0)
        # log10(100) = 2 → 2/3 ≈ 0.667
        assert norm(100) == pytest.approx(2/3, abs=0.01)

    def test_twoslopenorm(self):
        """TwoSlopeNorm maps diverging data around vcenter=0."""
        norm = mcolors.TwoSlopeNorm(vmin=-10, vcenter=0, vmax=100)
        assert norm(0) == pytest.approx(0.5)
        assert norm(-10) == pytest.approx(0.0, abs=0.01)
        assert norm(100) == pytest.approx(1.0, abs=0.01)

    def test_boundary_norm(self):
        """BoundaryNorm maps values to discrete bins."""
        norm = mcolors.BoundaryNorm([0, 10, 20, 50], ncolors=256)
        assert norm is not None

    def test_normalize_imshow(self):
        """imshow with norm=Normalize does not raise."""
        fig, ax = plt.subplots()
        norm = Normalize(vmin=0, vmax=10)
        ax.imshow([[1, 5], [7, 10]], norm=norm)
        plt.close('all')


# ---------------------------------------------------------------------------
# ScalarMappable
# ---------------------------------------------------------------------------

class TestScalarMappable:
    def test_scalarmappable_basic(self):
        """ScalarMappable can be created with a colormap."""
        from matplotlib.cm import ScalarMappable
        sm = ScalarMappable(cmap='viridis')
        assert sm is not None

    def test_scalarmappable_to_rgba(self):
        """ScalarMappable.to_rgba() maps a scalar to RGBA."""
        from matplotlib.cm import ScalarMappable
        sm = ScalarMappable(cmap='viridis')
        sm.set_clim(0, 100)
        rgba = sm.to_rgba(50)
        assert len(rgba) == 4
        assert all(0 <= v <= 1 for v in rgba)

    def test_scalarmappable_set_get_clim(self):
        """ScalarMappable set_clim / get_clim round-trip."""
        from matplotlib.cm import ScalarMappable
        sm = ScalarMappable(cmap='hot')
        sm.set_clim(10, 90)
        vmin, vmax = sm.get_clim()
        assert vmin == pytest.approx(10)
        assert vmax == pytest.approx(90)

    def test_scalarmappable_get_cmap(self):
        """ScalarMappable.get_cmap() returns the colormap."""
        from matplotlib.cm import ScalarMappable
        sm = ScalarMappable(cmap='plasma')
        cmap = sm.get_cmap()
        assert cmap is not None


# ---------------------------------------------------------------------------
# matplotlib.colors utilities
# ---------------------------------------------------------------------------

class TestColorsUtilities:
    def test_to_hex_named(self):
        """to_hex converts named colors to hex."""
        from matplotlib.colors import to_hex
        assert to_hex('red') == '#ff0000'
        assert to_hex('blue') == '#0000ff'
        assert to_hex('white') == '#ffffff'
        assert to_hex('black') == '#000000'

    def test_to_hex_rgb_tuple(self):
        """to_hex converts (r, g, b) tuple to hex."""
        from matplotlib.colors import to_hex
        result = to_hex((1.0, 0.0, 0.0))
        assert result == '#ff0000'

    def test_to_rgba_named(self):
        """to_rgba converts named colors to (r, g, b, a)."""
        from matplotlib.colors import to_rgba
        r, g, b, a = to_rgba('red')
        assert r == pytest.approx(1.0)
        assert g == pytest.approx(0.0)
        assert b == pytest.approx(0.0)
        assert a == pytest.approx(1.0)

    def test_to_rgba_with_alpha(self):
        """to_rgba with explicit alpha."""
        from matplotlib.colors import to_rgba
        r, g, b, a = to_rgba('blue', alpha=0.5)
        assert a == pytest.approx(0.5)

    def test_is_color_like(self):
        """is_color_like returns True for valid colors."""
        from matplotlib.colors import is_color_like
        assert is_color_like('red')
        assert is_color_like('#ff0000')
        assert is_color_like((1, 0, 0))
        assert is_color_like((1, 0, 0, 0.5))
        assert not is_color_like('notacolor')

    def test_colormap_list(self):
        """Common colormaps are registered."""
        for name in ['viridis', 'plasma', 'hot', 'coolwarm', 'gray', 'jet']:
            cmap = cm.get_cmap(name)
            assert cmap is not None, f"{name} not found"


# ---------------------------------------------------------------------------
# Colormap usage in plots
# ---------------------------------------------------------------------------

class TestColormapInPlots:
    def test_scatter_with_cmap_object(self):
        """scatter accepts a colormap object for cmap."""
        fig, ax = plt.subplots()
        cmap = plt.cm.plasma
        ax.scatter([1, 2, 3], [1, 2, 3], c=[1, 2, 3], cmap=cmap)
        plt.close('all')

    def test_imshow_with_cmap_object(self):
        """imshow accepts a colormap object for cmap."""
        fig, ax = plt.subplots()
        cmap = cm.get_cmap('hot')
        ax.imshow([[1, 2], [3, 4]], cmap=cmap)
        plt.close('all')

    def test_pcolormesh_with_cmap_object(self):
        """pcolormesh accepts a colormap object for cmap."""
        fig, ax = plt.subplots()
        cmap = plt.cm.viridis
        ax.pcolormesh([[1, 2], [3, 4]], cmap=cmap)
        plt.close('all')

    def test_colorbar_with_cmap_renders(self):
        """imshow + colorbar renders with custom cmap."""
        fig, ax = plt.subplots()
        im = ax.imshow([[0, 50], [100, 200]], cmap='coolwarm')
        fig.colorbar(im, ax=ax)
        svg = fig.to_svg()
        assert '<rect' in svg
        plt.close('all')
