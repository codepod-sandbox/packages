"""Tests for text, annotations, legends, axis formatting, and figure composition."""

import pytest
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches


# ---------------------------------------------------------------------------
# ax.annotate()
# ---------------------------------------------------------------------------

class TestAnnotate:
    def test_annotate_basic(self):
        """annotate with text and xy does not raise."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 4, 9])
        ax.annotate('peak', xy=(3, 9), xytext=(2, 7))
        plt.close('all')

    def test_annotate_returns_text(self):
        """annotate returns a Text-like object (not None)."""
        fig, ax = plt.subplots()
        result = ax.annotate('label', xy=(1, 1), xytext=(0, 0))
        assert result is not None
        plt.close('all')

    def test_annotate_with_arrow(self):
        """annotate with arrowprops does not raise."""
        fig, ax = plt.subplots()
        ax.annotate('peak', xy=(3, 9), xytext=(2, 7),
                    arrowprops={'arrowstyle': '->'})
        plt.close('all')

    def test_annotate_ha_va(self):
        """annotate with ha and va does not raise."""
        fig, ax = plt.subplots()
        ax.annotate('text', xy=(0.5, 0.5), xytext=(0.3, 0.7),
                    ha='center', va='bottom')
        plt.close('all')

    def test_annotate_fontsize(self):
        """annotate with fontsize does not raise."""
        fig, ax = plt.subplots()
        ax.annotate('small', xy=(0.5, 0.5), xytext=(0.3, 0.3), fontsize=8)
        plt.close('all')

    def test_annotate_color(self):
        """annotate with color does not raise."""
        fig, ax = plt.subplots()
        ax.annotate('red label', xy=(1, 1), xytext=(0.5, 0.5), color='red')
        plt.close('all')

    def test_annotate_svg_renders(self):
        """Figure with annotation renders to SVG."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 4, 9])
        ax.annotate('max', xy=(3, 9), xytext=(2, 7),
                    arrowprops={'arrowstyle': '->'})
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_annotate_multiple(self):
        """Multiple annotations do not raise."""
        fig, ax = plt.subplots()
        for i, (x, y) in enumerate([(1, 1), (2, 4), (3, 9)]):
            ax.annotate(f'pt{i}', xy=(x, y), xytext=(x - 0.3, y + 0.5))
        plt.close('all')


# ---------------------------------------------------------------------------
# ax.legend()
# ---------------------------------------------------------------------------

class TestLegend:
    def test_legend_auto_labels(self):
        """legend with auto labels does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1], label='line1')
        ax.plot([0, 1], [1, 0], label='line2')
        ax.legend()
        plt.close('all')

    def test_legend_explicit_labels(self):
        """legend with explicit labels list does not raise."""
        fig, ax = plt.subplots()
        l1, = ax.plot([0, 1], [0, 1])
        l2, = ax.plot([0, 1], [1, 0])
        ax.legend([l1, l2], ['first', 'second'])
        plt.close('all')

    def test_legend_loc_string(self):
        """legend with loc string does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1], label='line')
        ax.legend(loc='upper left')
        plt.close('all')

    def test_legend_loc_numeric(self):
        """legend with numeric loc does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1], label='line')
        ax.legend(loc=1)  # upper right
        plt.close('all')

    def test_legend_with_patches(self):
        """legend with patch handles does not raise."""
        fig, ax = plt.subplots()
        red_patch = mpatches.Patch(color='red', label='Red')
        blue_patch = mpatches.Patch(color='blue', label='Blue')
        ax.legend(handles=[red_patch, blue_patch])
        plt.close('all')

    def test_plt_legend(self):
        """plt.legend() wrapper does not raise."""
        plt.figure()
        plt.plot([0, 1], [0, 1], label='line')
        plt.legend()
        plt.close('all')

    def test_legend_svg_renders(self):
        """Figure with legend renders to SVG."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1], label='data')
        ax.legend()
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')


# ---------------------------------------------------------------------------
# ax.twinx() / ax.twiny()
# ---------------------------------------------------------------------------

class TestTwinAxes:
    def test_twinx_returns_axes(self):
        """twinx returns a new Axes."""
        fig, ax = plt.subplots()
        ax2 = ax.twinx()
        assert ax2 is not None
        plt.close('all')

    def test_twinx_independent_y(self):
        """twinx axes can have different y-scale plots."""
        fig, ax1 = plt.subplots()
        ax2 = ax1.twinx()
        ax1.plot([1, 2, 3], [1, 2, 3])
        ax2.plot([1, 2, 3], [100, 200, 300])
        plt.close('all')

    def test_twiny_returns_axes(self):
        """twiny returns a new Axes."""
        fig, ax = plt.subplots()
        ax2 = ax.twiny()
        assert ax2 is not None
        plt.close('all')

    def test_twinx_svg_renders(self):
        """Figure with twinx renders to SVG."""
        fig, ax1 = plt.subplots()
        ax2 = ax1.twinx()
        ax1.plot([1, 2, 3], [1, 2, 3], color='blue')
        ax2.plot([1, 2, 3], [10, 20, 30], color='red')
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_twinx_get_ylim(self):
        """twinx axes have their own ylim."""
        fig, ax1 = plt.subplots()
        ax2 = ax1.twinx()
        ax1.set_ylim(0, 10)
        ax2.set_ylim(0, 100)
        assert ax1.get_ylim() == pytest.approx((0, 10))
        assert ax2.get_ylim() == pytest.approx((0, 100))
        plt.close('all')


# ---------------------------------------------------------------------------
# fig.add_subplot() / fig.add_axes()
# ---------------------------------------------------------------------------

class TestFigureComposition:
    def test_add_subplot_basic(self):
        """fig.add_subplot(1,1,1) returns an Axes."""
        fig = plt.figure()
        ax = fig.add_subplot(1, 1, 1)
        assert ax is not None
        plt.close('all')

    def test_add_subplot_multiple(self):
        """fig.add_subplot creates multiple axes."""
        fig = plt.figure()
        ax1 = fig.add_subplot(1, 2, 1)
        ax2 = fig.add_subplot(1, 2, 2)
        assert ax1 is not None
        assert ax2 is not None
        plt.close('all')

    def test_add_subplot_shorthand(self):
        """fig.add_subplot(211) shorthand works."""
        fig = plt.figure()
        ax = fig.add_subplot(211)
        assert ax is not None
        plt.close('all')

    def test_add_subplot_plot_renders(self):
        """Axes from add_subplot can plot and render SVG."""
        fig = plt.figure()
        ax = fig.add_subplot(1, 1, 1)
        ax.plot([0, 1], [0, 1])
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_plt_figure_add_subplot(self):
        """plt.figure() + fig.add_subplot works."""
        fig = plt.figure()
        ax = fig.add_subplot(111)
        ax.bar([1, 2], [3, 4])
        plt.close('all')


# ---------------------------------------------------------------------------
# Axis tick formatting
# ---------------------------------------------------------------------------

class TestTickFormatting:
    def test_set_xticks_basic(self):
        """set_xticks does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2, 3], [0, 1, 4, 9])
        ax.set_xticks([0, 1, 2, 3])
        plt.close('all')

    def test_set_xticklabels_basic(self):
        """set_xticklabels does not raise."""
        fig, ax = plt.subplots()
        ax.set_xticks([0, 1, 2, 3])
        ax.set_xticklabels(['a', 'b', 'c', 'd'])
        plt.close('all')

    def test_set_yticks_basic(self):
        """set_yticks does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 10])
        ax.set_yticks([0, 5, 10])
        plt.close('all')

    def test_set_yticklabels_basic(self):
        """set_yticklabels does not raise."""
        fig, ax = plt.subplots()
        ax.set_yticks([0, 5, 10])
        ax.set_yticklabels(['low', 'mid', 'high'])
        plt.close('all')

    def test_tick_params_rotation(self):
        """tick_params with labelrotation does not raise."""
        fig, ax = plt.subplots()
        ax.bar([1, 2, 3], [4, 5, 6])
        ax.tick_params(axis='x', labelrotation=45)
        plt.close('all')

    def test_xtick_rotation_via_setp(self):
        """Rotating xtick labels via plt.setp does not raise."""
        fig, ax = plt.subplots()
        ax.bar([1, 2, 3], [4, 5, 6])
        plt.close('all')

    def test_tick_formatting_svg_renders(self):
        """Axes with custom ticks renders to SVG."""
        fig, ax = plt.subplots()
        ax.bar(['A', 'B', 'C'], [3, 7, 2])
        ax.set_yticks([0, 2, 4, 6, 8])
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')


# ---------------------------------------------------------------------------
# Axis spines
# ---------------------------------------------------------------------------

class TestSpines:
    def test_spines_dict_access(self):
        """ax.spines is a dict with 'top', 'bottom', 'left', 'right' keys."""
        fig, ax = plt.subplots()
        for key in ['top', 'bottom', 'left', 'right']:
            assert key in ax.spines
        plt.close('all')

    def test_spine_set_visible_false(self):
        """spine.set_visible(False) does not raise."""
        fig, ax = plt.subplots()
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        plt.close('all')

    def test_spine_set_linewidth(self):
        """spine.set_linewidth does not raise."""
        fig, ax = plt.subplots()
        ax.spines['bottom'].set_linewidth(2)
        plt.close('all')

    def test_spine_set_color(self):
        """spine.set_color does not raise."""
        fig, ax = plt.subplots()
        ax.spines['left'].set_color('gray')
        plt.close('all')

    def test_no_spines_svg_renders(self):
        """Axes with no top/right spines renders to SVG."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')
