"""Tests for Axes API: xaxis/yaxis, get_lines, get_children, figure API."""

import pytest
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches


# ---------------------------------------------------------------------------
# ax.xaxis / ax.yaxis attributes
# ---------------------------------------------------------------------------

class TestXYAxis:
    def test_xaxis_exists(self):
        """ax.xaxis is accessible."""
        fig, ax = plt.subplots()
        assert ax.xaxis is not None
        plt.close('all')

    def test_yaxis_exists(self):
        """ax.yaxis is accessible."""
        fig, ax = plt.subplots()
        assert ax.yaxis is not None
        plt.close('all')

    def test_xaxis_set_major_formatter(self):
        """ax.xaxis.set_major_formatter does not raise."""
        import matplotlib.ticker as ticker
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2], [0, 1, 4])
        ax.xaxis.set_major_formatter(ticker.FormatStrFormatter('%d'))
        plt.close('all')

    def test_xaxis_set_major_locator(self):
        """ax.xaxis.set_major_locator does not raise."""
        import matplotlib.ticker as ticker
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2], [0, 1, 4])
        ax.xaxis.set_major_locator(ticker.FixedLocator([0, 1, 2]))
        plt.close('all')

    def test_yaxis_set_major_formatter(self):
        """ax.yaxis.set_major_formatter does not raise."""
        import matplotlib.ticker as ticker
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 100])
        ax.yaxis.set_major_formatter(ticker.FuncFormatter(lambda x, _: f'{x:.0f}%'))
        plt.close('all')

    def test_xaxis_label_text(self):
        """ax.xaxis.label.set_text does not raise."""
        fig, ax = plt.subplots()
        ax.set_xlabel('X Axis')
        ax.xaxis.label.set_text('New Label')
        plt.close('all')


# ---------------------------------------------------------------------------
# ax.get_lines() / figure axes collection
# ---------------------------------------------------------------------------

class TestAxesRetrieval:
    def test_get_lines(self):
        """ax.get_lines() returns list of lines."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        ax.plot([0, 1], [1, 0])
        lines = ax.get_lines()
        assert len(lines) == 2
        plt.close('all')

    def test_get_lines_empty(self):
        """ax.get_lines() returns empty list when no lines."""
        fig, ax = plt.subplots()
        lines = ax.get_lines()
        assert len(lines) == 0
        plt.close('all')

    def test_fig_get_axes(self):
        """fig.get_axes() returns list of Axes."""
        fig, (ax1, ax2) = plt.subplots(1, 2)
        axes = fig.get_axes()
        assert len(axes) == 2
        plt.close('all')

    def test_fig_axes_attribute(self):
        """fig.axes returns list of Axes."""
        fig, axes_row = plt.subplots(1, 3)
        axes_list = fig.axes
        assert len(axes_list) == 3
        plt.close('all')

    def test_ax_get_title(self):
        """ax.get_title() returns set title."""
        fig, ax = plt.subplots()
        ax.set_title('My Title')
        assert ax.get_title() == 'My Title'
        plt.close('all')

    def test_ax_get_xlim_default(self):
        """ax.get_xlim() returns default limits."""
        fig, ax = plt.subplots()
        xlim = ax.get_xlim()
        assert len(xlim) == 2
        plt.close('all')


# ---------------------------------------------------------------------------
# Wedge patch (pie-like, used in pie charts)
# ---------------------------------------------------------------------------

class TestWedgePatch:
    def test_wedge_basic(self):
        """Wedge patch can be created and added."""
        from matplotlib.patches import Wedge
        fig, ax = plt.subplots()
        w = Wedge((0.5, 0.5), 0.3, 0, 90)
        ax.add_patch(w)
        plt.close('all')

    def test_wedge_with_color(self):
        """Wedge with facecolor does not raise."""
        from matplotlib.patches import Wedge
        fig, ax = plt.subplots()
        w = Wedge((0.5, 0.5), 0.3, 0, 120, facecolor='red', alpha=0.5)
        ax.add_patch(w)
        plt.close('all')

    def test_wedge_svg_renders(self):
        """Wedge renders to SVG."""
        from matplotlib.patches import Wedge
        fig, ax = plt.subplots()
        for i, (start, end, color) in enumerate([(0, 90, 'red'), (90, 180, 'blue')]):
            w = Wedge((0.5, 0.5), 0.3, start, end, facecolor=color)
            ax.add_patch(w)
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')


# ---------------------------------------------------------------------------
# Arrow patch
# ---------------------------------------------------------------------------

class TestArrowPatch:
    def test_arrow_basic(self):
        """mpatches.Arrow can be created."""
        fig, ax = plt.subplots()
        arrow = mpatches.Arrow(0.1, 0.1, 0.5, 0.5)
        ax.add_patch(arrow)
        plt.close('all')

    def test_arrow_with_width(self):
        """Arrow with width kwarg does not raise."""
        fig, ax = plt.subplots()
        arrow = mpatches.Arrow(0, 0, 1, 0, width=0.1)
        ax.add_patch(arrow)
        plt.close('all')

    def test_arrow_color(self):
        """Arrow with color does not raise."""
        fig, ax = plt.subplots()
        arrow = mpatches.Arrow(0, 0, 1, 1, color='red')
        ax.add_patch(arrow)
        plt.close('all')


# ---------------------------------------------------------------------------
# ax.set_clip_on() and related style settings
# ---------------------------------------------------------------------------

class TestClipAndStyle:
    def test_set_clip_on(self):
        """set_clip_on does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        ax.set_clip_on(False)
        plt.close('all')

    def test_patch_set_alpha(self):
        """Patch set_alpha does not raise."""
        fig, ax = plt.subplots()
        rect = mpatches.Rectangle((0, 0), 1, 1, alpha=0.3)
        ax.add_patch(rect)
        rect.set_alpha(0.5)
        plt.close('all')

    def test_patch_get_facecolor(self):
        """Patch get_facecolor returns a value."""
        rect = mpatches.Rectangle((0, 0), 1, 1, facecolor='blue')
        fc = rect.get_facecolor()
        assert fc is not None

    def test_patch_get_edgecolor(self):
        """Patch get_edgecolor returns a value."""
        rect = mpatches.Rectangle((0, 0), 1, 1, edgecolor='red')
        ec = rect.get_edgecolor()
        assert ec is not None


# ---------------------------------------------------------------------------
# plt.show() / plt.draw() no-ops
# ---------------------------------------------------------------------------

class TestDisplayNoOps:
    def test_plt_show_does_not_raise(self):
        """plt.show() does not raise (no-op without display)."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        plt.show(block=False)
        plt.close('all')

    def test_plt_draw_does_not_raise(self):
        """plt.draw() does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        plt.draw()
        plt.close('all')

    def test_fig_canvas_draw(self):
        """fig.canvas.draw() does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        if hasattr(fig, 'canvas') and fig.canvas is not None:
            fig.canvas.draw()
        plt.close('all')


# ---------------------------------------------------------------------------
# Copy/restore-state patterns
# ---------------------------------------------------------------------------

class TestGetSetState:
    def test_ax_get_xlim_set_xlim_roundtrip(self):
        """get_xlim/set_xlim round-trip."""
        fig, ax = plt.subplots()
        ax.plot([0, 10], [0, 10])
        ax.set_xlim(2, 8)
        xmin, xmax = ax.get_xlim()
        assert xmin == pytest.approx(2)
        assert xmax == pytest.approx(8)
        plt.close('all')

    def test_ax_get_ylim_set_ylim_roundtrip(self):
        """get_ylim/set_ylim round-trip."""
        fig, ax = plt.subplots()
        ax.set_ylim(-5, 15)
        ymin, ymax = ax.get_ylim()
        assert ymin == pytest.approx(-5)
        assert ymax == pytest.approx(15)
        plt.close('all')

    def test_ax_set_xlim_none_keeps_auto(self):
        """set_xlim with None values doesn't raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        ax.set_xlim(None, None)
        plt.close('all')
