"""
Upstream tests for errorbar and uncertainty visualization patterns.
"""

import numpy as np
import pytest
import matplotlib.pyplot as plt


class TestErrorbar:
    """Tests for errorbar patterns."""

    def teardown_method(self):
        plt.close('all')

    def test_errorbar_basic(self):
        fig, ax = plt.subplots()
        ax.errorbar([1, 2, 3], [4, 5, 6], yerr=[0.5, 0.5, 0.5])

    def test_errorbar_symmetric_yerr(self):
        fig, ax = plt.subplots()
        ax.errorbar([1, 2, 3], [4, 5, 6], yerr=0.5)

    def test_errorbar_asymmetric_yerr(self):
        fig, ax = plt.subplots()
        yerr = [[0.3, 0.4, 0.5], [0.5, 0.6, 0.7]]
        ax.errorbar([1, 2, 3], [4, 5, 6], yerr=yerr)

    def test_errorbar_xerr(self):
        fig, ax = plt.subplots()
        ax.errorbar([1, 2, 3], [4, 5, 6], xerr=[0.2, 0.2, 0.2])

    def test_errorbar_both(self):
        fig, ax = plt.subplots()
        ax.errorbar([1, 2, 3], [4, 5, 6],
                   xerr=[0.1, 0.1, 0.1],
                   yerr=[0.5, 0.5, 0.5])

    def test_errorbar_fmt(self):
        fig, ax = plt.subplots()
        ax.errorbar([1, 2, 3], [4, 5, 6], yerr=0.5, fmt='o-')

    def test_errorbar_fmt_none(self):
        fig, ax = plt.subplots()
        ax.errorbar([1, 2, 3], [4, 5, 6], yerr=0.5, fmt='none')

    def test_errorbar_capsize(self):
        fig, ax = plt.subplots()
        ax.errorbar([1, 2, 3], [4, 5, 6], yerr=0.5, capsize=5)

    def test_errorbar_capthick(self):
        fig, ax = plt.subplots()
        ax.errorbar([1, 2, 3], [4, 5, 6], yerr=0.5, capsize=5, capthick=2)

    def test_errorbar_color(self):
        fig, ax = plt.subplots()
        ax.errorbar([1, 2, 3], [4, 5, 6], yerr=0.5, color='red')

    def test_errorbar_ecolor(self):
        fig, ax = plt.subplots()
        ax.errorbar([1, 2, 3], [4, 5, 6], yerr=0.5,
                   fmt='o', ecolor='gray')

    def test_errorbar_elinewidth(self):
        fig, ax = plt.subplots()
        ax.errorbar([1, 2, 3], [4, 5, 6], yerr=0.5, elinewidth=2)

    def test_errorbar_label(self):
        fig, ax = plt.subplots()
        ax.errorbar([1, 2, 3], [4, 5, 6], yerr=0.5, label='data ± σ')
        ax.legend()

    def test_errorbar_alpha(self):
        fig, ax = plt.subplots()
        ax.errorbar([1, 2, 3], [4, 5, 6], yerr=0.5, alpha=0.7)

    def test_errorbar_returns_container(self):
        fig, ax = plt.subplots()
        result = ax.errorbar([1, 2, 3], [4, 5, 6], yerr=0.5)
        assert result is not None

    def test_errorbar_multiple(self):
        """Multiple errorbar series."""
        fig, ax = plt.subplots()
        ax.errorbar([1, 2, 3], [4, 5, 6], yerr=0.5,
                   fmt='b-o', label='Series A')
        ax.errorbar([1, 2, 3], [3, 4, 5], yerr=0.3,
                   fmt='r-s', label='Series B')
        ax.legend()


class TestSpecialPlots:
    """Tests for less common but useful plot types."""

    def teardown_method(self):
        plt.close('all')

    def test_step_basic(self):
        fig, ax = plt.subplots()
        ax.step([1, 2, 3, 4], [1, 2, 1, 3])

    def test_step_pre(self):
        fig, ax = plt.subplots()
        ax.step([1, 2, 3, 4], [1, 2, 1, 3], where='pre')

    def test_step_post(self):
        fig, ax = plt.subplots()
        ax.step([1, 2, 3, 4], [1, 2, 1, 3], where='post')

    def test_step_mid(self):
        fig, ax = plt.subplots()
        ax.step([1, 2, 3, 4], [1, 2, 1, 3], where='mid')

    def test_stairs_basic(self):
        fig, ax = plt.subplots()
        ax.stairs([1, 2, 1, 3], [0, 1, 2, 3, 4])

    def test_stairs_fill(self):
        fig, ax = plt.subplots()
        ax.stairs([1, 2, 1, 3], [0, 1, 2, 3, 4], fill=True)

    def test_stem_basic(self):
        fig, ax = plt.subplots()
        ax.stem([1, 2, 3], [1, 4, 2])

    def test_stem_linefmt(self):
        fig, ax = plt.subplots()
        ax.stem([1, 2, 3], [1, 4, 2], linefmt='b-', markerfmt='bo')

    def test_stackplot_basic(self):
        fig, ax = plt.subplots()
        x = [1, 2, 3, 4]
        y1 = [1, 2, 3, 2]
        y2 = [2, 1, 2, 3]
        ax.stackplot(x, y1, y2)

    def test_stackplot_labels(self):
        fig, ax = plt.subplots()
        x = [1, 2, 3]
        ax.stackplot(x, [1, 2, 1], [2, 1, 2], labels=['A', 'B'])
        ax.legend()

    def test_eventplot_basic(self):
        fig, ax = plt.subplots()
        positions = [1, 2, 3, 4, 5]
        ax.eventplot(positions)

    def test_eventplot_multiple(self):
        fig, ax = plt.subplots()
        positions = [[1, 2, 3], [1.5, 2.5, 3.5]]
        ax.eventplot(positions)

    def test_broken_barh_basic(self):
        fig, ax = plt.subplots()
        ax.broken_barh([(110, 30), (150, 10)], (10, 9))

    def test_hexbin_basic(self):
        fig, ax = plt.subplots()
        x = list(range(20))
        y = list(range(20))
        ax.hexbin(x, y, gridsize=5)

    def test_spy_basic(self):
        """Spy plot for matrix sparsity."""
        data = [[0, 1, 0], [1, 0, 1], [0, 1, 0]]
        fig, ax = plt.subplots()
        ax.spy(data)

    def test_matshow_basic(self):
        """Matshow for matrix visualization."""
        data = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
        fig, ax = plt.subplots()
        ax.matshow(data)
