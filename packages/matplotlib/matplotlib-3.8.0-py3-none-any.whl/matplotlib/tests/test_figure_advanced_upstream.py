"""Tests for advanced Figure API patterns used by LLMs."""

import pytest
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec


class TestFigureCreation:
    def test_figure_figsize(self):
        fig = plt.figure(figsize=(10, 8))
        assert fig.get_figwidth() == 10
        assert fig.get_figheight() == 8
        plt.close('all')

    def test_figure_dpi(self):
        fig = plt.figure(dpi=150)
        assert fig is not None
        plt.close('all')

    def test_figure_tight_layout(self):
        fig, axes = plt.subplots(2, 2)
        for row in axes:
            for ax in row:
                ax.plot([1, 2])
        fig.tight_layout()
        plt.close('all')

    def test_figure_subplots_adjust(self):
        fig, axes = plt.subplots(2, 2)
        fig.subplots_adjust(hspace=0.4, wspace=0.3)
        plt.close('all')

    def test_figure_add_axes(self):
        fig = plt.figure()
        ax = fig.add_axes([0.1, 0.1, 0.8, 0.8])
        assert ax is not None
        plt.close('all')

    def test_figure_clf(self):
        fig, ax = plt.subplots()
        ax.plot([1, 2])
        fig.clf()
        plt.close('all')

    def test_figure_clear(self):
        fig, ax = plt.subplots()
        ax.plot([1, 2])
        fig.clear()
        plt.close('all')

    def test_figure_patch(self):
        """fig.patch returns background rectangle."""
        fig = plt.figure()
        assert fig.patch is not None
        plt.close('all')

    def test_figure_get_axes(self):
        """fig.get_axes() returns list of axes."""
        fig, axes = plt.subplots(1, 2)
        ax_list = fig.get_axes()
        assert len(ax_list) == 2
        plt.close('all')

    def test_figure_axes_attribute(self):
        """fig.axes is same as get_axes()."""
        fig, axes = plt.subplots(1, 2)
        assert len(fig.axes) == 2
        plt.close('all')


class TestFigureText:
    def test_suptitle(self):
        fig, axes = plt.subplots(1, 2)
        fig.suptitle('Main Title')
        plt.close('all')

    def test_suptitle_fontsize(self):
        fig, axes = plt.subplots(1, 2)
        fig.suptitle('Main Title', fontsize=16)
        plt.close('all')

    def test_suptitle_y(self):
        fig, axes = plt.subplots(1, 2)
        fig.suptitle('Main Title', y=1.02)
        plt.close('all')

    def test_figtext(self):
        fig = plt.figure()
        fig.text(0.5, 0.01, 'figure text', ha='center')
        plt.close('all')

    def test_supxlabel(self):
        """fig.supxlabel() does not raise."""
        fig, axes = plt.subplots(2, 1)
        fig.supxlabel('Common X Label')
        plt.close('all')

    def test_supylabel(self):
        """fig.supylabel() does not raise."""
        fig, axes = plt.subplots(1, 2)
        fig.supylabel('Common Y Label')
        plt.close('all')


class TestFigureSize:
    def test_set_size_inches(self):
        fig = plt.figure()
        fig.set_size_inches(8, 6)
        assert fig.get_figwidth() == 8
        assert fig.get_figheight() == 6
        plt.close('all')

    def test_get_size_inches(self):
        fig = plt.figure(figsize=(7, 5))
        w, h = fig.get_size_inches()
        assert w == 7
        assert h == 5
        plt.close('all')

    def test_set_figwidth(self):
        fig = plt.figure()
        fig.set_figwidth(12)
        assert fig.get_figwidth() == 12
        plt.close('all')

    def test_set_figheight(self):
        fig = plt.figure()
        fig.set_figheight(9)
        assert fig.get_figheight() == 9
        plt.close('all')

    def test_set_dpi(self):
        fig = plt.figure()
        fig.set_dpi(200)
        assert fig.get_dpi() == 200
        plt.close('all')


class TestFigureColorbar:
    def test_colorbar_from_imshow(self):
        fig, ax = plt.subplots()
        data = [[1.0, 2.0], [3.0, 4.0]]
        im = ax.imshow(data)
        cb = fig.colorbar(im, ax=ax)
        assert cb is not None
        plt.close('all')

    def test_colorbar_label(self):
        fig, ax = plt.subplots()
        im = ax.imshow([[1.0, 2.0], [3.0, 4.0]])
        cb = fig.colorbar(im, ax=ax, label='intensity')
        assert cb is not None
        plt.close('all')

    def test_colorbar_orientation(self):
        fig, ax = plt.subplots()
        im = ax.imshow([[1.0, 2.0], [3.0, 4.0]])
        cb = fig.colorbar(im, ax=ax, orientation='horizontal')
        assert cb is not None
        plt.close('all')

    def test_colorbar_shrink(self):
        fig, ax = plt.subplots()
        im = ax.imshow([[1.0, 2.0], [3.0, 4.0]])
        cb = fig.colorbar(im, ax=ax, shrink=0.8)
        assert cb is not None
        plt.close('all')

    def test_colorbar_ticks(self):
        fig, ax = plt.subplots()
        im = ax.imshow([[1.0, 2.0], [3.0, 4.0]])
        cb = fig.colorbar(im, ax=ax, ticks=[1.0, 2.0, 3.0, 4.0])
        assert cb is not None
        plt.close('all')


class TestAxesTwinning:
    def test_twinx(self):
        """ax.twinx() creates a twin axes with shared x."""
        fig, ax = plt.subplots()
        ax2 = ax.twinx()
        assert ax2 is not None
        plt.close('all')

    def test_twiny(self):
        """ax.twiny() creates a twin axes with shared y."""
        fig, ax = plt.subplots()
        ax2 = ax.twiny()
        assert ax2 is not None
        plt.close('all')

    def test_twinx_plot(self):
        """twinx allows two y scales."""
        fig, ax1 = plt.subplots()
        ax2 = ax1.twinx()
        ax1.plot([1, 2, 3], [1, 4, 9], 'b-', label='y1')
        ax2.plot([1, 2, 3], [100, 200, 300], 'r-', label='y2')
        plt.close('all')
