"""Tests for color normalization and colormapping patterns."""

import pytest
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
import matplotlib.cm as cm


class TestNormalize:
    def test_normalize_basic(self):
        """Basic Normalize."""
        norm = mcolors.Normalize(vmin=0, vmax=10)
        assert norm is not None

    def test_normalize_call(self):
        """Normalize maps values to [0, 1]."""
        norm = mcolors.Normalize(vmin=0, vmax=100)
        result = norm(50)
        assert abs(result - 0.5) < 1e-6

    def test_normalize_clip(self):
        """Normalize with clip."""
        norm = mcolors.Normalize(vmin=0, vmax=10, clip=True)
        assert norm(15) == 1.0
        assert norm(-5) == 0.0

    def test_normalize_auto(self):
        """Normalize without explicit vmin/vmax."""
        norm = mcolors.Normalize()
        assert norm is not None

    def test_normalize_with_scatter(self):
        """Normalize used with scatter."""
        fig, ax = plt.subplots()
        x = [1.0, 2.0, 3.0, 4.0, 5.0]
        y = [2.0, 4.0, 1.0, 3.0, 5.0]
        c = [10.0, 20.0, 30.0, 40.0, 50.0]
        norm = mcolors.Normalize(vmin=10, vmax=50)
        sc = ax.scatter(x, y, c=c, norm=norm)
        assert sc is not None
        plt.close('all')


class TestLogNorm:
    def test_lognorm_basic(self):
        """Basic LogNorm."""
        norm = mcolors.LogNorm(vmin=1, vmax=1000)
        assert norm is not None

    def test_lognorm_call(self):
        """LogNorm maps log scale to [0, 1]."""
        norm = mcolors.LogNorm(vmin=1, vmax=100)
        result = norm(10)
        assert 0.0 < result < 1.0

    def test_lognorm_with_imshow(self):
        """LogNorm with imshow."""
        fig, ax = plt.subplots()
        data = [[1.0, 10.0, 100.0], [2.0, 20.0, 200.0], [5.0, 50.0, 500.0]]
        norm = mcolors.LogNorm(vmin=1, vmax=500)
        im = ax.imshow(data, norm=norm, cmap='viridis')
        assert im is not None
        plt.close('all')

    def test_lognorm_with_scatter(self):
        """LogNorm with scatter."""
        fig, ax = plt.subplots()
        x = [1.0, 2.0, 3.0, 4.0, 5.0]
        y = [1.0, 2.0, 3.0, 4.0, 5.0]
        c = [1.0, 10.0, 100.0, 1000.0, 10000.0]
        sc = ax.scatter(x, y, c=c, norm=mcolors.LogNorm(vmin=1, vmax=10000))
        assert sc is not None
        plt.close('all')


class TestTwoSlopeNorm:
    def test_twoslope_basic(self):
        """Basic TwoSlopeNorm."""
        norm = mcolors.TwoSlopeNorm(vcenter=0, vmin=-10, vmax=10)
        assert norm is not None

    def test_twoslope_with_imshow(self):
        """TwoSlopeNorm with imshow for diverging colormaps."""
        fig, ax = plt.subplots()
        data = [[-5.0, 0.0, 5.0], [-3.0, 1.0, 8.0], [-8.0, -1.0, 10.0]]
        norm = mcolors.TwoSlopeNorm(vcenter=0, vmin=-10, vmax=10)
        im = ax.imshow(data, norm=norm, cmap='RdBu')
        assert im is not None
        plt.close('all')


class TestBoundaryNorm:
    def test_boundary_basic(self):
        """Basic BoundaryNorm."""
        bounds = [0, 1, 2, 5, 10]
        norm = mcolors.BoundaryNorm(bounds, ncolors=256)
        assert norm is not None

    def test_boundary_with_imshow(self):
        """BoundaryNorm with imshow."""
        fig, ax = plt.subplots()
        data = [[0.5, 1.5, 3.0], [4.0, 7.0, 9.0], [0.1, 2.0, 8.0]]
        bounds = [0, 1, 2, 5, 10]
        norm = mcolors.BoundaryNorm(bounds, ncolors=4)
        im = ax.imshow(data, norm=norm)
        assert im is not None
        plt.close('all')


class TestColormapUsage:
    def test_get_cmap(self):
        """Get colormap by name."""
        cmap = cm.get_cmap('viridis')
        assert cmap is not None

    def test_cmap_call(self):
        """Call colormap to get RGBA."""
        cmap = cm.get_cmap('viridis')
        result = cmap(0.5)
        assert len(result) == 4

    def test_cmap_extremes(self):
        """Colormap at extremes."""
        cmap = cm.get_cmap('viridis')
        r0 = cmap(0.0)
        r1 = cmap(1.0)
        assert r0 != r1

    def test_cmap_with_scatter_c(self):
        """Scatter with c values and colormap."""
        fig, ax = plt.subplots()
        x = [1.0, 2.0, 3.0, 4.0, 5.0]
        y = [2.0, 1.0, 4.0, 3.0, 5.0]
        c = [0.1, 0.3, 0.5, 0.7, 0.9]
        sc = ax.scatter(x, y, c=c, cmap='plasma')
        assert sc is not None
        plt.close('all')

    def test_colormap_types(self):
        """Various standard colormaps."""
        for name in ['viridis', 'plasma', 'inferno', 'magma', 'cividis',
                     'Blues', 'Reds', 'Greens', 'RdBu', 'coolwarm', 'jet']:
            cmap = cm.get_cmap(name)
            assert cmap is not None

    def test_cmap_n_colors(self):
        """Colormap with N discrete colors."""
        cmap = cm.get_cmap('viridis', 10)
        assert cmap is not None

    def test_reversed_cmap(self):
        """Reversed colormap."""
        cmap = cm.get_cmap('viridis_r')
        assert cmap is not None

    def test_cmap_sequential_values(self):
        """Colormap produces sequential RGBA for sequential input."""
        cmap = cm.get_cmap('viridis')
        r1 = cmap(0.1)
        r2 = cmap(0.5)
        r3 = cmap(0.9)
        # Values should be different
        assert r1 != r3

    def test_colorbar_with_norm(self):
        """Colorbar with norm."""
        fig, ax = plt.subplots()
        data = [[1.0, 2.0, 3.0], [4.0, 5.0, 6.0], [7.0, 8.0, 9.0]]
        norm = mcolors.Normalize(vmin=1, vmax=9)
        im = ax.imshow(data, norm=norm, cmap='viridis')
        cbar = fig.colorbar(im)
        assert cbar is not None
        plt.close('all')


class TestColorConversions:
    def test_to_rgba_name(self):
        """Convert color name to RGBA."""
        rgba = mcolors.to_rgba('red')
        assert rgba == (1.0, 0.0, 0.0, 1.0)

    def test_to_rgba_hex(self):
        """Convert hex color to RGBA."""
        rgba = mcolors.to_rgba('#FF0000')
        assert abs(rgba[0] - 1.0) < 0.01
        assert abs(rgba[1] - 0.0) < 0.01
        assert abs(rgba[2] - 0.0) < 0.01

    def test_to_rgba_tuple_rgb(self):
        """Convert RGB tuple to RGBA."""
        rgba = mcolors.to_rgba((1.0, 0.0, 0.0))
        assert len(rgba) == 4
        assert rgba[3] == 1.0

    def test_to_rgba_with_alpha(self):
        """Convert color with explicit alpha."""
        rgba = mcolors.to_rgba('blue', alpha=0.5)
        assert abs(rgba[3] - 0.5) < 0.01

    def test_to_rgb(self):
        """Convert to RGB."""
        rgb = mcolors.to_rgb('green')
        assert len(rgb) == 3

    def test_to_hex(self):
        """Convert to hex."""
        hex_color = mcolors.to_hex('red')
        assert hex_color.startswith('#')
        assert len(hex_color) in (7, 9)  # #RRGGBB or #RRGGBBAA

    def test_is_color_like(self):
        """Check if value is a valid color."""
        assert mcolors.is_color_like('red')
        assert mcolors.is_color_like('#FF0000')
        assert mcolors.is_color_like((1.0, 0.0, 0.0))
        assert not mcolors.is_color_like('notacolor')

    def test_color_cycle(self):
        """Default color cycle."""
        fig, ax = plt.subplots()
        for i in range(5):
            ax.plot([0, 1], [i, i+1])
        plt.close('all')

    def test_c_style_colors(self):
        """CSS-style color names."""
        for color in ['red', 'blue', 'green', 'orange', 'purple', 'cyan',
                      'magenta', 'yellow', 'black', 'white', 'gray']:
            rgba = mcolors.to_rgba(color)
            assert len(rgba) == 4
