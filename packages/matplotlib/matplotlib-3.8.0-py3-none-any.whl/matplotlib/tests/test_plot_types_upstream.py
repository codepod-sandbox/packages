"""Tests for various plot types LLMs commonly generate."""

import pytest
import numpy as np
import matplotlib.pyplot as plt


class TestStem:
    def test_stem_basic(self):
        """ax.stem() does not raise."""
        fig, ax = plt.subplots()
        ax.stem([1, 2, 3, 4], [1, 3, 2, 4])
        plt.close('all')

    def test_stem_markerfmt(self):
        """ax.stem() with markerfmt does not raise."""
        fig, ax = plt.subplots()
        ax.stem([1, 2, 3], [1, 3, 2], markerfmt='D', linefmt='r-', basefmt='k-')
        plt.close('all')

    def test_stem_numpy(self):
        """ax.stem() with numpy array does not raise."""
        fig, ax = plt.subplots()
        x = np.linspace(0, 2*np.pi, 10)
        ax.stem(x, np.sin(x))
        plt.close('all')


class TestStairs:
    def test_stairs_basic(self):
        """ax.stairs() does not raise."""
        fig, ax = plt.subplots()
        ax.stairs([1, 2, 3, 4], [0, 1, 2, 3, 4])
        plt.close('all')

    def test_stairs_fill(self):
        """ax.stairs() with fill does not raise."""
        fig, ax = plt.subplots()
        ax.stairs([1, 2, 3, 4], [0, 1, 2, 3, 4], fill=True, alpha=0.4)
        plt.close('all')

    def test_stairs_orientation(self):
        """ax.stairs() with orientation='horizontal' does not raise."""
        fig, ax = plt.subplots()
        ax.stairs([1, 2, 3], [0, 1, 2, 3], orientation='horizontal')
        plt.close('all')


class TestBoxPlot:
    def test_boxplot_basic(self):
        """ax.boxplot() does not raise."""
        fig, ax = plt.subplots()
        data = [[1.0, 2.0, 3.0, 4.0, 5.0], [2.0, 3.0, 4.0, 5.0, 6.0], [0.0, 1.0, 2.0, 3.0, 4.0]]
        ax.boxplot(data)
        plt.close('all')

    def test_boxplot_notch(self):
        """ax.boxplot() with notch does not raise."""
        fig, ax = plt.subplots()
        ax.boxplot([[1, 2, 3, 4, 5]], notch=True)
        plt.close('all')

    def test_boxplot_horizontal(self):
        """ax.boxplot() horizontal does not raise."""
        fig, ax = plt.subplots()
        ax.boxplot([[1, 2, 3, 4, 5], [2, 3, 4, 5, 6]], vert=False)
        plt.close('all')

    def test_boxplot_with_labels(self):
        """ax.boxplot() with labels does not raise."""
        fig, ax = plt.subplots()
        ax.boxplot([[1, 2, 3], [4, 5, 6]], labels=['A', 'B'])
        plt.close('all')


class TestViolinPlot:
    def test_violinplot_basic(self):
        """ax.violinplot() does not raise."""
        fig, ax = plt.subplots()
        data = [[1.0, 2.0, 3.0, 4.0, 5.0], [2.0, 3.0, 4.0, 5.0, 6.0], [0.0, 1.0, 2.0, 3.0, 4.0]]
        ax.violinplot(data)
        plt.close('all')

    def test_violinplot_with_options(self):
        """ax.violinplot() with showmeans/showextrema does not raise."""
        fig, ax = plt.subplots()
        ax.violinplot([[1, 2, 3, 4, 5]], showmeans=True, showextrema=True)
        plt.close('all')


class TestPie:
    def test_pie_basic(self):
        """ax.pie() does not raise."""
        fig, ax = plt.subplots()
        ax.pie([30, 45, 25])
        plt.close('all')

    def test_pie_with_labels(self):
        """ax.pie() with labels does not raise."""
        fig, ax = plt.subplots()
        ax.pie([30, 45, 25], labels=['A', 'B', 'C'])
        plt.close('all')

    def test_pie_autopct(self):
        """ax.pie() with autopct does not raise."""
        fig, ax = plt.subplots()
        ax.pie([30, 45, 25], autopct='%1.1f%%')
        plt.close('all')

    def test_pie_explode(self):
        """ax.pie() with explode does not raise."""
        fig, ax = plt.subplots()
        ax.pie([30, 45, 25], explode=(0.1, 0, 0))
        plt.close('all')

    def test_pie_colors(self):
        """ax.pie() with colors does not raise."""
        fig, ax = plt.subplots()
        ax.pie([30, 40, 30], colors=['red', 'green', 'blue'])
        plt.close('all')

    def test_pie_shadow(self):
        """ax.pie() with shadow does not raise."""
        fig, ax = plt.subplots()
        ax.pie([1, 2, 3], shadow=True)
        plt.close('all')

    def test_pie_startangle(self):
        """ax.pie() with startangle does not raise."""
        fig, ax = plt.subplots()
        ax.pie([1, 2, 3], startangle=90)
        plt.close('all')

    def test_pie_returns_tuple(self):
        """ax.pie() returns (patches, texts) tuple."""
        fig, ax = plt.subplots()
        result = ax.pie([30, 45, 25])
        assert isinstance(result, tuple)
        assert len(result) >= 1
        plt.close('all')


class TestErrorBar:
    def test_errorbar_basic(self):
        """ax.errorbar() does not raise."""
        fig, ax = plt.subplots()
        ax.errorbar([1, 2, 3], [1, 4, 2], yerr=0.5)
        plt.close('all')

    def test_errorbar_xerr(self):
        """ax.errorbar() with xerr does not raise."""
        fig, ax = plt.subplots()
        ax.errorbar([1, 2, 3], [1, 4, 2], xerr=0.3, yerr=0.5)
        plt.close('all')

    def test_errorbar_asymmetric(self):
        """ax.errorbar() with asymmetric errors does not raise."""
        fig, ax = plt.subplots()
        ax.errorbar([1, 2, 3], [1, 4, 2],
                    yerr=[[0.1, 0.2, 0.1], [0.3, 0.4, 0.2]])
        plt.close('all')

    def test_errorbar_fmt(self):
        """ax.errorbar() with fmt does not raise."""
        fig, ax = plt.subplots()
        ax.errorbar([1, 2, 3], [1, 4, 2], yerr=0.5, fmt='o-')
        plt.close('all')

    def test_errorbar_capsize(self):
        """ax.errorbar() with capsize does not raise."""
        fig, ax = plt.subplots()
        ax.errorbar([1, 2, 3], [1, 4, 2], yerr=0.5, capsize=5)
        plt.close('all')
