"""
Upstream tests for common plot customization patterns.
Covers style, rcParams, color, and formatting patterns LLMs frequently use.
"""

import numpy as np
import pytest
import matplotlib.pyplot as plt
import matplotlib as mpl
import matplotlib.colors as mcolors


class TestColorPatterns:
    """Tests for color usage patterns."""

    def teardown_method(self):
        plt.close('all')

    def test_named_colors(self):
        fig, ax = plt.subplots()
        for color in ['red', 'blue', 'green', 'black', 'white', 'gray', 'orange']:
            ax.plot([0, 1], color=color)

    def test_hex_colors(self):
        fig, ax = plt.subplots()
        for color in ['#ff0000', '#00ff00', '#0000ff', '#333333']:
            ax.plot([0, 1], color=color)

    def test_rgb_tuple_colors(self):
        fig, ax = plt.subplots()
        for color in [(1, 0, 0), (0, 1, 0), (0, 0, 1), (0.5, 0.5, 0.5)]:
            ax.plot([0, 1], color=color)

    def test_rgba_tuple_colors(self):
        fig, ax = plt.subplots()
        ax.plot([0, 1], color=(1, 0, 0, 0.5))

    def test_css4_colors(self):
        fig, ax = plt.subplots()
        for color in ['steelblue', 'tomato', 'forestgreen', 'mediumpurple']:
            ax.plot([0, 1], color=color)

    def test_cycle_colors_cn(self):
        fig, ax = plt.subplots()
        ax.plot([0, 1], color='C0')
        ax.plot([0, 1], color='C1')
        ax.plot([0, 1], color='C2')

    def test_to_rgba_conversion(self):
        rgba = mcolors.to_rgba('red')
        assert len(rgba) == 4
        assert rgba[0] == 1.0
        assert rgba[3] == 1.0

    def test_to_hex_conversion(self):
        hex_color = mcolors.to_hex('blue')
        assert hex_color.startswith('#')
        assert len(hex_color) == 7

    def test_to_rgb_conversion(self):
        rgb = mcolors.to_rgb('green')
        assert len(rgb) == 3

    def test_is_color_like(self):
        assert mcolors.is_color_like('red')
        assert mcolors.is_color_like('#ff0000')
        assert mcolors.is_color_like((0.5, 0.5, 0.5))
        assert not mcolors.is_color_like('notacolor')


class TestLineStyles:
    """Tests for line style and marker patterns."""

    def teardown_method(self):
        plt.close('all')

    def test_linestyles_string(self):
        fig, ax = plt.subplots()
        for ls in ['-', '--', ':', '-.']:
            ax.plot([0, 1], linestyle=ls)

    def test_linestyles_named(self):
        fig, ax = plt.subplots()
        for ls in ['solid', 'dashed', 'dotted', 'dashdot']:
            ax.plot([0, 1], linestyle=ls)

    def test_markers_string(self):
        fig, ax = plt.subplots()
        for m in ['o', 's', '^', 'v', '<', '>', 'D', 'P', '*', 'x', '+']:
            ax.plot([0, 1, 2], [0, 1, 0], marker=m)

    def test_linewidth(self):
        fig, ax = plt.subplots()
        for lw in [0.5, 1, 2, 3, 5]:
            ax.plot([0, 1], linewidth=lw)

    def test_markersize(self):
        fig, ax = plt.subplots()
        for ms in [2, 5, 8, 12]:
            ax.plot([0, 1], marker='o', markersize=ms)

    def test_markerfacecolor(self):
        fig, ax = plt.subplots()
        ax.plot([0, 1], marker='o', markerfacecolor='blue')
        ax.plot([0, 1], marker='s', markerfacecolor='none')

    def test_markeredgecolor(self):
        fig, ax = plt.subplots()
        ax.plot([0, 1], marker='o', markeredgecolor='red', markeredgewidth=2)

    def test_fmt_string_combined(self):
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2], 'ro-')   # red, circle, solid
        ax.plot([0, 1, 2], 'bs--')  # blue, square, dashed
        ax.plot([0, 1, 2], 'g^:')   # green, triangle, dotted

    def test_alpha_line(self):
        fig, ax = plt.subplots()
        ax.plot([0, 1], alpha=0.5)


class TestGridAndSpines:
    """Tests for grid and spine customization."""

    def teardown_method(self):
        plt.close('all')

    def test_grid_on(self):
        fig, ax = plt.subplots()
        ax.grid(True)

    def test_grid_off(self):
        fig, ax = plt.subplots()
        ax.grid(False)

    def test_grid_axis(self):
        fig, ax = plt.subplots()
        ax.grid(axis='x')
        ax.grid(axis='y')
        ax.grid(axis='both')

    def test_grid_style(self):
        fig, ax = plt.subplots()
        ax.grid(color='gray', linestyle='--', linewidth=0.5, alpha=0.7)

    def test_grid_which(self):
        fig, ax = plt.subplots()
        ax.grid(which='major')
        ax.grid(which='minor')
        ax.grid(which='both')

    def test_spines_set_visible(self):
        fig, ax = plt.subplots()
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)

    def test_spines_all(self):
        fig, ax = plt.subplots()
        for spine in ['top', 'bottom', 'left', 'right']:
            ax.spines[spine].set_visible(True)
            ax.spines[spine].set_linewidth(1.5)

    def test_spines_set_color(self):
        fig, ax = plt.subplots()
        ax.spines['bottom'].set_color('blue')

    def test_spines_set_linewidth(self):
        fig, ax = plt.subplots()
        ax.spines['left'].set_linewidth(2)


class TestRcParams:
    """Tests for rcParams usage."""

    def teardown_method(self):
        plt.close('all')
        mpl.rcdefaults()

    def test_rcparams_access(self):
        val = mpl.rcParams['lines.linewidth']
        assert isinstance(val, (int, float))

    def test_rcparams_set(self):
        mpl.rcParams['lines.linewidth'] = 2.5
        assert mpl.rcParams['lines.linewidth'] == 2.5

    def test_rcparams_figure_figsize(self):
        mpl.rcParams['figure.figsize'] = [8, 6]
        # Verify it's stored in rcParams (figure creation may or may not pick it up)
        assert mpl.rcParams['figure.figsize'] == [8, 6]

    def test_rc_context(self):
        with mpl.rc_context({'lines.linewidth': 3.0}):
            assert mpl.rcParams['lines.linewidth'] == 3.0
        # restored after context
        assert mpl.rcParams['lines.linewidth'] != 3.0

    def test_rcdefaults(self):
        mpl.rcParams['lines.linewidth'] = 99
        mpl.rcdefaults()
        # should be restored to default
        assert mpl.rcParams['lines.linewidth'] != 99

    def test_plt_rc(self):
        plt.rc('lines', linewidth=3.0, linestyle='--')
        assert mpl.rcParams['lines.linewidth'] == 3.0

    def test_plt_rcdefaults(self):
        plt.rcParams['lines.linewidth'] = 10
        plt.rcdefaults()
        assert plt.rcParams['lines.linewidth'] != 10


class TestFigureProperties:
    """Tests for Figure-level properties."""

    def teardown_method(self):
        plt.close('all')

    def test_figure_facecolor(self):
        fig = plt.figure(facecolor='white')
        assert fig.get_facecolor() is not None

    def test_figure_set_facecolor(self):
        fig = plt.figure()
        fig.set_facecolor('lightgray')

    def test_figure_size_inches(self):
        fig = plt.figure(figsize=(8, 6))
        w, h = fig.get_size_inches()
        assert w == 8.0
        assert h == 6.0

    def test_figure_set_size_inches(self):
        fig = plt.figure()
        fig.set_size_inches(10, 8)
        w, h = fig.get_size_inches()
        assert w == 10.0
        assert h == 8.0

    def test_figure_dpi(self):
        fig = plt.figure(dpi=100)
        assert fig.get_dpi() == 100

    def test_figure_set_dpi(self):
        fig = plt.figure()
        fig.set_dpi(150)
        assert fig.get_dpi() == 150

    def test_axes_facecolor(self):
        fig, ax = plt.subplots()
        ax.set_facecolor('lightyellow')
        # should not raise

    def test_axes_title_font_size(self):
        fig, ax = plt.subplots()
        ax.set_title('Title', fontsize=14, pad=10)

    def test_axes_labels_fontsize(self):
        fig, ax = plt.subplots()
        ax.set_xlabel('X', fontsize=12, labelpad=5)
        ax.set_ylabel('Y', fontsize=12, labelpad=5)
