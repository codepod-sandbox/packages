"""Tests for advanced annotation patterns used by LLMs."""

import pytest
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches


class TestAnnotateBasic:
    def test_annotate_simple(self):
        """ax.annotate() with text and xy."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 4, 9])
        ax.annotate('peak', xy=(3, 9))
        plt.close('all')

    def test_annotate_with_xytext(self):
        """annotate with xytext offset."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 4, 9])
        ax.annotate('peak', xy=(3, 9), xytext=(2.5, 8))
        plt.close('all')

    def test_annotate_with_arrow(self):
        """annotate with arrowprops."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        ax.annotate('point', xy=(1, 1), xytext=(0.5, 0.8),
                    arrowprops=dict(arrowstyle='->'))
        plt.close('all')

    def test_annotate_arrowstyle_fancy(self):
        """annotate with fancy arrowstyle."""
        fig, ax = plt.subplots()
        ax.annotate('', xy=(0.5, 0.5), xytext=(0.2, 0.2),
                    arrowprops=dict(arrowstyle='->', color='red'))
        plt.close('all')

    def test_annotate_xycoords_axes_fraction(self):
        """annotate with xycoords='axes fraction'."""
        fig, ax = plt.subplots()
        ax.annotate('center', xy=(0.5, 0.5), xycoords='axes fraction')
        plt.close('all')

    def test_annotate_xycoords_figure_fraction(self):
        """annotate with xycoords='figure fraction'."""
        fig, ax = plt.subplots()
        ax.annotate('fig', xy=(0.5, 0.5), xycoords='figure fraction')
        plt.close('all')

    def test_annotate_textcoords_offset_points(self):
        """annotate with textcoords='offset points'."""
        fig, ax = plt.subplots()
        ax.plot([1], [1])
        ax.annotate('label', xy=(1, 1), xytext=(10, 10),
                    textcoords='offset points')
        plt.close('all')

    def test_annotate_fontsize(self):
        """annotate with fontsize kwarg."""
        fig, ax = plt.subplots()
        ax.annotate('text', xy=(0, 0), fontsize=14)
        plt.close('all')

    def test_annotate_color(self):
        """annotate with color kwarg."""
        fig, ax = plt.subplots()
        ax.annotate('text', xy=(0, 0), color='red')
        plt.close('all')

    def test_annotate_ha_va(self):
        """annotate with ha and va."""
        fig, ax = plt.subplots()
        ax.annotate('text', xy=(0.5, 0.5), ha='center', va='bottom')
        plt.close('all')


class TestTextAnnotation:
    def test_ax_text(self):
        """ax.text() with coordinates."""
        fig, ax = plt.subplots()
        ax.text(0.5, 0.5, 'hello')
        plt.close('all')

    def test_ax_text_transform(self):
        """ax.text with transAxes transform."""
        fig, ax = plt.subplots()
        ax.text(0.5, 0.5, 'center', transform=ax.transAxes)
        plt.close('all')

    def test_ax_text_fontsize(self):
        """ax.text with fontsize."""
        fig, ax = plt.subplots()
        ax.text(0.5, 0.5, 'big', fontsize=18)
        plt.close('all')

    def test_ax_text_fontweight(self):
        """ax.text with fontweight bold."""
        fig, ax = plt.subplots()
        ax.text(0.5, 0.5, 'bold', fontweight='bold')
        plt.close('all')

    def test_ax_text_color(self):
        """ax.text with color."""
        fig, ax = plt.subplots()
        ax.text(0.5, 0.5, 'red text', color='red')
        plt.close('all')

    def test_ax_text_rotation(self):
        """ax.text with rotation."""
        fig, ax = plt.subplots()
        ax.text(0.5, 0.5, 'rotated', rotation=45)
        plt.close('all')

    def test_ax_text_bbox(self):
        """ax.text with bbox styling."""
        fig, ax = plt.subplots()
        ax.text(0.5, 0.5, 'boxed', bbox=dict(boxstyle='round', facecolor='wheat'))
        plt.close('all')

    def test_fig_text(self):
        """fig.text() adds text to figure."""
        fig, ax = plt.subplots()
        fig.text(0.5, 0.01, 'figure text', ha='center')
        plt.close('all')

    def test_plt_text(self):
        """plt.text() shortcut."""
        fig, ax = plt.subplots()
        plt.text(0.5, 0.5, 'hello')
        plt.close('all')


class TestArrowAnnotation:
    def test_annotate_arrow_dict(self):
        """annotate with arrowprops as dict."""
        fig, ax = plt.subplots()
        ax.annotate('', xy=(1, 1), xytext=(0, 0),
                    arrowprops=dict(arrowstyle='->', lw=1.5))
        plt.close('all')

    def test_annotate_connectionstyle(self):
        """annotate with connectionstyle arc3."""
        fig, ax = plt.subplots()
        ax.annotate('', xy=(1, 1), xytext=(0, 0),
                    arrowprops=dict(arrowstyle='->', connectionstyle='arc3,rad=0.3'))
        plt.close('all')

    def test_ax_arrow(self):
        """ax.arrow() draws arrow patch."""
        fig, ax = plt.subplots()
        ax.arrow(0, 0, 1, 1, head_width=0.1, head_length=0.1, fc='blue', ec='blue')
        plt.close('all')

    def test_annotate_multiple(self):
        """Multiple annotations on same axes."""
        fig, ax = plt.subplots()
        x = [1, 2, 3, 4, 5]
        y = [1, 4, 9, 16, 25]
        ax.plot(x, y)
        for xi, yi in zip(x, y):
            ax.annotate(f'({xi},{yi})', xy=(xi, yi), fontsize=8)
        plt.close('all')


class TestSpecialAnnotation:
    def test_axvline_label(self):
        """axvline with label for legend."""
        fig, ax = plt.subplots()
        ax.axvline(x=2.5, color='r', linestyle='--', label='threshold')
        ax.legend()
        plt.close('all')

    def test_axhline_annotate(self):
        """axhline as annotation."""
        fig, ax = plt.subplots()
        ax.axhline(y=0, color='k', linewidth=0.5)
        ax.annotate('zero', xy=(0, 0), fontsize=8)
        plt.close('all')

    def test_fill_between_label(self):
        """fill_between with label."""
        fig, ax = plt.subplots()
        x = [1, 2, 3]
        ax.fill_between(x, [0, 0, 0], [1, 2, 1], alpha=0.3, label='region')
        ax.legend()
        plt.close('all')

    def test_annotate_returns_annotation(self):
        """annotate returns an object."""
        fig, ax = plt.subplots()
        ann = ax.annotate('test', xy=(0, 0))
        assert ann is not None
        plt.close('all')
