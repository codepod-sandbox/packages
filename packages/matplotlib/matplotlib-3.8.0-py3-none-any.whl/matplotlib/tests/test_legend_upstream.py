"""Tests for legend features, placement, handles, and styling."""

import pytest
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.lines as mlines
import matplotlib.patches as mpatches


# ---------------------------------------------------------------------------
# Basic legend
# ---------------------------------------------------------------------------

class TestLegendBasic:
    def test_legend_single_line(self):
        """legend() with single labeled line does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1], label='line')
        ax.legend()
        plt.close('all')

    def test_legend_multiple_lines(self):
        """legend() with multiple lines does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1], label='line A')
        ax.plot([0, 1], [1, 0], label='line B')
        ax.plot([0, 1], [0.5, 0.5], label='line C')
        ax.legend()
        plt.close('all')

    def test_legend_returns_object(self):
        """legend() returns a Legend object."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1], label='line')
        leg = ax.legend()
        assert leg is not None
        plt.close('all')

    def test_legend_no_labels_no_raise(self):
        """legend() with no labeled artists does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        ax.legend()
        plt.close('all')


# ---------------------------------------------------------------------------
# Legend location
# ---------------------------------------------------------------------------

class TestLegendLocation:
    def test_legend_loc_best(self):
        """legend(loc='best') does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1], label='line')
        ax.legend(loc='best')
        plt.close('all')

    def test_legend_loc_upper_right(self):
        """legend(loc='upper right') does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1], label='line')
        ax.legend(loc='upper right')
        plt.close('all')

    def test_legend_loc_lower_left(self):
        """legend(loc='lower left') does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1], label='line')
        ax.legend(loc='lower left')
        plt.close('all')

    def test_legend_loc_outside(self):
        """legend(loc='outside right upper') does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1], label='line')
        ax.legend(loc='upper right')
        plt.close('all')

    def test_legend_bbox_to_anchor(self):
        """legend with bbox_to_anchor does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1], label='line')
        ax.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
        plt.close('all')


# ---------------------------------------------------------------------------
# Legend properties
# ---------------------------------------------------------------------------

class TestLegendProperties:
    def test_legend_fontsize(self):
        """legend with fontsize does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1], label='line')
        ax.legend(fontsize=12)
        plt.close('all')

    def test_legend_title(self):
        """legend with title does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1], label='A')
        ax.legend(title='Legend Title')
        plt.close('all')

    def test_legend_ncol(self):
        """legend with ncol does not raise."""
        fig, ax = plt.subplots()
        for i in range(4):
            ax.plot([0, 1], [i, i+1], label=f'item {i}')
        ax.legend(ncol=2)
        plt.close('all')

    def test_legend_frameon(self):
        """legend with frameon=False does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1], label='line')
        ax.legend(frameon=False)
        plt.close('all')

    def test_legend_framealpha(self):
        """legend with framealpha does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1], label='line')
        ax.legend(framealpha=0.5)
        plt.close('all')

    def test_legend_fancybox(self):
        """legend with fancybox=True does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1], label='line')
        ax.legend(fancybox=True)
        plt.close('all')

    def test_legend_shadow(self):
        """legend with shadow=True does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1], label='line')
        ax.legend(shadow=True)
        plt.close('all')


# ---------------------------------------------------------------------------
# Legend handles
# ---------------------------------------------------------------------------

class TestLegendHandles:
    def test_legend_custom_handles(self):
        """legend with custom handles does not raise."""
        fig, ax = plt.subplots()
        line1 = mlines.Line2D([], [], color='red', label='Red line')
        line2 = mlines.Line2D([], [], color='blue', linestyle='--',
                              label='Blue dashed')
        ax.legend(handles=[line1, line2])
        plt.close('all')

    def test_legend_patch_handle(self):
        """legend with patch handle does not raise."""
        fig, ax = plt.subplots()
        patch = mpatches.Patch(color='green', label='Green area')
        ax.legend(handles=[patch])
        plt.close('all')

    def test_legend_mixed_handles(self):
        """legend with mixed artist handles does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1], color='blue', label='data')
        patch = mpatches.Patch(color='red', label='region')
        leg = ax.legend(handles=[
            mlines.Line2D([], [], color='blue', label='data'),
            patch
        ])
        assert leg is not None
        plt.close('all')


# ---------------------------------------------------------------------------
# plt.legend and figure legend
# ---------------------------------------------------------------------------

class TestPltLegend:
    def test_plt_legend(self):
        """plt.legend() does not raise."""
        plt.figure()
        plt.plot([0, 1], [0, 1], label='line')
        plt.legend()
        plt.close('all')

    def test_figure_legend(self):
        """fig.legend() does not raise."""
        fig, axes = plt.subplots(1, 2)
        axes[0].plot([0, 1], [0, 1], label='line A')
        axes[1].plot([0, 1], [1, 0], label='line B')
        fig.legend(loc='upper right')
        plt.close('all')

    def test_legend_svg(self):
        """Legend renders to SVG."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1], label='sin(x)')
        ax.plot([0, 1], [1, 0], label='cos(x)')
        ax.legend(loc='upper right')
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')
