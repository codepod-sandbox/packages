"""
Upstream tests for publication-quality figure patterns commonly used by LLMs.
"""

import pytest
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
import io


class TestPublicationFigures:
    """Tests for publication-quality figure patterns."""

    def teardown_method(self):
        plt.close('all')
        mpl.rcdefaults()

    def test_minimal_style(self):
        """Minimal axes style (no top/right spines)."""
        fig, ax = plt.subplots()
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        ax.plot(np.linspace(0, 10, 50), np.sin(np.linspace(0, 10, 50)))
        ax.set_xlabel('x', fontsize=12)
        ax.set_ylabel('f(x)', fontsize=12)
        ax.set_title('Minimal Style', fontsize=14)

    def test_figure_width_height(self):
        """Control figure dimensions for journals."""
        # Single column: 3.5 inches wide
        fig, ax = plt.subplots(figsize=(3.5, 2.5))
        ax.plot([1, 2, 3])
        w, h = fig.get_size_inches()
        assert w == 3.5
        assert h == 2.5

    def test_high_dpi_figure(self):
        """High DPI for print quality."""
        fig, ax = plt.subplots(dpi=300)
        assert fig.get_dpi() == 300

    def test_savefig_publication(self):
        """Save as high-quality PNG."""
        fig, ax = plt.subplots(figsize=(6, 4), dpi=150)
        ax.plot([1, 2, 3], [1, 4, 9])
        ax.set_title('Publication Figure')
        buf = io.BytesIO()
        fig.savefig(buf, format='png', dpi=150, bbox_inches='tight')
        buf.seek(0)
        assert len(buf.read()) > 0

    def test_savefig_svg_for_vector(self):
        """Save as SVG for vector graphics."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3])
        buf = io.BytesIO()
        fig.savefig(buf, format='svg', bbox_inches='tight')
        buf.seek(0)
        content = buf.read()
        assert len(content) > 50

    def test_panel_labels(self):
        """Common pattern: (a), (b), (c) panel labels."""
        fig, axes = plt.subplots(1, 3, figsize=(12, 4))
        for i, (ax, label) in enumerate(zip(axes, ['(a)', '(b)', '(c)'])):
            ax.plot(np.random.rand(10))
            ax.text(-0.1, 1.05, label, transform=ax.transAxes,
                    fontsize=14, fontweight='bold', va='top', ha='right')

    def test_errorbar_publication(self):
        """Error bars with capsize for publications."""
        x = np.arange(5)
        y = np.array([2.3, 3.1, 2.8, 3.6, 3.0])
        err = np.array([0.2, 0.15, 0.25, 0.18, 0.22])
        fig, ax = plt.subplots()
        ax.errorbar(x, y, yerr=err, fmt='o-', capsize=4, capthick=1.5,
                    elinewidth=1.5, markersize=6, color='black')
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)

    def test_inset_axes(self):
        """Inset axes within main plot."""
        fig, ax = plt.subplots()
        ax.plot(np.linspace(0, 10, 100), np.sin(np.linspace(0, 10, 100)))
        # Create inset
        left, bottom, width, height = [0.6, 0.6, 0.35, 0.3]
        ax_inset = fig.add_axes([left, bottom, width, height])
        ax_inset.plot(np.linspace(0, 2, 20), np.sin(np.linspace(0, 2, 20)))
        ax_inset.set_xlim(0, 2)

    def test_shared_axis_multi_panel(self):
        """Panels sharing x-axis."""
        fig, (ax1, ax2) = plt.subplots(2, 1, sharex=True, figsize=(8, 6))
        t = np.linspace(0, 10, 200)
        ax1.plot(t, np.sin(t), color='blue')
        ax2.plot(t, np.cos(t), color='red')
        ax1.set_ylabel('sin(t)')
        ax2.set_ylabel('cos(t)')
        ax2.set_xlabel('Time (s)')
        plt.tight_layout()

    def test_legend_outside(self):
        """Legend placed outside axes."""
        fig, ax = plt.subplots(figsize=(8, 4))
        for i in range(5):
            ax.plot(np.random.rand(10), label=f'Series {i}')
        ax.legend(loc='center left', bbox_to_anchor=(1, 0.5))
        plt.tight_layout()

    def test_annotate_with_formula(self):
        """LaTeX-like annotations in text."""
        fig, ax = plt.subplots()
        x = np.linspace(-3, 3, 100)
        ax.plot(x, x**2)
        ax.text(0.5, 0.9, 'f(x) = x^2', transform=ax.transAxes,
                ha='center', fontsize=12)

    def test_colorbar_label_fontsize(self):
        """Colorbar with proper label and font size."""
        fig, ax = plt.subplots()
        data = np.random.rand(10, 10)
        im = ax.imshow(data, cmap='viridis')
        cbar = fig.colorbar(im, ax=ax)
        cbar.set_label('Intensity', fontsize=12)

    def test_tick_spacing_publication(self):
        """Control tick spacing for clean look."""
        import matplotlib.ticker as ticker
        fig, ax = plt.subplots()
        ax.plot(np.linspace(0, 10, 100), np.sin(np.linspace(0, 10, 100)))
        ax.xaxis.set_major_locator(ticker.MultipleLocator(2))
        ax.yaxis.set_major_locator(ticker.MultipleLocator(0.5))
        ax.set_xlim(0, 10)
        ax.set_ylim(-1.5, 1.5)


class TestFigureExport:
    """Tests for figure export patterns."""

    def teardown_method(self):
        plt.close('all')

    def test_export_png_tight(self):
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3])
        ax.set_xlabel('x label with descenders')
        buf = io.BytesIO()
        fig.savefig(buf, format='png', bbox_inches='tight')
        buf.seek(0)
        assert len(buf.read()) > 0

    def test_export_with_facecolor(self):
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3])
        buf = io.BytesIO()
        fig.savefig(buf, format='png', facecolor='white', edgecolor='none')
        buf.seek(0)
        assert len(buf.read()) > 0

    def test_export_transparent(self):
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3])
        buf = io.BytesIO()
        fig.savefig(buf, format='png', transparent=True)
        buf.seek(0)
        assert len(buf.read()) > 0

    def test_multiple_figs_export(self):
        """Export multiple figures."""
        figs = []
        for i in range(3):
            fig, ax = plt.subplots()
            ax.plot([i, i+1, i+2])
            ax.set_title(f'Figure {i}')
            figs.append(fig)
        for fig in figs:
            buf = io.BytesIO()
            fig.savefig(buf, format='png')
            buf.seek(0)
            assert len(buf.read()) > 0
