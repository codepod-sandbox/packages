"""Tests for matplotlib.path.Path and related drawing primitives."""

import pytest
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.path as mpath
import matplotlib.patches as mpatches


# ---------------------------------------------------------------------------
# Path creation
# ---------------------------------------------------------------------------

class TestPathCreation:
    def test_path_basic(self):
        """Path with vertices and codes can be created."""
        path = mpath.Path(
            vertices=[(0, 0), (1, 0), (1, 1), (0, 1), (0, 0)],
            codes=[mpath.Path.MOVETO, mpath.Path.LINETO,
                   mpath.Path.LINETO, mpath.Path.LINETO,
                   mpath.Path.CLOSEPOLY],
        )
        assert path is not None

    def test_path_moveto_lineto(self):
        """Path with just MOVETO and LINETO works."""
        path = mpath.Path(
            [(0, 0), (1, 1)],
            [mpath.Path.MOVETO, mpath.Path.LINETO]
        )
        assert path is not None

    def test_path_unit_circle(self):
        """Path.unit_circle() returns a circle path."""
        path = mpath.Path.unit_circle()
        assert path is not None

    def test_path_unit_rectangle(self):
        """Path.unit_rectangle() returns a rectangle path."""
        path = mpath.Path.unit_rectangle()
        assert path is not None

    def test_path_codes(self):
        """Path constants are accessible."""
        assert mpath.Path.MOVETO is not None
        assert mpath.Path.LINETO is not None
        assert mpath.Path.CURVE3 is not None
        assert mpath.Path.CURVE4 is not None
        assert mpath.Path.CLOSEPOLY is not None

    def test_path_vertices(self):
        """Path.vertices returns the vertex array."""
        verts = [(0, 0), (1, 0), (1, 1)]
        codes = [mpath.Path.MOVETO, mpath.Path.LINETO, mpath.Path.LINETO]
        path = mpath.Path(verts, codes)
        assert len(path.vertices) == 3


# ---------------------------------------------------------------------------
# PathPatch
# ---------------------------------------------------------------------------

class TestPathPatch:
    def test_pathpatch_basic(self):
        """PathPatch can be created and added to axes."""
        path = mpath.Path(
            [(0, 0), (1, 0), (0.5, 1), (0, 0)],
            [mpath.Path.MOVETO, mpath.Path.LINETO,
             mpath.Path.LINETO, mpath.Path.CLOSEPOLY]
        )
        fig, ax = plt.subplots()
        patch = mpatches.PathPatch(path, facecolor='cyan', edgecolor='black')
        ax.add_patch(patch)
        plt.close('all')

    def test_pathpatch_alpha(self):
        """PathPatch with alpha does not raise."""
        path = mpath.Path([(0, 0), (1, 0), (1, 1)],
                          [mpath.Path.MOVETO, mpath.Path.LINETO,
                           mpath.Path.LINETO])
        fig, ax = plt.subplots()
        patch = mpatches.PathPatch(path, alpha=0.5)
        ax.add_patch(patch)
        plt.close('all')

    def test_pathpatch_svg(self):
        """PathPatch renders to SVG."""
        # A star shape via Path
        import math
        outer = 1.0
        inner = 0.4
        n = 5
        verts = []
        codes = []
        for i in range(n):
            angle_out = math.pi / 2 + 2 * math.pi * i / n
            angle_in = angle_out + math.pi / n
            verts.append((outer * math.cos(angle_out),
                          outer * math.sin(angle_out)))
            codes.append(mpath.Path.MOVETO if i == 0 else mpath.Path.LINETO)
            verts.append((inner * math.cos(angle_in),
                          inner * math.sin(angle_in)))
            codes.append(mpath.Path.LINETO)
        verts.append(verts[0])
        codes.append(mpath.Path.CLOSEPOLY)
        path = mpath.Path(verts, codes)
        fig, ax = plt.subplots()
        patch = mpatches.PathPatch(path, facecolor='gold', edgecolor='black')
        ax.add_patch(patch)
        ax.set_xlim(-1.5, 1.5)
        ax.set_ylim(-1.5, 1.5)
        ax.set_aspect('equal')
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')


# ---------------------------------------------------------------------------
# Bezier curves via Path
# ---------------------------------------------------------------------------

class TestBezierPath:
    def test_quadratic_bezier(self):
        """Path with CURVE3 (quadratic bezier) does not raise."""
        path = mpath.Path(
            [(0, 0), (0.5, 1), (1, 0)],
            [mpath.Path.MOVETO, mpath.Path.CURVE3, mpath.Path.CURVE3]
        )
        fig, ax = plt.subplots()
        patch = mpatches.PathPatch(path, facecolor='none', edgecolor='blue')
        ax.add_patch(patch)
        plt.close('all')

    def test_cubic_bezier(self):
        """Path with CURVE4 (cubic bezier) does not raise."""
        path = mpath.Path(
            [(0, 0), (0.3, 1), (0.7, 1), (1, 0)],
            [mpath.Path.MOVETO, mpath.Path.CURVE4,
             mpath.Path.CURVE4, mpath.Path.CURVE4]
        )
        fig, ax = plt.subplots()
        patch = mpatches.PathPatch(path, facecolor='none', edgecolor='red')
        ax.add_patch(patch)
        plt.close('all')
