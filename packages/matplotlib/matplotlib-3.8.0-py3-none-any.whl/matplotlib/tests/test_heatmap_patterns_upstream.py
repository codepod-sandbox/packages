"""
Upstream tests for heatmap and matrix visualization patterns commonly used by LLMs.
"""

import pytest
import numpy as np
import matplotlib.pyplot as plt


class TestHeatmapBasic:
    """Tests for heatmap creation patterns (common seaborn alternative)."""

    def teardown_method(self):
        plt.close('all')

    def test_imshow_as_heatmap(self):
        """imshow with square data as a heatmap."""
        data = np.random.rand(5, 5)
        fig, ax = plt.subplots()
        im = ax.imshow(data, cmap='YlOrRd')
        assert im is not None

    def test_heatmap_with_colorbar(self):
        data = np.random.rand(8, 8)
        fig, ax = plt.subplots()
        im = ax.imshow(data, cmap='hot')
        fig.colorbar(im, ax=ax)

    def test_heatmap_annotations(self):
        """Annotate each cell with its value."""
        data = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
        fig, ax = plt.subplots()
        im = ax.imshow(data, cmap='Blues')
        for i in range(3):
            for j in range(3):
                ax.text(j, i, str(data[i, j]), ha='center', va='center', color='black')

    def test_heatmap_custom_ticks(self):
        labels = ['A', 'B', 'C', 'D']
        data = np.random.rand(4, 4)
        fig, ax = plt.subplots()
        im = ax.imshow(data)
        ax.set_xticks(range(4))
        ax.set_yticks(range(4))
        ax.set_xticklabels(labels)
        ax.set_yticklabels(labels)

    def test_heatmap_correlation_matrix(self):
        """Correlation matrix heatmap pattern."""
        rng = np.random.default_rng(42)
        data = rng.normal(0, 1, (50, 5))
        corr = np.corrcoef(data.T)
        fig, ax = plt.subplots(figsize=(6, 5))
        im = ax.imshow(corr, cmap='RdBu', vmin=-1, vmax=1)
        fig.colorbar(im, ax=ax)
        ax.set_title('Correlation Matrix')

    def test_heatmap_confusion_matrix(self):
        """Confusion matrix visualization."""
        cm = np.array([[50, 2, 1], [3, 45, 4], [2, 3, 48]])
        fig, ax = plt.subplots()
        im = ax.imshow(cm, interpolation='nearest', cmap='Blues')
        ax.set_xlabel('Predicted')
        ax.set_ylabel('True')
        for i in range(3):
            for j in range(3):
                ax.text(j, i, str(cm[i, j]), ha='center', va='center')

    def test_heatmap_diverging_centered(self):
        """Diverging colormap centered at zero."""
        data = np.random.randn(6, 6)
        fig, ax = plt.subplots()
        vmax = np.abs(data).max()
        im = ax.imshow(data, cmap='RdBu_r', vmin=-vmax, vmax=vmax)
        fig.colorbar(im, ax=ax)

    def test_pcolormesh_heatmap(self):
        """pcolormesh as heatmap."""
        data = np.random.rand(6, 6)
        fig, ax = plt.subplots()
        pc = ax.pcolormesh(data, cmap='viridis')
        fig.colorbar(pc, ax=ax)

    def test_heatmap_masked_values(self):
        """Heatmap with masked (NaN) values."""
        data = np.random.rand(5, 5)
        data[2, 2] = np.nan
        import matplotlib.cm as cm
        import matplotlib.colors as mcolors
        cmap = plt.get_cmap('viridis')
        cmap.set_bad('gray', 1.0)
        fig, ax = plt.subplots()
        masked = np.ma.array(data, mask=np.isnan(data))
        im = ax.imshow(masked, cmap=cmap)
        assert im is not None

    def test_heatmap_with_labels_and_title(self):
        n = 4
        data = np.random.rand(n, n)
        fig, ax = plt.subplots(figsize=(5, 4))
        im = ax.imshow(data, cmap='YlGnBu')
        fig.colorbar(im)
        ax.set_xticks(range(n))
        ax.set_yticks(range(n))
        ax.set_xticklabels([f'X{i}' for i in range(n)])
        ax.set_yticklabels([f'Y{i}' for i in range(n)])
        ax.set_title('Sample Heatmap')
        plt.tight_layout()


class TestMatrixPlots:
    """Tests for matrix and 2D array visualization."""

    def teardown_method(self):
        plt.close('all')

    def test_spy_matrix(self):
        """Visualize sparsity pattern of a matrix."""
        data = np.eye(5)
        data[0, 2] = 1
        data[3, 1] = 1
        fig, ax = plt.subplots()
        ax.spy(data)

    def test_matshow(self):
        """matshow for small matrices."""
        data = np.random.rand(4, 4)
        fig, ax = plt.subplots()
        ax.matshow(data, cmap='RdYlGn')

    def test_imshow_integer_data(self):
        data = np.arange(25).reshape(5, 5)
        fig, ax = plt.subplots()
        im = ax.imshow(data, cmap='copper')
        assert im is not None

    def test_imshow_float_data(self):
        data = np.linspace(0, 1, 100).reshape(10, 10)
        fig, ax = plt.subplots()
        im = ax.imshow(data, cmap='gray')
        assert im is not None

    def test_imshow_2d_gaussian(self):
        x = np.linspace(-3, 3, 50)
        y = np.linspace(-3, 3, 50)
        X, Y = np.meshgrid(x, y)
        Z = np.exp(-(X ** 2 + Y ** 2) / 2)
        fig, ax = plt.subplots()
        im = ax.imshow(Z, extent=[-3, 3, -3, 3], cmap='hot', origin='lower')
        fig.colorbar(im, ax=ax)

    def test_multiple_heatmaps(self):
        """Side-by-side heatmaps."""
        fig, axes = plt.subplots(1, 2, figsize=(10, 4))
        data1 = np.random.rand(5, 5)
        data2 = np.random.rand(5, 5)
        im1 = axes[0].imshow(data1, cmap='Blues')
        im2 = axes[1].imshow(data2, cmap='Reds')
        fig.colorbar(im1, ax=axes[0])
        fig.colorbar(im2, ax=axes[1])
        plt.tight_layout()
