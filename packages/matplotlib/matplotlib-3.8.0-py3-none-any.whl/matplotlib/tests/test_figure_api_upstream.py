"""Tests for Figure API: add_subplot, add_axes, text, lines, patches, etc."""

import pytest
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.lines as mlines


# ---------------------------------------------------------------------------
# Figure.add_subplot
# ---------------------------------------------------------------------------

class TestFigureAddSubplot:
    def test_add_subplot_111(self):
        """add_subplot(111) does not raise."""
        fig = plt.figure()
        ax = fig.add_subplot(111)
        assert ax is not None
        plt.close('all')

    def test_add_subplot_nrows_ncols_index(self):
        """add_subplot(2, 2, 1) does not raise."""
        fig = plt.figure()
        for i in range(1, 5):
            ax = fig.add_subplot(2, 2, i)
            assert ax is not None
        plt.close('all')

    def test_add_subplot_polar(self):
        """add_subplot with projection='polar' does not raise."""
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='polar')
        assert ax is not None
        plt.close('all')

    def test_add_subplot_returns_axes(self):
        """add_subplot returns an Axes object."""
        from matplotlib.axes import Axes
        fig = plt.figure()
        ax = fig.add_subplot(111)
        assert isinstance(ax, Axes)
        plt.close('all')


# ---------------------------------------------------------------------------
# Figure.add_axes
# ---------------------------------------------------------------------------

class TestFigureAddAxes:
    def test_add_axes_rect(self):
        """add_axes with rect=[l, b, w, h] does not raise."""
        fig = plt.figure()
        ax = fig.add_axes([0.1, 0.1, 0.8, 0.8])
        assert ax is not None
        plt.close('all')

    def test_add_axes_small(self):
        """add_axes with small inset rect does not raise."""
        fig = plt.figure()
        ax_main = fig.add_axes([0.1, 0.1, 0.8, 0.8])
        ax_inset = fig.add_axes([0.65, 0.65, 0.25, 0.25])
        assert ax_inset is not None
        plt.close('all')


# ---------------------------------------------------------------------------
# Figure text and annotations
# ---------------------------------------------------------------------------

class TestFigureText:
    def test_figure_text(self):
        """Figure.text() does not raise."""
        fig = plt.figure()
        t = fig.text(0.5, 0.5, 'center label')
        assert t is not None
        plt.close('all')

    def test_figure_text_fontsize(self):
        """Figure.text() with fontsize does not raise."""
        fig = plt.figure()
        t = fig.text(0.5, 0.98, 'Title', fontsize=14,
                     ha='center', va='top')
        assert t is not None
        plt.close('all')

    def test_suptitle_returns_text(self):
        """suptitle returns a Text object."""
        fig, axes = plt.subplots(1, 2)
        t = fig.suptitle('Overall Title')
        assert t is not None
        plt.close('all')


# ---------------------------------------------------------------------------
# Figure patches and lines
# ---------------------------------------------------------------------------

class TestFigureArtists:
    def test_figure_add_artist(self):
        """Figure.add_artist() does not raise."""
        fig = plt.figure()
        line = mlines.Line2D([0.1, 0.9], [0.5, 0.5], color='red')
        fig.add_artist(line)
        plt.close('all')

    def test_figure_lines_collection(self):
        """figure.lines is accessible (returns list, possibly empty)."""
        fig = plt.figure()
        ax = fig.add_subplot(111)
        ax.plot([0, 1], [0, 1])
        lines = getattr(fig, 'lines', [])
        assert lines is not None
        plt.close('all')


# ---------------------------------------------------------------------------
# Figure.get_axes()
# ---------------------------------------------------------------------------

class TestFigureGetAxes:
    def test_get_axes_single(self):
        """get_axes() returns list with one axes."""
        fig, ax = plt.subplots()
        axes_list = fig.get_axes()
        assert len(axes_list) == 1
        plt.close('all')

    def test_get_axes_multiple(self):
        """get_axes() returns all added axes."""
        fig, axes = plt.subplots(2, 2)
        axes_list = fig.get_axes()
        assert len(axes_list) == 4
        plt.close('all')

    def test_figure_axes_attribute(self):
        """figure.axes list is accessible."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        assert len(fig.axes) >= 1
        plt.close('all')


# ---------------------------------------------------------------------------
# Figure savefig variants
# ---------------------------------------------------------------------------

class TestFigureSavefig:
    def test_savefig_bbox_tight(self):
        """savefig with bbox_inches='tight' does not raise."""
        import io
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        buf = io.BytesIO()
        fig.savefig(buf, format='png', bbox_inches='tight')
        assert buf.tell() > 0
        plt.close('all')

    def test_savefig_facecolor(self):
        """savefig with facecolor does not raise."""
        import io
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        buf = io.BytesIO()
        fig.savefig(buf, format='png', facecolor='white')
        assert buf.tell() > 0
        plt.close('all')

    def test_savefig_transparent(self):
        """savefig with transparent=True does not raise."""
        import io
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        buf = io.BytesIO()
        fig.savefig(buf, format='png', transparent=True)
        assert buf.tell() > 0
        plt.close('all')


# ---------------------------------------------------------------------------
# plt.gcf() / plt.gca()
# ---------------------------------------------------------------------------

class TestGcfGca:
    def test_gcf(self):
        """plt.gcf() returns current figure."""
        fig = plt.figure()
        gcf = plt.gcf()
        assert gcf is fig
        plt.close('all')

    def test_gca(self):
        """plt.gca() returns current axes."""
        fig, ax = plt.subplots()
        gca = plt.gca()
        assert gca is ax
        plt.close('all')

    def test_gcf_after_subplots(self):
        """plt.gcf() works after subplots()."""
        fig, ax = plt.subplots()
        gcf = plt.gcf()
        assert gcf is not None
        plt.close('all')
