"""Tests for step, stackplot, stem, broken_barh, eventplot and other special plot types."""

import pytest
import matplotlib.pyplot as plt
import numpy as np


class TestStepPlot:
    def test_step_basic(self):
        """Basic step plot."""
        fig, ax = plt.subplots()
        x = [0, 1, 2, 3, 4]
        y = [0, 1, 0, 1, 0]
        result = ax.step(x, y)
        assert result is not None
        plt.close('all')

    def test_step_pre(self):
        """Step with 'pre' where."""
        fig, ax = plt.subplots()
        ax.step([1, 2, 3], [1, 2, 1], where='pre')
        plt.close('all')

    def test_step_post(self):
        """Step with 'post' where."""
        fig, ax = plt.subplots()
        ax.step([1, 2, 3], [1, 2, 1], where='post')
        plt.close('all')

    def test_step_mid(self):
        """Step with 'mid' where."""
        fig, ax = plt.subplots()
        ax.step([1, 2, 3], [1, 2, 1], where='mid')
        plt.close('all')

    def test_step_styled(self):
        """Step with color and linestyle."""
        fig, ax = plt.subplots()
        ax.step([1, 2, 3, 4], [2, 1, 3, 2], color='red', linewidth=2)
        plt.close('all')

    def test_step_with_plot(self):
        """Step combined with regular plot."""
        fig, ax = plt.subplots()
        x = [1, 2, 3, 4, 5]
        y = [2, 3, 1, 4, 2]
        ax.step(x, y, label='step', where='mid')
        ax.plot(x, y, 'o', label='data')
        ax.legend()
        plt.close('all')

    def test_step_numpy_arrays(self):
        """Step with numpy arrays."""
        fig, ax = plt.subplots()
        x = [0.0, 1.0, 2.0, 3.0]
        y = [1.0, 3.0, 2.0, 4.0]
        ax.step(x, y)
        plt.close('all')


class TestStackplot:
    def test_stackplot_basic(self):
        """Basic stackplot."""
        fig, ax = plt.subplots()
        x = [1, 2, 3, 4, 5]
        y1 = [1, 2, 3, 2, 1]
        y2 = [2, 1, 2, 3, 2]
        result = ax.stackplot(x, y1, y2)
        assert result is not None
        plt.close('all')

    def test_stackplot_with_labels(self):
        """Stackplot with labels."""
        fig, ax = plt.subplots()
        x = [1, 2, 3, 4]
        ax.stackplot(x, [1, 2, 3, 2], [2, 1, 2, 1], labels=['Group A', 'Group B'])
        ax.legend()
        plt.close('all')

    def test_stackplot_with_colors(self):
        """Stackplot with explicit colors."""
        fig, ax = plt.subplots()
        x = [1, 2, 3]
        ax.stackplot(x, [1, 2, 1], [2, 1, 2], colors=['blue', 'orange'])
        plt.close('all')

    def test_stackplot_three_series(self):
        """Stackplot with three data series."""
        fig, ax = plt.subplots()
        x = [0, 1, 2, 3, 4]
        ax.stackplot(x, [1, 2, 3, 2, 1], [2, 1, 2, 1, 2], [1, 1, 1, 1, 1],
                     labels=['A', 'B', 'C'])
        ax.legend(loc='upper left')
        plt.close('all')

    def test_stackplot_baseline_zero(self):
        """Stackplot with zero baseline."""
        fig, ax = plt.subplots()
        x = [1, 2, 3]
        ax.stackplot(x, [1, 2, 3], [3, 2, 1], baseline='zero')
        plt.close('all')

    def test_stackplot_alpha(self):
        """Stackplot with alpha."""
        fig, ax = plt.subplots()
        x = [1, 2, 3, 4]
        ax.stackplot(x, [1, 2, 1, 2], [2, 1, 2, 1], alpha=0.7)
        plt.close('all')


class TestStemPlot:
    def test_stem_basic(self):
        """Basic stem plot."""
        fig, ax = plt.subplots()
        x = [1, 2, 3, 4, 5]
        y = [1, 3, 2, 4, 1]
        result = ax.stem(x, y)
        assert result is not None
        plt.close('all')

    def test_stem_formats(self):
        """Stem with format strings."""
        fig, ax = plt.subplots()
        ax.stem([1, 2, 3], [3, 1, 4], linefmt='r-', markerfmt='ro', basefmt='k-')
        plt.close('all')

    def test_stem_numpy(self):
        """Stem with numpy arrays."""
        fig, ax = plt.subplots()
        x = [0.0, 1.0, 2.0, 3.0, 4.0]
        y = [2.0, 4.0, 3.0, 5.0, 1.0]
        ax.stem(x, y)
        plt.close('all')

    def test_stem_no_x(self):
        """Stem with only y values."""
        fig, ax = plt.subplots()
        ax.stem([2, 4, 1, 3, 5])
        plt.close('all')


class TestBrokenBarh:
    def test_broken_barh_basic(self):
        """Basic broken_barh plot."""
        fig, ax = plt.subplots()
        ax.broken_barh([(10, 50), (100, 20), (130, 10)], (10, 9))
        plt.close('all')

    def test_broken_barh_multiple_rows(self):
        """Broken barh with multiple rows."""
        fig, ax = plt.subplots()
        ax.broken_barh([(10, 50), (100, 20)], (10, 9), facecolors='blue')
        ax.broken_barh([(20, 30), (120, 40)], (20, 9), facecolors='red')
        plt.close('all')

    def test_broken_barh_styled(self):
        """Broken barh with styling."""
        fig, ax = plt.subplots()
        ax.broken_barh([(10, 30), (60, 20)], (15, 5),
                       facecolors='cyan', edgecolors='black', linewidth=2)
        plt.close('all')

    def test_broken_barh_with_labels(self):
        """Broken barh with axis labels."""
        fig, ax = plt.subplots()
        ax.broken_barh([(10, 50)], (10, 9))
        ax.set_ylim(5, 35)
        ax.set_xlim(0, 200)
        ax.set_xlabel('time (s)')
        ax.set_yticks([15, 25])
        ax.set_yticklabels(['Task 1', 'Task 2'])
        ax.grid(True)
        plt.close('all')


class TestEventPlot:
    def test_eventplot_basic(self):
        """Basic eventplot."""
        fig, ax = plt.subplots()
        positions = [1, 2, 3, 4, 5]
        result = ax.eventplot(positions)
        assert result is not None
        plt.close('all')

    def test_eventplot_multiple_sets(self):
        """Eventplot with multiple sets."""
        fig, ax = plt.subplots()
        positions = [[1, 2, 3], [1.5, 2.5, 3.5], [2, 3, 4]]
        ax.eventplot(positions)
        plt.close('all')

    def test_eventplot_horizontal(self):
        """Eventplot horizontal orientation."""
        fig, ax = plt.subplots()
        ax.eventplot([1, 2, 3, 4], orientation='horizontal')
        plt.close('all')

    def test_eventplot_vertical(self):
        """Eventplot vertical orientation."""
        fig, ax = plt.subplots()
        ax.eventplot([1, 2, 3, 4], orientation='vertical')
        plt.close('all')

    def test_eventplot_styled(self):
        """Eventplot with styling."""
        fig, ax = plt.subplots()
        ax.eventplot([1, 2, 3, 4, 5], colors='red', lineoffsets=1, linelengths=0.8)
        plt.close('all')


class TestSpanSelectors:
    def test_axvspan(self):
        """Add vertical span."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3, 4, 5], [1, 2, 1, 2, 1])
        ax.axvspan(2, 3, alpha=0.3, color='yellow')
        plt.close('all')

    def test_axhspan(self):
        """Add horizontal span."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3, 4, 5], [1, 2, 3, 2, 1])
        ax.axhspan(1.5, 2.5, alpha=0.3, color='green')
        plt.close('all')

    def test_axvline(self):
        """Add vertical line."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3])
        ax.axvline(x=2, color='red', linestyle='--')
        plt.close('all')

    def test_axhline(self):
        """Add horizontal line."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 1])
        ax.axhline(y=1.5, color='blue', linestyle=':')
        plt.close('all')

    def test_axvline_default(self):
        """axvline with default x."""
        fig, ax = plt.subplots()
        ax.axvline()
        plt.close('all')

    def test_multiple_spans(self):
        """Multiple spans and lines."""
        fig, ax = plt.subplots()
        ax.plot([0, 10], [0, 10])
        ax.axvspan(2, 4, alpha=0.2, color='blue', label='Region A')
        ax.axvspan(6, 8, alpha=0.2, color='red', label='Region B')
        ax.axhline(y=5, color='green', linestyle='--', label='Threshold')
        ax.legend()
        plt.close('all')
