"""Tests for pie, boxplot, violinplot, step, broken_barh, table, and related chart types."""

import pytest
import numpy as np
import matplotlib.pyplot as plt


# ---------------------------------------------------------------------------
# ax.pie()
# ---------------------------------------------------------------------------

class TestPie:
    def test_pie_basic(self):
        """pie(sizes) does not raise."""
        fig, ax = plt.subplots()
        result = ax.pie([30, 25, 20, 15, 10])
        assert result is not None
        plt.close('all')

    def test_pie_returns_tuple(self):
        """pie returns a tuple (patches, texts, ...)."""
        fig, ax = plt.subplots()
        result = ax.pie([1, 2, 3])
        assert isinstance(result, tuple)
        assert len(result) >= 2
        plt.close('all')

    def test_pie_with_labels(self):
        """pie with labels does not raise."""
        fig, ax = plt.subplots()
        ax.pie([30, 25, 45], labels=['A', 'B', 'C'])
        plt.close('all')

    def test_pie_with_autopct(self):
        """pie with autopct does not raise."""
        fig, ax = plt.subplots()
        ax.pie([30, 25, 45], autopct='%1.1f%%')
        plt.close('all')

    def test_pie_labels_in_svg(self):
        """pie sector labels appear in SVG."""
        fig, ax = plt.subplots()
        ax.pie([50, 50], labels=['Alpha', 'Beta'])
        svg = fig.to_svg()
        assert 'Alpha' in svg
        plt.close('all')

    def test_pie_svg_renders(self):
        """pie renders to SVG."""
        fig, ax = plt.subplots()
        ax.pie([1, 2, 3, 4])
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_pie_startangle(self):
        """pie with startangle does not raise."""
        fig, ax = plt.subplots()
        ax.pie([30, 70], startangle=90)
        plt.close('all')

    def test_pie_explode(self):
        """pie with explode does not raise."""
        fig, ax = plt.subplots()
        ax.pie([30, 70], explode=[0.1, 0])
        plt.close('all')

    def test_plt_pie(self):
        """plt.pie() wrapper works."""
        plt.figure()
        result = plt.pie([1, 2, 3])
        assert result is not None
        plt.close('all')

    def test_pie_numpy_array(self):
        """pie with numpy array input."""
        fig, ax = plt.subplots()
        sizes = np.array([30, 25, 20, 15, 10])
        result = ax.pie(sizes)
        assert result is not None
        plt.close('all')


# ---------------------------------------------------------------------------
# ax.boxplot()
# ---------------------------------------------------------------------------

class TestBoxplot:
    def test_boxplot_single_dataset(self):
        """boxplot with a single list."""
        fig, ax = plt.subplots()
        bp = ax.boxplot([1, 2, 3, 4, 5, 6, 7])
        assert isinstance(bp, dict)
        plt.close('all')

    def test_boxplot_has_boxes(self):
        """boxplot result contains 'boxes' key."""
        fig, ax = plt.subplots()
        bp = ax.boxplot([1, 2, 3, 4, 5])
        assert 'boxes' in bp
        plt.close('all')

    def test_boxplot_has_medians(self):
        """boxplot result contains 'medians' key."""
        fig, ax = plt.subplots()
        bp = ax.boxplot([1, 2, 3, 4, 5])
        assert 'medians' in bp
        plt.close('all')

    def test_boxplot_multiple_datasets(self):
        """boxplot with multiple datasets."""
        fig, ax = plt.subplots()
        data = [[1, 2, 3, 4], [2, 3, 4, 5, 6], [1, 3, 5, 7]]
        bp = ax.boxplot(data)
        assert 'boxes' in bp
        plt.close('all')

    def test_boxplot_svg_renders(self):
        """boxplot renders to SVG."""
        fig, ax = plt.subplots()
        ax.boxplot([[1, 2, 3, 4, 5], [2, 3, 4, 5, 6]])
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_boxplot_vert_false(self):
        """horizontal boxplot (vert=False) does not raise."""
        fig, ax = plt.subplots()
        ax.boxplot([1, 2, 3, 4, 5], vert=False)
        plt.close('all')

    def test_boxplot_numpy_array(self):
        """boxplot with numpy array."""
        fig, ax = plt.subplots()
        data = np.random.randn(50).tolist()
        bp = ax.boxplot(data)
        assert bp is not None
        plt.close('all')

    def test_plt_boxplot(self):
        """plt.boxplot() wrapper works."""
        plt.figure()
        result = plt.boxplot([1, 2, 3, 4, 5])
        assert result is not None
        plt.close('all')


# ---------------------------------------------------------------------------
# ax.violinplot()
# ---------------------------------------------------------------------------

class TestViolinplot:
    def test_violinplot_basic(self):
        """violinplot with single dataset."""
        fig, ax = plt.subplots()
        result = ax.violinplot([1, 2, 3, 4, 5])
        assert result is not None
        plt.close('all')

    def test_violinplot_multiple(self):
        """violinplot with multiple datasets."""
        fig, ax = plt.subplots()
        result = ax.violinplot([[1, 2, 3], [2, 3, 4, 5], [1, 3, 5]])
        assert result is not None
        plt.close('all')

    def test_violinplot_svg_renders(self):
        """violinplot renders to SVG."""
        fig, ax = plt.subplots()
        ax.violinplot([1, 2, 3, 4, 5, 4, 3, 2, 1])
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_violinplot_positions(self):
        """violinplot with explicit positions."""
        fig, ax = plt.subplots()
        ax.violinplot([[1, 2, 3], [4, 5, 6]], positions=[1, 3])
        plt.close('all')

    def test_plt_violinplot(self):
        """plt.violinplot() wrapper works."""
        plt.figure()
        result = plt.violinplot([1, 2, 3, 4, 5])
        assert result is not None
        plt.close('all')


# ---------------------------------------------------------------------------
# ax.step()
# ---------------------------------------------------------------------------

class TestStep:
    def test_step_basic(self):
        """step(x, y) does not raise."""
        fig, ax = plt.subplots()
        result = ax.step([1, 2, 3], [1, 4, 2])
        assert result is not None
        plt.close('all')

    def test_step_returns_list(self):
        """step returns a list of Line2D."""
        from matplotlib.lines import Line2D
        fig, ax = plt.subplots()
        result = ax.step([1, 2, 3], [1, 4, 2])
        assert isinstance(result, list)
        plt.close('all')

    def test_step_where_pre(self):
        """step with where='pre' does not raise."""
        fig, ax = plt.subplots()
        ax.step([1, 2, 3], [1, 4, 2], where='pre')
        plt.close('all')

    def test_step_where_post(self):
        """step with where='post' does not raise."""
        fig, ax = plt.subplots()
        ax.step([1, 2, 3], [1, 4, 2], where='post')
        plt.close('all')

    def test_step_where_mid(self):
        """step with where='mid' does not raise."""
        fig, ax = plt.subplots()
        ax.step([1, 2, 3], [1, 4, 2], where='mid')
        plt.close('all')

    def test_step_svg_renders(self):
        """step renders to SVG."""
        fig, ax = plt.subplots()
        ax.step([1, 2, 3, 4], [1, 3, 2, 4])
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_step_updates_limits(self):
        """step updates axis limits."""
        fig, ax = plt.subplots()
        ax.step([0, 10], [0, 5])
        xmin, xmax = ax.get_xlim()
        assert xmin <= 0 and xmax >= 10
        plt.close('all')

    def test_plt_step(self):
        """plt.step() wrapper works."""
        plt.figure()
        result = plt.step([1, 2, 3], [1, 4, 2])
        assert result is not None
        plt.close('all')


# ---------------------------------------------------------------------------
# ax.broken_barh()
# ---------------------------------------------------------------------------

class TestBrokenBarh:
    def test_broken_barh_basic(self):
        """broken_barh(xranges, yrange) does not raise."""
        fig, ax = plt.subplots()
        ax.broken_barh([(0, 50), (100, 30)], (10, 20))
        plt.close('all')

    def test_broken_barh_returns_list(self):
        """broken_barh returns a list of Rectangle patches."""
        fig, ax = plt.subplots()
        result = ax.broken_barh([(0, 40), (60, 20)], (5, 10))
        assert isinstance(result, list)
        assert len(result) == 2
        plt.close('all')

    def test_broken_barh_adds_to_patches(self):
        """broken_barh patches are in ax.patches."""
        fig, ax = plt.subplots()
        ax.broken_barh([(0, 30), (50, 20)], (0, 10))
        assert len(ax.patches) == 2
        plt.close('all')

    def test_broken_barh_color(self):
        """broken_barh with facecolors does not raise."""
        fig, ax = plt.subplots()
        ax.broken_barh([(0, 50)], (10, 20), facecolors='blue')
        plt.close('all')

    def test_broken_barh_multiple_rows(self):
        """multiple broken_barh calls for Gantt chart."""
        fig, ax = plt.subplots()
        ax.broken_barh([(0, 30)], (0, 8), facecolors='tab:blue')
        ax.broken_barh([(40, 20)], (10, 8), facecolors='tab:orange')
        ax.broken_barh([(20, 50)], (20, 8), facecolors='tab:green')
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_broken_barh_svg_renders(self):
        """broken_barh renders to SVG."""
        fig, ax = plt.subplots()
        ax.broken_barh([(0, 50), (100, 30)], (10, 20))
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_plt_broken_barh(self):
        """plt.broken_barh() wrapper works."""
        plt.figure()
        result = plt.broken_barh([(0, 30)], (0, 10))
        assert result is not None
        plt.close('all')


# ---------------------------------------------------------------------------
# ax.table()
# ---------------------------------------------------------------------------

class TestTable:
    def test_table_basic(self):
        """table with cellText does not raise."""
        from matplotlib.table import Table
        fig, ax = plt.subplots()
        t = ax.table(cellText=[['1', '2'], ['3', '4']], loc='center')
        assert isinstance(t, Table)
        plt.close('all')

    def test_table_with_col_labels(self):
        """table with colLabels does not raise."""
        fig, ax = plt.subplots()
        ax.table(cellText=[['a', 'b'], ['c', 'd']],
                 colLabels=['Col1', 'Col2'], loc='center')
        plt.close('all')

    def test_table_with_row_labels(self):
        """table with rowLabels does not raise."""
        fig, ax = plt.subplots()
        ax.table(cellText=[['1'], ['2']],
                 rowLabels=['Row1', 'Row2'], loc='center')
        plt.close('all')

    def test_table_svg_renders(self):
        """table renders to SVG."""
        fig, ax = plt.subplots()
        ax.table(cellText=[['A', 'B'], ['C', 'D']], loc='center')
        ax.axis('off')
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_plt_table(self):
        """plt.table() wrapper works."""
        plt.figure()
        t = plt.table(cellText=[['1', '2'], ['3', '4']])
        assert t is not None
        plt.close('all')


# ---------------------------------------------------------------------------
# ax.stem()
# ---------------------------------------------------------------------------

class TestStem:
    def test_stem_basic(self):
        """stem(x, y) does not raise."""
        fig, ax = plt.subplots()
        result = ax.stem([1, 2, 3], [1, 4, 2])
        assert result is not None
        plt.close('all')

    def test_stem_svg_renders(self):
        """stem renders to SVG."""
        fig, ax = plt.subplots()
        ax.stem([1, 2, 3, 4], [3, 1, 4, 1])
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_stem_linefmt(self):
        """stem with linefmt does not raise."""
        fig, ax = plt.subplots()
        ax.stem([1, 2, 3], [1, 4, 2], linefmt='C1-')
        plt.close('all')

    def test_plt_stem(self):
        """plt.stem() wrapper works."""
        plt.figure()
        result = plt.stem([1, 2, 3], [1, 4, 2])
        assert result is not None
        plt.close('all')
