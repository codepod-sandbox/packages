"""matplotlib test suite."""
