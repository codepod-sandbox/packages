"""Tests for advanced ticker (Formatter and Locator) patterns."""

import pytest
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker


class TestFormatters:
    def test_func_formatter(self):
        """FuncFormatter with custom function."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3])
        formatter = mticker.FuncFormatter(lambda x, pos: f'{x:.1f}')
        ax.xaxis.set_major_formatter(formatter)
        plt.close('all')

    def test_func_formatter_percent(self):
        """FuncFormatter for percentage."""
        fig, ax = plt.subplots()
        ax.plot([0.0, 0.25, 0.5, 0.75, 1.0], [1.0, 2.0, 3.0, 4.0, 5.0])
        formatter = mticker.FuncFormatter(lambda x, pos: f'{x*100:.0f}%')
        ax.xaxis.set_major_formatter(formatter)
        plt.close('all')

    def test_fixed_formatter(self):
        """FixedFormatter for categorical labels."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2, 3], [1, 2, 1, 2])
        ax.xaxis.set_major_formatter(mticker.FixedFormatter(['Q1', 'Q2', 'Q3', 'Q4']))
        ax.xaxis.set_major_locator(mticker.FixedLocator([0, 1, 2, 3]))
        plt.close('all')

    def test_format_str_formatter(self):
        """FormatStrFormatter with format string."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1000, 2000, 3000])
        ax.yaxis.set_major_formatter(mticker.FormatStrFormatter('$%d'))
        plt.close('all')

    def test_str_method_formatter(self):
        """StrMethodFormatter with str.format template."""
        fig, ax = plt.subplots()
        ax.plot([0.1, 0.5, 1.0], [1.0, 2.0, 3.0])
        ax.yaxis.set_major_formatter(mticker.StrMethodFormatter('{x:.2f}'))
        plt.close('all')

    def test_null_formatter(self):
        """NullFormatter removes tick labels."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3])
        ax.xaxis.set_major_formatter(mticker.NullFormatter())
        plt.close('all')

    def test_percent_formatter(self):
        """PercentFormatter for percentage display."""
        fig, ax = plt.subplots()
        ax.plot([0.0, 0.25, 0.5, 0.75, 1.0], [1.0, 2.0, 3.0, 4.0, 5.0])
        ax.xaxis.set_major_formatter(mticker.PercentFormatter(xmax=1.0))
        plt.close('all')

    def test_scalar_formatter(self):
        """ScalarFormatter (default)."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3])
        ax.xaxis.set_major_formatter(mticker.ScalarFormatter())
        plt.close('all')


class TestLocators:
    def test_fixed_locator(self):
        """FixedLocator at specific positions."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2, 3, 4, 5], [0, 1, 2, 3, 4, 5])
        ax.xaxis.set_major_locator(mticker.FixedLocator([0, 1, 2, 3, 4, 5]))
        plt.close('all')

    def test_multiple_locator(self):
        """MultipleLocator at every N."""
        fig, ax = plt.subplots()
        ax.plot([0, 10, 20, 30], [0, 1, 2, 3])
        ax.xaxis.set_major_locator(mticker.MultipleLocator(5))
        plt.close('all')

    def test_maxn_locator(self):
        """MaxNLocator with max N ticks."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3, 4, 5], [1, 2, 3, 4, 5])
        ax.xaxis.set_major_locator(mticker.MaxNLocator(nbins=5))
        plt.close('all')

    def test_null_locator(self):
        """NullLocator removes ticks."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3])
        ax.xaxis.set_major_locator(mticker.NullLocator())
        plt.close('all')

    def test_log_locator(self):
        """LogLocator for log scale."""
        fig, ax = plt.subplots()
        ax.plot([1, 10, 100, 1000], [1, 2, 3, 4])
        ax.set_xscale('log')
        ax.xaxis.set_major_locator(mticker.LogLocator(base=10))
        plt.close('all')

    def test_linear_locator(self):
        """LinearLocator with numticks."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2, 3], [0, 1, 2, 3])
        ax.xaxis.set_major_locator(mticker.LinearLocator(numticks=5))
        plt.close('all')

    def test_auto_minor_locator(self):
        """AutoMinorLocator for minor ticks."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2, 3], [0, 1, 2, 3])
        ax.xaxis.set_minor_locator(mticker.AutoMinorLocator())
        plt.close('all')

    def test_index_locator(self):
        """IndexLocator with base and offset."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2, 3, 4, 5], [0, 1, 2, 3, 4, 5])
        ax.xaxis.set_major_locator(mticker.IndexLocator(base=2, offset=0))
        plt.close('all')


class TestTickFormatPatterns:
    def test_currency_format(self):
        """Currency formatting with FuncFormatter."""
        fig, ax = plt.subplots()
        x = [1, 2, 3, 4, 5]
        y = [1000.0, 2500.0, 1800.0, 3200.0, 2800.0]
        ax.bar(x, y)
        ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, p: f'${x:,.0f}'))
        plt.close('all')

    def test_scientific_notation_off(self):
        """Turn off scientific notation."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2, 3], [1e6, 2e6, 1.5e6, 2.5e6])
        formatter = mticker.ScalarFormatter()
        formatter.set_scientific(False)
        ax.yaxis.set_major_formatter(formatter)
        plt.close('all')

    def test_minor_ticks_with_grid(self):
        """Minor ticks with grid."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2, 3, 4, 5], [0, 1, 4, 9, 16, 25])
        ax.xaxis.set_major_locator(mticker.MultipleLocator(1))
        ax.xaxis.set_minor_locator(mticker.MultipleLocator(0.5))
        ax.grid(True, which='major', linestyle='-')
        ax.grid(True, which='minor', linestyle='--', alpha=0.5)
        plt.close('all')

    def test_combined_locator_formatter(self):
        """FixedLocator with FixedFormatter combined."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2, 3, 4], [10, 20, 30, 40, 50])
        positions = [0, 1, 2, 3, 4]
        labels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri']
        ax.xaxis.set_major_locator(mticker.FixedLocator(positions))
        ax.xaxis.set_major_formatter(mticker.FixedFormatter(labels))
        plt.close('all')

    def test_rotation_tick_labels(self):
        """Rotate tick labels."""
        fig, ax = plt.subplots()
        months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                  'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
        ax.plot(list(range(12)), [float(i) for i in range(12)])
        ax.set_xticks(list(range(12)))
        ax.set_xticklabels(months, rotation=45, ha='right')
        plt.close('all')

    def test_tick_params_labelsize(self):
        """tick_params with labelsize."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3])
        ax.tick_params(axis='both', labelsize=8)
        plt.close('all')

    def test_tick_params_direction(self):
        """tick_params with tick direction."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3])
        ax.tick_params(axis='both', direction='in')
        plt.close('all')

    def test_log_formatter_math(self):
        """LogFormatterMathtext for log axis."""
        fig, ax = plt.subplots()
        ax.plot([1, 10, 100, 1000], [1, 2, 3, 4])
        ax.set_xscale('log')
        ax.xaxis.set_major_formatter(mticker.LogFormatterMathtext())
        plt.close('all')
