"""Tests for scale transformations (log, symlog, etc.)."""

import pytest
import numpy as np
import matplotlib.pyplot as plt


class TestLogScale:
    def test_logscale_x(self):
        """set_xscale('log') does not raise."""
        fig, ax = plt.subplots()
        ax.plot([1, 10, 100, 1000])
        ax.set_xscale('log')
        plt.close('all')

    def test_logscale_y(self):
        """set_yscale('log') does not raise."""
        fig, ax = plt.subplots()
        ax.plot([1, 10, 100, 1000])
        ax.set_yscale('log')
        plt.close('all')

    def test_logscale_both(self):
        """loglog scale does not raise."""
        fig, ax = plt.subplots()
        x = np.logspace(0, 3, 20)
        ax.loglog(x, x**2)
        plt.close('all')

    def test_semilogx(self):
        """semilogx does not raise."""
        fig, ax = plt.subplots()
        x = np.logspace(0, 3, 20)
        ax.semilogx(x, np.log(x))
        plt.close('all')

    def test_semilogy(self):
        """semilogy does not raise."""
        fig, ax = plt.subplots()
        x = np.linspace(1, 10, 20)
        ax.semilogy(x, np.exp(x))
        plt.close('all')

    def test_logscale_base_10(self):
        """set_xscale('log', base=10) does not raise."""
        fig, ax = plt.subplots()
        ax.plot([1, 10, 100])
        ax.set_xscale('log', base=10)
        plt.close('all')

    def test_logscale_base_2(self):
        """set_xscale('log', base=2) does not raise."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 4, 8, 16])
        ax.set_xscale('log', base=2)
        plt.close('all')

    def test_logscale_get_xscale(self):
        """get_xscale() returns 'log' after set."""
        fig, ax = plt.subplots()
        ax.set_xscale('log')
        scale = ax.get_xscale()
        assert scale == 'log'
        plt.close('all')

    def test_logscale_get_yscale(self):
        """get_yscale() returns 'log' after set."""
        fig, ax = plt.subplots()
        ax.set_yscale('log')
        scale = ax.get_yscale()
        assert scale == 'log'
        plt.close('all')

    def test_linear_scale_default(self):
        """Default scale is 'linear'."""
        fig, ax = plt.subplots()
        assert ax.get_xscale() == 'linear'
        assert ax.get_yscale() == 'linear'
        plt.close('all')


class TestSymLogScale:
    def test_symlog_x(self):
        """set_xscale('symlog') does not raise."""
        fig, ax = plt.subplots()
        ax.plot(np.linspace(-100, 100, 50))
        ax.set_xscale('symlog')
        plt.close('all')

    def test_symlog_y(self):
        """set_yscale('symlog') does not raise."""
        fig, ax = plt.subplots()
        ax.plot(np.linspace(-100, 100, 50))
        ax.set_yscale('symlog')
        plt.close('all')

    def test_symlog_with_linthresh(self):
        """set_xscale('symlog', linthresh=0.1) does not raise."""
        fig, ax = plt.subplots()
        ax.plot([-10, -1, 0, 1, 10])
        ax.set_xscale('symlog', linthresh=0.1)
        plt.close('all')


class TestScaleSVG:
    def test_logscale_svg(self):
        """Log-scaled plot renders to SVG."""
        fig, ax = plt.subplots()
        x = np.logspace(0, 3, 10)
        ax.semilogy(x, x)
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_loglog_svg(self):
        """Loglog plot renders to SVG."""
        fig, ax = plt.subplots()
        x = np.logspace(0, 2, 10)
        ax.loglog(x, x**2)
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')
