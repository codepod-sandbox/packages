"""Tests for imshow patterns and 2D data visualization."""

import pytest
import io
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors


class TestImshowBasic:
    def test_imshow_2d_array(self):
        """imshow with 2D numerical array."""
        fig, ax = plt.subplots()
        data = [[1.0, 2.0, 3.0], [4.0, 5.0, 6.0], [7.0, 8.0, 9.0]]
        im = ax.imshow(data)
        assert im is not None
        plt.close('all')

    def test_imshow_cmap(self):
        """imshow with colormap."""
        fig, ax = plt.subplots()
        data = [[0.0, 0.5, 1.0], [0.3, 0.6, 0.9]]
        im = ax.imshow(data, cmap='viridis')
        cmap = im.get_cmap()
        cmap_name = cmap.name if hasattr(cmap, 'name') else cmap
        assert cmap_name == 'viridis'
        plt.close('all')

    def test_imshow_vmin_vmax(self):
        """imshow with explicit vmin/vmax."""
        fig, ax = plt.subplots()
        data = [[1.0, 5.0, 10.0], [15.0, 20.0, 25.0]]
        im = ax.imshow(data, vmin=0, vmax=30)
        assert im is not None
        plt.close('all')

    def test_imshow_rgb(self):
        """imshow with RGB data."""
        fig, ax = plt.subplots()
        # HxWx3 RGB array
        data = [[[255, 0, 0], [0, 255, 0]], [[0, 0, 255], [255, 255, 0]]]
        im = ax.imshow(data)
        assert im is not None
        plt.close('all')

    def test_imshow_rgba(self):
        """imshow with RGBA data."""
        fig, ax = plt.subplots()
        data = [[[255, 0, 0, 128], [0, 255, 0, 255]]]
        im = ax.imshow(data)
        assert im is not None
        plt.close('all')

    def test_imshow_origin(self):
        """imshow with origin parameter."""
        fig, ax = plt.subplots()
        data = [[1.0, 2.0], [3.0, 4.0]]
        ax.imshow(data, origin='upper')
        ax.imshow(data, origin='lower')
        plt.close('all')

    def test_imshow_aspect(self):
        """imshow with aspect ratio."""
        fig, ax = plt.subplots()
        data = [[1.0, 2.0, 3.0, 4.0, 5.0]]
        ax.imshow(data, aspect='auto')
        plt.close('all')

    def test_imshow_extent(self):
        """imshow with extent."""
        fig, ax = plt.subplots()
        data = [[1.0, 2.0], [3.0, 4.0]]
        im = ax.imshow(data, extent=[-1, 1, -1, 1])
        assert im is not None
        plt.close('all')

    def test_imshow_interpolation(self):
        """imshow with interpolation."""
        fig, ax = plt.subplots()
        data = [[1.0, 2.0], [3.0, 4.0]]
        ax.imshow(data, interpolation='nearest')
        plt.close('all')

    def test_imshow_with_colorbar(self):
        """imshow with colorbar."""
        fig, ax = plt.subplots()
        data = [[1.0, 2.0, 3.0], [4.0, 5.0, 6.0], [7.0, 8.0, 9.0]]
        im = ax.imshow(data, cmap='hot')
        cbar = plt.colorbar(im)
        assert cbar is not None
        plt.close('all')

    def test_imshow_with_title(self):
        """imshow with title and labels."""
        fig, ax = plt.subplots()
        data = [[1.0, 2.0], [3.0, 4.0]]
        ax.imshow(data, cmap='viridis')
        ax.set_title('Heatmap')
        ax.set_xlabel('X')
        ax.set_ylabel('Y')
        plt.close('all')


class TestPcolormeshPatterns:
    def test_pcolormesh_basic(self):
        """Basic pcolormesh."""
        fig, ax = plt.subplots()
        x = [0.0, 1.0, 2.0, 3.0]
        y = [0.0, 1.0, 2.0]
        z = [[1.0, 2.0, 3.0], [4.0, 5.0, 6.0]]
        mesh = ax.pcolormesh(x, y, z)
        assert mesh is not None
        plt.close('all')

    def test_pcolormesh_cmap(self):
        """Pcolormesh with colormap."""
        fig, ax = plt.subplots()
        x = [0.0, 1.0, 2.0]
        y = [0.0, 1.0, 2.0]
        z = [[1.0, 2.0], [3.0, 4.0]]
        mesh = ax.pcolormesh(x, y, z, cmap='plasma')
        assert mesh is not None
        plt.close('all')

    def test_pcolormesh_with_colorbar(self):
        """Pcolormesh with colorbar."""
        fig, ax = plt.subplots()
        x = [0.0, 1.0, 2.0, 3.0]
        y = [0.0, 1.0, 2.0, 3.0]
        z = [[1.0, 2.0, 3.0], [4.0, 5.0, 6.0], [7.0, 8.0, 9.0]]
        mesh = ax.pcolormesh(x, y, z)
        cbar = plt.colorbar(mesh)
        assert cbar is not None
        plt.close('all')

    def test_pcolor_basic(self):
        """Basic pcolor."""
        fig, ax = plt.subplots()
        x = [0.0, 1.0, 2.0]
        y = [0.0, 1.0, 2.0]
        z = [[1.0, 2.0], [3.0, 4.0]]
        pc = ax.pcolor(x, y, z)
        assert pc is not None
        plt.close('all')


class TestContourPatterns:
    def test_contour_basic(self):
        """Basic contour plot."""
        fig, ax = plt.subplots()
        x = [0.0, 1.0, 2.0]
        y = [0.0, 1.0, 2.0]
        z = [[1.0, 2.0, 1.0], [2.0, 4.0, 2.0], [1.0, 2.0, 1.0]]
        cs = ax.contour(x, y, z)
        assert cs is not None
        plt.close('all')

    def test_contourf_basic(self):
        """Basic contourf (filled contours)."""
        fig, ax = plt.subplots()
        x = [0.0, 1.0, 2.0]
        y = [0.0, 1.0, 2.0]
        z = [[1.0, 2.0, 1.0], [2.0, 4.0, 2.0], [1.0, 2.0, 1.0]]
        cs = ax.contourf(x, y, z)
        assert cs is not None
        plt.close('all')

    def test_contourf_with_colorbar(self):
        """Contourf with colorbar."""
        fig, ax = plt.subplots()
        x = [0.0, 1.0, 2.0, 3.0]
        y = [0.0, 1.0, 2.0, 3.0]
        z = [[0.0, 1.0, 2.0, 1.0],
             [1.0, 2.0, 4.0, 2.0],
             [2.0, 4.0, 6.0, 4.0],
             [1.0, 2.0, 4.0, 2.0]]
        cs = ax.contourf(x, y, z, cmap='RdYlBu')
        cbar = plt.colorbar(cs)
        assert cbar is not None
        plt.close('all')

    def test_contour_levels(self):
        """Contour with explicit levels."""
        fig, ax = plt.subplots()
        x = [0.0, 1.0, 2.0]
        y = [0.0, 1.0, 2.0]
        z = [[1.0, 2.0, 3.0], [2.0, 3.0, 4.0], [3.0, 4.0, 5.0]]
        cs = ax.contour(x, y, z, levels=[1.5, 2.5, 3.5])
        assert cs is not None
        plt.close('all')

    def test_contour_and_contourf_combined(self):
        """Combined contour lines and filled contours."""
        fig, ax = plt.subplots()
        x = [0.0, 1.0, 2.0]
        y = [0.0, 1.0, 2.0]
        z = [[1.0, 2.0, 1.0], [2.0, 4.0, 2.0], [1.0, 2.0, 1.0]]
        filled = ax.contourf(x, y, z, cmap='viridis')
        lines = ax.contour(x, y, z, colors='black', linewidths=0.5)
        assert filled is not None
        assert lines is not None
        plt.close('all')


class TestImshowSavefig:
    def test_imshow_savefig_png(self):
        """imshow saved to PNG."""
        fig, ax = plt.subplots()
        data = [[1.0, 2.0, 3.0], [4.0, 5.0, 6.0], [7.0, 8.0, 9.0]]
        ax.imshow(data, cmap='viridis')
        buf = io.BytesIO()
        fig.savefig(buf, format='png')
        buf.seek(0)
        assert len(buf.read()) > 0
        plt.close('all')

    def test_imshow_savefig_svg(self):
        """imshow saved to SVG."""
        fig, ax = plt.subplots()
        data = [[1.0, 2.0], [3.0, 4.0]]
        ax.imshow(data, cmap='hot')
        buf = io.BytesIO()
        fig.savefig(buf, format='svg')
        buf.seek(0)
        content = buf.read().decode('utf-8')
        assert '<svg' in content
        plt.close('all')
