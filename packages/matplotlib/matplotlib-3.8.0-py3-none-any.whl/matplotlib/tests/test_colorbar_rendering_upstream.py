"""Tests for colorbar rendering — fig.colorbar(), plt.colorbar(), Colorbar class."""

import io
import pytest

import matplotlib.pyplot as plt
from matplotlib.colorbar import Colorbar
import numpy as np


# ---------------------------------------------------------------------------
# Colorbar class API
# ---------------------------------------------------------------------------

class TestColorbarAPI:
    def test_colorbar_has_set_label(self):
        fig, ax = plt.subplots()
        im = ax.imshow([[1, 2], [3, 4]])
        cb = fig.colorbar(im, ax=ax)
        assert hasattr(cb, 'set_label')
        plt.close('all')

    def test_colorbar_set_get_label(self):
        fig, ax = plt.subplots()
        im = ax.imshow([[1, 2], [3, 4]])
        cb = fig.colorbar(im, ax=ax)
        cb.set_label('intensity')
        assert cb.get_label() == 'intensity'
        plt.close('all')

    def test_colorbar_set_label_none(self):
        fig, ax = plt.subplots()
        im = ax.imshow([[1, 2], [3, 4]])
        cb = fig.colorbar(im, ax=ax)
        cb.set_label(None)
        assert cb.get_label() == ''
        plt.close('all')

    def test_colorbar_set_get_ticks(self):
        fig, ax = plt.subplots()
        im = ax.imshow([[0, 1], [2, 3]])
        cb = fig.colorbar(im, ax=ax)
        cb.set_ticks([0, 1, 2, 3])
        assert cb.get_ticks() == [0, 1, 2, 3]
        plt.close('all')

    def test_colorbar_set_ticks_none_resets(self):
        fig, ax = plt.subplots()
        im = ax.imshow([[0, 1], [2, 3]])
        cb = fig.colorbar(im, ax=ax)
        cb.set_ticks([0, 1])
        cb.set_ticks(None)
        assert cb.get_ticks() is None
        plt.close('all')

    def test_colorbar_set_ticklabels(self):
        fig, ax = plt.subplots()
        im = ax.imshow([[0, 1], [2, 3]])
        cb = fig.colorbar(im, ax=ax)
        cb.set_ticks([0, 3])
        cb.set_ticklabels(['low', 'high'])
        assert cb.get_ticklabels() == ['low', 'high']
        plt.close('all')

    def test_colorbar_remove(self):
        fig, ax = plt.subplots()
        im = ax.imshow([[1, 2], [3, 4]])
        cb = fig.colorbar(im, ax=ax)
        cb.remove()
        assert ax._colorbar is None
        assert cb.ax is None
        plt.close('all')

    def test_colorbar_is_colorbar_instance(self):
        fig, ax = plt.subplots()
        im = ax.imshow([[1, 2], [3, 4]])
        cb = fig.colorbar(im, ax=ax)
        assert isinstance(cb, Colorbar)
        plt.close('all')


# ---------------------------------------------------------------------------
# fig.colorbar() registration
# ---------------------------------------------------------------------------

class TestFigureColorbar:
    def test_colorbar_stored_in_figure(self):
        fig, ax = plt.subplots()
        im = ax.imshow([[1, 2], [3, 4]])
        cb = fig.colorbar(im, ax=ax)
        assert cb in fig._colorbars
        plt.close('all')

    def test_colorbar_default_ax_is_last_axes(self):
        fig, ax = plt.subplots()
        im = ax.imshow([[1, 2], [3, 4]])
        cb = fig.colorbar(im)  # no ax= argument
        assert cb.ax is ax
        plt.close('all')

    def test_colorbar_attaches_to_axes(self):
        fig, ax = plt.subplots()
        im = ax.imshow([[1, 2], [3, 4]])
        cb = fig.colorbar(im, ax=ax)
        assert ax._colorbar is cb
        plt.close('all')

    def test_multiple_colorbars(self):
        fig, (ax1, ax2) = plt.subplots(1, 2)
        im1 = ax1.imshow([[1, 2], [3, 4]])
        im2 = ax2.imshow([[5, 6], [7, 8]])
        cb1 = fig.colorbar(im1, ax=ax1)
        cb2 = fig.colorbar(im2, ax=ax2)
        assert len(fig._colorbars) == 2
        assert cb1 in fig._colorbars
        assert cb2 in fig._colorbars
        plt.close('all')


# ---------------------------------------------------------------------------
# plt.colorbar() wrapper
# ---------------------------------------------------------------------------

class TestPltColorbar:
    def test_plt_colorbar_returns_colorbar(self):
        fig, ax = plt.subplots()
        im = ax.imshow([[1, 2], [3, 4]])
        cb = plt.colorbar(im)
        assert isinstance(cb, Colorbar)
        plt.close('all')

    def test_plt_colorbar_with_ax(self):
        fig, ax = plt.subplots()
        im = ax.imshow([[1, 2], [3, 4]])
        cb = plt.colorbar(im, ax=ax)
        assert cb.ax is ax
        plt.close('all')


# ---------------------------------------------------------------------------
# SVG rendering
# ---------------------------------------------------------------------------

class TestColorbarSVGRendering:
    def test_colorbar_svg_no_error(self):
        fig, ax = plt.subplots()
        im = ax.imshow([[1, 2], [3, 4]])
        fig.colorbar(im, ax=ax)
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_colorbar_svg_has_rects(self):
        """Colorbar gradient is made of rect elements."""
        fig, ax = plt.subplots()
        im = ax.imshow([[1, 2], [3, 4]])
        fig.colorbar(im, ax=ax)
        svg = fig.to_svg()
        assert '<rect' in svg
        plt.close('all')

    def test_colorbar_svg_has_tick_labels(self):
        """Default tick labels appear in SVG."""
        fig, ax = plt.subplots()
        im = ax.imshow([[0, 5], [10, 15]])
        fig.colorbar(im, ax=ax)
        svg = fig.to_svg()
        assert '<text' in svg or 'text' in svg
        plt.close('all')

    def test_colorbar_svg_with_label(self):
        """Custom label text appears in SVG."""
        fig, ax = plt.subplots()
        im = ax.imshow([[1, 2], [3, 4]])
        cb = fig.colorbar(im, ax=ax)
        cb.set_label('my label')
        svg = fig.to_svg()
        assert 'my label' in svg
        plt.close('all')

    def test_colorbar_svg_different_cmaps(self):
        """Different colormaps render without error."""
        for cmap in ['viridis', 'plasma', 'hot', 'coolwarm']:
            fig, ax = plt.subplots()
            im = ax.imshow([[1, 2], [3, 4]], cmap=cmap)
            fig.colorbar(im, ax=ax)
            svg = fig.to_svg()
            assert '<rect' in svg
            plt.close('all')

    def test_colorbar_axes_reserves_space(self):
        """Axes right margin is larger when colorbar attached."""
        fig, ax = plt.subplots()
        im = ax.imshow([[1, 2], [3, 4]])
        svg_without = fig.to_svg()

        fig2, ax2 = plt.subplots()
        im2 = ax2.imshow([[1, 2], [3, 4]])
        fig2.colorbar(im2, ax=ax2)
        svg_with = fig2.to_svg()

        # Both should render
        assert len(svg_without) > 0
        assert len(svg_with) > 0
        plt.close('all')


# ---------------------------------------------------------------------------
# PNG rendering
# ---------------------------------------------------------------------------

class TestColorbarPNGRendering:
    def test_colorbar_png_no_error(self):
        fig, ax = plt.subplots()
        im = ax.imshow([[1, 2], [3, 4]])
        fig.colorbar(im, ax=ax)
        buf = io.BytesIO()
        fig.savefig(buf, format='png')
        assert buf.tell() > 0
        plt.close('all')

    def test_colorbar_png_bytes_nonempty(self):
        fig, ax = plt.subplots()
        im = ax.imshow(np.arange(16).reshape(4, 4))
        fig.colorbar(im, ax=ax)
        buf = io.BytesIO()
        fig.savefig(buf, format='png')
        buf.seek(0)
        data = buf.read()
        assert data[:4] == b'\x89PNG'
        assert len(data) > 100
        plt.close('all')


# ---------------------------------------------------------------------------
# imshow + colorbar full workflow
# ---------------------------------------------------------------------------

class TestImshowColorbarWorkflow:
    def test_imshow_colorbar_viridis(self):
        """Full imshow + colorbar workflow with viridis."""
        fig, ax = plt.subplots()
        data = np.linspace(0, 1, 16).reshape(4, 4)
        im = ax.imshow(data, cmap='viridis')
        cb = fig.colorbar(im, ax=ax)
        svg = fig.to_svg()
        assert '<rect' in svg
        plt.close('all')

    def test_imshow_colorbar_explicit_clim(self):
        """Colorbar ticks reflect explicit clim."""
        fig, ax = plt.subplots()
        im = ax.imshow([[0, 50], [100, 200]])
        im.set_clim(0, 200)
        cb = fig.colorbar(im, ax=ax)
        cmap, vmin, vmax = cb._get_cmap_and_clim()
        assert vmin == 0
        assert vmax == 200
        plt.close('all')

    def test_imshow_colorbar_custom_ticks(self):
        """Custom ticks appear at correct positions."""
        fig, ax = plt.subplots()
        im = ax.imshow([[0, 100], [200, 300]])
        cb = fig.colorbar(im, ax=ax)
        cb.set_ticks([0, 150, 300])
        cb.set_ticklabels(['low', 'mid', 'high'])
        svg = fig.to_svg()
        assert 'low' in svg or len(svg) > 0
        plt.close('all')

    def test_colorbar_get_cmap_and_clim_viridis(self):
        """_get_cmap_and_clim returns correct values."""
        fig, ax = plt.subplots()
        im = ax.imshow([[10, 20], [30, 40]])
        cb = fig.colorbar(im, ax=ax)
        cmap, vmin, vmax = cb._get_cmap_and_clim()
        assert cmap is not None
        assert vmin == pytest.approx(10)
        assert vmax == pytest.approx(40)
        plt.close('all')

    def test_plt_colorbar_imshow_workflow(self):
        """plt.colorbar(im) full round-trip."""
        fig, ax = plt.subplots()
        im = ax.imshow([[1, 2], [3, 4]])
        cb = plt.colorbar(im)
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')
