"""Tests for additional axes methods: twinx/twiny, inset_axes, set_aspect, etc."""

import pytest
import numpy as np
import matplotlib.pyplot as plt


# ---------------------------------------------------------------------------
# twinx / twiny
# ---------------------------------------------------------------------------

class TestTwinAxes:
    def test_twinx_basic(self):
        """twinx() creates a second y-axis."""
        fig, ax1 = plt.subplots()
        ax2 = ax1.twinx()
        assert ax2 is not None
        plt.close('all')

    def test_twinx_plot_both(self):
        """Plotting on both twinx axes does not raise."""
        fig, ax1 = plt.subplots()
        ax1.plot([0, 1, 2], [1, 4, 9], color='blue')
        ax2 = ax1.twinx()
        ax2.plot([0, 1, 2], [100, 50, 200], color='red')
        plt.close('all')

    def test_twinx_set_ylabel(self):
        """twinx with set_ylabel on both axes does not raise."""
        fig, ax1 = plt.subplots()
        ax1.set_ylabel('Primary', color='blue')
        ax2 = ax1.twinx()
        ax2.set_ylabel('Secondary', color='red')
        plt.close('all')

    def test_twinx_svg(self):
        """twinx renders to SVG."""
        fig, ax1 = plt.subplots()
        ax1.plot([0, 1, 2], [1, 4, 9])
        ax2 = ax1.twinx()
        ax2.plot([0, 1, 2], [100, 50, 200], 'r-')
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_twiny_basic(self):
        """twiny() creates a second x-axis."""
        fig, ax1 = plt.subplots()
        ax2 = ax1.twiny()
        assert ax2 is not None
        plt.close('all')


# ---------------------------------------------------------------------------
# set_aspect
# ---------------------------------------------------------------------------

class TestSetAspect:
    def test_set_aspect_equal(self):
        """set_aspect('equal') does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        ax.set_aspect('equal')
        plt.close('all')

    def test_set_aspect_auto(self):
        """set_aspect('auto') does not raise."""
        fig, ax = plt.subplots()
        ax.set_aspect('auto')
        plt.close('all')

    def test_set_aspect_numeric(self):
        """set_aspect(1.5) does not raise."""
        fig, ax = plt.subplots()
        ax.set_aspect(1.5)
        plt.close('all')

    def test_set_aspect_equal_svg(self):
        """equal aspect ratio renders to SVG."""
        fig, ax = plt.subplots()
        theta = [i * 3.14159 / 50 for i in range(101)]
        ax.plot([np.cos(t) for t in theta], [np.sin(t) for t in theta])
        ax.set_aspect('equal')
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')


# ---------------------------------------------------------------------------
# inset_axes
# ---------------------------------------------------------------------------

class TestInsetAxes:
    def test_inset_axes_basic(self):
        """inset_axes creates a smaller axes inside the main one."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2], [1, 4, 9])
        axins = ax.inset_axes([0.6, 0.6, 0.35, 0.35])
        assert axins is not None
        plt.close('all')

    def test_inset_axes_plot(self):
        """Plotting in inset_axes does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2, 3], [1, 4, 9, 16])
        axins = ax.inset_axes([0.6, 0.6, 0.35, 0.35])
        axins.plot([0, 1], [1, 4])
        plt.close('all')

    def test_inset_axes_svg(self):
        """inset_axes renders to SVG."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2, 3], [1, 4, 9, 16])
        axins = ax.inset_axes([0.6, 0.6, 0.35, 0.35])
        axins.plot([0.5, 1.5], [2, 6])
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')


# ---------------------------------------------------------------------------
# get/set limits with auto-scaling
# ---------------------------------------------------------------------------

class TestAutoScaling:
    def test_autoscale_on(self):
        """autoscale() does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2], [1, 4, 9])
        ax.autoscale()
        plt.close('all')

    def test_autoscale_x_only(self):
        """autoscale(axis='x') does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2], [1, 4, 9])
        ax.autoscale(axis='x')
        plt.close('all')

    def test_autoscale_y_only(self):
        """autoscale(axis='y') does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2], [1, 4, 9])
        ax.autoscale(axis='y')
        plt.close('all')

    def test_relim(self):
        """relim() does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2], [1, 4, 9])
        ax.relim()
        plt.close('all')


# ---------------------------------------------------------------------------
# cla() / clf()
# ---------------------------------------------------------------------------

class TestClear:
    def test_cla_basic(self):
        """cla() clears the axes."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        ax.cla()
        plt.close('all')

    def test_clf_basic(self):
        """clf() clears the figure."""
        fig = plt.figure()
        ax = fig.add_subplot(111)
        ax.plot([0, 1], [0, 1])
        fig.clf()
        plt.close('all')

    def test_plt_cla(self):
        """plt.cla() does not raise."""
        plt.figure()
        plt.plot([0, 1], [0, 1])
        plt.cla()
        plt.close('all')

    def test_plt_clf(self):
        """plt.clf() does not raise."""
        plt.figure()
        plt.plot([0, 1], [0, 1])
        plt.clf()
        plt.close('all')


# ---------------------------------------------------------------------------
# Grid
# ---------------------------------------------------------------------------

class TestGrid:
    def test_grid_on(self):
        """grid(True) does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        ax.grid(True)
        plt.close('all')

    def test_grid_off(self):
        """grid(False) does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        ax.grid(False)
        plt.close('all')

    def test_grid_axis_x(self):
        """grid(axis='x') does not raise."""
        fig, ax = plt.subplots()
        ax.grid(axis='x')
        plt.close('all')

    def test_grid_style(self):
        """grid with linestyle and alpha does not raise."""
        fig, ax = plt.subplots()
        ax.grid(linestyle='--', alpha=0.5)
        plt.close('all')

    def test_plt_grid(self):
        """plt.grid() does not raise."""
        plt.figure()
        plt.plot([0, 1], [0, 1])
        plt.grid(True)
        plt.close('all')
