"""Tests for scales, log plots, tick formatting, and related features."""

import pytest
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker


# ---------------------------------------------------------------------------
# Log scale / semilog / loglog
# ---------------------------------------------------------------------------

class TestLogScale:
    def test_set_xscale_log(self):
        """set_xscale('log') does not raise."""
        fig, ax = plt.subplots()
        ax.plot([1, 10, 100], [1, 2, 3])
        ax.set_xscale('log')
        plt.close('all')

    def test_set_yscale_log(self):
        """set_yscale('log') does not raise."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 10, 100])
        ax.set_yscale('log')
        plt.close('all')

    def test_loglog(self):
        """loglog() does not raise."""
        fig, ax = plt.subplots()
        ax.loglog([1, 10, 100], [1, 100, 10000])
        plt.close('all')

    def test_semilogx(self):
        """semilogx() does not raise."""
        fig, ax = plt.subplots()
        ax.semilogx([1, 10, 100], [1, 2, 3])
        plt.close('all')

    def test_semilogy(self):
        """semilogy() does not raise."""
        fig, ax = plt.subplots()
        ax.semilogy([1, 2, 3], [1, 10, 100])
        plt.close('all')

    def test_log_scale_get_xscale(self):
        """get_xscale returns 'log' after set_xscale('log')."""
        fig, ax = plt.subplots()
        ax.set_xscale('log')
        assert ax.get_xscale() == 'log'
        plt.close('all')

    def test_log_scale_get_yscale(self):
        """get_yscale returns 'log' after set_yscale('log')."""
        fig, ax = plt.subplots()
        ax.set_yscale('log')
        assert ax.get_yscale() == 'log'
        plt.close('all')

    def test_linear_scale_default(self):
        """Default scale is 'linear'."""
        fig, ax = plt.subplots()
        assert ax.get_xscale() == 'linear'
        assert ax.get_yscale() == 'linear'
        plt.close('all')

    def test_log_scale_svg_renders(self):
        """Log-scale plot renders to SVG."""
        fig, ax = plt.subplots()
        ax.loglog([1, 10, 100, 1000], [1, 4, 9, 16])
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_plt_loglog(self):
        """plt.loglog() wrapper does not raise."""
        plt.figure()
        plt.loglog([1, 10, 100], [1, 100, 1000])
        plt.close('all')

    def test_plt_semilogx(self):
        """plt.semilogx() wrapper does not raise."""
        plt.figure()
        plt.semilogx([1, 10, 100], [1, 2, 3])
        plt.close('all')

    def test_plt_semilogy(self):
        """plt.semilogy() wrapper does not raise."""
        plt.figure()
        plt.semilogy([1, 2, 3], [1, 10, 100])
        plt.close('all')


# ---------------------------------------------------------------------------
# Ticker - more formatters and locators
# ---------------------------------------------------------------------------

class TestTickerMore:
    def test_log_formatter(self):
        """LogFormatter can be created."""
        fmt = ticker.LogFormatter()
        assert fmt is not None

    def test_log_formatter_math_text(self):
        """LogFormatterMathtext can be created."""
        fmt = ticker.LogFormatterMathtext()
        assert fmt is not None

    def test_log_locator(self):
        """LogLocator can be created."""
        loc = ticker.LogLocator()
        assert loc is not None

    def test_max_n_locator(self):
        """MaxNLocator with nbins does not raise."""
        loc = ticker.MaxNLocator(nbins=5)
        assert loc is not None

    def test_null_formatter(self):
        """NullFormatter formats to empty string."""
        fmt = ticker.NullFormatter()
        result = fmt(1.0, 0)
        assert result == ''

    def test_null_locator(self):
        """NullLocator can be created."""
        loc = ticker.NullLocator()
        assert loc is not None

    def test_percent_formatter(self):
        """PercentFormatter can be created."""
        fmt = ticker.PercentFormatter(xmax=1.0)
        assert fmt is not None

    def test_apply_log_locator_to_axis(self):
        """Applying LogLocator to axis after log scale does not raise."""
        fig, ax = plt.subplots()
        ax.set_xscale('log')
        ax.xaxis.set_major_locator(ticker.LogLocator(base=10))
        plt.close('all')

    def test_apply_percent_formatter(self):
        """Applying PercentFormatter to axis does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 0.25, 0.5, 0.75, 1.0], [0, 1, 4, 9, 16])
        ax.xaxis.set_major_formatter(ticker.PercentFormatter(xmax=1.0))
        plt.close('all')


# ---------------------------------------------------------------------------
# ax.margins()
# ---------------------------------------------------------------------------

class TestMargins:
    def test_margins_default(self):
        """margins() returns current margins without args."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        # Should not raise
        ax.margins()
        plt.close('all')

    def test_margins_tight(self):
        """margins(0) sets no padding."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        ax.margins(0)
        plt.close('all')

    def test_margins_generous(self):
        """margins(0.2) sets generous padding."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        ax.margins(0.2)
        plt.close('all')


# ---------------------------------------------------------------------------
# ax.set_xscale / ax.set_yscale with symlog
# ---------------------------------------------------------------------------

class TestSymlogScale:
    def test_set_xscale_symlog(self):
        """set_xscale('symlog') does not raise."""
        fig, ax = plt.subplots()
        ax.plot([-100, -10, -1, 0, 1, 10, 100], [1, 2, 3, 4, 3, 2, 1])
        ax.set_xscale('symlog')
        plt.close('all')

    def test_set_yscale_symlog(self):
        """set_yscale('symlog') does not raise."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3, 4, 5, 6, 7], [-100, -10, -1, 0, 1, 10, 100])
        ax.set_yscale('symlog')
        plt.close('all')


# ---------------------------------------------------------------------------
# Box plots with parameters
# ---------------------------------------------------------------------------

class TestBoxplotParams:
    def test_boxplot_notch(self):
        """boxplot with notch=True does not raise."""
        import random
        random.seed(42)
        fig, ax = plt.subplots()
        data = [random.gauss(0, 1) for _ in range(50)]
        ax.boxplot(data, notch=True)
        plt.close('all')

    def test_boxplot_horizontal(self):
        """boxplot with vert=False does not raise."""
        import random
        random.seed(42)
        fig, ax = plt.subplots()
        data = [random.gauss(0, 1) for _ in range(50)]
        ax.boxplot(data, vert=False)
        plt.close('all')

    def test_boxplot_whis(self):
        """boxplot with whis parameter does not raise."""
        import random
        random.seed(42)
        fig, ax = plt.subplots()
        data = [random.gauss(0, 1) for _ in range(50)]
        ax.boxplot(data, whis=1.5)
        plt.close('all')

    def test_boxplot_showfliers_false(self):
        """boxplot with showfliers=False does not raise."""
        import random
        random.seed(42)
        fig, ax = plt.subplots()
        data = [random.gauss(0, 1) for _ in range(50)]
        ax.boxplot(data, showfliers=False)
        plt.close('all')

    def test_boxplot_returns_dict(self):
        """boxplot returns a dict with artists."""
        import random
        random.seed(42)
        fig, ax = plt.subplots()
        data = [random.gauss(0, 1) for _ in range(30)]
        result = ax.boxplot(data)
        assert result is not None
        plt.close('all')


# ---------------------------------------------------------------------------
# ax.errorbar with various error forms
# ---------------------------------------------------------------------------

class TestErrorbarVariants:
    def test_errorbar_symmetric_yerr(self):
        """errorbar with symmetric scalar yerr does not raise."""
        fig, ax = plt.subplots()
        ax.errorbar([1, 2, 3], [1, 4, 9], yerr=0.5)
        plt.close('all')

    def test_errorbar_asymmetric_yerr(self):
        """errorbar with asymmetric [low, high] yerr does not raise."""
        fig, ax = plt.subplots()
        ax.errorbar([1, 2, 3], [1, 4, 9],
                    yerr=[[0.2, 0.3, 0.4], [0.5, 0.6, 0.7]])
        plt.close('all')

    def test_errorbar_xerr_only(self):
        """errorbar with only xerr does not raise."""
        fig, ax = plt.subplots()
        ax.errorbar([1, 2, 3], [1, 4, 9], xerr=[0.1, 0.1, 0.1])
        plt.close('all')

    def test_errorbar_capsize(self):
        """errorbar with capsize does not raise."""
        fig, ax = plt.subplots()
        ax.errorbar([1, 2, 3], [1, 4, 9], yerr=[0.5, 0.5, 0.5], capsize=5)
        plt.close('all')

    def test_errorbar_fmt(self):
        """errorbar with fmt='o-' does not raise."""
        fig, ax = plt.subplots()
        ax.errorbar([1, 2, 3], [1, 4, 9], yerr=0.5, fmt='o-')
        plt.close('all')

    def test_errorbar_svg_renders(self):
        """errorbar renders to SVG."""
        fig, ax = plt.subplots()
        ax.errorbar([1, 2, 3, 4], [1, 4, 9, 16],
                    yerr=[0.5, 0.8, 1.0, 1.2],
                    fmt='b-o', capsize=4)
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')
