"""Tests for more patch types: Arrow, FancyArrow, FancyBboxPatch, Arc, Wedge."""

import pytest
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches


# ---------------------------------------------------------------------------
# Arrow
# ---------------------------------------------------------------------------

class TestArrow:
    def test_arrow_basic(self):
        """Arrow can be created and added to axes."""
        fig, ax = plt.subplots()
        arrow = mpatches.Arrow(0, 0, 1, 1)
        ax.add_patch(arrow)
        plt.close('all')

    def test_arrow_width(self):
        """Arrow with width does not raise."""
        fig, ax = plt.subplots()
        arrow = mpatches.Arrow(0, 0, 1, 1, width=0.5)
        ax.add_patch(arrow)
        plt.close('all')

    def test_arrow_color(self):
        """Arrow with color does not raise."""
        fig, ax = plt.subplots()
        arrow = mpatches.Arrow(0, 0, 0.5, 0.5, color='red')
        ax.add_patch(arrow)
        plt.close('all')


# ---------------------------------------------------------------------------
# FancyArrowPatch / annotate arrows
# ---------------------------------------------------------------------------

class TestAnnotateArrows:
    def test_annotate_arrowprops(self):
        """annotate with arrowprops does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0.5], [0.5], 'ro')
        ax.annotate('point', xy=(0.5, 0.5), xytext=(0.7, 0.8),
                    arrowprops=dict(arrowstyle='->', color='black'))
        plt.close('all')

    def test_annotate_arrowprops_fancyarrow(self):
        """annotate with fancy arrowstyle does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0.5], [0.5], 'bo')
        ax.annotate('label', xy=(0.5, 0.5), xytext=(0.2, 0.8),
                    arrowprops=dict(arrowstyle='fancy', color='blue'))
        plt.close('all')


# ---------------------------------------------------------------------------
# FancyBboxPatch
# ---------------------------------------------------------------------------

class TestFancyBboxPatch:
    def test_fancybboxpatch_round(self):
        """FancyBboxPatch with round boxstyle does not raise."""
        fig, ax = plt.subplots()
        fb = mpatches.FancyBboxPatch((0.1, 0.1), 0.5, 0.3,
                                     boxstyle='round,pad=0.1')
        ax.add_patch(fb)
        plt.close('all')

    def test_fancybboxpatch_square(self):
        """FancyBboxPatch with square boxstyle does not raise."""
        fig, ax = plt.subplots()
        fb = mpatches.FancyBboxPatch((0.1, 0.1), 0.5, 0.3,
                                     boxstyle='square,pad=0.1')
        ax.add_patch(fb)
        plt.close('all')

    def test_fancybboxpatch_facecolor(self):
        """FancyBboxPatch with facecolor does not raise."""
        fig, ax = plt.subplots()
        fb = mpatches.FancyBboxPatch((0, 0), 1, 1,
                                     boxstyle='round,pad=0.05',
                                     facecolor='lightblue',
                                     edgecolor='navy')
        ax.add_patch(fb)
        plt.close('all')


# ---------------------------------------------------------------------------
# Arc
# ---------------------------------------------------------------------------

class TestArc:
    def test_arc_basic(self):
        """Arc can be created and added to axes."""
        fig, ax = plt.subplots()
        arc = mpatches.Arc((0.5, 0.5), 0.4, 0.4, angle=0,
                           theta1=0, theta2=180)
        ax.add_patch(arc)
        plt.close('all')

    def test_arc_full_circle(self):
        """Arc with theta1=0, theta2=360 is a full circle."""
        fig, ax = plt.subplots()
        arc = mpatches.Arc((0, 0), 1, 1, theta1=0, theta2=360)
        ax.add_patch(arc)
        plt.close('all')

    def test_arc_color(self):
        """Arc with color does not raise."""
        fig, ax = plt.subplots()
        arc = mpatches.Arc((0, 0), 1, 0.5, color='red', linewidth=2)
        ax.add_patch(arc)
        plt.close('all')


# ---------------------------------------------------------------------------
# Wedge
# ---------------------------------------------------------------------------

class TestWedge:
    def test_wedge_basic(self):
        """Wedge can be created and added to axes."""
        fig, ax = plt.subplots()
        wedge = mpatches.Wedge((0, 0), 1, 0, 90)
        ax.add_patch(wedge)
        plt.close('all')

    def test_wedge_with_width(self):
        """Wedge with width (donut slice) does not raise."""
        fig, ax = plt.subplots()
        wedge = mpatches.Wedge((0, 0), 1, 0, 90, width=0.3)
        ax.add_patch(wedge)
        plt.close('all')

    def test_wedge_facecolor(self):
        """Wedge with facecolor does not raise."""
        fig, ax = plt.subplots()
        wedge = mpatches.Wedge((0, 0), 1, 30, 120, facecolor='gold')
        ax.add_patch(wedge)
        plt.close('all')

    def test_wedge_svg(self):
        """Wedge renders to SVG."""
        fig, ax = plt.subplots()
        for i, (start, end, color) in enumerate(
                [(0, 120, 'red'), (120, 240, 'blue'), (240, 360, 'green')]):
            wedge = mpatches.Wedge((0, 0), 1, start, end, facecolor=color)
            ax.add_patch(wedge)
        ax.set_xlim(-1.5, 1.5)
        ax.set_ylim(-1.5, 1.5)
        ax.set_aspect('equal')
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')


# ---------------------------------------------------------------------------
# Patch properties
# ---------------------------------------------------------------------------

class TestPatchProperties:
    def test_rectangle_get_xy(self):
        """Rectangle get_xy returns position."""
        rect = mpatches.Rectangle((0.1, 0.2), 0.5, 0.3)
        xy = rect.get_xy()
        assert xy[0] == pytest.approx(0.1)
        assert xy[1] == pytest.approx(0.2)

    def test_rectangle_get_width(self):
        """Rectangle get_width returns width."""
        rect = mpatches.Rectangle((0, 0), 0.6, 0.4)
        assert rect.get_width() == pytest.approx(0.6)

    def test_rectangle_get_height(self):
        """Rectangle get_height returns height."""
        rect = mpatches.Rectangle((0, 0), 0.6, 0.4)
        assert rect.get_height() == pytest.approx(0.4)

    def test_rectangle_set_xy(self):
        """Rectangle set_xy updates position."""
        rect = mpatches.Rectangle((0, 0), 1, 1)
        rect.set_xy((0.5, 0.5))
        xy = rect.get_xy()
        assert xy[0] == pytest.approx(0.5)
        assert xy[1] == pytest.approx(0.5)

    def test_patch_get_facecolor(self):
        """Patch get_facecolor returns color."""
        rect = mpatches.Rectangle((0, 0), 1, 1, facecolor='blue')
        fc = rect.get_facecolor()
        assert fc is not None

    def test_patch_get_edgecolor(self):
        """Patch get_edgecolor returns color."""
        rect = mpatches.Rectangle((0, 0), 1, 1, edgecolor='red')
        ec = rect.get_edgecolor()
        assert ec is not None

    def test_patch_set_facecolor(self):
        """Patch set_facecolor does not raise."""
        fig, ax = plt.subplots()
        rect = mpatches.Rectangle((0, 0), 1, 1)
        ax.add_patch(rect)
        rect.set_facecolor('green')
        plt.close('all')

    def test_patch_set_edgecolor(self):
        """Patch set_edgecolor does not raise."""
        fig, ax = plt.subplots()
        rect = mpatches.Rectangle((0, 0), 1, 1)
        ax.add_patch(rect)
        rect.set_edgecolor('black')
        plt.close('all')

    def test_patch_set_linewidth(self):
        """Patch set_linewidth does not raise."""
        fig, ax = plt.subplots()
        rect = mpatches.Rectangle((0, 0), 1, 1)
        ax.add_patch(rect)
        rect.set_linewidth(3.0)
        plt.close('all')
