"""Tests for matplotlib.patches — various patch shapes."""

import pytest
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches


class TestCircle:
    def test_circle_basic(self):
        """Circle() does not raise."""
        c = mpatches.Circle((0.5, 0.5), radius=0.2)
        assert c is not None

    def test_circle_add_to_axes(self):
        """Adding Circle to axes does not raise."""
        fig, ax = plt.subplots()
        c = mpatches.Circle((0.5, 0.5), radius=0.2, color='blue')
        ax.add_patch(c)
        plt.close('all')

    def test_circle_facecolor_edgecolor(self):
        """Circle with face/edge colors does not raise."""
        fig, ax = plt.subplots()
        c = mpatches.Circle((0, 0), 0.5, facecolor='red', edgecolor='black')
        ax.add_patch(c)
        plt.close('all')

    def test_circle_get_radius(self):
        """Circle.get_radius() returns correct value."""
        c = mpatches.Circle((0, 0), radius=0.3)
        assert c.get_radius() == 0.3

    def test_circle_set_radius(self):
        """Circle.set_radius() changes radius."""
        c = mpatches.Circle((0, 0), radius=0.1)
        c.set_radius(0.5)
        assert c.get_radius() == 0.5


class TestEllipse:
    def test_ellipse_basic(self):
        """Ellipse() does not raise."""
        e = mpatches.Ellipse((0.5, 0.5), width=0.4, height=0.2)
        assert e is not None

    def test_ellipse_add_to_axes(self):
        """Adding Ellipse to axes does not raise."""
        fig, ax = plt.subplots()
        e = mpatches.Ellipse((0.5, 0.5), width=0.4, height=0.2, angle=30)
        ax.add_patch(e)
        plt.close('all')

    def test_ellipse_rotated(self):
        """Ellipse with angle does not raise."""
        fig, ax = plt.subplots()
        e = mpatches.Ellipse((0, 0), width=2, height=1, angle=45, alpha=0.5)
        ax.add_patch(e)
        plt.close('all')


class TestRectangle:
    def test_rectangle_basic(self):
        """Rectangle() does not raise."""
        r = mpatches.Rectangle((0.1, 0.1), 0.5, 0.3)
        assert r is not None

    def test_rectangle_add_to_axes(self):
        """Adding Rectangle to axes does not raise."""
        fig, ax = plt.subplots()
        r = mpatches.Rectangle((0.1, 0.1), 0.5, 0.3, linewidth=2, edgecolor='red')
        ax.add_patch(r)
        plt.close('all')

    def test_rectangle_get_width_height(self):
        """Rectangle get_width/get_height work."""
        r = mpatches.Rectangle((0, 0), 3, 2)
        assert r.get_width() == 3
        assert r.get_height() == 2

    def test_rectangle_set_xy(self):
        """Rectangle set_xy works."""
        r = mpatches.Rectangle((0, 0), 1, 1)
        r.set_xy((0.5, 0.5))
        assert r.get_xy() == (0.5, 0.5)


class TestFancyArrowPatch:
    def test_fancy_arrow_patch(self):
        """FancyArrowPatch() does not raise."""
        fig, ax = plt.subplots()
        arrow = mpatches.FancyArrowPatch((0.1, 0.1), (0.9, 0.9),
                                         arrowstyle='->', mutation_scale=15)
        ax.add_patch(arrow)
        plt.close('all')

    def test_fancy_arrow_patch_styles(self):
        """FancyArrowPatch with various arrowstyles does not raise."""
        for style in ['->', '-|>', '<->', 'simple', 'fancy']:
            fig, ax = plt.subplots()
            try:
                arrow = mpatches.FancyArrowPatch((0.2, 0.2), (0.8, 0.8),
                                                  arrowstyle=style,
                                                  mutation_scale=15)
                ax.add_patch(arrow)
            except Exception:
                pass  # some styles may not be implemented
            plt.close('all')

    def test_fancy_arrow_patch_color(self):
        """FancyArrowPatch with color does not raise."""
        fig, ax = plt.subplots()
        arrow = mpatches.FancyArrowPatch((0, 0), (1, 1),
                                         color='red', arrowstyle='->')
        ax.add_patch(arrow)
        plt.close('all')


class TestPolygon:
    def test_polygon_basic(self):
        """Polygon() does not raise."""
        verts = [(0, 0), (1, 0), (0.5, 1)]
        p = mpatches.Polygon(verts)
        assert p is not None

    def test_polygon_add_to_axes(self):
        """Adding Polygon to axes does not raise."""
        fig, ax = plt.subplots()
        verts = [(0, 0), (1, 0), (0.5, 1), (0, 0)]
        p = mpatches.Polygon(verts, closed=True, fill=True, facecolor='green')
        ax.add_patch(p)
        plt.close('all')

    def test_polygon_get_xy(self):
        """Polygon.get_xy() returns vertices."""
        verts = [(0, 0), (1, 0), (0.5, 1)]
        p = mpatches.Polygon(verts)
        xy = p.get_xy()
        assert len(xy) > 0


class TestPathPatch:
    def test_pathpatch_basic(self):
        """PathPatch() does not raise."""
        from matplotlib.path import Path
        path = Path([(0, 0), (1, 0), (1, 1), (0, 0)],
                    [Path.MOVETO, Path.LINETO, Path.LINETO, Path.CLOSEPOLY])
        fig, ax = plt.subplots()
        pp = mpatches.PathPatch(path, facecolor='orange')
        ax.add_patch(pp)
        plt.close('all')


class TestPatchProperties:
    def test_patch_alpha(self):
        """Patch with alpha does not raise."""
        fig, ax = plt.subplots()
        c = mpatches.Circle((0.5, 0.5), 0.3, alpha=0.5)
        ax.add_patch(c)
        plt.close('all')

    def test_patch_linestyle(self):
        """Patch with linestyle does not raise."""
        fig, ax = plt.subplots()
        r = mpatches.Rectangle((0.1, 0.1), 0.5, 0.3, linestyle='--')
        ax.add_patch(r)
        plt.close('all')

    def test_patch_linewidth(self):
        """Patch with linewidth does not raise."""
        fig, ax = plt.subplots()
        r = mpatches.Rectangle((0.1, 0.1), 0.5, 0.3, linewidth=3)
        ax.add_patch(r)
        plt.close('all')

    def test_patch_hatch(self):
        """Patch with hatch does not raise."""
        fig, ax = plt.subplots()
        r = mpatches.Rectangle((0.1, 0.1), 0.5, 0.3, hatch='/')
        ax.add_patch(r)
        plt.close('all')

    def test_patch_zorder(self):
        """Patch with zorder does not raise."""
        fig, ax = plt.subplots()
        c = mpatches.Circle((0.5, 0.5), 0.2, zorder=5)
        ax.add_patch(c)
        plt.close('all')

    def test_patch_label(self):
        """Patch with label for legend does not raise."""
        fig, ax = plt.subplots()
        c = mpatches.Circle((0.5, 0.5), 0.2, label='circle')
        ax.add_patch(c)
        ax.legend()
        plt.close('all')
