"""Tests for quiver, quiverkey, and streamplot."""

import pytest
import numpy as np
import matplotlib.pyplot as plt


# ---------------------------------------------------------------------------
# quiver
# ---------------------------------------------------------------------------

class TestQuiver:
    def test_quiver_basic(self):
        """quiver with U, V arrays does not raise."""
        fig, ax = plt.subplots()
        x = np.arange(5)
        y = np.arange(5)
        U = np.ones((5, 5))
        V = np.zeros((5, 5))
        ax.quiver(x, y, U, V)
        plt.close('all')

    def test_quiver_no_xy(self):
        """quiver with just U, V (implicit grid) does not raise."""
        fig, ax = plt.subplots()
        U = np.ones((3, 3))
        V = np.ones((3, 3))
        ax.quiver(U, V)
        plt.close('all')

    def test_quiver_color(self):
        """quiver with color does not raise."""
        fig, ax = plt.subplots()
        x = [0, 1, 2]
        y = [0, 1, 2]
        U = [1, 0, -1]
        V = [0, 1, 0]
        ax.quiver(x, y, U, V, color='red')
        plt.close('all')

    def test_quiver_scale(self):
        """quiver with scale does not raise."""
        fig, ax = plt.subplots()
        x = [0, 1, 2]
        y = [0, 1, 2]
        U = [1, 0, -1]
        V = [0, 1, 0]
        ax.quiver(x, y, U, V, scale=10)
        plt.close('all')

    def test_quiver_returns_quiver(self):
        """quiver returns a Quiver object."""
        fig, ax = plt.subplots()
        q = ax.quiver([0, 1], [0, 1], [1, 0], [0, 1])
        assert q is not None
        plt.close('all')

    def test_quiver_svg(self):
        """quiver renders to SVG."""
        fig, ax = plt.subplots()
        x = np.linspace(-1, 1, 5)
        y = np.linspace(-1, 1, 5)
        X, Y = np.meshgrid(x, y)
        U = -Y
        V = X
        ax.quiver(X, Y, U, V)
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_plt_quiver(self):
        """plt.quiver() wrapper does not raise."""
        plt.figure()
        plt.quiver([0, 1], [0, 1], [1, 0], [0, 1])
        plt.close('all')


# ---------------------------------------------------------------------------
# quiverkey
# ---------------------------------------------------------------------------

class TestQuiverKey:
    def test_quiverkey_basic(self):
        """quiverkey does not raise."""
        fig, ax = plt.subplots()
        q = ax.quiver([0, 1], [0, 1], [1, 0], [0, 1])
        ax.quiverkey(q, X=0.9, Y=1.05, U=1, label='1 m/s',
                     labelpos='E')
        plt.close('all')


# ---------------------------------------------------------------------------
# streamplot
# ---------------------------------------------------------------------------

class TestStreamplot:
    def test_streamplot_basic(self):
        """streamplot does not raise."""
        x = np.linspace(-2, 2, 10)
        y = np.linspace(-2, 2, 10)
        X, Y = np.meshgrid(x, y)
        U = -Y
        V = X
        fig, ax = plt.subplots()
        ax.streamplot(x, y, U, V)
        plt.close('all')

    def test_streamplot_density(self):
        """streamplot with density does not raise."""
        x = np.linspace(-2, 2, 10)
        y = np.linspace(-2, 2, 10)
        X, Y = np.meshgrid(x, y)
        U = np.ones_like(X)
        V = np.zeros_like(Y)
        fig, ax = plt.subplots()
        ax.streamplot(x, y, U, V, density=1.5)
        plt.close('all')

    def test_streamplot_color(self):
        """streamplot with color does not raise."""
        x = np.linspace(-2, 2, 10)
        y = np.linspace(-2, 2, 10)
        X, Y = np.meshgrid(x, y)
        U = -Y
        V = X
        fig, ax = plt.subplots()
        ax.streamplot(x, y, U, V, color='blue')
        plt.close('all')

    def test_streamplot_linewidth(self):
        """streamplot with linewidth does not raise."""
        x = np.linspace(-2, 2, 8)
        y = np.linspace(-2, 2, 8)
        X, Y = np.meshgrid(x, y)
        U = X
        V = Y
        fig, ax = plt.subplots()
        ax.streamplot(x, y, U, V, linewidth=2)
        plt.close('all')

    def test_streamplot_svg(self):
        """streamplot renders to SVG."""
        x = np.linspace(-2, 2, 10)
        y = np.linspace(-2, 2, 10)
        X, Y = np.meshgrid(x, y)
        U = -Y
        V = X
        fig, ax = plt.subplots()
        ax.streamplot(x, y, U, V, cmap='viridis')
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_plt_streamplot(self):
        """plt.streamplot() wrapper does not raise."""
        x = np.linspace(-1, 1, 5)
        y = np.linspace(-1, 1, 5)
        X, Y = np.meshgrid(x, y)
        plt.figure()
        plt.streamplot(x, y, X, Y)
        plt.close('all')
