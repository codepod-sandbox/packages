"""Tests for subplot patterns commonly used by LLMs."""

import pytest
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec


class TestSubplots:
    def test_subplots_1x1(self):
        """plt.subplots() returns (fig, ax)."""
        fig, ax = plt.subplots()
        assert fig is not None
        assert ax is not None
        plt.close('all')

    def test_subplots_1xn(self):
        """plt.subplots(1, 3) returns array of axes."""
        fig, axes = plt.subplots(1, 3)
        assert len(axes) == 3
        plt.close('all')

    def test_subplots_nxm(self):
        """plt.subplots(2, 2) returns 2D array of axes."""
        fig, axes = plt.subplots(2, 2)
        assert len(axes) == 2
        assert len(axes[0]) == 2
        plt.close('all')

    def test_subplots_nx1(self):
        """plt.subplots(3, 1) returns column of axes."""
        fig, axes = plt.subplots(3, 1)
        assert len(axes) == 3
        plt.close('all')

    def test_subplots_figsize(self):
        """plt.subplots(figsize=...) does not raise."""
        fig, ax = plt.subplots(figsize=(10, 6))
        assert fig.figsize == (10, 6) or fig.get_figwidth() == 10
        plt.close('all')

    def test_subplots_sharex(self):
        """plt.subplots(sharex=True) does not raise."""
        fig, axes = plt.subplots(2, 1, sharex=True)
        assert len(axes) == 2
        plt.close('all')

    def test_subplots_sharey(self):
        """plt.subplots(sharey=True) does not raise."""
        fig, axes = plt.subplots(1, 2, sharey=True)
        assert len(axes) == 2
        plt.close('all')

    def test_subplots_subplot_kw(self):
        """plt.subplots(subplot_kw=...) does not raise."""
        fig, ax = plt.subplots(subplot_kw={'projection': 'polar'})
        assert ax is not None
        plt.close('all')

    def test_subplots_plot_each(self):
        """Can plot on each subplot."""
        fig, axes = plt.subplots(2, 2)
        for i, row in enumerate(axes):
            for j, ax in enumerate(row):
                ax.plot([0, 1], [i, j])
        plt.close('all')

    def test_subplots_titles(self):
        """Can set titles on each subplot."""
        fig, axes = plt.subplots(1, 3)
        for i, ax in enumerate(axes):
            ax.set_title(f'Plot {i+1}')
        fig.suptitle('All Plots')
        plt.close('all')

    def test_subplots_tight_layout(self):
        """tight_layout after subplots does not raise."""
        fig, axes = plt.subplots(2, 2)
        for row in axes:
            for ax in row:
                ax.plot([1, 2, 3])
        plt.tight_layout()
        plt.close('all')


class TestGridSpec:
    def test_gridspec_basic(self):
        """GridSpec(2, 3) does not raise."""
        fig = plt.figure()
        gs = gridspec.GridSpec(2, 3)
        ax = fig.add_subplot(gs[0, 0])
        assert ax is not None
        plt.close('all')

    def test_gridspec_spanning(self):
        """GridSpec with spanning cells does not raise."""
        fig = plt.figure()
        gs = gridspec.GridSpec(2, 2)
        ax1 = fig.add_subplot(gs[0, :])  # span full row
        ax2 = fig.add_subplot(gs[1, 0])
        ax3 = fig.add_subplot(gs[1, 1])
        assert ax1 is not None
        plt.close('all')

    def test_gridspec_spacing(self):
        """GridSpec with wspace/hspace does not raise."""
        fig = plt.figure()
        gs = gridspec.GridSpec(2, 2, wspace=0.4, hspace=0.6)
        for i in range(4):
            fig.add_subplot(gs[i // 2, i % 2])
        plt.close('all')

    def test_gridspec_via_add_gridspec(self):
        """fig.add_gridspec() does not raise."""
        fig = plt.figure()
        gs = fig.add_gridspec(2, 3)
        ax = fig.add_subplot(gs[0, 0])
        assert ax is not None
        plt.close('all')

    def test_gridspec_nested(self):
        """Nested GridSpec does not raise."""
        fig = plt.figure()
        outer = gridspec.GridSpec(1, 2)
        inner = gridspec.GridSpecFromSubplotSpec(2, 1, subplot_spec=outer[0])
        ax1 = fig.add_subplot(inner[0])
        ax2 = fig.add_subplot(inner[1])
        ax3 = fig.add_subplot(outer[1])
        assert ax1 is not None
        plt.close('all')


class TestFigureManagement:
    def test_plt_figure_num(self):
        """plt.figure(num=1) does not raise."""
        fig = plt.figure(1)
        assert fig is not None
        plt.close('all')

    def test_plt_close_all(self):
        """plt.close('all') does not raise."""
        for _ in range(3):
            plt.figure()
        plt.close('all')

    def test_plt_clf(self):
        """plt.clf() clears the figure."""
        fig = plt.figure()
        ax = fig.add_subplot(111)
        ax.plot([1, 2])
        plt.clf()
        plt.close('all')

    def test_plt_cla(self):
        """plt.cla() clears current axes."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3])
        plt.cla()
        plt.close('all')

    def test_fig_number(self):
        """Figure has a number attribute."""
        fig = plt.figure()
        # number may be None in this implementation
        assert fig is not None
        plt.close('all')

    def test_multiple_figures(self):
        """Creating multiple figures does not raise."""
        figs = [plt.figure() for _ in range(5)]
        assert len(figs) == 5
        plt.close('all')
