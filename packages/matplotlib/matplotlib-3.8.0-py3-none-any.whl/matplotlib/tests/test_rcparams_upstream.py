"""Tests for rcParams, rcdefaults, and matplotlib.rc()."""

import pytest
import matplotlib
import matplotlib.pyplot as plt


# ---------------------------------------------------------------------------
# rcParams access
# ---------------------------------------------------------------------------

class TestRcParams:
    def test_rcparams_exists(self):
        """matplotlib.rcParams exists."""
        assert matplotlib.rcParams is not None

    def test_rcparams_is_dict_like(self):
        """rcParams is dict-like."""
        assert hasattr(matplotlib.rcParams, '__getitem__')
        assert hasattr(matplotlib.rcParams, '__setitem__')

    def test_rcparams_figure_figsize(self):
        """rcParams contains figure.figsize."""
        val = matplotlib.rcParams.get('figure.figsize')
        assert val is not None

    def test_rcparams_font_size(self):
        """rcParams contains font.size."""
        val = matplotlib.rcParams.get('font.size')
        assert val is not None

    def test_rcparams_lines_linewidth(self):
        """rcParams contains lines.linewidth."""
        val = matplotlib.rcParams.get('lines.linewidth')
        assert val is not None

    def test_rcparams_set_value(self):
        """Setting rcParams value does not raise."""
        original = matplotlib.rcParams.get('lines.linewidth', 1.5)
        matplotlib.rcParams['lines.linewidth'] = 2.0
        assert matplotlib.rcParams.get('lines.linewidth') == pytest.approx(2.0)
        matplotlib.rcParams['lines.linewidth'] = original

    def test_plt_rcparams(self):
        """plt.rcParams refers to matplotlib.rcParams."""
        assert plt.rcParams is not None


# ---------------------------------------------------------------------------
# matplotlib.rc()
# ---------------------------------------------------------------------------

class TestMplRc:
    def test_rc_lines(self):
        """matplotlib.rc('lines', linewidth=2) does not raise."""
        matplotlib.rc('lines', linewidth=2)

    def test_rc_font(self):
        """matplotlib.rc('font', size=12) does not raise."""
        matplotlib.rc('font', size=12)

    def test_rc_axes(self):
        """matplotlib.rc('axes', grid=True) does not raise."""
        matplotlib.rc('axes', grid=True)

    def test_rc_figure(self):
        """matplotlib.rc('figure', figsize=(8, 6)) does not raise."""
        matplotlib.rc('figure', figsize=(8, 6))


# ---------------------------------------------------------------------------
# rcdefaults
# ---------------------------------------------------------------------------

class TestRcDefaults:
    def test_rcdefaults(self):
        """matplotlib.rcdefaults() does not raise."""
        matplotlib.rcdefaults()

    def test_rcdefaults_restores(self):
        """rcdefaults restores original state."""
        original = matplotlib.rcParams.get('lines.linewidth')
        matplotlib.rcParams['lines.linewidth'] = 99.0
        matplotlib.rcdefaults()
        new_val = matplotlib.rcParams.get('lines.linewidth')
        assert new_val != 99.0


# ---------------------------------------------------------------------------
# Context manager matplotlib.rc_context
# ---------------------------------------------------------------------------

class TestRcContext:
    def test_rc_context_basic(self):
        """rc_context does not raise."""
        with matplotlib.rc_context():
            pass

    def test_rc_context_sets_params(self):
        """rc_context temporarily changes rcParams."""
        original = matplotlib.rcParams.get('lines.linewidth', 1.5)
        with matplotlib.rc_context({'lines.linewidth': 5.0}):
            val = matplotlib.rcParams.get('lines.linewidth')
            assert val == pytest.approx(5.0)
        # After context, should be restored
        after = matplotlib.rcParams.get('lines.linewidth')
        assert after == pytest.approx(original)

    def test_rc_context_in_plot(self):
        """Plotting inside rc_context does not raise."""
        with matplotlib.rc_context({'lines.linewidth': 3.0}):
            fig, ax = plt.subplots()
            ax.plot([0, 1], [0, 1])
            plt.close('all')
