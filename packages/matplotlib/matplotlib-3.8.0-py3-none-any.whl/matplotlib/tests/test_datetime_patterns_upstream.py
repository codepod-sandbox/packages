"""
Upstream tests for datetime/date axis patterns commonly used by LLMs.
"""

import pytest
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from datetime import datetime, date, timedelta


class TestDatetimePlotting:
    """Tests for datetime on axes."""

    def teardown_method(self):
        plt.close('all')

    def test_plot_datetime_x(self):
        dates = [datetime(2023, 1, 1), datetime(2023, 1, 2), datetime(2023, 1, 3)]
        values = [10, 20, 15]
        fig, ax = plt.subplots()
        ax.plot(dates, values)

    def test_plot_datetime_simple(self):
        dates = [datetime(2023, 6, i) for i in range(1, 6)]
        values = [i ** 2 for i in range(1, 6)]
        fig, ax = plt.subplots()
        ax.plot(dates, values, 'b-o')
        ax.set_title('Time Series')

    def test_plot_date_objects(self):
        dates = [date(2023, 1, i) for i in range(1, 8)]
        values = list(range(7))
        fig, ax = plt.subplots()
        ax.plot(dates, values)

    def test_bar_with_dates(self):
        dates = [datetime(2023, i, 1) for i in range(1, 5)]
        values = [10, 20, 15, 25]
        fig, ax = plt.subplots()
        ax.bar(dates, values)

    def test_scatter_with_dates(self):
        dates = [datetime(2023, 1, i) for i in range(1, 6)]
        values = [1, 4, 2, 5, 3]
        fig, ax = plt.subplots()
        ax.scatter(dates, values)

    def test_datetime_xlim(self):
        fig, ax = plt.subplots()
        dates = [datetime(2023, 1, 1), datetime(2023, 12, 31)]
        ax.plot(dates, [0, 1])
        ax.set_xlim(datetime(2023, 1, 1), datetime(2023, 12, 31))

    def test_fill_between_dates(self):
        dates = [datetime(2023, 1, i) for i in range(1, 6)]
        y1 = [10, 12, 11, 14, 13]
        y2 = [8, 9, 10, 11, 10]
        fig, ax = plt.subplots()
        ax.fill_between(dates, y1, y2, alpha=0.3)


class TestDateFormatters:
    """Tests for date formatting."""

    def teardown_method(self):
        plt.close('all')

    def test_date_formatter(self):
        formatter = mdates.DateFormatter('%Y-%m-%d')
        assert formatter is not None

    def test_date_formatter_formats(self):
        fig, ax = plt.subplots()
        dates = [datetime(2023, 1, 1), datetime(2023, 6, 1), datetime(2023, 12, 31)]
        ax.plot(dates, [1, 2, 3])
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%b %Y'))

    def test_month_formatter(self):
        formatter = mdates.DateFormatter('%b')
        assert formatter is not None

    def test_year_formatter(self):
        formatter = mdates.DateFormatter('%Y')
        assert formatter is not None

    def test_auto_date_formatter(self):
        formatter = mdates.AutoDateFormatter(mdates.AutoDateLocator())
        assert formatter is not None


class TestDateLocators:
    """Tests for date locators."""

    def teardown_method(self):
        plt.close('all')

    def test_auto_date_locator(self):
        locator = mdates.AutoDateLocator()
        assert locator is not None

    def test_year_locator(self):
        locator = mdates.YearLocator()
        assert locator is not None

    def test_month_locator(self):
        locator = mdates.MonthLocator()
        assert locator is not None

    def test_week_day_locator(self):
        locator = mdates.WeekdayLocator()
        assert locator is not None

    def test_day_locator(self):
        locator = mdates.DayLocator(interval=7)
        assert locator is not None

    def test_hour_locator(self):
        locator = mdates.HourLocator(interval=6)
        assert locator is not None

    def test_minute_locator(self):
        locator = mdates.MinuteLocator(interval=30)
        assert locator is not None

    def test_set_locator_on_axis(self):
        fig, ax = plt.subplots()
        dates = [datetime(2023, i, 1) for i in range(1, 7)]
        ax.plot(dates, range(6))
        ax.xaxis.set_major_locator(mdates.MonthLocator())
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%b'))

    def test_autofmt_xdate(self):
        fig, ax = plt.subplots()
        dates = [datetime(2023, 1, i) for i in range(1, 6)]
        ax.plot(dates, range(5))
        fig.autofmt_xdate()

    def test_autofmt_xdate_rotation(self):
        fig, ax = plt.subplots()
        dates = [datetime(2023, 1, i) for i in range(1, 6)]
        ax.plot(dates, range(5))
        fig.autofmt_xdate(rotation=45)

    def test_autofmt_xdate_ha(self):
        fig, ax = plt.subplots()
        dates = [datetime(2023, 1, i) for i in range(1, 6)]
        ax.plot(dates, range(5))
        fig.autofmt_xdate(ha='right')


class TestDateConversions:
    """Tests for date conversion utilities."""

    def teardown_method(self):
        plt.close('all')

    def test_date2num(self):
        dt = datetime(2023, 1, 1)
        num = mdates.date2num(dt)
        assert isinstance(num, float)

    def test_num2date(self):
        dt = datetime(2023, 6, 15)
        num = mdates.date2num(dt)
        dt_back = mdates.num2date(num)
        assert dt_back.year == 2023
        assert dt_back.month == 6
        assert dt_back.day == 15

    def test_date2num_list(self):
        dates = [datetime(2023, 1, i) for i in range(1, 4)]
        nums = mdates.date2num(dates)
        assert len(nums) == 3
