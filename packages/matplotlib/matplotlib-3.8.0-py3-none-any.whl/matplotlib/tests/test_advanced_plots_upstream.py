"""Tests for pcolormesh, twinx/twiny, stackplot, set_aspect, annotate rendering."""

import pytest
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.image import AxesImage


# ---------------------------------------------------------------------------
# ax.pcolormesh()
# ---------------------------------------------------------------------------

class TestPcolormesh:
    def test_pcolormesh_1arg_returns_axesimage(self):
        """pcolormesh(C) returns an AxesImage."""
        fig, ax = plt.subplots()
        C = [[1, 2], [3, 4]]
        im = ax.pcolormesh(C)
        assert isinstance(im, AxesImage)
        plt.close('all')

    def test_pcolormesh_adds_to_images(self):
        """pcolormesh result is in ax.images."""
        fig, ax = plt.subplots()
        ax.pcolormesh([[1, 2], [3, 4]])
        assert len(ax.images) == 1
        plt.close('all')

    def test_pcolormesh_updates_xlim(self):
        """pcolormesh with 1 arg updates xlim to [0, ncols]."""
        fig, ax = plt.subplots()
        C = [[1, 2, 3], [4, 5, 6]]
        ax.pcolormesh(C)
        xmin, xmax = ax.get_xlim()
        assert xmin <= 0 and xmax >= 3
        plt.close('all')

    def test_pcolormesh_updates_ylim(self):
        """pcolormesh with 1 arg updates ylim to [0, nrows]."""
        fig, ax = plt.subplots()
        C = [[1, 2], [3, 4], [5, 6]]
        ax.pcolormesh(C)
        ymin, ymax = ax.get_ylim()
        assert ymin <= 0 and ymax >= 3
        plt.close('all')

    def test_pcolormesh_3arg(self):
        """pcolormesh(X, Y, C) with 3 args does not raise."""
        fig, ax = plt.subplots()
        X, Y = np.meshgrid([0, 1, 2], [0, 1, 2])
        C = np.arange(9).reshape(3, 3)
        im = ax.pcolormesh(X, Y, C)
        assert im is not None
        plt.close('all')

    def test_pcolormesh_cmap_kwarg(self):
        """pcolormesh with cmap kwarg does not raise."""
        fig, ax = plt.subplots()
        ax.pcolormesh([[1, 2], [3, 4]], cmap='hot')
        plt.close('all')

    def test_pcolormesh_numpy_array(self):
        """pcolormesh with a numpy 2D array."""
        fig, ax = plt.subplots()
        Z = np.arange(16).reshape(4, 4)
        im = ax.pcolormesh(Z)
        assert im is not None
        plt.close('all')

    def test_pcolormesh_svg_renders(self):
        """pcolormesh renders to SVG without error."""
        fig, ax = plt.subplots()
        ax.pcolormesh([[1, 2], [3, 4]], cmap='viridis')
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_pcolormesh_vmin_vmax(self):
        """pcolormesh with vmin/vmax does not raise."""
        fig, ax = plt.subplots()
        ax.pcolormesh([[0, 100], [50, 200]], vmin=0, vmax=200)
        plt.close('all')

    def test_plt_pcolormesh(self):
        """plt.pcolormesh() wrapper works."""
        plt.figure()
        im = plt.pcolormesh([[1, 2], [3, 4]])
        assert im is not None
        plt.close('all')


# ---------------------------------------------------------------------------
# ax.twinx() / ax.twiny()
# ---------------------------------------------------------------------------

class TestTwinAxes:
    def test_twinx_returns_axes(self):
        """twinx() returns a new Axes."""
        fig, ax = plt.subplots()
        ax2 = ax.twinx()
        assert ax2 is not None
        assert ax2 is not ax
        plt.close('all')

    def test_twiny_returns_axes(self):
        """twiny() returns a new Axes."""
        fig, ax = plt.subplots()
        ax2 = ax.twiny()
        assert ax2 is not None
        assert ax2 is not ax
        plt.close('all')

    def test_twinx_shares_xlim(self):
        """twinx shares the same x limits."""
        fig, ax = plt.subplots()
        ax.set_xlim(0, 10)
        ax2 = ax.twinx()
        xmin, xmax = ax2.get_xlim()
        assert xmin == pytest.approx(0) and xmax == pytest.approx(10)
        plt.close('all')

    def test_twiny_shares_ylim(self):
        """twiny shares the same y limits."""
        fig, ax = plt.subplots()
        ax.set_ylim(0, 5)
        ax2 = ax.twiny()
        ymin, ymax = ax2.get_ylim()
        assert ymin == pytest.approx(0) and ymax == pytest.approx(5)
        plt.close('all')

    def test_twinx_independent_ylim(self):
        """twinx axes has its own y limits."""
        fig, ax = plt.subplots()
        ax.set_ylim(0, 10)
        ax2 = ax.twinx()
        ax2.set_ylim(0, 100)
        ymin2, ymax2 = ax2.get_ylim()
        assert ymax2 == pytest.approx(100)
        plt.close('all')

    def test_twinx_can_plot(self):
        """can plot on twinx axes."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3])
        ax2 = ax.twinx()
        ax2.plot([1, 2, 3], [100, 200, 300])
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_twinx_svg_renders(self):
        """twinx renders to SVG."""
        fig, ax = plt.subplots()
        ax.bar([1, 2, 3], [1, 4, 9])
        ax2 = ax.twinx()
        ax2.plot([1, 2, 3], [10, 20, 30], 'r-')
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')


# ---------------------------------------------------------------------------
# ax.stackplot()
# ---------------------------------------------------------------------------

class TestStackplot:
    def test_stackplot_basic(self):
        """stackplot(x, y1, y2) does not raise."""
        fig, ax = plt.subplots()
        x = [1, 2, 3, 4]
        y1 = [1, 2, 3, 4]
        y2 = [1, 1, 1, 1]
        result = ax.stackplot(x, y1, y2)
        assert result is not None
        plt.close('all')

    def test_stackplot_returns_list(self):
        """stackplot returns a list of PolyCollection."""
        from matplotlib.collections import PolyCollection
        fig, ax = plt.subplots()
        result = ax.stackplot([1, 2, 3], [1, 2, 3], [2, 1, 2])
        assert isinstance(result, list)
        plt.close('all')

    def test_stackplot_svg_renders(self):
        """stackplot renders to SVG."""
        fig, ax = plt.subplots()
        ax.stackplot([1, 2, 3], [1, 2, 3], [1, 1, 1])
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_stackplot_labels(self):
        """stackplot with labels does not raise."""
        fig, ax = plt.subplots()
        ax.stackplot([1, 2], [1, 2], [2, 1], labels=['A', 'B'])
        plt.close('all')

    def test_plt_stackplot(self):
        """plt.stackplot() wrapper works."""
        plt.figure()
        result = plt.stackplot([1, 2, 3], [1, 2, 3])
        assert result is not None
        plt.close('all')


# ---------------------------------------------------------------------------
# ax.annotate()
# ---------------------------------------------------------------------------

class TestAnnotate:
    def test_annotate_basic(self):
        """annotate(text, xy) does not raise."""
        fig, ax = plt.subplots()
        ax.annotate('peak', xy=(1, 1))
        plt.close('all')

    def test_annotate_with_xytext(self):
        """annotate with xytext offset does not raise."""
        fig, ax = plt.subplots()
        ax.annotate('peak', xy=(1, 1), xytext=(2, 2))
        plt.close('all')

    def test_annotate_with_arrowprops(self):
        """annotate with arrowprops does not raise."""
        fig, ax = plt.subplots()
        ax.annotate('label', xy=(0, 0), xytext=(1, 1),
                    arrowprops=dict(arrowstyle='->'))
        plt.close('all')

    def test_annotate_svg_renders(self):
        """annotate renders to SVG."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        ax.annotate('point', xy=(0.5, 0.5))
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_annotate_text_in_svg(self):
        """annotation text appears in SVG output."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        ax.annotate('my_annotation', xy=(0.5, 0.5))
        svg = fig.to_svg()
        assert 'my_annotation' in svg
        plt.close('all')

    def test_plt_annotate(self):
        """plt.annotate() wrapper works."""
        plt.figure()
        plt.plot([0, 1], [0, 1])
        plt.annotate('label', xy=(0.5, 0.5))
        plt.close('all')


# ---------------------------------------------------------------------------
# ax.set_aspect()
# ---------------------------------------------------------------------------

class TestSetAspect:
    def test_set_aspect_equal(self):
        """set_aspect('equal') does not raise."""
        fig, ax = plt.subplots()
        ax.set_aspect('equal')
        plt.close('all')

    def test_set_aspect_auto(self):
        """set_aspect('auto') does not raise."""
        fig, ax = plt.subplots()
        ax.set_aspect('auto')
        plt.close('all')

    def test_set_aspect_numeric(self):
        """set_aspect(2.0) does not raise."""
        fig, ax = plt.subplots()
        ax.set_aspect(2.0)
        plt.close('all')

    def test_set_aspect_preserves_plot(self):
        """plot still renders after set_aspect."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        ax.set_aspect('equal')
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')


# ---------------------------------------------------------------------------
# ax.set_facecolor() / ax.set_axisbelow()
# ---------------------------------------------------------------------------

class TestAxesStyle:
    def test_set_facecolor(self):
        """set_facecolor does not raise."""
        fig, ax = plt.subplots()
        ax.set_facecolor('#eeeeee')
        plt.close('all')

    def test_set_facecolor_named(self):
        """set_facecolor with named color does not raise."""
        fig, ax = plt.subplots()
        ax.set_facecolor('lightgray')
        plt.close('all')

    def test_set_axisbelow_true(self):
        """set_axisbelow(True) does not raise."""
        fig, ax = plt.subplots()
        ax.set_axisbelow(True)
        plt.close('all')

    def test_facecolor_svg_renders(self):
        """axes with facecolor renders to SVG."""
        fig, ax = plt.subplots()
        ax.set_facecolor('#f0f0f0')
        ax.plot([0, 1], [0, 1])
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')


# ---------------------------------------------------------------------------
# ax.errorbar()
# ---------------------------------------------------------------------------

class TestErrorbar:
    def test_errorbar_basic(self):
        """errorbar(x, y, yerr) does not raise."""
        fig, ax = plt.subplots()
        ax.errorbar([1, 2, 3], [1, 4, 9], yerr=[0.1, 0.2, 0.3])
        plt.close('all')

    def test_errorbar_returns_container(self):
        """errorbar returns a result."""
        fig, ax = plt.subplots()
        result = ax.errorbar([1, 2], [1, 2], yerr=[0.1, 0.1])
        assert result is not None
        plt.close('all')

    def test_errorbar_xerr(self):
        """errorbar with xerr does not raise."""
        fig, ax = plt.subplots()
        ax.errorbar([1, 2, 3], [1, 4, 9], xerr=0.1)
        plt.close('all')

    def test_errorbar_both_err(self):
        """errorbar with both xerr and yerr."""
        fig, ax = plt.subplots()
        ax.errorbar([1, 2], [1, 2], yerr=0.1, xerr=0.2)
        plt.close('all')

    def test_errorbar_svg_renders(self):
        """errorbar renders to SVG."""
        fig, ax = plt.subplots()
        ax.errorbar([1, 2, 3], [1, 4, 9], yerr=[0.1, 0.2, 0.3])
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_plt_errorbar(self):
        """plt.errorbar() wrapper works."""
        plt.figure()
        result = plt.errorbar([1, 2, 3], [1, 4, 9], yerr=0.5)
        assert result is not None
        plt.close('all')


# ---------------------------------------------------------------------------
# ax.contour() / ax.contourf()
# ---------------------------------------------------------------------------

class TestContour:
    def test_contour_basic(self):
        """contour(Z) does not raise."""
        fig, ax = plt.subplots()
        Z = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
        result = ax.contour(Z)
        assert result is not None
        plt.close('all')

    def test_contourf_basic(self):
        """contourf(Z) does not raise."""
        fig, ax = plt.subplots()
        Z = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
        result = ax.contourf(Z)
        assert result is not None
        plt.close('all')

    def test_contour_svg_renders(self):
        """contour renders to SVG."""
        fig, ax = plt.subplots()
        Z = np.arange(9).reshape(3, 3).tolist()
        ax.contour(Z)
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_contourf_svg_renders(self):
        """contourf renders to SVG."""
        fig, ax = plt.subplots()
        Z = np.arange(9).reshape(3, 3).tolist()
        ax.contourf(Z)
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_plt_contour(self):
        """plt.contour() wrapper works."""
        plt.figure()
        result = plt.contour([[1, 2], [3, 4]])
        assert result is not None
        plt.close('all')

    def test_plt_contourf(self):
        """plt.contourf() wrapper works."""
        plt.figure()
        result = plt.contourf([[1, 2], [3, 4]])
        assert result is not None
        plt.close('all')
