"""
Upstream matplotlib tests imported from lib/matplotlib/tests/test_lines.py.

These tests are adapted from the real matplotlib test suite to validate
compatibility of our Line2D implementation.  Upstream tests that require
rendering infrastructure or APIs we haven't implemented are omitted.
"""

import pytest

from matplotlib.lines import Line2D


# ---------------------------------------------------------------------------
# 1. test_invalid_line_data (upstream ~line 41)
# Our Line2D raises TypeError (via list()) on scalar input, while upstream
# raises RuntimeError.  We adapt the expected exception type.
# ---------------------------------------------------------------------------
def test_invalid_line_data():
    with pytest.raises(TypeError):
        Line2D(0, [])
    with pytest.raises(TypeError):
        Line2D([], 1)

    line = Line2D([], [])
    with pytest.raises(TypeError):
        line.set_xdata(0)
    with pytest.raises(TypeError):
        line.set_ydata(0)


# ---------------------------------------------------------------------------
# 2. test_set_drawstyle (upstream ~line 126, positive-case)
# Upstream test_valid_drawstyles expects ValueError on invalid input, which
# we don't enforce.  This adapted version tests the positive cases.
# ---------------------------------------------------------------------------
def test_set_drawstyle():
    line = Line2D([], [])
    for ds in ["default", "steps-pre", "steps-mid", "steps-post", "steps"]:
        line.set_drawstyle(ds)
        assert line.get_drawstyle() == ds


# ---------------------------------------------------------------------------
# 3. test_set_linestyle (upstream ~line 89, positive-case)
# ---------------------------------------------------------------------------
def test_set_linestyle():
    line = Line2D([], [])
    for ls in ["-", "--", "-.", ":"]:
        line.set_linestyle(ls)
        assert line.get_linestyle() == ls


# ---------------------------------------------------------------------------
# 4. test_set_color (upstream ~line 73, positive-case)
# ---------------------------------------------------------------------------
def test_set_color():
    line = Line2D([], [])
    line.set_color("red")
    assert line.get_color() == "red"
    line.set_c("blue")
    assert line.get_color() == "blue"


# ---------------------------------------------------------------------------
# 5. test_line_data_copy (upstream pattern: input mutation safety)
# Ensures get_xdata/get_ydata return copies, not references.
# ---------------------------------------------------------------------------
def test_line_data_copy():
    line = Line2D([1, 2, 3], [4, 5, 6])
    xdata = line.get_xdata()
    ydata = line.get_ydata()
    # Mutating the returned lists should not affect the line
    xdata.append(99)
    ydata.append(99)
    assert line.get_xdata() == [1, 2, 3]
    assert line.get_ydata() == [4, 5, 6]


# ---------------------------------------------------------------------------
# 6. test_set_data (upstream pattern: set_data updates both x and y)
# ---------------------------------------------------------------------------
def test_set_data():
    line = Line2D([], [])
    line.set_data([1, 2], [3, 4])
    assert line.get_xdata() == [1, 2]
    assert line.get_ydata() == [3, 4]
    x, y = line.get_data()
    assert x == [1, 2]
    assert y == [3, 4]


# ---------------------------------------------------------------------------
# 7. test_line_defaults (upstream pattern: default property values)
# ---------------------------------------------------------------------------
def test_line_defaults():
    line = Line2D([], [])
    assert line.get_linewidth() == 1.5
    assert line.get_linestyle() == '-'
    assert line.get_marker() == 'None'
    assert line.get_markersize() == 6.0
    assert line.get_fillstyle() == 'full'
    assert line.get_drawstyle() == 'default'
    assert line.zorder == 2


# ---------------------------------------------------------------------------
# 8. test_line_constructor_kwargs (upstream pattern)
# ---------------------------------------------------------------------------
def test_line_constructor_kwargs():
    line = Line2D([0], [0], color='lime', linewidth=3, linestyle='--',
                  marker='o', label='test', markersize=10, fillstyle='left',
                  drawstyle='steps-pre')
    assert line.get_color() == 'lime'
    assert line.get_linewidth() == 3
    assert line.get_linestyle() == '--'
    assert line.get_marker() == 'o'
    assert line.get_label() == 'test'
    assert line.get_markersize() == 10
    assert line.get_fillstyle() == 'left'
    assert line.get_drawstyle() == 'steps-pre'


# ---------------------------------------------------------------------------
# 9. test_line_aliases (upstream pattern: lw, ls, ms, c)
# ---------------------------------------------------------------------------
def test_line_aliases():
    line = Line2D([], [])
    line.set_lw(5)
    assert line.get_linewidth() == 5
    line.set_ls(':')
    assert line.get_linestyle() == ':'
    line.set_ms(12)
    assert line.get_markersize() == 12
    line.set_c('green')
    assert line.get_color() == 'green'


# ===========================================================================
# Newly ported upstream tests (2026-03-19)
# Source: https://github.com/matplotlib/matplotlib/blob/main/lib/matplotlib/tests/test_lines.py
# ===========================================================================

import matplotlib.pyplot as plt


# ---------------------------------------------------------------------------
# test_valid_linestyles (upstream)
# ---------------------------------------------------------------------------
def test_valid_linestyles():
    """Upstream: invalid linestyle raises ValueError."""
    line = Line2D([], [])
    with pytest.raises(ValueError):
        line.set_linestyle('aardvark')


# ---------------------------------------------------------------------------
# test_valid_drawstyles (upstream)
# ---------------------------------------------------------------------------
def test_valid_drawstyles():
    """Upstream: invalid drawstyle raises ValueError."""
    line = Line2D([], [])
    with pytest.raises(ValueError):
        line.set_drawstyle('foobar')


# ---------------------------------------------------------------------------
# test_valid_colors (upstream)
# ---------------------------------------------------------------------------
def test_valid_colors():
    """Upstream: invalid color raises ValueError."""
    line = Line2D([], [])
    with pytest.raises(ValueError):
        line.set_color("foobar")


# ---------------------------------------------------------------------------
# test_line_colors (upstream)
# ---------------------------------------------------------------------------
def test_line_colors():
    """Upstream: various valid color specifications."""
    fig, ax = plt.subplots()
    ax.plot(range(10), color='none')
    ax.plot(range(10), color='r')
    ax.plot(range(10), color='.3')
    ax.plot(range(10), color=(1, 0, 0, 1))
    ax.plot(range(10), color=(1, 0, 0))


# ---------------------------------------------------------------------------
# test_linestyle_variants (upstream)
# ---------------------------------------------------------------------------
def test_linestyle_variants():
    """Upstream: all standard linestyle strings work."""
    fig, ax = plt.subplots()
    for ls in ["-", "solid", "--", "dashed",
               "-.", "dashdot", ":", "dotted"]:
        ax.plot(range(10), linestyle=ls)


# ===========================================================================
# Newly ported upstream tests (2026-03-19, batch 2)
# ===========================================================================


# ---------------------------------------------------------------------------
# test_drawstyle_variants (upstream ~line 97)
# ---------------------------------------------------------------------------
def test_drawstyle_variants():
    """Upstream: all drawstyle variants work in plot."""
    fig, ax = plt.subplots()
    dss = ["default", "steps-mid", "steps-pre", "steps-post", "steps"]
    for ds in dss:
        line = Line2D(range(10), range(10), drawstyle=ds)
        assert line.get_drawstyle() == ds


# ---------------------------------------------------------------------------
# Additional Line2D tests
# ---------------------------------------------------------------------------

def test_line_visibility():
    """Line2D visibility can be toggled."""
    line = Line2D([0, 1], [0, 1])
    assert line.get_visible() is True
    line.set_visible(False)
    assert line.get_visible() is False


def test_line_zorder():
    """Line2D zorder can be set."""
    line = Line2D([0, 1], [0, 1])
    assert line.zorder == 2
    line.set_zorder(10)
    assert line.get_zorder() == 10


def test_line_label():
    """Line2D label can be set/get."""
    line = Line2D([0, 1], [0, 1])
    line.set_label('my line')
    assert line.get_label() == 'my line'


def test_line_marker_set():
    """Line2D marker can be changed after construction."""
    line = Line2D([0, 1], [0, 1])
    line.set_marker('o')
    assert line.get_marker() == 'o'


def test_line_markersize_set():
    """Line2D markersize can be changed via set_ms."""
    line = Line2D([0, 1], [0, 1])
    line.set_ms(15)
    assert line.get_markersize() == 15


def test_line_fillstyle_set():
    """Line2D fillstyle can be set."""
    line = Line2D([0, 1], [0, 1])
    line.set_fillstyle('bottom')
    assert line.get_fillstyle() == 'bottom'


def test_line_linewidth_set():
    """Line2D linewidth can be changed."""
    line = Line2D([0, 1], [0, 1])
    line.set_linewidth(3.0)
    assert line.get_linewidth() == 3.0


def test_line_data_get():
    """Line2D get_data returns (xdata, ydata)."""
    line = Line2D([1, 2, 3], [4, 5, 6])
    x, y = line.get_data()
    assert x == [1, 2, 3]
    assert y == [4, 5, 6]


def test_line_set_xdata_ydata():
    """Line2D set_xdata / set_ydata update data independently."""
    line = Line2D([1, 2], [3, 4])
    line.set_xdata([10, 20])
    assert line.get_xdata() == [10, 20]
    assert line.get_ydata() == [3, 4]
    line.set_ydata([30, 40])
    assert line.get_ydata() == [30, 40]


# ---------------------------------------------------------------------------
# Line2D set_data (upstream ~line 200)
# ---------------------------------------------------------------------------
def test_line_set_data():
    """Line2D set_data updates both x and y."""
    line = Line2D([1, 2], [3, 4])
    line.set_data([10, 20, 30], [40, 50, 60])
    assert line.get_xdata() == [10, 20, 30]
    assert line.get_ydata() == [40, 50, 60]


# ---------------------------------------------------------------------------
# Line2D color validation (upstream ~line 120)
# ---------------------------------------------------------------------------
def test_line_set_color_valid():
    """set_color accepts valid color strings."""
    line = Line2D([0, 1], [0, 1])
    line.set_color('red')
    assert line.get_color() == 'red'
    line.set_color('#ff0000')
    assert line.get_color() == '#ff0000'


def test_line_set_color_invalid():
    """set_color raises ValueError for invalid colors."""
    line = Line2D([0, 1], [0, 1])
    with pytest.raises(ValueError):
        line.set_color('not_a_real_color')


def test_line_set_c_alias():
    """set_c is an alias for set_color."""
    line = Line2D([0, 1], [0, 1])
    line.set_c('blue')
    assert line.get_color() == 'blue'


# ---------------------------------------------------------------------------
# Line2D linestyle validation (upstream ~line 145)
# ---------------------------------------------------------------------------
def test_line_linestyle_solid():
    """set_linestyle('solid') is valid."""
    line = Line2D([0, 1], [0, 1])
    line.set_linestyle('solid')
    assert line.get_linestyle() == 'solid'


def test_line_linestyle_dashed():
    """set_linestyle('--') is valid."""
    line = Line2D([0, 1], [0, 1])
    line.set_linestyle('--')
    assert line.get_linestyle() == '--'


def test_line_linestyle_dashdot():
    """set_linestyle('dashdot') is valid."""
    line = Line2D([0, 1], [0, 1])
    line.set_linestyle('dashdot')
    assert line.get_linestyle() == 'dashdot'


def test_line_linestyle_dotted():
    """set_linestyle(':') is valid."""
    line = Line2D([0, 1], [0, 1])
    line.set_linestyle(':')
    assert line.get_linestyle() == ':'


def test_line_linestyle_none():
    """set_linestyle('None') is valid."""
    line = Line2D([0, 1], [0, 1])
    line.set_linestyle('None')
    assert line.get_linestyle() == 'None'


def test_line_linestyle_empty():
    """set_linestyle('') is valid."""
    line = Line2D([0, 1], [0, 1])
    line.set_linestyle('')
    assert line.get_linestyle() == ''


# ---------------------------------------------------------------------------
# Line2D marker
# ---------------------------------------------------------------------------
def test_line_marker_set():
    """set_marker changes the marker."""
    line = Line2D([0, 1], [0, 1])
    line.set_marker('o')
    assert line.get_marker() == 'o'


def test_line_marker_none():
    """Default marker is 'None'."""
    line = Line2D([0, 1], [0, 1])
    assert line.get_marker() == 'None'


# ---------------------------------------------------------------------------
# Line2D markersize
# ---------------------------------------------------------------------------
def test_line_markersize_default():
    """Default markersize is 6.0."""
    line = Line2D([0, 1], [0, 1])
    assert line.get_markersize() == 6.0


def test_line_markersize_set():
    """set_markersize changes the size."""
    line = Line2D([0, 1], [0, 1])
    line.set_markersize(10.0)
    assert line.get_markersize() == 10.0


def test_line_set_ms_alias():
    """set_ms is an alias for set_markersize."""
    line = Line2D([0, 1], [0, 1])
    line.set_ms(8.0)
    assert line.get_markersize() == 8.0


# ---------------------------------------------------------------------------
# Line2D drawstyle
# ---------------------------------------------------------------------------
def test_line_drawstyle_default():
    """Default drawstyle is 'default'."""
    line = Line2D([0, 1], [0, 1])
    assert line.get_drawstyle() == 'default'


def test_line_drawstyle_set():
    """set_drawstyle changes the style."""
    line = Line2D([0, 1], [0, 1])
    line.set_drawstyle('steps')
    assert line.get_drawstyle() == 'steps'


def test_line_drawstyle_invalid():
    """Invalid drawstyle raises ValueError."""
    line = Line2D([0, 1], [0, 1])
    with pytest.raises(ValueError):
        line.set_drawstyle('invalid')


# ---------------------------------------------------------------------------
# Line2D visibility
# ---------------------------------------------------------------------------
def test_line_visible_default():
    """Default visibility is True."""
    line = Line2D([0, 1], [0, 1])
    assert line.get_visible() is True


def test_line_set_visible():
    """set_visible changes visibility."""
    line = Line2D([0, 1], [0, 1])
    line.set_visible(False)
    assert line.get_visible() is False


# ---------------------------------------------------------------------------
# Line2D alpha
# ---------------------------------------------------------------------------
def test_line_alpha_default():
    """Default alpha is None."""
    line = Line2D([0, 1], [0, 1])
    assert line.get_alpha() is None


def test_line_set_alpha():
    """set_alpha changes alpha."""
    line = Line2D([0, 1], [0, 1])
    line.set_alpha(0.5)
    assert line.get_alpha() == 0.5


# ---------------------------------------------------------------------------
# Line2D zorder
# ---------------------------------------------------------------------------
def test_line_zorder_default():
    """Default zorder for Line2D is 2."""
    line = Line2D([0, 1], [0, 1])
    assert line.get_zorder() == 2


def test_line_set_zorder():
    """set_zorder changes the zorder."""
    line = Line2D([0, 1], [0, 1])
    line.set_zorder(10)
    assert line.get_zorder() == 10


# ---------------------------------------------------------------------------
# Line2D label
# ---------------------------------------------------------------------------
def test_line_label_default():
    """Default label is empty string."""
    line = Line2D([0, 1], [0, 1])
    assert line.get_label() == ''


def test_line_label_set():
    """set_label changes the label."""
    line = Line2D([0, 1], [0, 1])
    line.set_label('my line')
    assert line.get_label() == 'my line'


def test_line_label_constructor():
    """label in constructor sets the label."""
    line = Line2D([0, 1], [0, 1], label='ctor label')
    assert line.get_label() == 'ctor label'


# ---------------------------------------------------------------------------
# Line2D constructor kwargs
# ---------------------------------------------------------------------------
def test_line_constructor_color():
    """color kwarg in constructor."""
    line = Line2D([0, 1], [0, 1], color='red')
    assert line.get_color() == 'red'


def test_line_constructor_linewidth():
    """linewidth kwarg in constructor."""
    line = Line2D([0, 1], [0, 1], linewidth=3.0)
    assert line.get_linewidth() == 3.0


def test_line_constructor_linestyle():
    """linestyle kwarg in constructor."""
    line = Line2D([0, 1], [0, 1], linestyle='--')
    assert line.get_linestyle() == '--'


def test_line_constructor_marker():
    """marker kwarg in constructor."""
    line = Line2D([0, 1], [0, 1], marker='o')
    assert line.get_marker() == 'o'


# ---------------------------------------------------------------------------
# Line2D set_lw alias
# ---------------------------------------------------------------------------
def test_line_set_lw_alias():
    """set_lw is an alias for set_linewidth."""
    line = Line2D([0, 1], [0, 1])
    line.set_lw(5.0)
    assert line.get_linewidth() == 5.0


# ---------------------------------------------------------------------------
# Line2D set_ls alias
# ---------------------------------------------------------------------------
def test_line_set_ls_alias():
    """set_ls is an alias for set_linestyle."""
    line = Line2D([0, 1], [0, 1])
    line.set_ls('--')
    assert line.get_linestyle() == '--'


# ---------------------------------------------------------------------------
# Line2D empty data
# ---------------------------------------------------------------------------
def test_line_empty_data():
    """Line2D with empty data."""
    line = Line2D([], [])
    assert line.get_xdata() == []
    assert line.get_ydata() == []
    x, y = line.get_data()
    assert x == []
    assert y == []
