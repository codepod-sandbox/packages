"""
Upstream tests for statistics plot patterns commonly used by LLMs.
"""

import pytest
import numpy as np
import matplotlib.pyplot as plt


class TestBoxplotPatterns:
    """Tests for boxplot and violin plot patterns."""

    def teardown_method(self):
        plt.close('all')

    def test_boxplot_single(self):
        rng = np.random.default_rng(42)
        data = rng.normal(0, 1, 50)
        fig, ax = plt.subplots()
        bp = ax.boxplot(data)
        assert bp is not None

    def test_boxplot_multiple(self):
        rng = np.random.default_rng(42)
        data = [rng.normal(i, 1, 30) for i in range(3)]
        fig, ax = plt.subplots()
        bp = ax.boxplot(data)
        assert bp is not None

    def test_boxplot_notch(self):
        rng = np.random.default_rng(42)
        data = [rng.normal(i, 1, 30) for i in range(3)]
        fig, ax = plt.subplots()
        ax.boxplot(data, notch=True)

    def test_boxplot_vert_false(self):
        rng = np.random.default_rng(42)
        data = [rng.normal(0, 1, 20) for _ in range(3)]
        fig, ax = plt.subplots()
        ax.boxplot(data, vert=False)

    def test_boxplot_labels(self):
        rng = np.random.default_rng(42)
        data = [rng.normal(i, 1, 30) for i in range(3)]
        fig, ax = plt.subplots()
        ax.boxplot(data, labels=['A', 'B', 'C'])

    def test_boxplot_patch_artist(self):
        rng = np.random.default_rng(42)
        data = [rng.normal(i, 1, 30) for i in range(3)]
        fig, ax = plt.subplots()
        bp = ax.boxplot(data, patch_artist=True)
        assert bp is not None

    def test_violinplot_basic(self):
        rng = np.random.default_rng(42)
        data = [rng.normal(i, 1, 30) for i in range(3)]
        fig, ax = plt.subplots()
        vp = ax.violinplot(data)
        assert vp is not None

    def test_violinplot_positions(self):
        rng = np.random.default_rng(42)
        data = [rng.normal(0, 1, 30) for _ in range(3)]
        fig, ax = plt.subplots()
        ax.violinplot(data, positions=[1, 3, 5])

    def test_violinplot_no_whiskers(self):
        rng = np.random.default_rng(42)
        data = [rng.normal(0, 1, 30) for _ in range(3)]
        fig, ax = plt.subplots()
        ax.violinplot(data, showextrema=False)

    def test_violinplot_quantiles(self):
        rng = np.random.default_rng(42)
        data = [rng.normal(0, 1, 100) for _ in range(2)]
        fig, ax = plt.subplots()
        ax.violinplot(data, quantiles=[[0.25, 0.75], [0.25, 0.75]])


class TestHistogramPatterns:
    """Tests for histogram patterns."""

    def teardown_method(self):
        plt.close('all')

    def test_hist_basic(self):
        rng = np.random.default_rng(42)
        data = rng.normal(0, 1, 100)
        fig, ax = plt.subplots()
        n, bins, patches = ax.hist(data)
        assert len(n) > 0

    def test_hist_bins_int(self):
        rng = np.random.default_rng(42)
        data = rng.normal(0, 1, 100)
        fig, ax = plt.subplots()
        ax.hist(data, bins=20)

    def test_hist_bins_array(self):
        rng = np.random.default_rng(42)
        data = rng.normal(0, 1, 100)
        fig, ax = plt.subplots()
        bins = np.linspace(-3, 3, 13)
        ax.hist(data, bins=bins)

    def test_hist_density(self):
        rng = np.random.default_rng(42)
        data = rng.normal(0, 1, 100)
        fig, ax = plt.subplots()
        ax.hist(data, density=True)

    def test_hist_cumulative(self):
        rng = np.random.default_rng(42)
        data = rng.normal(0, 1, 100)
        fig, ax = plt.subplots()
        ax.hist(data, cumulative=True)

    def test_hist_color(self):
        rng = np.random.default_rng(42)
        data = rng.normal(0, 1, 100)
        fig, ax = plt.subplots()
        ax.hist(data, color='steelblue', edgecolor='black')

    def test_hist_alpha(self):
        rng = np.random.default_rng(42)
        data1 = rng.normal(0, 1, 100)
        data2 = rng.normal(2, 1, 100)
        fig, ax = plt.subplots()
        ax.hist(data1, alpha=0.5, label='Group 1')
        ax.hist(data2, alpha=0.5, label='Group 2')
        ax.legend()

    def test_hist_horizontal(self):
        rng = np.random.default_rng(42)
        data = rng.normal(0, 1, 100)
        fig, ax = plt.subplots()
        ax.hist(data, orientation='horizontal')

    def test_hist_log_scale(self):
        rng = np.random.default_rng(42)
        data = rng.exponential(1, 500)
        fig, ax = plt.subplots()
        ax.hist(data, bins=30, log=True)

    def test_hist_stacked(self):
        rng = np.random.default_rng(42)
        data1 = rng.normal(0, 1, 50)
        data2 = rng.normal(1, 1, 50)
        fig, ax = plt.subplots()
        ax.hist([data1, data2], stacked=True)


class TestErrorBarPatterns:
    """Tests for error bar patterns."""

    def teardown_method(self):
        plt.close('all')

    def test_errorbar_yerr(self):
        x = np.arange(5)
        y = np.array([2.0, 3.5, 2.8, 4.2, 3.0])
        yerr = np.array([0.3, 0.4, 0.2, 0.5, 0.3])
        fig, ax = plt.subplots()
        ax.errorbar(x, y, yerr=yerr)

    def test_errorbar_xerr(self):
        x = np.array([1.0, 2.0, 3.0, 4.0])
        y = np.array([2.0, 3.5, 2.8, 4.2])
        xerr = np.array([0.1, 0.2, 0.1, 0.15])
        fig, ax = plt.subplots()
        ax.errorbar(x, y, xerr=xerr)

    def test_errorbar_both(self):
        x = np.arange(4)
        y = np.array([1.0, 2.0, 3.0, 2.5])
        yerr = 0.2
        xerr = 0.1
        fig, ax = plt.subplots()
        ax.errorbar(x, y, yerr=yerr, xerr=xerr, fmt='o-')

    def test_errorbar_asymmetric(self):
        x = np.arange(3)
        y = np.array([2.0, 3.5, 2.8])
        yerr = np.array([[0.2, 0.3, 0.1], [0.4, 0.5, 0.3]])
        fig, ax = plt.subplots()
        ax.errorbar(x, y, yerr=yerr)

    def test_errorbar_fmt(self):
        x = np.arange(5)
        y = np.random.rand(5)
        fig, ax = plt.subplots()
        ax.errorbar(x, y, yerr=0.1, fmt='s--', color='blue')

    def test_errorbar_capsize(self):
        x = np.arange(4)
        y = np.random.rand(4)
        fig, ax = plt.subplots()
        ax.errorbar(x, y, yerr=0.2, capsize=5)


class TestStemStepPlots:
    """Tests for stem and step plot patterns."""

    def teardown_method(self):
        plt.close('all')

    def test_stem_basic(self):
        x = np.arange(5)
        y = np.array([1, 3, 2, 4, 2])
        fig, ax = plt.subplots()
        ax.stem(x, y)

    def test_stem_markerfmt(self):
        x = np.arange(5)
        y = [1, 2, 3, 2, 1]
        fig, ax = plt.subplots()
        ax.stem(x, y, markerfmt='D')

    def test_step_pre(self):
        x = np.arange(5)
        y = np.array([1, 3, 2, 4, 2])
        fig, ax = plt.subplots()
        ax.step(x, y, where='pre')

    def test_step_post(self):
        x = np.arange(5)
        y = np.array([1, 3, 2, 4, 2])
        fig, ax = plt.subplots()
        ax.step(x, y, where='post')

    def test_step_mid(self):
        x = np.arange(5)
        y = np.array([1, 3, 2, 4, 2])
        fig, ax = plt.subplots()
        ax.step(x, y, where='mid')

    def test_fill_between_basic(self):
        x = np.linspace(0, 10, 50)
        y1 = np.sin(x)
        y2 = np.cos(x)
        fig, ax = plt.subplots()
        ax.fill_between(x, y1, y2, alpha=0.3)

    def test_fill_between_where(self):
        x = np.linspace(0, 10, 50)
        y1 = np.sin(x)
        y2 = np.zeros_like(x)
        fig, ax = plt.subplots()
        ax.fill_between(x, y1, y2, where=y1 > 0, alpha=0.5, color='green')
        ax.fill_between(x, y1, y2, where=y1 < 0, alpha=0.5, color='red')

    def test_fill_betweenx(self):
        y = np.linspace(0, 10, 50)
        x1 = np.sin(y)
        x2 = np.zeros_like(y)
        fig, ax = plt.subplots()
        ax.fill_betweenx(y, x1, x2, alpha=0.3)
