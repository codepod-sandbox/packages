"""Tests for advanced legend and colorbar patterns."""

import pytest
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.lines as mlines
import matplotlib.colors as mcolors


class TestLegendAdvanced:
    def test_legend_loc_string(self):
        """Legend with location string."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3], label='Line')
        ax.legend(loc='upper left')
        plt.close('all')

    def test_legend_loc_int(self):
        """Legend with location integer."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3], label='Line')
        ax.legend(loc=1)  # upper right
        plt.close('all')

    def test_legend_outside(self):
        """Legend outside the axes."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3], label='Line A')
        ax.plot([1, 2, 3], [3, 2, 1], label='Line B')
        ax.legend(loc='upper left', bbox_to_anchor=(1, 1))
        plt.close('all')

    def test_legend_title(self):
        """Legend with title."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3], label='Line A')
        ax.legend(title='My Legend')
        plt.close('all')

    def test_legend_fontsize(self):
        """Legend with font size."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3], label='Line')
        ax.legend(fontsize=10)
        plt.close('all')

    def test_legend_ncol(self):
        """Legend with multiple columns."""
        fig, ax = plt.subplots()
        for i in range(4):
            ax.plot([1, 2, 3], [i, i+1, i+2], label=f'Line {i+1}')
        ax.legend(ncol=2)
        plt.close('all')

    def test_legend_frameon(self):
        """Legend without frame."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3], label='Line')
        ax.legend(frameon=False)
        plt.close('all')

    def test_legend_fancybox(self):
        """Legend with fancy box."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3], label='Line')
        ax.legend(fancybox=True)
        plt.close('all')

    def test_legend_shadow(self):
        """Legend with shadow."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3], label='Line')
        ax.legend(shadow=True)
        plt.close('all')

    def test_legend_custom_handles(self):
        """Legend with custom handles."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3])
        handles = [mpatches.Patch(color='red', label='Red'),
                   mpatches.Patch(color='blue', label='Blue')]
        ax.legend(handles=handles)
        plt.close('all')

    def test_legend_custom_lines(self):
        """Legend with custom line handles."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3], color='red', linewidth=3)
        handles = [mlines.Line2D([], [], color='red', linewidth=3, label='Thick Red')]
        ax.legend(handles=handles)
        plt.close('all')

    def test_legend_alpha(self):
        """Legend with alpha."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3], label='Line')
        leg = ax.legend(framealpha=0.5)
        plt.close('all')

    def test_legend_get_set(self):
        """Get and set legend."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3], label='Line')
        leg = ax.legend()
        assert ax.get_legend() is leg
        plt.close('all')

    def test_legend_remove(self):
        """Remove legend."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3], label='Line')
        leg = ax.legend()
        leg.remove()
        plt.close('all')


class TestColorbarAdvanced:
    def test_colorbar_orientation_horizontal(self):
        """Horizontal colorbar."""
        fig, ax = plt.subplots()
        data = [[1.0, 2.0, 3.0], [4.0, 5.0, 6.0]]
        im = ax.imshow(data)
        cbar = fig.colorbar(im, orientation='horizontal')
        assert cbar is not None
        plt.close('all')

    def test_colorbar_orientation_vertical(self):
        """Vertical colorbar (default)."""
        fig, ax = plt.subplots()
        data = [[1.0, 2.0, 3.0], [4.0, 5.0, 6.0]]
        im = ax.imshow(data)
        cbar = fig.colorbar(im, orientation='vertical')
        assert cbar is not None
        plt.close('all')

    def test_colorbar_label(self):
        """Colorbar with label."""
        fig, ax = plt.subplots()
        im = ax.imshow([[1.0, 2.0], [3.0, 4.0]])
        cbar = fig.colorbar(im)
        cbar.set_label('Value')
        plt.close('all')

    def test_colorbar_ticks(self):
        """Colorbar with custom ticks."""
        fig, ax = plt.subplots()
        data = [[0.0, 5.0], [5.0, 10.0]]
        im = ax.imshow(data, vmin=0, vmax=10)
        cbar = fig.colorbar(im)
        cbar.set_ticks([0, 2, 5, 8, 10])
        plt.close('all')

    def test_colorbar_ticklabels(self):
        """Colorbar with custom tick labels."""
        fig, ax = plt.subplots()
        im = ax.imshow([[0.0, 1.0], [2.0, 3.0]], vmin=0, vmax=3)
        cbar = fig.colorbar(im)
        cbar.set_ticks([0, 1, 2, 3])
        cbar.set_ticklabels(['Low', 'Med-Low', 'Med-High', 'High'])
        plt.close('all')

    def test_colorbar_extend_both(self):
        """Colorbar with extend both."""
        fig, ax = plt.subplots()
        data = [[0.0, 5.0], [5.0, 10.0]]
        im = ax.imshow(data, vmin=2, vmax=8)
        cbar = fig.colorbar(im, extend='both')
        assert cbar is not None
        plt.close('all')

    def test_colorbar_extend_min(self):
        """Colorbar extending min."""
        fig, ax = plt.subplots()
        im = ax.imshow([[0.0, 5.0], [5.0, 10.0]], vmin=2, vmax=10)
        cbar = fig.colorbar(im, extend='min')
        assert cbar is not None
        plt.close('all')

    def test_colorbar_extend_max(self):
        """Colorbar extending max."""
        fig, ax = plt.subplots()
        im = ax.imshow([[0.0, 5.0], [5.0, 10.0]], vmin=0, vmax=8)
        cbar = fig.colorbar(im, extend='max')
        assert cbar is not None
        plt.close('all')

    def test_colorbar_shrink(self):
        """Colorbar with shrink."""
        fig, ax = plt.subplots()
        im = ax.imshow([[1.0, 2.0], [3.0, 4.0]])
        cbar = fig.colorbar(im, shrink=0.5)
        assert cbar is not None
        plt.close('all')

    def test_colorbar_pad(self):
        """Colorbar with pad."""
        fig, ax = plt.subplots()
        im = ax.imshow([[1.0, 2.0], [3.0, 4.0]])
        cbar = fig.colorbar(im, pad=0.1)
        assert cbar is not None
        plt.close('all')

    def test_plt_colorbar(self):
        """plt.colorbar."""
        fig, ax = plt.subplots()
        im = ax.imshow([[1.0, 2.0], [3.0, 4.0]])
        cbar = plt.colorbar(im)
        assert cbar is not None
        plt.close('all')

    def test_colorbar_with_scatter(self):
        """Colorbar with scatter plot."""
        fig, ax = plt.subplots()
        x = [1.0, 2.0, 3.0, 4.0, 5.0]
        y = [2.0, 1.0, 4.0, 3.0, 5.0]
        c = [1.0, 2.0, 3.0, 4.0, 5.0]
        sc = ax.scatter(x, y, c=c, cmap='viridis')
        cbar = plt.colorbar(sc)
        cbar.set_label('Z values')
        plt.close('all')

    def test_colorbar_with_contourf(self):
        """Colorbar with contourf."""
        fig, ax = plt.subplots()
        x = [0.0, 1.0, 2.0]
        y = [0.0, 1.0, 2.0]
        z = [[1.0, 2.0, 1.0], [2.0, 4.0, 2.0], [1.0, 2.0, 1.0]]
        cs = ax.contourf(x, y, z, cmap='viridis')
        cbar = plt.colorbar(cs)
        assert cbar is not None
        plt.close('all')
