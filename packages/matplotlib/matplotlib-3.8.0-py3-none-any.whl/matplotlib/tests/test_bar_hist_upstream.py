"""Tests for bar and histogram plots."""

import pytest
import numpy as np
import matplotlib.pyplot as plt


class TestBar:
    def test_bar_basic(self):
        """ax.bar() with basic args does not raise."""
        fig, ax = plt.subplots()
        ax.bar([1, 2, 3], [3, 1, 4])
        plt.close('all')

    def test_bar_width(self):
        """ax.bar() with width does not raise."""
        fig, ax = plt.subplots()
        ax.bar([1, 2, 3], [3, 1, 4], width=0.5)
        plt.close('all')

    def test_bar_color_list(self):
        """ax.bar() with list of colors does not raise."""
        fig, ax = plt.subplots()
        ax.bar([1, 2, 3], [3, 1, 4], color=['red', 'blue', 'green'])
        plt.close('all')

    def test_bar_bottom(self):
        """ax.bar() with bottom parameter does not raise."""
        fig, ax = plt.subplots()
        ax.bar([1, 2, 3], [3, 1, 4], bottom=[1, 2, 0])
        plt.close('all')

    def test_bar_horizontal(self):
        """ax.barh() does not raise."""
        fig, ax = plt.subplots()
        ax.barh([1, 2, 3], [3, 1, 4])
        plt.close('all')

    def test_bar_with_labels(self):
        """ax.bar() with tick_label does not raise."""
        fig, ax = plt.subplots()
        ax.bar(['A', 'B', 'C'], [3, 1, 4])
        plt.close('all')

    def test_bar_edgecolor(self):
        """ax.bar() with edgecolor does not raise."""
        fig, ax = plt.subplots()
        ax.bar([1, 2, 3], [3, 1, 4], edgecolor='black', linewidth=1.5)
        plt.close('all')

    def test_bar_alpha(self):
        """ax.bar() with alpha does not raise."""
        fig, ax = plt.subplots()
        ax.bar([1, 2, 3], [3, 1, 4], alpha=0.7)
        plt.close('all')

    def test_bar_hatch(self):
        """ax.bar() with hatch does not raise."""
        fig, ax = plt.subplots()
        ax.bar([1, 2, 3], [3, 1, 4], hatch='/', edgecolor='black')
        plt.close('all')

    def test_bar_stacked(self):
        """Stacked bar chart with bottom does not raise."""
        fig, ax = plt.subplots()
        cats = ['A', 'B', 'C']
        v1 = [3, 1, 4]
        v2 = [2, 3, 1]
        ax.bar(cats, v1, label='v1')
        ax.bar(cats, v2, bottom=v1, label='v2')
        ax.legend()
        plt.close('all')

    def test_bar_returns_container(self):
        """ax.bar() returns a BarContainer."""
        fig, ax = plt.subplots()
        bars = ax.bar([1, 2, 3], [3, 1, 4])
        assert bars is not None
        plt.close('all')

    def test_bar_numpy_arrays(self):
        """ax.bar() with numpy arrays does not raise."""
        fig, ax = plt.subplots()
        x = np.arange(5)
        y = np.array([1.0, 3.0, 2.0, 4.0, 1.5])
        ax.bar(x, y)
        plt.close('all')

    def test_barh_color_list(self):
        """ax.barh() with list of colors does not raise."""
        fig, ax = plt.subplots()
        ax.barh([1, 2, 3], [3, 1, 4], color=['red', 'green', 'blue'])
        plt.close('all')

    def test_bar_yerr(self):
        """ax.bar() with yerr does not raise."""
        fig, ax = plt.subplots()
        ax.bar([1, 2, 3], [3, 1, 4], yerr=[0.1, 0.2, 0.3])
        plt.close('all')


class TestHistogram:
    def test_hist_basic(self):
        """ax.hist() does not raise."""
        fig, ax = plt.subplots()
        ax.hist([1, 2, 2, 3, 3, 3, 4, 4, 4, 4])
        plt.close('all')

    def test_hist_bins(self):
        """ax.hist() with bins does not raise."""
        fig, ax = plt.subplots()
        ax.hist(np.random.randn(100), bins=20)
        plt.close('all')

    def test_hist_density(self):
        """ax.hist() with density=True does not raise."""
        fig, ax = plt.subplots()
        ax.hist([1, 1, 2, 2, 3], density=True)
        plt.close('all')

    def test_hist_cumulative(self):
        """ax.hist() with cumulative=True does not raise."""
        fig, ax = plt.subplots()
        ax.hist([1, 2, 3, 4, 5], cumulative=True)
        plt.close('all')

    def test_hist_orientation_horizontal(self):
        """ax.hist() with orientation='horizontal' does not raise."""
        fig, ax = plt.subplots()
        ax.hist([1, 2, 3, 4, 5], orientation='horizontal')
        plt.close('all')

    def test_hist_stacked(self):
        """ax.hist() with stacked=True and multiple datasets does not raise."""
        fig, ax = plt.subplots()
        ax.hist([[1, 2, 3], [2, 3, 4], [3, 4, 5]], stacked=True)
        plt.close('all')

    def test_hist_color(self):
        """ax.hist() with color does not raise."""
        fig, ax = plt.subplots()
        ax.hist([1, 2, 3], color='blue', alpha=0.7)
        plt.close('all')

    def test_hist_range(self):
        """ax.hist() with range does not raise."""
        fig, ax = plt.subplots()
        ax.hist(np.random.randn(100), range=(-2, 2))
        plt.close('all')

    def test_hist_returns_tuple(self):
        """ax.hist() returns (n, bins, patches) tuple."""
        fig, ax = plt.subplots()
        result = ax.hist([1, 2, 3, 4, 5], bins=3)
        assert isinstance(result, tuple)
        assert len(result) == 3
        plt.close('all')

    def test_hist_log(self):
        """ax.hist() with log=True does not raise."""
        fig, ax = plt.subplots()
        ax.hist([1, 2, 3, 3, 3, 4, 5], log=True)
        plt.close('all')

    def test_hist_histtype(self):
        """ax.hist() with different histtypes does not raise."""
        for ht in ['bar', 'barstacked', 'step', 'stepfilled']:
            fig, ax = plt.subplots()
            ax.hist([1, 2, 3, 4], histtype=ht)
            plt.close('all')

    def test_plt_hist(self):
        """plt.hist() wrapper does not raise."""
        plt.figure()
        plt.hist([1, 2, 3, 4, 5])
        plt.close('all')

    def test_hist_svg(self):
        """Histogram renders to SVG."""
        fig, ax = plt.subplots()
        ax.hist(np.random.randn(50), bins=10)
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')
