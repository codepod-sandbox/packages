"""
Upstream tests for scatter plot patterns commonly used by LLMs.
"""

import numpy as np
import pytest
import matplotlib.pyplot as plt


class TestScatterBasic:
    """Basic scatter plot patterns."""

    def teardown_method(self):
        plt.close('all')

    def test_scatter_basic(self):
        fig, ax = plt.subplots()
        ax.scatter([1, 2, 3], [4, 5, 6])

    def test_scatter_color_string(self):
        fig, ax = plt.subplots()
        ax.scatter([1, 2, 3], [4, 5, 6], c='red')

    def test_scatter_color_hex(self):
        fig, ax = plt.subplots()
        ax.scatter([1, 2, 3], [4, 5, 6], c='#0080ff')

    def test_scatter_color_array(self):
        """Scatter with array of values for coloring."""
        fig, ax = plt.subplots()
        ax.scatter([1, 2, 3], [4, 5, 6], c=[1, 2, 3], cmap='viridis')

    def test_scatter_size_scalar(self):
        fig, ax = plt.subplots()
        ax.scatter([1, 2, 3], [4, 5, 6], s=50)

    def test_scatter_size_array(self):
        fig, ax = plt.subplots()
        ax.scatter([1, 2, 3], [4, 5, 6], s=[10, 50, 100])

    def test_scatter_alpha(self):
        fig, ax = plt.subplots()
        ax.scatter([1, 2, 3], [4, 5, 6], alpha=0.5)

    def test_scatter_marker(self):
        fig, ax = plt.subplots()
        for m in ['o', 's', '^', 'D', 'P']:
            ax.scatter([1], [1], marker=m)

    def test_scatter_edgecolors(self):
        fig, ax = plt.subplots()
        ax.scatter([1, 2, 3], [4, 5, 6], edgecolors='black')

    def test_scatter_edgecolors_none(self):
        fig, ax = plt.subplots()
        ax.scatter([1, 2, 3], [4, 5, 6], edgecolors='none')

    def test_scatter_linewidths(self):
        fig, ax = plt.subplots()
        ax.scatter([1, 2, 3], [4, 5, 6], linewidths=1.5)

    def test_scatter_label(self):
        fig, ax = plt.subplots()
        ax.scatter([1, 2], [3, 4], label='Data')
        ax.legend()

    def test_scatter_zorder(self):
        fig, ax = plt.subplots()
        sc = ax.scatter([1, 2], [3, 4], zorder=3)
        assert sc.get_zorder() == 3

    def test_scatter_vmin_vmax(self):
        fig, ax = plt.subplots()
        ax.scatter([1, 2, 3], [4, 5, 6], c=[1, 5, 10],
                  cmap='hot', vmin=0, vmax=10)

    def test_scatter_with_colorbar(self):
        fig, ax = plt.subplots()
        sc = ax.scatter([1, 2, 3], [4, 5, 6], c=[1, 2, 3], cmap='viridis')
        plt.colorbar(sc, ax=ax)


class TestScatterGroups:
    """Tests for scatter group patterns."""

    def teardown_method(self):
        plt.close('all')

    def test_scatter_groups_by_color(self):
        """Scatter with groups colored differently."""
        fig, ax = plt.subplots()
        groups = {'A': ([1, 2, 3], [1, 2, 1]),
                  'B': ([4, 5, 6], [2, 3, 2]),
                  'C': ([7, 8, 9], [3, 4, 3])}
        colors = {'A': 'red', 'B': 'green', 'C': 'blue'}
        for name, (x, y) in groups.items():
            ax.scatter(x, y, c=colors[name], label=name, s=50)
        ax.legend()

    def test_scatter_continuous_color(self):
        """Scatter with continuous color scale."""
        n = 30
        x = list(range(n))
        y = [i**0.5 for i in range(n)]
        c = list(range(n))
        fig, ax = plt.subplots()
        sc = ax.scatter(x, y, c=c, cmap='plasma', s=50)
        plt.colorbar(sc, ax=ax, label='index')

    def test_scatter_bubble_chart(self):
        """Bubble chart (scatter with size encoding)."""
        fig, ax = plt.subplots()
        x = [1, 2, 3, 4, 5]
        y = [5, 4, 3, 2, 1]
        sizes = [50, 100, 200, 300, 500]
        ax.scatter(x, y, s=sizes, alpha=0.6)

    def test_scatter_matrix_pattern(self):
        """Multiple scatter plots (simulated scatter matrix)."""
        fig, axes = plt.subplots(2, 2, figsize=(8, 8))
        data_x = [1, 2, 3, 4, 5]
        data_y = [2, 4, 1, 5, 3]
        data_z = [3, 1, 4, 1, 5]
        pairs = [(data_x, data_y), (data_x, data_z),
                 (data_y, data_x), (data_y, data_z)]
        for (row_axes), (xi, yi) in zip(axes, pairs[:2]):
            for ax, (x, y) in zip(row_axes, pairs[:2]):
                ax.scatter(x, y, alpha=0.5)

    def test_scatter_with_annotations(self):
        """Scatter with point labels."""
        fig, ax = plt.subplots()
        points = {'A': (1, 2), 'B': (3, 4), 'C': (2, 1)}
        for name, (x, y) in points.items():
            ax.scatter([x], [y], s=100)
            ax.annotate(name, (x, y), textcoords='offset points',
                       xytext=(5, 5))

    def test_scatter_add_line_of_best_fit(self):
        """Common: scatter + trend line."""
        x = [1, 2, 3, 4, 5]
        y = [2, 4, 3, 5, 6]
        fig, ax = plt.subplots()
        ax.scatter(x, y, label='data')
        # Simple trend line
        ax.plot([min(x), max(x)], [min(y), max(y)], 'r--', label='trend')
        ax.legend()


class TestScatterNumpyPatterns:
    """Tests for scatter with numpy arrays."""

    def teardown_method(self):
        plt.close('all')

    def test_scatter_numpy_arrays(self):
        x = np.array([1, 2, 3, 4, 5])
        y = np.array([2, 4, 1, 5, 3])
        fig, ax = plt.subplots()
        ax.scatter(x, y)

    def test_scatter_numpy_color_array(self):
        n = 20
        x = np.arange(n)
        y = np.random.default_rng(42).random(n)
        c = np.random.default_rng(42).random(n)
        fig, ax = plt.subplots()
        ax.scatter(x, y, c=c, cmap='RdYlBu')

    def test_scatter_numpy_2d_color(self):
        """Scatter with explicit RGBA colors array."""
        n = 5
        x = list(range(n))
        y = list(range(n))
        colors = [(i/n, 0, 1 - i/n, 0.8) for i in range(n)]
        fig, ax = plt.subplots()
        ax.scatter(x, y, c=colors)

    def test_scatter_get_offsets(self):
        fig, ax = plt.subplots()
        sc = ax.scatter([1, 2, 3], [4, 5, 6])
        offsets = sc.get_offsets()
        assert len(offsets) == 3

    def test_scatter_set_offsets(self):
        fig, ax = plt.subplots()
        sc = ax.scatter([1, 2], [3, 4])
        sc.set_offsets([[5, 6], [7, 8]])
        offsets = sc.get_offsets()
        assert len(offsets) == 2
