"""
Upstream tests — batch 18.
Focus: Axes operations, plot types, tick management, collections, pyplot.
Adapted from matplotlib upstream tests (no canvas rendering, no image comparison).
Note: Avoiding pytest.approx and np.arange(N) single-arg form.
"""
import math
import pytest
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.figure import Figure
from matplotlib.axes import Axes
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle, Circle, Polygon
from matplotlib.collections import LineCollection, PathCollection
from matplotlib.transforms import Bbox, Affine2D
from matplotlib.text import Text
import matplotlib.colors as mcolors
import matplotlib.ticker as mticker


def close(a, b, tol=1e-10):
    """Check approximate equality."""
    return abs(a - b) < tol


# ------------------------------------------------------------------
# Axes plot type tests
# ------------------------------------------------------------------

class TestAxesPlots:
    def test_plot_basic(self):
        fig, ax = plt.subplots()
        lines = ax.plot([0, 1, 2], [0, 1, 4])
        assert len(lines) == 1
        assert len(ax.lines) == 1

    def test_plot_returns_list(self):
        fig, ax = plt.subplots()
        result = ax.plot([0, 1], [0, 1])
        assert isinstance(result, list)

    def test_plot_color(self):
        fig, ax = plt.subplots()
        lines = ax.plot([0, 1], [0, 1], color='red')
        assert len(lines) == 1

    def test_plot_fmt(self):
        fig, ax = plt.subplots()
        lines = ax.plot([0, 1], [0, 1], 'r--')
        assert len(lines) == 1

    def test_plot_label(self):
        fig, ax = plt.subplots()
        lines = ax.plot([0, 1], [0, 1], label='myline')
        assert lines[0].get_label() == 'myline'

    def test_plot_linewidth(self):
        fig, ax = plt.subplots()
        lines = ax.plot([0, 1], [0, 1], linewidth=3)
        assert close(lines[0].get_linewidth(), 3)

    def test_plot_multi_line(self):
        fig, ax = plt.subplots()
        lines = ax.plot([0, 1], [0, 1], [0, 1], [1, 0])
        assert len(lines) == 2

    def test_scatter_basic(self):
        fig, ax = plt.subplots()
        ax.scatter([1, 2, 3], [4, 5, 6])
        assert len(ax.collections) >= 1

    def test_scatter_with_color(self):
        fig, ax = plt.subplots()
        ax.scatter([1, 2], [3, 4], c='red')
        assert len(ax.collections) >= 1

    def test_bar_basic(self):
        fig, ax = plt.subplots()
        bars = ax.bar([0, 1, 2], [3, 5, 2])
        assert bars is not None

    def test_barh_basic(self):
        fig, ax = plt.subplots()
        bars = ax.barh([0, 1, 2], [3, 5, 2])
        assert bars is not None

    def test_hist_basic(self):
        fig, ax = plt.subplots()
        data = [1, 2, 2, 3, 3, 3, 4]
        n, bins, patches = ax.hist(data, bins=4)
        assert len(n) == 4

    def test_hist_density(self):
        fig, ax = plt.subplots()
        data = [1, 2, 2, 3, 3, 3, 4]
        n, bins, patches = ax.hist(data, bins=4, density=True)
        assert len(n) == 4

    def test_fill_between(self):
        fig, ax = plt.subplots()
        x = [0, 1, 2]
        ax.fill_between(x, [0, 1, 0], [1, 2, 1])

    def test_axhline(self):
        fig, ax = plt.subplots()
        line = ax.axhline(y=0.5)
        assert line is not None

    def test_axvline(self):
        fig, ax = plt.subplots()
        line = ax.axvline(x=0.5)
        assert line is not None

    def test_axhspan(self):
        fig, ax = plt.subplots()
        patch = ax.axhspan(0.2, 0.8)
        assert patch is not None

    def test_axvspan(self):
        fig, ax = plt.subplots()
        patch = ax.axvspan(0.2, 0.8)
        assert patch is not None

    def test_errorbar(self):
        fig, ax = plt.subplots()
        x = [1, 2, 3]
        y = [1, 4, 9]
        err = [0.1, 0.2, 0.3]
        container = ax.errorbar(x, y, yerr=err)
        assert container is not None

    def test_stem(self):
        fig, ax = plt.subplots()
        x = [1, 2, 3, 4]
        y = [1, 4, 2, 3]
        container = ax.stem(x, y)
        assert container is not None

    def test_stairs(self):
        fig, ax = plt.subplots()
        ax.stairs([1, 2, 3], [0, 1, 2, 3])


# ------------------------------------------------------------------
# Axes limits and ticks
# ------------------------------------------------------------------

class TestAxesLimsTicks:
    def test_xlim_set_get(self):
        fig, ax = plt.subplots()
        ax.set_xlim(0, 10)
        xlim = ax.get_xlim()
        assert close(xlim[0], 0)
        assert close(xlim[1], 10)

    def test_ylim_set_get(self):
        fig, ax = plt.subplots()
        ax.set_ylim(-5, 5)
        ylim = ax.get_ylim()
        assert close(ylim[0], -5)
        assert close(ylim[1], 5)

    def test_xlim_tuple(self):
        fig, ax = plt.subplots()
        ax.set_xlim((1, 9))
        xlim = ax.get_xlim()
        assert close(xlim[0], 1)
        assert close(xlim[1], 9)

    def test_ylim_tuple(self):
        fig, ax = plt.subplots()
        ax.set_ylim((-3, 3))
        ylim = ax.get_ylim()
        assert close(ylim[0], -3)
        assert close(ylim[1], 3)

    def test_invert_xaxis(self):
        fig, ax = plt.subplots()
        ax.set_xlim(0, 10)
        ax.invert_xaxis()
        xlim = ax.get_xlim()
        # After invert, left > right
        assert xlim[0] > xlim[1]

    def test_invert_yaxis(self):
        fig, ax = plt.subplots()
        ax.set_ylim(0, 10)
        ax.invert_yaxis()
        ylim = ax.get_ylim()
        # After invert, bottom > top
        assert ylim[0] > ylim[1]

    def test_set_xticks(self):
        fig, ax = plt.subplots()
        ax.set_xticks([0, 1, 2, 3])
        ticks = ax.get_xticks()
        assert list(ticks) == [0, 1, 2, 3]

    def test_set_yticks(self):
        fig, ax = plt.subplots()
        ax.set_yticks([0, 0.5, 1.0])
        ticks = ax.get_yticks()
        assert list(ticks) == [0, 0.5, 1.0]

    def test_set_xticklabels(self):
        fig, ax = plt.subplots()
        ax.set_xticks([0, 1, 2])
        ax.set_xticklabels(['a', 'b', 'c'])
        labels = ax.get_xticklabels()
        # Labels may be strings or Text objects depending on implementation
        texts = [l.get_text() if hasattr(l, 'get_text') else l for l in labels]
        assert texts == ['a', 'b', 'c']

    def test_set_yticklabels(self):
        fig, ax = plt.subplots()
        ax.set_yticks([0, 1, 2])
        ax.set_yticklabels(['x', 'y', 'z'])
        labels = ax.get_yticklabels()
        # Labels may be strings or Text objects depending on implementation
        texts = [l.get_text() if hasattr(l, 'get_text') else l for l in labels]
        assert texts == ['x', 'y', 'z']

    def test_set_xlabel(self):
        fig, ax = plt.subplots()
        ax.set_xlabel('X Axis')
        assert ax.get_xlabel() == 'X Axis'

    def test_set_ylabel(self):
        fig, ax = plt.subplots()
        ax.set_ylabel('Y Axis')
        assert ax.get_ylabel() == 'Y Axis'

    def test_set_title(self):
        fig, ax = plt.subplots()
        ax.set_title('My Plot')
        assert ax.get_title() == 'My Plot'

    def test_grid_on(self):
        fig, ax = plt.subplots()
        ax.grid(True)
        assert ax._grid is True

    def test_grid_off(self):
        fig, ax = plt.subplots()
        ax.grid(True)
        ax.grid(False)
        assert ax._grid is False

    def test_set_major_locator(self):
        fig, ax = plt.subplots()
        loc = mticker.MultipleLocator(0.5)
        ax.xaxis.set_major_locator(loc)
        # Should not error

    def test_set_major_formatter(self):
        fig, ax = plt.subplots()
        fmt = mticker.FormatStrFormatter('%.2f')
        ax.xaxis.set_major_formatter(fmt)
        # Should not error

    def test_tick_params(self):
        fig, ax = plt.subplots()
        ax.tick_params(axis='x', labelsize=10)
        ax.tick_params(axis='y', labelsize=12)
        ax.tick_params(axis='both', length=5)


# ------------------------------------------------------------------
# Axes properties
# ------------------------------------------------------------------

class TestAxesProperties:
    def test_facecolor(self):
        fig, ax = plt.subplots()
        ax.set_facecolor('yellow')
        fc = ax.get_facecolor()
        assert fc is not None

    def test_aspect_auto(self):
        fig, ax = plt.subplots()
        ax.set_aspect('auto')
        assert ax.get_aspect() == 'auto'

    def test_aspect_equal(self):
        fig, ax = plt.subplots()
        ax.set_aspect('equal')
        assert ax.get_aspect() == 'equal'

    def test_aspect_numeric(self):
        fig, ax = plt.subplots()
        ax.set_aspect(1.5)
        assert close(ax.get_aspect(), 1.5)

    def test_get_position(self):
        fig, ax = plt.subplots()
        pos = ax.get_position()
        assert pos is not None

    def test_navigate(self):
        fig, ax = plt.subplots()
        assert ax.get_navigate()
        ax.set_navigate(False)
        assert not ax.get_navigate()

    def test_frame_on(self):
        fig, ax = plt.subplots()
        assert ax.get_frame_on()
        ax.set_frame_on(False)
        assert not ax.get_frame_on()

    def test_axisbelow(self):
        fig, ax = plt.subplots()
        ax.set_axisbelow(True)
        assert ax.get_axisbelow()
        ax.set_axisbelow(False)
        assert not ax.get_axisbelow()

    def test_autoscale_on(self):
        fig, ax = plt.subplots()
        ax.set_autoscale_on(False)
        assert not ax.get_autoscale_on()
        ax.set_autoscale_on(True)
        assert ax.get_autoscale_on()

    def test_autoscalex_on(self):
        fig, ax = plt.subplots()
        ax.set_autoscalex_on(False)
        assert not ax.get_autoscalex_on()

    def test_autoscaley_on(self):
        fig, ax = plt.subplots()
        ax.set_autoscaley_on(False)
        assert not ax.get_autoscaley_on()

    def test_set_method(self):
        fig, ax = plt.subplots()
        ax.set(xlabel='X', ylabel='Y', title='T')
        assert ax.get_xlabel() == 'X'
        assert ax.get_ylabel() == 'Y'
        assert ax.get_title() == 'T'

    def test_cla(self):
        fig, ax = plt.subplots()
        ax.plot([1, 2], [3, 4])
        ax.cla()
        assert len(ax.lines) == 0

    def test_clear(self):
        fig, ax = plt.subplots()
        ax.plot([1, 2], [3, 4])
        ax.clear()
        assert len(ax.lines) == 0


# ------------------------------------------------------------------
# Subplot / sharex / sharey tests
# ------------------------------------------------------------------

class TestSubplots:
    def test_subplots_1x1(self):
        fig, ax = plt.subplots()
        assert ax is not None

    def test_subplots_1x2(self):
        fig, axes = plt.subplots(1, 2)
        assert len(axes) == 2

    def test_subplots_2x1(self):
        fig, axes = plt.subplots(2, 1)
        assert len(axes) == 2

    def test_subplots_2x2(self):
        fig, axes = plt.subplots(2, 2)
        assert len(axes) == 2
        assert len(axes[0]) == 2

    def test_sharex(self):
        fig, axes = plt.subplots(2, 1, sharex=True)
        axes[0].set_xlim(0, 10)
        xlim = axes[1].get_xlim()
        assert close(xlim[0], 0)
        assert close(xlim[1], 10)

    def test_sharey(self):
        fig, axes = plt.subplots(1, 2, sharey=True)
        axes[0].set_ylim(0, 20)
        ylim = axes[1].get_ylim()
        assert close(ylim[0], 0)
        assert close(ylim[1], 20)

    def test_add_subplot_index(self):
        fig = Figure()
        ax = fig.add_subplot(2, 2, 1)
        assert ax is not None

    def test_add_subplot_211(self):
        fig = Figure()
        ax = fig.add_subplot(211)
        assert ax is not None


# ------------------------------------------------------------------
# pyplot interface tests
# ------------------------------------------------------------------

class TestPyplot:
    def test_figure(self):
        fig = plt.figure()
        assert fig is not None
        plt.close('all')

    def test_subplots_convenience(self):
        fig, ax = plt.subplots()
        assert fig is not None
        assert ax is not None
        plt.close('all')

    def test_gcf(self):
        fig = plt.figure()
        gcf = plt.gcf()
        assert gcf is fig
        plt.close('all')

    def test_gca(self):
        fig, ax = plt.subplots()
        gca = plt.gca()
        assert gca is ax
        plt.close('all')

    def test_close_all(self):
        plt.figure()
        plt.figure()
        plt.close('all')

    def test_plot_function(self):
        plt.plot([0, 1], [0, 1])
        plt.close('all')

    def test_scatter_function(self):
        plt.scatter([1, 2, 3], [4, 5, 6])
        plt.close('all')

    def test_xlabel_ylabel(self):
        fig, ax = plt.subplots()
        plt.xlabel('X')
        plt.ylabel('Y')
        plt.close('all')

    def test_title(self):
        fig, ax = plt.subplots()
        plt.title('Test')
        plt.close('all')

    def test_xlim_ylim(self):
        fig, ax = plt.subplots()
        plt.xlim(0, 10)
        plt.ylim(-5, 5)
        plt.close('all')

    def test_legend(self):
        fig, ax = plt.subplots()
        plt.plot([0, 1], [0, 1], label='line')
        plt.legend()
        plt.close('all')

    def test_axhline(self):
        fig, ax = plt.subplots()
        plt.axhline(y=0)
        plt.close('all')

    def test_axvline(self):
        fig, ax = plt.subplots()
        plt.axvline(x=0)
        plt.close('all')

    def test_grid(self):
        fig, ax = plt.subplots()
        plt.grid(True)
        plt.close('all')


# ------------------------------------------------------------------
# Collections tests
# ------------------------------------------------------------------

class TestCollections:
    def test_line_collection_creation(self):
        segs = [[[0, 0], [1, 1]], [[1, 0], [0, 1]]]
        lc = LineCollection(segs)
        assert lc is not None

    def test_line_collection_get_segments(self):
        segs = [[[0, 0], [1, 1]], [[2, 0], [3, 1]]]
        lc = LineCollection(segs)
        got = lc.get_segments()
        assert len(got) == 2

    def test_line_collection_color(self):
        segs = [[[0, 0], [1, 1]]]
        lc = LineCollection(segs, color='red')
        assert lc is not None

    def test_line_collection_linewidth(self):
        segs = [[[0, 0], [1, 1]]]
        lc = LineCollection(segs, linewidth=2)
        assert lc is not None

    def test_path_collection_creation(self):
        import numpy as np
        offsets = np.array([[1, 2], [3, 4]])
        pc = PathCollection(offsets=offsets)
        assert pc is not None

    def test_add_line_collection_to_axes(self):
        fig, ax = plt.subplots()
        segs = [[[0, 0], [1, 1]], [[1, 0], [0, 1]]]
        lc = LineCollection(segs)
        ax.add_collection(lc)
        assert len(ax.collections) >= 1


# ------------------------------------------------------------------
# Text tests
# ------------------------------------------------------------------

class TestText:
    def test_creation(self):
        t = Text(0, 0, 'Hello')
        assert t is not None

    def test_get_text(self):
        t = Text(1, 2, 'World')
        assert t.get_text() == 'World'

    def test_set_text(self):
        t = Text(0, 0, 'Hello')
        t.set_text('Goodbye')
        assert t.get_text() == 'Goodbye'

    def test_position(self):
        t = Text(3, 4, 'test')
        pos = t.get_position()
        assert close(pos[0], 3)
        assert close(pos[1], 4)

    def test_set_position(self):
        t = Text(0, 0, 'test')
        t.set_position((5, 6))
        pos = t.get_position()
        assert close(pos[0], 5)
        assert close(pos[1], 6)

    def test_fontsize(self):
        t = Text(0, 0, 'test', fontsize=14)
        assert close(t.get_fontsize(), 14)

    def test_color(self):
        t = Text(0, 0, 'test', color='red')
        c = t.get_color()
        assert c is not None

    def test_visible(self):
        t = Text(0, 0, 'test')
        assert t.get_visible()
        t.set_visible(False)
        assert not t.get_visible()

    def test_alpha(self):
        t = Text(0, 0, 'test')
        t.set_alpha(0.7)
        assert close(t.get_alpha(), 0.7)

    def test_axes_text(self):
        fig, ax = plt.subplots()
        t = ax.text(0.5, 0.5, 'Center')
        assert t is not None
        assert t.get_text() == 'Center'
