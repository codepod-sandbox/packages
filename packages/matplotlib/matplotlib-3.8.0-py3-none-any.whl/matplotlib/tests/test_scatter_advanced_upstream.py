"""Tests for advanced scatter plot features."""

import pytest
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors


class TestScatterBasic:
    def test_scatter_basic(self):
        """ax.scatter() does not raise."""
        fig, ax = plt.subplots()
        ax.scatter([1, 2, 3], [1, 4, 2])
        plt.close('all')

    def test_scatter_with_c(self):
        """ax.scatter() with c parameter does not raise."""
        fig, ax = plt.subplots()
        ax.scatter([1, 2, 3], [1, 4, 2], c=[1.0, 2.0, 3.0], cmap='viridis')
        plt.close('all')

    def test_scatter_with_s(self):
        """ax.scatter() with s parameter does not raise."""
        fig, ax = plt.subplots()
        ax.scatter([1, 2, 3], [1, 4, 2], s=[10, 100, 500])
        plt.close('all')

    def test_scatter_with_alpha(self):
        """ax.scatter() with alpha does not raise."""
        fig, ax = plt.subplots()
        ax.scatter([1, 2, 3], [1, 4, 2], alpha=0.5)
        plt.close('all')

    def test_scatter_with_marker(self):
        """ax.scatter() with marker does not raise."""
        for marker in ['o', 's', '^', 'D', '*', '+', 'x']:
            fig, ax = plt.subplots()
            ax.scatter([1, 2, 3], [1, 4, 2], marker=marker)
            plt.close('all')

    def test_scatter_with_edgecolors(self):
        """ax.scatter() with edgecolors does not raise."""
        fig, ax = plt.subplots()
        ax.scatter([1, 2, 3], [1, 4, 2], edgecolors='black', linewidths=1)
        plt.close('all')

    def test_scatter_returns_pathcollection(self):
        """ax.scatter() returns a PathCollection."""
        from matplotlib.collections import PathCollection
        fig, ax = plt.subplots()
        sc = ax.scatter([1, 2, 3], [1, 4, 2])
        assert isinstance(sc, PathCollection)
        plt.close('all')

    def test_scatter_cmap_norm(self):
        """ax.scatter() with norm does not raise."""
        from matplotlib.colors import Normalize
        fig, ax = plt.subplots()
        norm = Normalize(vmin=0, vmax=10)
        ax.scatter([1, 2, 3], [1, 4, 2], c=[2.0, 5.0, 8.0],
                   cmap='plasma', norm=norm)
        plt.close('all')

    def test_scatter_zorder(self):
        """ax.scatter() with zorder does not raise."""
        fig, ax = plt.subplots()
        ax.scatter([1, 2], [1, 2], zorder=5)
        plt.close('all')

    def test_scatter_label(self):
        """ax.scatter() with label for legend does not raise."""
        fig, ax = plt.subplots()
        ax.scatter([1, 2, 3], [1, 4, 2], label='data')
        ax.legend()
        plt.close('all')

    def test_scatter_svg(self):
        """Scatter plot renders to SVG."""
        fig, ax = plt.subplots()
        ax.scatter(np.random.rand(20), np.random.rand(20))
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_plt_scatter(self):
        """plt.scatter() wrapper does not raise."""
        plt.figure()
        plt.scatter([1, 2, 3], [1, 2, 3])
        plt.close('all')


class TestScatterColormap:
    def test_scatter_viridis_cmap(self):
        """Scatter with viridis colormap does not raise."""
        fig, ax = plt.subplots()
        x = np.random.rand(50)
        y = np.random.rand(50)
        c = np.random.rand(50)
        sc = ax.scatter(x, y, c=c, cmap='viridis')
        assert sc is not None
        plt.close('all')

    def test_scatter_discrete_colors(self):
        """Scatter with discrete color list does not raise."""
        fig, ax = plt.subplots()
        colors = ['red', 'blue', 'green', 'orange']
        for i, color in enumerate(colors):
            ax.scatter([i], [i], color=color, s=100)
        plt.close('all')

    def test_scatter_get_offsets(self):
        """PathCollection.get_offsets() returns data points."""
        fig, ax = plt.subplots()
        sc = ax.scatter([1, 2, 3], [4, 5, 6])
        offsets = sc.get_offsets()
        assert offsets is not None
        plt.close('all')

    def test_scatter_set_sizes(self):
        """PathCollection.set_sizes() does not raise."""
        fig, ax = plt.subplots()
        sc = ax.scatter([1, 2, 3], [4, 5, 6])
        sc.set_sizes([100, 200, 300])
        plt.close('all')

    def test_scatter_with_colorbar(self):
        """Scatter with colorbar does not raise."""
        fig, ax = plt.subplots()
        c = np.array([1.0, 2.0, 3.0, 4.0, 5.0])
        sc = ax.scatter(range(5), range(5), c=c, cmap='coolwarm')
        fig.colorbar(sc, ax=ax)
        plt.close('all')
