"""
Upstream tests for advanced numpy + matplotlib integration patterns.
"""

import pytest
import numpy as np
import matplotlib.pyplot as plt


class TestMeshgridPlotting:
    """Tests for meshgrid/contour plotting patterns."""

    def teardown_method(self):
        plt.close('all')

    def test_contour_basic(self):
        x = np.linspace(-3, 3, 30)
        y = np.linspace(-3, 3, 30)
        X, Y = np.meshgrid(x, y)
        Z = np.exp(-(X**2 + Y**2))
        fig, ax = plt.subplots()
        cs = ax.contour(X, Y, Z)
        assert cs is not None

    def test_contourf_basic(self):
        x = np.linspace(-2, 2, 25)
        y = np.linspace(-2, 2, 25)
        X, Y = np.meshgrid(x, y)
        Z = X**2 + Y**2
        fig, ax = plt.subplots()
        cs = ax.contourf(X, Y, Z, levels=10)
        assert cs is not None

    def test_contour_levels(self):
        x = np.linspace(0, 5, 30)
        y = np.linspace(0, 5, 30)
        X, Y = np.meshgrid(x, y)
        Z = np.sin(X) * np.cos(Y)
        fig, ax = plt.subplots()
        levels = np.linspace(-1, 1, 11)
        cs = ax.contourf(X, Y, Z, levels=levels, cmap='RdBu')
        fig.colorbar(cs, ax=ax)

    def test_contour_with_labels(self):
        x = np.linspace(-3, 3, 20)
        y = np.linspace(-3, 3, 20)
        X, Y = np.meshgrid(x, y)
        Z = X**2 - Y**2
        fig, ax = plt.subplots()
        cs = ax.contour(X, Y, Z, levels=6)
        ax.clabel(cs, inline=True, fontsize=8)

    def test_contourf_over_contour(self):
        """Filled contour with contour lines overlay."""
        x = np.linspace(-2, 2, 20)
        y = np.linspace(-2, 2, 20)
        X, Y = np.meshgrid(x, y)
        Z = np.sqrt(X**2 + Y**2)
        fig, ax = plt.subplots()
        ax.contourf(X, Y, Z, cmap='viridis')
        ax.contour(X, Y, Z, colors='white', alpha=0.5)

    def test_meshgrid_quiver(self):
        x = np.linspace(-2, 2, 8)
        y = np.linspace(-2, 2, 8)
        X, Y = np.meshgrid(x, y)
        U = -Y
        V = X
        fig, ax = plt.subplots()
        ax.quiver(X, Y, U, V)

    def test_streamplot(self):
        x = np.linspace(-2, 2, 15)
        y = np.linspace(-2, 2, 15)
        X, Y = np.meshgrid(x, y)
        U = -Y
        V = X
        fig, ax = plt.subplots()
        ax.streamplot(x, y, U, V, density=1, linewidth=1)

    def test_surface_via_pcolormesh(self):
        x = np.linspace(0, 4, 20)
        y = np.linspace(0, 4, 20)
        X, Y = np.meshgrid(x, y)
        Z = np.sin(X) * np.cos(Y)
        fig, ax = plt.subplots()
        pc = ax.pcolormesh(X, Y, Z, cmap='RdYlBu', shading='auto')
        fig.colorbar(pc)


class TestNumpyStatisticalPlots:
    """Tests for statistical plots using numpy arrays."""

    def teardown_method(self):
        plt.close('all')

    def test_rolling_mean_plot(self):
        """Plot time series with rolling mean."""
        rng = np.random.default_rng(42)
        t = np.arange(100)
        signal = np.sin(t * 0.2) + rng.normal(0, 0.3, 100)
        window = 5
        rolling = np.convolve(signal, np.ones(window)/window, mode='valid')
        t_valid = t[window-1:]
        fig, ax = plt.subplots()
        ax.plot(t, signal, alpha=0.4, label='Raw')
        ax.plot(t_valid, rolling, lw=2, label='Rolling Mean')
        ax.legend()

    def test_confidence_interval_plot(self):
        """Fill between for confidence interval."""
        x = np.linspace(0, 10, 50)
        mean = np.sin(x)
        std = 0.2 + 0.1 * np.abs(np.sin(x))
        fig, ax = plt.subplots()
        ax.plot(x, mean, 'b-', lw=2)
        ax.fill_between(x, mean - std, mean + std, alpha=0.3, color='blue')
        ax.set_title('Confidence Interval')

    def test_2d_histogram(self):
        rng = np.random.default_rng(42)
        x = rng.normal(0, 1, 500)
        y = rng.normal(0, 1, 500)
        fig, ax = plt.subplots()
        h = ax.hist2d(x, y, bins=20)
        fig.colorbar(h[3], ax=ax)

    def test_hexbin_plot(self):
        rng = np.random.default_rng(42)
        x = rng.normal(0, 1, 300)
        y = rng.normal(0, 1, 300)
        fig, ax = plt.subplots()
        hb = ax.hexbin(x, y, gridsize=15, cmap='Reds')
        fig.colorbar(hb, ax=ax)

    def test_scatter_colormap_continuous(self):
        """Scatter colored by continuous variable."""
        rng = np.random.default_rng(42)
        x = rng.uniform(0, 10, 100)
        y = rng.uniform(0, 10, 100)
        colors = np.sqrt(x**2 + y**2)
        fig, ax = plt.subplots()
        sc = ax.scatter(x, y, c=colors, cmap='plasma', s=30)
        fig.colorbar(sc, ax=ax)

    def test_polar_plot(self):
        """Polar plot with numpy data."""
        theta = np.linspace(0, 2 * np.pi, 100)
        r = 1 + 0.5 * np.cos(3 * theta)
        fig, ax = plt.subplots(subplot_kw={'projection': 'polar'})
        ax.plot(theta, r)

    def test_radar_chart(self):
        """Radar chart (polar bar)."""
        categories = ['A', 'B', 'C', 'D', 'E']
        values = np.array([4, 3, 5, 2, 4])
        angles = np.linspace(0, 2 * np.pi, len(categories), endpoint=False)
        fig, ax = plt.subplots(subplot_kw={'projection': 'polar'})
        ax.plot(angles, values)
        ax.fill(angles, values, alpha=0.2)

    def test_pcolor_gradient(self):
        """pcolor with gradient pattern."""
        x = np.arange(0, 10)
        y = np.arange(0, 10)
        X, Y = np.meshgrid(x, y)
        Z = X + Y
        fig, ax = plt.subplots()
        ax.pcolor(X, Y, Z, cmap='cool')


class TestNumpyLineArtistry:
    """Tests for line art using numpy arrays."""

    def teardown_method(self):
        plt.close('all')

    def test_lissajous_curve(self):
        t = np.linspace(0, 2 * np.pi, 500)
        x = np.sin(3 * t)
        y = np.sin(2 * t + np.pi / 4)
        fig, ax = plt.subplots()
        ax.plot(x, y, lw=1.5)
        ax.set_aspect('equal')

    def test_spiral_plot(self):
        t = np.linspace(0, 4 * np.pi, 500)
        r = t / (4 * np.pi)
        x = r * np.cos(t)
        y = r * np.sin(t)
        fig, ax = plt.subplots()
        ax.plot(x, y)
        ax.set_aspect('equal')

    def test_parametric_curve(self):
        t = np.linspace(0, 2 * np.pi, 100)
        x = (1 + 0.5 * np.cos(t)) * np.cos(t)
        y = (1 + 0.5 * np.cos(t)) * np.sin(t)
        fig, ax = plt.subplots()
        ax.plot(x, y)

    def test_colorline_plot(self):
        """Plot line with color varying along it."""
        t = np.linspace(0, 2 * np.pi, 100)
        x = np.cos(t)
        y = np.sin(t)
        # Color by t using scatter with continuous c
        fig, ax = plt.subplots()
        sc = ax.scatter(x, y, c=t, cmap='hsv', s=20)
        fig.colorbar(sc)

    def test_multiple_sinusoids(self):
        """Multiple sinusoidal signals with numpy."""
        x = np.linspace(0, 4 * np.pi, 200)
        freqs = [1, 2, 3, 4]
        fig, ax = plt.subplots()
        for f in freqs:
            ax.plot(x, np.sin(f * x) / f, label=f'f={f}')
        ax.legend(loc='upper right')
        ax.grid(True, alpha=0.3)
