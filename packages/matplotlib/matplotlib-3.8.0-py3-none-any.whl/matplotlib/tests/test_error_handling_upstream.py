"""Tests for error handling and edge cases used by LLMs."""

import pytest
import numpy as np
import matplotlib.pyplot as plt


class TestEdgeCases:
    def test_plot_empty_list(self):
        """plot([]) doesn't crash."""
        fig, ax = plt.subplots()
        ax.plot([], [])
        plt.close('all')

    def test_plot_single_point(self):
        """plot with single data point."""
        fig, ax = plt.subplots()
        ax.plot([1.0], [2.0])
        plt.close('all')

    def test_plot_large_data(self):
        """plot with 1000 points doesn't crash."""
        fig, ax = plt.subplots()
        x = [float(i) for i in range(1000)]
        y = [float(i * i) for i in range(1000)]
        ax.plot(x, y)
        plt.close('all')

    def test_scatter_empty(self):
        """scatter([]) doesn't crash."""
        fig, ax = plt.subplots()
        ax.scatter([], [])
        plt.close('all')

    def test_bar_single(self):
        """bar with single bar."""
        fig, ax = plt.subplots()
        ax.bar([0.0], [1.0])
        plt.close('all')

    def test_xlim_reversed(self):
        """set_xlim with reversed range."""
        fig, ax = plt.subplots()
        ax.set_xlim(10, 0)
        xmin, xmax = ax.get_xlim()
        assert xmin == 10
        assert xmax == 0
        plt.close('all')

    def test_ylim_reversed(self):
        """set_ylim with reversed range."""
        fig, ax = plt.subplots()
        ax.set_ylim(1, -1)
        plt.close('all')

    def test_set_xlim_float(self):
        """set_xlim with float args."""
        fig, ax = plt.subplots()
        ax.set_xlim(-1.5, 3.7)
        xmin, xmax = ax.get_xlim()
        assert abs(xmin - (-1.5)) < 1e-9
        assert abs(xmax - 3.7) < 1e-9
        plt.close('all')

    def test_plot_numpy_array(self):
        """plot with numpy array."""
        fig, ax = plt.subplots()
        x = np.array([1.0, 2.0, 3.0])
        y = np.array([4.0, 5.0, 6.0])
        ax.plot(x, y)
        plt.close('all')

    def test_scatter_numpy(self):
        """scatter with numpy arrays."""
        fig, ax = plt.subplots()
        x = np.array([1.0, 2.0, 3.0])
        y = np.array([4.0, 5.0, 6.0])
        ax.scatter(x, y)
        plt.close('all')

    def test_hist_numpy(self):
        """hist with numpy array."""
        fig, ax = plt.subplots()
        data = np.array([1.0, 2.0, 2.5, 3.0, 3.5])
        ax.hist(data, bins=3)
        plt.close('all')

    def test_title_empty_string(self):
        """set_title with empty string."""
        fig, ax = plt.subplots()
        ax.set_title('')
        plt.close('all')

    def test_label_none(self):
        """plot with no label still works."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3])
        ax.legend()  # Should not crash even with unlabeled lines
        plt.close('all')


class TestMultipleCallsPattern:
    def test_multiple_plots_same_axes(self):
        """Multiple plots on same axes."""
        fig, ax = plt.subplots()
        for i in range(5):
            ax.plot([1.0, 2.0, 3.0], [float(i), float(i+1), float(i+2)])
        assert len(ax.lines) == 5
        plt.close('all')

    def test_clear_and_replot(self):
        """cla() then replot."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3])
        ax.cla()
        ax.plot([4, 5, 6])
        assert len(ax.lines) == 1
        plt.close('all')

    def test_close_and_recreate(self):
        """close('all') and recreate."""
        for _ in range(3):
            fig, ax = plt.subplots()
            ax.plot([1, 2])
            plt.close('all')

    def test_subplots_iteration(self):
        """Iterate over subplots."""
        fig, axes = plt.subplots(2, 3)
        count = 0
        for row in axes:
            for ax in row:
                ax.plot([1.0, 2.0])
                count += 1
        assert count == 6
        plt.close('all')


class TestColorsAndStyles:
    def test_color_hex(self):
        """plot with hex color."""
        fig, ax = plt.subplots()
        ax.plot([1, 2], color='#ff0000')
        plt.close('all')

    def test_color_rgb_tuple(self):
        """plot with RGB tuple."""
        fig, ax = plt.subplots()
        ax.plot([1, 2], color=(1.0, 0.0, 0.0))
        plt.close('all')

    def test_color_rgba_tuple(self):
        """plot with RGBA tuple."""
        fig, ax = plt.subplots()
        ax.plot([1, 2], color=(1.0, 0.0, 0.0, 0.5))
        plt.close('all')

    def test_color_c_shorthand(self):
        """c= shorthand for color."""
        fig, ax = plt.subplots()
        ax.plot([1, 2], c='blue')
        plt.close('all')

    def test_fmt_no_line(self):
        """plot with 'o' (dots only, no line)."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [4, 5, 6], 'o')
        plt.close('all')

    def test_fmt_dash_dot(self):
        """plot with '-.' format string."""
        fig, ax = plt.subplots()
        ax.plot([1, 2], '-.r')
        plt.close('all')

    def test_zorder_layering(self):
        """Multiple artists with different zorders."""
        fig, ax = plt.subplots()
        ax.plot([1, 2], zorder=1)
        ax.plot([3, 4], zorder=10)
        plt.close('all')


class TestOutputFormats:
    def test_savefig_svg_string(self):
        """savefig to SVG string returns content."""
        import io
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3])
        buf = io.StringIO()
        fig.savefig(buf, format='svg')
        content = buf.getvalue()
        assert len(content) > 0
        plt.close('all')

    def test_savefig_png_bytes(self):
        """savefig to PNG bytes returns content."""
        import io
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3])
        buf = io.BytesIO()
        fig.savefig(buf, format='png')
        content = buf.getvalue()
        assert len(content) > 0
        plt.close('all')

    def test_to_svg(self):
        """fig.to_svg() returns SVG string."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3])
        svg = fig.to_svg()
        assert isinstance(svg, str)
        assert len(svg) > 0
        plt.close('all')
