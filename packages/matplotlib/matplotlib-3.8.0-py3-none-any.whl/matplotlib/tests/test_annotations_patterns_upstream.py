"""
Upstream tests for annotation patterns commonly used by LLMs.
Covers text, annotate, and arrow placement.
"""

import numpy as np
import pytest
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches


class TestAnnotateBasic:
    """Basic annotation patterns."""

    def teardown_method(self):
        plt.close('all')

    def test_annotate_simple(self):
        fig, ax = plt.subplots()
        ax.annotate('label', xy=(1, 1))

    def test_annotate_with_xytext(self):
        fig, ax = plt.subplots()
        ax.annotate('Peak', xy=(2, 5), xytext=(3, 5.5))

    def test_annotate_with_arrow(self):
        fig, ax = plt.subplots()
        ax.annotate(
            'Max',
            xy=(2, 4),
            xytext=(3, 4.5),
            arrowprops={'arrowstyle': '->'}
        )

    def test_annotate_arrowstyle_fancy(self):
        fig, ax = plt.subplots()
        ax.annotate(
            'Point',
            xy=(1, 1),
            xytext=(2, 2),
            arrowprops={'arrowstyle': '-|>'}
        )

    def test_annotate_ha_va(self):
        fig, ax = plt.subplots()
        ax.annotate('center', xy=(1, 1), ha='center', va='bottom')

    def test_annotate_fontsize(self):
        fig, ax = plt.subplots()
        ax.annotate('big text', xy=(1, 1), fontsize=14)

    def test_annotate_color(self):
        fig, ax = plt.subplots()
        ax.annotate('colored', xy=(1, 1), color='red')

    def test_annotate_fontweight(self):
        fig, ax = plt.subplots()
        ax.annotate('bold', xy=(1, 1), fontweight='bold')

    def test_annotate_returns_annotation(self):
        fig, ax = plt.subplots()
        ann = ax.annotate('text', xy=(0, 0))
        assert ann is not None

    def test_annotate_xy_coords_data(self):
        fig, ax = plt.subplots()
        ax.annotate('data coords', xy=(1, 1), xycoords='data')

    def test_annotate_xy_coords_axes_fraction(self):
        fig, ax = plt.subplots()
        ax.annotate('upper left', xy=(0.05, 0.95), xycoords='axes fraction')

    def test_annotate_bbox(self):
        fig, ax = plt.subplots()
        ax.annotate(
            'boxed',
            xy=(1, 1),
            bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5)
        )

    def test_annotate_multiple(self):
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 4, 9])
        points = [(1, 1), (2, 4), (3, 9)]
        labels = ['A', 'B', 'C']
        for (x, y), label in zip(points, labels):
            ax.annotate(label, xy=(x, y), xytext=(x + 0.1, y + 0.5),
                       arrowprops={'arrowstyle': '->'})


class TestTextAnnotations:
    """Tests for ax.text() method."""

    def teardown_method(self):
        plt.close('all')

    def test_text_basic(self):
        fig, ax = plt.subplots()
        t = ax.text(0.5, 0.5, 'Hello')
        assert t is not None

    def test_text_transform_axes(self):
        fig, ax = plt.subplots()
        ax.text(0.5, 0.5, 'Center', transform=ax.transAxes,
                ha='center', va='center')

    def test_text_transform_data(self):
        fig, ax = plt.subplots()
        ax.set_xlim(0, 10)
        ax.set_ylim(0, 10)
        ax.text(5, 5, 'Middle', transform=ax.transData)

    def test_text_fontsize(self):
        fig, ax = plt.subplots()
        t = ax.text(0.5, 0.5, 'text', fontsize=16)
        assert t.get_fontsize() == 16

    def test_text_color(self):
        fig, ax = plt.subplots()
        t = ax.text(0.5, 0.5, 'text', color='red')
        assert t.get_color() == 'red'

    def test_text_ha_va(self):
        fig, ax = plt.subplots()
        t = ax.text(0.5, 0.5, 'text', ha='center', va='center')
        assert t.get_ha() == 'center'
        assert t.get_va() == 'center'

    def test_text_rotation(self):
        fig, ax = plt.subplots()
        t = ax.text(0.5, 0.5, 'rotated', rotation=45)
        assert t.get_rotation() == 45.0

    def test_text_vertical(self):
        fig, ax = plt.subplots()
        t = ax.text(0.5, 0.5, 'vertical', rotation='vertical')
        assert t.get_rotation() == 90.0

    def test_text_alpha(self):
        fig, ax = plt.subplots()
        t = ax.text(0.5, 0.5, 'text', alpha=0.5)
        assert t.get_alpha() == 0.5

    def test_text_fontfamily(self):
        fig, ax = plt.subplots()
        t = ax.text(0.5, 0.5, 'text', fontfamily='monospace')

    def test_text_fontweight(self):
        fig, ax = plt.subplots()
        t = ax.text(0.5, 0.5, 'text', fontweight='bold')
        assert t.get_fontweight() == 'bold'

    def test_text_bbox_style(self):
        fig, ax = plt.subplots()
        ax.text(0.5, 0.5, 'boxed', bbox=dict(boxstyle='round', facecolor='lightblue'))

    def test_text_multiline(self):
        fig, ax = plt.subplots()
        ax.text(0.5, 0.5, 'Line 1\nLine 2\nLine 3', ha='center')

    def test_fig_text(self):
        fig = plt.figure()
        t = fig.text(0.5, 0.5, 'Figure Text', ha='center', fontsize=12)
        assert t is not None


class TestAnnotateGetSet:
    """Tests for annotation get/set methods."""

    def teardown_method(self):
        plt.close('all')

    def test_annotation_get_text(self):
        fig, ax = plt.subplots()
        ann = ax.annotate('hello', xy=(0, 0))
        assert ann.get_text() == 'hello'

    def test_annotation_set_text(self):
        fig, ax = plt.subplots()
        ann = ax.annotate('hello', xy=(0, 0))
        ann.set_text('world')
        assert ann.get_text() == 'world'

    def test_annotation_get_position(self):
        fig, ax = plt.subplots()
        ann = ax.annotate('text', xy=(0, 0), xytext=(1, 1))
        pos = ann.get_position()
        assert pos[0] == 1
        assert pos[1] == 1

    def test_annotation_xy(self):
        fig, ax = plt.subplots()
        ann = ax.annotate('text', xy=(2, 3))
        assert ann.xy == (2, 3)

    def test_annotation_xytext(self):
        fig, ax = plt.subplots()
        ann = ax.annotate('text', xy=(1, 1), xytext=(2, 2))
        assert ann.xytext == (2, 2)

    def test_annotation_xyann(self):
        fig, ax = plt.subplots()
        ann = ax.annotate('text', xy=(1, 1), xytext=(2, 2))
        # xyann is alias for xytext
        assert ann.xyann == (2, 2)

    def test_annotation_set_visible(self):
        fig, ax = plt.subplots()
        ann = ax.annotate('text', xy=(0, 0))
        ann.set_visible(False)
        assert ann.get_visible() is False

    def test_annotation_set_fontsize(self):
        fig, ax = plt.subplots()
        ann = ax.annotate('text', xy=(0, 0))
        ann.set_fontsize(14)
        assert ann.get_fontsize() == 14

    def test_annotation_zorder(self):
        fig, ax = plt.subplots()
        ann = ax.annotate('text', xy=(0, 0))
        ann.set_zorder(5)
        assert ann.get_zorder() == 5
