"""Tests for hist2d, hexbin, savefig BytesIO, and related density plot features."""

import io
import pytest
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.image import AxesImage
from matplotlib.collections import PolyCollection


# ---------------------------------------------------------------------------
# ax.hist2d()
# ---------------------------------------------------------------------------

class TestHist2d:
    def test_hist2d_basic(self):
        """hist2d returns (h, xedges, yedges, image)."""
        fig, ax = plt.subplots()
        x = [1, 2, 3, 4, 5, 3, 2, 1]
        y = [1, 2, 3, 4, 5, 2, 3, 4]
        result = ax.hist2d(x, y, bins=4)
        assert len(result) == 4
        plt.close('all')

    def test_hist2d_returns_axesimage(self):
        """hist2d image is an AxesImage."""
        fig, ax = plt.subplots()
        h, xe, ye, im = ax.hist2d([1, 2, 3], [1, 2, 3], bins=3)
        assert isinstance(im, AxesImage)
        plt.close('all')

    def test_hist2d_bin_edges_count(self):
        """hist2d returns correct number of bin edges."""
        fig, ax = plt.subplots()
        h, xe, ye, im = ax.hist2d([1, 2, 3, 4], [1, 2, 3, 4], bins=4)
        assert len(xe) == 5  # n+1 edges
        assert len(ye) == 5
        plt.close('all')

    def test_hist2d_h_shape(self):
        """hist2d h array has correct shape."""
        fig, ax = plt.subplots()
        h, xe, ye, im = ax.hist2d([1, 2, 3], [1, 2, 3], bins=3)
        assert len(h) == 3  # ny rows
        assert len(h[0]) == 3  # nx cols
        plt.close('all')

    def test_hist2d_updates_limits(self):
        """hist2d updates axis limits."""
        fig, ax = plt.subplots()
        ax.hist2d([0, 10], [0, 10], bins=2)
        xmin, xmax = ax.get_xlim()
        assert xmin <= 0 and xmax >= 10
        plt.close('all')

    def test_hist2d_adds_to_images(self):
        """hist2d image is added to ax.images."""
        fig, ax = plt.subplots()
        ax.hist2d([1, 2, 3], [1, 2, 3], bins=3)
        assert len(ax.images) == 1
        plt.close('all')

    def test_hist2d_cmap_kwarg(self):
        """hist2d with cmap kwarg does not raise."""
        fig, ax = plt.subplots()
        ax.hist2d([1, 2, 3], [1, 2, 3], bins=3, cmap='hot')
        plt.close('all')

    def test_hist2d_svg_renders(self):
        """hist2d renders to SVG."""
        fig, ax = plt.subplots()
        ax.hist2d([1, 2, 3, 2, 1], [1, 2, 3, 1, 2], bins=3)
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_hist2d_numpy_arrays(self):
        """hist2d with numpy arrays."""
        fig, ax = plt.subplots()
        rng = np.random.default_rng(42)
        x = rng.normal(0, 1, 50).tolist()
        y = rng.normal(0, 1, 50).tolist()
        h, xe, ye, im = ax.hist2d(x, y, bins=10)
        assert im is not None
        plt.close('all')

    def test_plt_hist2d(self):
        """plt.hist2d() wrapper works."""
        plt.figure()
        result = plt.hist2d([1, 2, 3], [1, 2, 3], bins=3)
        assert len(result) == 4
        plt.close('all')


# ---------------------------------------------------------------------------
# ax.hexbin()
# ---------------------------------------------------------------------------

class TestHexbin:
    def test_hexbin_basic(self):
        """hexbin(x, y) does not raise."""
        fig, ax = plt.subplots()
        x = [1, 2, 3, 4, 5]
        y = [1, 2, 3, 4, 5]
        result = ax.hexbin(x, y)
        assert result is not None
        plt.close('all')

    def test_hexbin_returns_polycollection(self):
        """hexbin returns a PolyCollection."""
        fig, ax = plt.subplots()
        hb = ax.hexbin([1, 2, 3], [1, 2, 3])
        assert isinstance(hb, PolyCollection)
        plt.close('all')

    def test_hexbin_in_collections(self):
        """hexbin result is in ax.collections."""
        fig, ax = plt.subplots()
        ax.hexbin([1, 2, 3], [1, 2, 3])
        assert len(ax.collections) == 1
        plt.close('all')

    def test_hexbin_updates_limits(self):
        """hexbin updates axis limits."""
        fig, ax = plt.subplots()
        ax.hexbin([0, 10], [0, 10])
        xmin, xmax = ax.get_xlim()
        assert xmin <= 0 and xmax >= 10
        plt.close('all')

    def test_hexbin_gridsize(self):
        """hexbin with gridsize does not raise."""
        fig, ax = plt.subplots()
        ax.hexbin([1, 2, 3], [1, 2, 3], gridsize=10)
        plt.close('all')

    def test_hexbin_svg_renders(self):
        """hexbin renders to SVG."""
        fig, ax = plt.subplots()
        ax.hexbin([1, 2, 3, 2, 1], [1, 2, 3, 1, 2], gridsize=5)
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_hexbin_numpy_arrays(self):
        """hexbin with numpy arrays."""
        fig, ax = plt.subplots()
        rng = np.random.default_rng(42)
        x = rng.normal(0, 1, 30).tolist()
        y = rng.normal(0, 1, 30).tolist()
        hb = ax.hexbin(x, y, gridsize=5)
        assert hb is not None
        plt.close('all')

    def test_plt_hexbin(self):
        """plt.hexbin() wrapper works."""
        plt.figure()
        result = plt.hexbin([1, 2, 3], [1, 2, 3])
        assert result is not None
        plt.close('all')


# ---------------------------------------------------------------------------
# fig.savefig() to BytesIO / StringIO
# ---------------------------------------------------------------------------

class TestSavefigIO:
    def test_savefig_svg_to_bytesio(self):
        """savefig(BytesIO, format='svg') writes bytes."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        buf = io.BytesIO()
        fig.savefig(buf, format='svg')
        assert buf.tell() > 0
        plt.close('all')

    def test_savefig_png_to_bytesio(self):
        """savefig(BytesIO, format='png') writes bytes."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        buf = io.BytesIO()
        fig.savefig(buf, format='png')
        buf.seek(0)
        data = buf.read()
        assert data[:4] == b'\x89PNG'
        plt.close('all')

    def test_savefig_svg_content(self):
        """SVG saved to BytesIO is valid UTF-8 SVG."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        buf = io.BytesIO()
        fig.savefig(buf, format='svg')
        buf.seek(0)
        content = buf.read().decode('utf-8')
        assert '<svg' in content
        plt.close('all')

    def test_savefig_png_nonempty(self):
        """savefig PNG is non-empty."""
        fig, ax = plt.subplots()
        ax.bar([1, 2, 3], [1, 4, 9])
        buf = io.BytesIO()
        fig.savefig(buf, format='png')
        assert buf.tell() > 100
        plt.close('all')

    def test_savefig_default_format_is_png_for_bytesio(self):
        """savefig without format for BytesIO defaults to PNG."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        buf = io.BytesIO()
        fig.savefig(buf)
        buf.seek(0)
        data = buf.read()
        # Should be PNG
        assert data[:4] == b'\x89PNG'
        plt.close('all')

    def test_plt_savefig_svg(self):
        """plt.savefig() to BytesIO with SVG format."""
        plt.figure()
        plt.plot([0, 1], [0, 1])
        buf = io.BytesIO()
        plt.savefig(buf, format='svg')
        assert buf.tell() > 0
        plt.close('all')
