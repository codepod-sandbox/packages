"""Tests for GridSpec, SubplotSpec, and complex subplot arrangements."""

import pytest
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec


# ---------------------------------------------------------------------------
# GridSpec indexing
# ---------------------------------------------------------------------------

class TestGridSpecIndexing:
    def test_gridspec_single_cell(self):
        """GridSpec single cell access does not raise."""
        fig = plt.figure()
        gs = gridspec.GridSpec(3, 3)
        ax = fig.add_subplot(gs[1, 1])
        assert ax is not None
        plt.close('all')

    def test_gridspec_row_span(self):
        """GridSpec row slice creates subplot spanning rows."""
        fig = plt.figure()
        gs = gridspec.GridSpec(3, 2)
        ax = fig.add_subplot(gs[:, 0])  # full left column
        assert ax is not None
        plt.close('all')

    def test_gridspec_col_span(self):
        """GridSpec column slice creates subplot spanning columns."""
        fig = plt.figure()
        gs = gridspec.GridSpec(2, 3)
        ax = fig.add_subplot(gs[0, :])  # full top row
        assert ax is not None
        plt.close('all')

    def test_gridspec_partial_span(self):
        """GridSpec partial row/col span works."""
        fig = plt.figure()
        gs = gridspec.GridSpec(3, 3)
        ax = fig.add_subplot(gs[1:3, 0:2])  # 2x2 bottom-left block
        assert ax is not None
        plt.close('all')

    def test_gridspec_all_cells(self):
        """GridSpec all cells can be added as subplots."""
        fig = plt.figure()
        gs = gridspec.GridSpec(2, 3)
        axes = []
        for row in range(2):
            for col in range(3):
                ax = fig.add_subplot(gs[row, col])
                axes.append(ax)
        assert len(axes) == 6
        plt.close('all')


# ---------------------------------------------------------------------------
# GridSpec with spacing
# ---------------------------------------------------------------------------

class TestGridSpecSpacing:
    def test_hspace(self):
        """GridSpec with hspace does not raise."""
        fig = plt.figure()
        gs = gridspec.GridSpec(3, 1, hspace=0.5)
        for i in range(3):
            fig.add_subplot(gs[i])
        plt.close('all')

    def test_wspace(self):
        """GridSpec with wspace does not raise."""
        fig = plt.figure()
        gs = gridspec.GridSpec(1, 3, wspace=0.4)
        for i in range(3):
            fig.add_subplot(gs[i])
        plt.close('all')

    def test_figure_subplot_kw(self):
        """plt.subplots with subplot_kw does not raise."""
        fig, axes = plt.subplots(2, 2, subplot_kw={'aspect': 'equal'})
        assert len(axes) == 2
        plt.close('all')


# ---------------------------------------------------------------------------
# GridSpecFromSubplotSpec
# ---------------------------------------------------------------------------

class TestGridSpecNested:
    def test_gridspecfromsubplotspec(self):
        """GridSpecFromSubplotSpec creates nested grid."""
        fig = plt.figure()
        outer_gs = gridspec.GridSpec(1, 2)
        inner_gs = gridspec.GridSpecFromSubplotSpec(
            2, 1, subplot_spec=outer_gs[0])
        ax1 = fig.add_subplot(inner_gs[0])
        ax2 = fig.add_subplot(inner_gs[1])
        ax3 = fig.add_subplot(outer_gs[1])
        assert ax1 is not None
        assert ax2 is not None
        assert ax3 is not None
        plt.close('all')


# ---------------------------------------------------------------------------
# Complex layout patterns
# ---------------------------------------------------------------------------

class TestComplexLayouts:
    def test_dashboard_layout(self):
        """Dashboard-style layout with main and side panels."""
        fig = plt.figure(figsize=(10, 8))
        gs = gridspec.GridSpec(2, 3, figure=fig)
        ax_main = fig.add_subplot(gs[:, :2])
        ax_top_right = fig.add_subplot(gs[0, 2])
        ax_bottom_right = fig.add_subplot(gs[1, 2])
        ax_main.plot([0, 1, 2], [0, 1, 0])
        ax_top_right.bar([1, 2], [3, 5])
        ax_bottom_right.pie([40, 60])
        plt.close('all')

    def test_comparison_layout(self):
        """Side-by-side comparison layout renders to SVG."""
        fig = plt.figure(figsize=(12, 4))
        gs = gridspec.GridSpec(1, 3, figure=fig)
        for i, cmap in enumerate(['viridis', 'plasma', 'inferno']):
            ax = fig.add_subplot(gs[0, i])
            data = [[j * i for j in range(5)] for _ in range(5)]
            ax.imshow(data, cmap=cmap)
            ax.set_title(cmap)
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_subplot_mosaic_style(self):
        """Complex GridSpec mimicking subplot_mosaic."""
        fig = plt.figure(figsize=(8, 6))
        gs = gridspec.GridSpec(3, 2)
        # Top row: full width
        ax_top = fig.add_subplot(gs[0, :])
        # Middle: two panels
        ax_mid_left = fig.add_subplot(gs[1, 0])
        ax_mid_right = fig.add_subplot(gs[1, 1])
        # Bottom: full width
        ax_bottom = fig.add_subplot(gs[2, :])
        for ax in [ax_top, ax_mid_left, ax_mid_right, ax_bottom]:
            ax.plot([0, 1], [0, 1])
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')
