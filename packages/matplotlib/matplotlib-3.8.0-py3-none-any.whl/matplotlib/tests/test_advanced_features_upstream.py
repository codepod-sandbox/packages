"""Tests for contour, stackplot, imshow features, tick formatters, and text utilities."""

import pytest
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker


# ---------------------------------------------------------------------------
# ax.contour() / ax.contourf()
# ---------------------------------------------------------------------------

class TestContour:
    def test_contour_basic(self):
        """contour(Z) with 2D array does not raise."""
        fig, ax = plt.subplots()
        Z = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
        ax.contour(Z)
        plt.close('all')

    def test_contourf_basic(self):
        """contourf(Z) with 2D array does not raise."""
        fig, ax = plt.subplots()
        Z = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
        ax.contourf(Z)
        plt.close('all')

    def test_contour_with_xyz(self):
        """contour(X, Y, Z) does not raise."""
        fig, ax = plt.subplots()
        x = [0, 1, 2]
        y = [0, 1, 2]
        Z = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
        ax.contour(x, y, Z)
        plt.close('all')

    def test_contour_levels(self):
        """contour with levels does not raise."""
        fig, ax = plt.subplots()
        Z = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
        ax.contour(Z, levels=[2, 4, 6, 8])
        plt.close('all')

    def test_contourf_cmap(self):
        """contourf with cmap does not raise."""
        fig, ax = plt.subplots()
        Z = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
        ax.contourf(Z, cmap='plasma')
        plt.close('all')

    def test_contour_svg_renders(self):
        """contourf renders to SVG."""
        fig, ax = plt.subplots()
        Z = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
        ax.contourf(Z)
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_plt_contour(self):
        """plt.contour() wrapper works."""
        plt.figure()
        Z = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
        plt.contour(Z)
        plt.close('all')

    def test_plt_contourf(self):
        """plt.contourf() wrapper works."""
        plt.figure()
        Z = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
        plt.contourf(Z)
        plt.close('all')


# ---------------------------------------------------------------------------
# ax.stackplot()
# ---------------------------------------------------------------------------

class TestStackplot:
    def test_stackplot_basic(self):
        """stackplot(x, y1, y2) does not raise."""
        fig, ax = plt.subplots()
        x = [0, 1, 2, 3]
        y1 = [1, 2, 3, 4]
        y2 = [2, 1, 2, 1]
        ax.stackplot(x, y1, y2)
        plt.close('all')

    def test_stackplot_with_labels(self):
        """stackplot with labels does not raise."""
        fig, ax = plt.subplots()
        x = [0, 1, 2, 3]
        ax.stackplot(x, [1, 2, 3, 4], [2, 1, 2, 1],
                     labels=['series1', 'series2'])
        plt.close('all')

    def test_stackplot_svg_renders(self):
        """stackplot renders to SVG."""
        fig, ax = plt.subplots()
        x = [0, 1, 2, 3, 4]
        ax.stackplot(x, [1, 2, 3, 4, 5], [2, 1, 2, 1, 2])
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_stackplot_colors(self):
        """stackplot with colors does not raise."""
        fig, ax = plt.subplots()
        x = [0, 1, 2]
        ax.stackplot(x, [1, 2, 3], [2, 1, 2],
                     colors=['blue', 'green'])
        plt.close('all')


# ---------------------------------------------------------------------------
# Axis inversion
# ---------------------------------------------------------------------------

class TestAxisInversion:
    def test_invert_xaxis(self):
        """invert_xaxis() inverts x axis."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2], [0, 1, 4])
        ax.invert_xaxis()
        xmin, xmax = ax.get_xlim()
        assert xmin > xmax
        plt.close('all')

    def test_invert_yaxis(self):
        """invert_yaxis() inverts y axis."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2], [0, 1, 4])
        ax.invert_yaxis()
        ymin, ymax = ax.get_ylim()
        assert ymin > ymax
        plt.close('all')

    def test_xaxis_inverted(self):
        """xaxis_inverted() reports correct state."""
        fig, ax = plt.subplots()
        ax.invert_xaxis()
        assert ax.xaxis_inverted()
        plt.close('all')

    def test_yaxis_inverted(self):
        """yaxis_inverted() reports correct state."""
        fig, ax = plt.subplots()
        ax.invert_yaxis()
        assert ax.yaxis_inverted()
        plt.close('all')

    def test_inverted_svg_renders(self):
        """Axes with inverted axes renders to SVG."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2], [0, 1, 4])
        ax.invert_yaxis()
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')


# ---------------------------------------------------------------------------
# matplotlib.ticker formatters
# ---------------------------------------------------------------------------

class TestTickerFormatters:
    def test_format_str_formatter(self):
        """FormatStrFormatter can be created."""
        fmt = ticker.FormatStrFormatter('%.2f')
        assert fmt is not None

    def test_format_str_formatter_call(self):
        """FormatStrFormatter formats a value."""
        fmt = ticker.FormatStrFormatter('%.2f')
        result = fmt(3.14159, 0)
        assert '3.14' in result

    def test_scalar_formatter(self):
        """ScalarFormatter can be created."""
        fmt = ticker.ScalarFormatter()
        assert fmt is not None

    def test_func_formatter(self):
        """FuncFormatter wraps a callable."""
        fmt = ticker.FuncFormatter(lambda x, pos: f'{x:.1f}%')
        assert fmt is not None
        result = fmt(50, 0)
        assert '50.0%' in result

    def test_fixed_locator(self):
        """FixedLocator with explicit ticks."""
        loc = ticker.FixedLocator([0, 1, 2, 3])
        assert loc is not None

    def test_multiple_locator(self):
        """MultipleLocator with base."""
        loc = ticker.MultipleLocator(0.5)
        assert loc is not None

    def test_auto_locator(self):
        """AutoLocator can be created."""
        loc = ticker.AutoLocator()
        assert loc is not None

    def test_apply_formatter_to_axis(self):
        """Applying FormatStrFormatter to axis does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2], [0, 1, 4])
        ax.xaxis.set_major_formatter(ticker.FormatStrFormatter('%d'))
        plt.close('all')

    def test_apply_locator_to_axis(self):
        """Applying FixedLocator to axis does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2, 3], [0, 1, 4, 9])
        ax.xaxis.set_major_locator(ticker.FixedLocator([0, 1, 2, 3]))
        plt.close('all')


# ---------------------------------------------------------------------------
# ax.text() features
# ---------------------------------------------------------------------------

class TestTextFeatures:
    def test_text_basic(self):
        """ax.text returns an object."""
        fig, ax = plt.subplots()
        t = ax.text(0.5, 0.5, 'hello')
        assert t is not None
        plt.close('all')

    def test_text_with_transform(self):
        """ax.text with transform=ax.transAxes does not raise."""
        fig, ax = plt.subplots()
        ax.text(0.5, 0.5, 'center', transform=ax.transAxes)
        plt.close('all')

    def test_text_fontsize(self):
        """ax.text with fontsize does not raise."""
        fig, ax = plt.subplots()
        ax.text(0.5, 0.5, 'big text', fontsize=16)
        plt.close('all')

    def test_text_ha_va(self):
        """ax.text with ha/va does not raise."""
        fig, ax = plt.subplots()
        ax.text(0.5, 0.5, 'centered', ha='center', va='center')
        plt.close('all')

    def test_text_color(self):
        """ax.text with color does not raise."""
        fig, ax = plt.subplots()
        ax.text(0.5, 0.5, 'colored', color='red')
        plt.close('all')

    def test_text_bbox(self):
        """ax.text with bbox kwarg does not raise."""
        fig, ax = plt.subplots()
        ax.text(0.5, 0.5, 'boxed', bbox={'facecolor': 'yellow', 'alpha': 0.5})
        plt.close('all')

    def test_text_rotation(self):
        """ax.text with rotation does not raise."""
        fig, ax = plt.subplots()
        ax.text(0.5, 0.5, 'rotated', rotation=45)
        plt.close('all')

    def test_text_svg_renders(self):
        """Axes with text renders to SVG."""
        fig, ax = plt.subplots()
        ax.text(0.5, 0.5, 'Hello World', ha='center', va='center', fontsize=14)
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_plt_text(self):
        """plt.text() wrapper does not raise."""
        plt.figure()
        plt.plot([0, 1], [0, 1])
        plt.text(0.5, 0.5, 'label')
        plt.close('all')


# ---------------------------------------------------------------------------
# Figure suptitle and title
# ---------------------------------------------------------------------------

class TestFigureTitles:
    def test_suptitle_basic(self):
        """fig.suptitle does not raise."""
        fig, ax = plt.subplots()
        fig.suptitle('Main Title')
        plt.close('all')

    def test_suptitle_with_fontsize(self):
        """fig.suptitle with fontsize does not raise."""
        fig, ax = plt.subplots()
        fig.suptitle('Title', fontsize=16)
        plt.close('all')

    def test_plt_suptitle(self):
        """plt.suptitle() wrapper does not raise."""
        fig, ax = plt.subplots()
        plt.suptitle('Figure Title')
        plt.close('all')

    def test_ax_set_title(self):
        """ax.set_title does not raise."""
        fig, ax = plt.subplots()
        ax.set_title('Axis Title')
        plt.close('all')

    def test_title_svg_renders(self):
        """Figure with suptitle renders to SVG."""
        fig, axes = plt.subplots(1, 2)
        fig.suptitle('Overall')
        axes[0].set_title('Left')
        axes[1].set_title('Right')
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')
