"""Tests for LineCollection, PathCollection, and collection properties."""

import pytest
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.collections as mcollections


# ---------------------------------------------------------------------------
# LineCollection
# ---------------------------------------------------------------------------

class TestLineCollectionAdvanced:
    def test_linecollection_basic(self):
        """LineCollection can be created and added to axes."""
        fig, ax = plt.subplots()
        segs = [[[0, 0], [1, 1]], [[0, 1], [1, 0]]]
        lc = mcollections.LineCollection(segs)
        ax.add_collection(lc)
        plt.close('all')

    def test_linecollection_colors(self):
        """LineCollection with colors does not raise."""
        fig, ax = plt.subplots()
        segs = [[[0, 0], [1, 1]], [[0, 1], [1, 0]]]
        lc = mcollections.LineCollection(segs, colors=['red', 'blue'])
        ax.add_collection(lc)
        plt.close('all')

    def test_linecollection_linewidths(self):
        """LineCollection with linewidths does not raise."""
        fig, ax = plt.subplots()
        segs = [[[0, 0], [1, 1]], [[0, 1], [1, 0]]]
        lc = mcollections.LineCollection(segs, linewidths=[1, 3])
        ax.add_collection(lc)
        plt.close('all')

    def test_linecollection_set_array(self):
        """set_array on LineCollection does not raise."""
        fig, ax = plt.subplots()
        segs = [[[i, 0], [i, 1]] for i in range(5)]
        lc = mcollections.LineCollection(segs)
        lc.set_array([0, 1, 2, 3, 4])
        ax.add_collection(lc)
        plt.close('all')

    def test_linecollection_alpha(self):
        """LineCollection with alpha does not raise."""
        fig, ax = plt.subplots()
        segs = [[[0, 0], [1, 1]]]
        lc = mcollections.LineCollection(segs, alpha=0.5)
        ax.add_collection(lc)
        plt.close('all')

    def test_linecollection_get_paths(self):
        """LineCollection get_paths returns paths."""
        segs = [[[0, 0], [1, 1]], [[0, 1], [1, 0]]]
        lc = mcollections.LineCollection(segs)
        paths = lc.get_paths()
        assert paths is not None

    def test_linecollection_svg(self):
        """LineCollection renders to SVG."""
        fig, ax = plt.subplots()
        segs = [[[i, 0], [i, i * 0.5]] for i in range(5)]
        lc = mcollections.LineCollection(segs, linewidths=2)
        ax.add_collection(lc)
        ax.set_xlim(-1, 6)
        ax.set_ylim(-1, 3)
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')


# ---------------------------------------------------------------------------
# PathCollection (created by scatter)
# ---------------------------------------------------------------------------

class TestPathCollectionAdvanced:
    def test_scatter_returns_pathcollection(self):
        """scatter returns a PathCollection."""
        fig, ax = plt.subplots()
        sc = ax.scatter([1, 2, 3], [1, 2, 3])
        assert isinstance(sc, mcollections.PathCollection)
        plt.close('all')

    def test_pathcollection_get_offsets(self):
        """PathCollection.get_offsets returns the scatter points."""
        fig, ax = plt.subplots()
        sc = ax.scatter([1, 2, 3], [4, 5, 6])
        offsets = sc.get_offsets()
        assert len(offsets) == 3
        plt.close('all')

    def test_pathcollection_set_sizes(self):
        """PathCollection.set_sizes does not raise."""
        fig, ax = plt.subplots()
        sc = ax.scatter([1, 2, 3], [1, 2, 3])
        sc.set_sizes([50, 100, 150])
        plt.close('all')

    def test_pathcollection_get_sizes(self):
        """PathCollection.get_sizes returns sizes."""
        fig, ax = plt.subplots()
        sc = ax.scatter([1, 2, 3], [1, 2, 3], s=50)
        sizes = sc.get_sizes()
        assert sizes is not None
        plt.close('all')


# ---------------------------------------------------------------------------
# PolyCollection
# ---------------------------------------------------------------------------

class TestPolyCollectionAdvanced:
    def test_polycollection_basic(self):
        """PolyCollection can be created and added to axes."""
        fig, ax = plt.subplots()
        verts = [[[0, 0], [1, 0], [0.5, 1]],
                 [[1, 0], [2, 0], [1.5, 1]]]
        pc = mcollections.PolyCollection(verts)
        ax.add_collection(pc)
        plt.close('all')

    def test_polycollection_facecolors(self):
        """PolyCollection with facecolors does not raise."""
        fig, ax = plt.subplots()
        verts = [[[0, 0], [1, 0], [0.5, 1]],
                 [[1, 0], [2, 0], [1.5, 1]]]
        pc = mcollections.PolyCollection(verts, facecolors=['red', 'blue'])
        ax.add_collection(pc)
        plt.close('all')


# ---------------------------------------------------------------------------
# Collection colormap and clim
# ---------------------------------------------------------------------------

class TestCollectionClimAdv:
    def test_scatter_set_clim(self):
        """scatter PathCollection set_clim does not raise."""
        fig, ax = plt.subplots()
        sc = ax.scatter([1, 2, 3], [1, 2, 3], c=[0.1, 0.5, 0.9])
        sc.set_clim(0, 1)
        plt.close('all')

    def test_scatter_get_clim(self):
        """scatter PathCollection get_clim returns vmin, vmax."""
        fig, ax = plt.subplots()
        sc = ax.scatter([1, 2, 3], [1, 2, 3], c=[0.1, 0.5, 0.9],
                        vmin=0, vmax=1)
        vmin, vmax = sc.get_clim()
        assert vmin == pytest.approx(0)
        assert vmax == pytest.approx(1)
        plt.close('all')

    def test_scatter_colorbar(self):
        """scatter with colorbar does not raise."""
        fig, ax = plt.subplots()
        sc = ax.scatter([1, 2, 3], [1, 2, 3], c=[10, 20, 30])
        fig.colorbar(sc, ax=ax)
        plt.close('all')


# ---------------------------------------------------------------------------
# fill_between creates PolyCollection
# ---------------------------------------------------------------------------

class TestFillBetweenCollectionAdv:
    def test_fill_between_returns_result(self):
        """fill_between returns a PolyCollection."""
        fig, ax = plt.subplots()
        x = [0, 1, 2, 3]
        result = ax.fill_between(x, [0, 1, 0, 1], [1, 2, 1, 2])
        assert result is not None
        plt.close('all')

    def test_fill_between_set_alpha(self):
        """fill_between result supports set_alpha."""
        fig, ax = plt.subplots()
        x = [0, 1, 2, 3]
        fc = ax.fill_between(x, [0, 1, 0, 1], [1, 2, 1, 2])
        fc.set_alpha(0.3)
        plt.close('all')
