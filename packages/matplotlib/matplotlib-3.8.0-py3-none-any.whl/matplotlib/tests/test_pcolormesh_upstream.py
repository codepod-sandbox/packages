"""Tests for pcolormesh/pcolor patterns used by LLMs."""

import pytest
import numpy as np
import matplotlib.pyplot as plt


def make_mesh(n=8):
    x = np.linspace(0.0, 1.0, n + 1)
    y = np.linspace(0.0, 1.0, n + 1)
    X, Y = np.meshgrid(x, y)
    Z = X * Y
    return X, Y, Z


class TestPcolormesh:
    def test_pcolormesh_basic(self):
        fig, ax = plt.subplots()
        X, Y, Z = make_mesh()
        pc = ax.pcolormesh(X, Y, Z[:-1, :-1])
        assert pc is not None
        plt.close('all')

    def test_pcolormesh_cmap(self):
        fig, ax = plt.subplots()
        X, Y, Z = make_mesh()
        pc = ax.pcolormesh(X, Y, Z[:-1, :-1], cmap='viridis')
        assert pc is not None
        plt.close('all')

    def test_pcolormesh_vmin_vmax(self):
        fig, ax = plt.subplots()
        X, Y, Z = make_mesh()
        pc = ax.pcolormesh(X, Y, Z[:-1, :-1], vmin=0.0, vmax=0.5)
        assert pc is not None
        plt.close('all')

    def test_pcolormesh_colorbar(self):
        fig, ax = plt.subplots()
        X, Y, Z = make_mesh()
        pc = ax.pcolormesh(X, Y, Z[:-1, :-1])
        fig.colorbar(pc, ax=ax)
        plt.close('all')

    def test_pcolormesh_alpha(self):
        fig, ax = plt.subplots()
        X, Y, Z = make_mesh()
        pc = ax.pcolormesh(X, Y, Z[:-1, :-1], alpha=0.7)
        assert pc is not None
        plt.close('all')

    def test_pcolormesh_shading_flat(self):
        fig, ax = plt.subplots()
        X, Y, Z = make_mesh()
        pc = ax.pcolormesh(X, Y, Z[:-1, :-1], shading='flat')
        assert pc is not None
        plt.close('all')

    def test_pcolormesh_shading_gouraud(self):
        fig, ax = plt.subplots()
        X, Y, Z = make_mesh()
        pc = ax.pcolormesh(X, Y, Z, shading='gouraud')
        assert pc is not None
        plt.close('all')

    def test_pcolormesh_edgecolors(self):
        fig, ax = plt.subplots()
        X, Y, Z = make_mesh()
        pc = ax.pcolormesh(X, Y, Z[:-1, :-1], edgecolors='k')
        assert pc is not None
        plt.close('all')

    def test_pcolor_alias(self):
        """pcolor is an alias for pcolormesh."""
        fig, ax = plt.subplots()
        X, Y, Z = make_mesh()
        pc = ax.pcolor(X, Y, Z[:-1, :-1])
        assert pc is not None
        plt.close('all')

    def test_plt_pcolormesh(self):
        """plt.pcolormesh() shortcut."""
        fig, ax = plt.subplots()
        X, Y, Z = make_mesh()
        pc = plt.pcolormesh(X, Y, Z[:-1, :-1])
        assert pc is not None
        plt.close('all')

    def test_pcolormesh_z_only(self):
        """pcolormesh(Z) without X, Y."""
        fig, ax = plt.subplots()
        Z = np.array([[1.0, 2.0, 3.0], [4.0, 5.0, 6.0]])
        pc = ax.pcolormesh(Z)
        assert pc is not None
        plt.close('all')

    def test_pcolormesh_norm(self):
        """pcolormesh with norm."""
        from matplotlib.colors import Normalize
        fig, ax = plt.subplots()
        X, Y, Z = make_mesh()
        norm = Normalize(vmin=0.0, vmax=1.0)
        pc = ax.pcolormesh(X, Y, Z[:-1, :-1], norm=norm)
        assert pc is not None
        plt.close('all')


class TestImshowAdvanced:
    def test_imshow_aspect_auto(self):
        fig, ax = plt.subplots()
        data = [[1.0, 2.0], [3.0, 4.0]]
        im = ax.imshow(data, aspect='auto')
        assert im is not None
        plt.close('all')

    def test_imshow_extent(self):
        fig, ax = plt.subplots()
        data = [[1.0, 2.0], [3.0, 4.0]]
        im = ax.imshow(data, extent=[0, 10, 0, 10])
        assert im is not None
        plt.close('all')

    def test_imshow_origin_upper(self):
        fig, ax = plt.subplots()
        data = [[1.0, 2.0], [3.0, 4.0]]
        im = ax.imshow(data, origin='upper')
        assert im is not None
        plt.close('all')

    def test_imshow_cmap_label(self):
        fig, ax = plt.subplots()
        data = [[1.0, 2.0, 3.0], [4.0, 5.0, 6.0]]
        im = ax.imshow(data, cmap='hot')
        fig.colorbar(im, ax=ax, label='intensity')
        plt.close('all')

    def test_imshow_interpolation(self):
        fig, ax = plt.subplots()
        data = [[1.0, 2.0], [3.0, 4.0]]
        im = ax.imshow(data, interpolation='nearest')
        assert im is not None
        plt.close('all')
