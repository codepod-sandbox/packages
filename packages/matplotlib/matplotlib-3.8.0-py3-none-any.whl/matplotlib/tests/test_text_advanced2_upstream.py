"""Tests for advanced text and font properties."""

import pytest
import matplotlib.pyplot as plt
import matplotlib.text as mtext


class TestTextProperties:
    def test_text_position(self):
        """Text at specific position."""
        fig, ax = plt.subplots()
        t = ax.text(0.5, 0.5, 'Hello World')
        assert t is not None
        plt.close('all')

    def test_text_fontsize(self):
        """Text with font size."""
        fig, ax = plt.subplots()
        t = ax.text(0.5, 0.5, 'Big Text', fontsize=16)
        assert t.get_fontsize() == 16
        plt.close('all')

    def test_text_fontweight(self):
        """Text with font weight."""
        fig, ax = plt.subplots()
        t = ax.text(0.5, 0.5, 'Bold', fontweight='bold')
        assert t is not None
        plt.close('all')

    def test_text_fontstyle(self):
        """Text with italic style."""
        fig, ax = plt.subplots()
        t = ax.text(0.5, 0.5, 'Italic', fontstyle='italic')
        assert t is not None
        plt.close('all')

    def test_text_ha_va(self):
        """Text with horizontal and vertical alignment."""
        fig, ax = plt.subplots()
        ax.text(0.5, 0.5, 'Center', ha='center', va='center')
        ax.text(0.0, 0.0, 'Left-Bottom', ha='left', va='bottom')
        ax.text(1.0, 1.0, 'Right-Top', ha='right', va='top')
        plt.close('all')

    def test_text_color(self):
        """Text with color."""
        fig, ax = plt.subplots()
        t = ax.text(0.5, 0.5, 'Colored', color='red')
        assert t is not None
        plt.close('all')

    def test_text_alpha(self):
        """Text with alpha."""
        fig, ax = plt.subplots()
        t = ax.text(0.5, 0.5, 'Transparent', alpha=0.5)
        assert abs(t.get_alpha() - 0.5) < 0.01
        plt.close('all')

    def test_text_rotation(self):
        """Text with rotation."""
        fig, ax = plt.subplots()
        ax.text(0.5, 0.5, 'Rotated 45°', rotation=45)
        plt.close('all')

    def test_text_bbox(self):
        """Text with bounding box."""
        fig, ax = plt.subplots()
        t = ax.text(0.5, 0.5, 'Boxed',
                    bbox=dict(facecolor='yellow', edgecolor='black', alpha=0.8))
        assert t is not None
        plt.close('all')

    def test_text_transform(self):
        """Text with axes transform."""
        fig, ax = plt.subplots()
        ax.text(0.1, 0.9, 'Top Left', transform=ax.transAxes, ha='left')
        plt.close('all')

    def test_title_fontsize(self):
        """Title with font size."""
        fig, ax = plt.subplots()
        ax.set_title('My Title', fontsize=14)
        plt.close('all')

    def test_title_fontweight(self):
        """Title with font weight."""
        fig, ax = plt.subplots()
        ax.set_title('Bold Title', fontweight='bold')
        plt.close('all')

    def test_title_color(self):
        """Title with color."""
        fig, ax = plt.subplots()
        ax.set_title('Colored Title', color='navy')
        plt.close('all')

    def test_title_pad(self):
        """Title with padding."""
        fig, ax = plt.subplots()
        ax.set_title('Padded Title', pad=20)
        plt.close('all')


class TestAxisLabels:
    def test_xlabel_fontsize(self):
        """X-axis label with font size."""
        fig, ax = plt.subplots()
        ax.set_xlabel('X Axis', fontsize=12)
        plt.close('all')

    def test_ylabel_fontsize(self):
        """Y-axis label with font size."""
        fig, ax = plt.subplots()
        ax.set_ylabel('Y Axis', fontsize=12)
        plt.close('all')

    def test_xlabel_color(self):
        """X-axis label color."""
        fig, ax = plt.subplots()
        ax.set_xlabel('X Axis', color='blue')
        plt.close('all')

    def test_xlabel_labelpad(self):
        """X-axis label with padding."""
        fig, ax = plt.subplots()
        ax.set_xlabel('X Axis', labelpad=10)
        plt.close('all')

    def test_ylabel_rotation(self):
        """Y-axis label rotation."""
        fig, ax = plt.subplots()
        ax.set_ylabel('Y Axis', rotation=0)
        plt.close('all')


class TestTickLabelFormatting:
    def test_set_xticklabels_fontsize(self):
        """Tick labels with font size."""
        fig, ax = plt.subplots()
        ax.set_xticks([0, 1, 2, 3])
        ax.set_xticklabels(['A', 'B', 'C', 'D'], fontsize=10)
        plt.close('all')

    def test_get_xticklabels(self):
        """Get tick label text objects."""
        fig, ax = plt.subplots()
        ax.set_xticks([0, 1, 2])
        ax.set_xticklabels(['X', 'Y', 'Z'])
        labels = ax.get_xticklabels()
        assert labels is not None
        plt.close('all')

    def test_get_yticklabels(self):
        """Get y tick labels."""
        fig, ax = plt.subplots()
        labels = ax.get_yticklabels()
        assert labels is not None
        plt.close('all')

    def test_tick_label_rotation(self):
        """Rotate tick labels via set_xticklabels."""
        fig, ax = plt.subplots()
        ax.set_xticks([0, 1, 2, 3])
        ax.set_xticklabels(['January', 'February', 'March', 'April'],
                           rotation=45, ha='right')
        plt.close('all')

    def test_tick_label_invisible(self):
        """Make tick labels invisible."""
        fig, ax = plt.subplots()
        ax.set_xticklabels([])
        plt.close('all')

    def test_setp_rotation(self):
        """plt.setp for tick label properties."""
        fig, ax = plt.subplots()
        ax.set_xticks([0, 1, 2])
        ax.set_xticklabels(['A', 'B', 'C'])
        labels = ax.get_xticklabels()
        plt.setp(labels, rotation=30)
        plt.close('all')


class TestAnnotate:
    def test_annotate_basic(self):
        """Basic annotation."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 4, 9])
        ax.annotate('Peak', xy=(3, 9), xytext=(2, 8))
        plt.close('all')

    def test_annotate_arrow(self):
        """Annotation with arrow."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 4, 9])
        ax.annotate('Max', xy=(3, 9), xytext=(2, 7),
                    arrowprops=dict(arrowstyle='->', color='red'))
        plt.close('all')

    def test_annotate_textcoords(self):
        """Annotation with offset points."""
        fig, ax = plt.subplots()
        ax.scatter([1.0, 2.0, 3.0], [1.0, 4.0, 9.0])
        ax.annotate('Point', xy=(2, 4), xytext=(10, 10),
                    textcoords='offset points')
        plt.close('all')

    def test_annotate_multiple(self):
        """Multiple annotations."""
        fig, ax = plt.subplots()
        points = [(1.0, 1.0, 'A'), (2.0, 4.0, 'B'), (3.0, 9.0, 'C')]
        ax.plot([p[0] for p in points], [p[1] for p in points], 'bo')
        for x, y, label in points:
            ax.annotate(label, xy=(x, y), xytext=(x + 0.1, y + 0.5))
        plt.close('all')

    def test_annotate_bbox(self):
        """Annotation with bbox."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 4, 9])
        ax.annotate('Important', xy=(2, 4), xytext=(1.5, 6),
                    bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
        plt.close('all')

    def test_annotate_fancyarrowpatch(self):
        """Annotation with fancy arrow."""
        fig, ax = plt.subplots()
        ax.plot([0.5, 1.5, 2.5], [1.0, 2.0, 1.5])
        ax.annotate('', xy=(2.5, 1.5), xytext=(0.5, 1.0),
                    arrowprops=dict(arrowstyle='fancy'))
        plt.close('all')


class TestFigureText:
    def test_fig_text(self):
        """Text on figure."""
        fig, ax = plt.subplots()
        fig.text(0.5, 0.01, 'Figure Label', ha='center')
        plt.close('all')

    def test_suptitle_fontsize(self):
        """Suptitle with font size."""
        fig, axes = plt.subplots(1, 2)
        fig.suptitle('Overall Title', fontsize=16, fontweight='bold')
        plt.close('all')

    def test_text_with_math(self):
        """Text with simple math-like strings."""
        fig, ax = plt.subplots()
        ax.text(0.5, 0.5, 'R^2 = 0.95', ha='center')
        plt.close('all')
