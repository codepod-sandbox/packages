"""
Upstream tests for complex chart types commonly used by LLMs.
"""

import pytest
import numpy as np
import matplotlib.pyplot as plt


class TestStackedBarCharts:
    """Tests for stacked bar chart patterns."""

    def teardown_method(self):
        plt.close('all')

    def test_stacked_bar_basic(self):
        categories = ['A', 'B', 'C', 'D']
        vals1 = np.array([3, 4, 2, 5])
        vals2 = np.array([2, 3, 4, 1])
        x = np.arange(len(categories))
        fig, ax = plt.subplots()
        ax.bar(x, vals1, label='Series 1')
        ax.bar(x, vals2, bottom=vals1, label='Series 2')
        ax.legend()
        ax.set_xticks(list(x))
        ax.set_xticklabels(categories)

    def test_stacked_bar_three_groups(self):
        x = np.arange(5)
        v1 = np.array([2, 3, 1, 4, 2])
        v2 = np.array([1, 2, 3, 1, 3])
        v3 = np.array([3, 1, 2, 2, 1])
        fig, ax = plt.subplots()
        ax.bar(x, v1, label='G1')
        ax.bar(x, v2, bottom=v1, label='G2')
        ax.bar(x, v3, bottom=v1 + v2, label='G3')
        ax.legend()

    def test_horizontal_stacked_bar(self):
        categories = ['P1', 'P2', 'P3']
        vals1 = [10, 15, 8]
        vals2 = [5, 8, 12]
        y = np.arange(len(categories))
        fig, ax = plt.subplots()
        ax.barh(y, vals1, label='Component A')
        ax.barh(y, vals2, left=vals1, label='Component B')
        ax.set_yticks(list(y))
        ax.set_yticklabels(categories)
        ax.legend()

    def test_100_percent_stacked_bar(self):
        """100% stacked bar chart."""
        x = np.arange(4)
        v1 = np.array([30, 25, 40, 20])
        v2 = np.array([40, 35, 30, 50])
        v3 = np.array([30, 40, 30, 30])
        total = v1 + v2 + v3
        fig, ax = plt.subplots()
        ax.bar(x, v1 / total * 100)
        ax.bar(x, v2 / total * 100, bottom=v1 / total * 100)
        ax.bar(x, v3 / total * 100, bottom=(v1 + v2) / total * 100)
        ax.set_ylim(0, 100)
        ax.set_ylabel('Percentage (%)')


class TestSpecializedCharts:
    """Tests for specialized chart types."""

    def teardown_method(self):
        plt.close('all')

    def test_waterfall_chart(self):
        """Waterfall chart using bars."""
        values = [100, 20, -15, 30, -10, 25]
        labels = ['Start', 'Q1', 'Loss', 'Q2', 'Expense', 'Final']
        cumsum = np.cumsum([0] + values[:-1])
        fig, ax = plt.subplots()
        colors = ['green' if v >= 0 else 'red' for v in values]
        ax.bar(range(len(values)), values, bottom=cumsum, color=colors)
        ax.set_xticks(range(len(labels)))
        ax.set_xticklabels(labels)

    def test_gantt_chart(self):
        """Simple Gantt chart using barh."""
        tasks = ['Task A', 'Task B', 'Task C', 'Task D']
        starts = [0, 2, 4, 1]
        durations = [3, 2, 3, 4]
        y = np.arange(len(tasks))
        fig, ax = plt.subplots(figsize=(8, 4))
        ax.barh(y, durations, left=starts, height=0.5)
        ax.set_yticks(list(y))
        ax.set_yticklabels(tasks)
        ax.set_xlabel('Day')
        ax.set_title('Project Timeline')

    def test_population_pyramid(self):
        """Population pyramid chart."""
        age_groups = ['0-10', '11-20', '21-30', '31-40', '41-50']
        male = np.array([50, 60, 70, 55, 45])
        female = np.array([48, 58, 68, 57, 47])
        y = np.arange(len(age_groups))
        fig, ax = plt.subplots()
        ax.barh(y, -male, label='Male')
        ax.barh(y, female, label='Female')
        ax.set_yticks(list(y))
        ax.set_yticklabels(age_groups)
        ax.legend()

    def test_bubble_chart(self):
        """Bubble chart (scatter with variable size)."""
        rng = np.random.default_rng(42)
        x = rng.uniform(0, 10, 20)
        y = rng.uniform(0, 10, 20)
        sizes = rng.uniform(50, 500, 20)
        colors = rng.uniform(0, 1, 20)
        fig, ax = plt.subplots()
        sc = ax.scatter(x, y, s=sizes, c=colors, alpha=0.6, cmap='viridis')
        fig.colorbar(sc, ax=ax)

    def test_lollipop_chart(self):
        """Lollipop (dot plot) chart."""
        categories = ['A', 'B', 'C', 'D', 'E']
        values = np.array([4.5, 3.2, 5.8, 2.1, 4.9])
        y = np.arange(len(categories))
        fig, ax = plt.subplots()
        ax.hlines(y, 0, values, linewidth=1, color='gray')
        ax.plot(values, y, 'o', markersize=8, color='steelblue')
        ax.set_yticks(list(y))
        ax.set_yticklabels(categories)

    def test_area_chart(self):
        """Stacked area chart."""
        x = np.arange(10)
        y1 = np.random.rand(10) * 5 + 5
        y2 = np.random.rand(10) * 3 + 2
        y3 = np.random.rand(10) * 4 + 3
        fig, ax = plt.subplots()
        ax.stackplot(x, y1, y2, y3, labels=['A', 'B', 'C'], alpha=0.7)
        ax.legend(loc='upper left')

    def test_ridge_plot_simulation(self):
        """Ridge plot simulation using fill_between."""
        rng = np.random.default_rng(42)
        n_groups = 4
        x = np.linspace(-4, 4, 100)
        fig, ax = plt.subplots()
        for i in range(n_groups):
            mu = rng.uniform(-1, 1)
            density = np.exp(-(x - mu)**2 / 2) / np.sqrt(2 * np.pi)
            offset = i * 0.3
            ax.fill_between(x, offset, offset + density, alpha=0.5)


class TestPieAndRadar:
    """Tests for pie and polar plot patterns."""

    def teardown_method(self):
        plt.close('all')

    def test_pie_basic(self):
        sizes = [30, 25, 20, 15, 10]
        labels = ['A', 'B', 'C', 'D', 'E']
        fig, ax = plt.subplots()
        ax.pie(sizes, labels=labels)

    def test_pie_explode(self):
        sizes = [30, 25, 20, 15, 10]
        explode = (0.1, 0, 0, 0, 0)
        fig, ax = plt.subplots()
        ax.pie(sizes, explode=explode, autopct='%1.1f%%')

    def test_donut_chart(self):
        sizes = [35, 25, 20, 20]
        fig, ax = plt.subplots()
        wedges, _ = ax.pie(sizes, wedgeprops=dict(width=0.5))
        ax.set_title('Donut Chart')

    def test_nested_pie(self):
        """Two rings pie chart."""
        outer_sizes = [40, 35, 25]
        inner_sizes = [20, 20, 15, 20, 25]
        fig, ax = plt.subplots()
        ax.pie(outer_sizes, radius=1.2, wedgeprops=dict(width=0.3))
        ax.pie(inner_sizes, radius=0.9, wedgeprops=dict(width=0.4))

    def test_polar_scatter(self):
        """Scatter plot in polar coordinates."""
        rng = np.random.default_rng(42)
        theta = rng.uniform(0, 2 * np.pi, 50)
        r = rng.uniform(0, 1, 50)
        fig, ax = plt.subplots(subplot_kw={'projection': 'polar'})
        ax.scatter(theta, r, alpha=0.7)

    def test_polar_bar(self):
        """Bar plot in polar coordinates."""
        N = 8
        theta = np.linspace(0, 2 * np.pi, N, endpoint=False)
        radii = np.random.rand(N) * 5
        width = 2 * np.pi / N
        fig, ax = plt.subplots(subplot_kw={'projection': 'polar'})
        ax.bar(theta, radii, width=width, alpha=0.7)

    def test_polar_with_lines(self):
        """Multiple lines in polar plot."""
        theta = np.linspace(0, 2 * np.pi, 100)
        fig, ax = plt.subplots(subplot_kw={'projection': 'polar'})
        for n in [1, 2, 3]:
            r = n * np.abs(np.sin(n * theta))
            ax.plot(theta, r, label=f'n={n}')
        ax.legend()
