"""
Upstream tests for fill_between, contour, and surface-style patterns.
"""

import numpy as np
import pytest
import matplotlib.pyplot as plt


class TestFillBetween:
    """Tests for fill_between patterns."""

    def teardown_method(self):
        plt.close('all')

    def test_fill_between_basic(self):
        fig, ax = plt.subplots()
        x = [0, 1, 2, 3, 4]
        y1 = [0, 1, 2, 1, 0]
        y2 = [0, 0, 0, 0, 0]
        ax.fill_between(x, y1, y2)

    def test_fill_between_color(self):
        fig, ax = plt.subplots()
        x = [0, 1, 2]
        y1 = [1, 2, 1]
        y2 = [0, 0, 0]
        ax.fill_between(x, y1, y2, color='blue')

    def test_fill_between_alpha(self):
        fig, ax = plt.subplots()
        x = [0, 1, 2]
        y1 = [1, 2, 1]
        ax.fill_between(x, y1, 0, alpha=0.3)

    def test_fill_between_scalar_y2(self):
        fig, ax = plt.subplots()
        x = [0, 1, 2, 3]
        y = [1, 2, 1.5, 2.5]
        ax.fill_between(x, y, 0)  # fill to y=0

    def test_fill_between_label(self):
        fig, ax = plt.subplots()
        x = [0, 1, 2]
        ax.fill_between(x, [1, 2, 1], [0, 0, 0], label='area')
        ax.legend()

    def test_fill_between_where(self):
        fig, ax = plt.subplots()
        x = [0, 1, 2, 3, 4]
        y = [0, 1, -1, 2, -0.5]
        ax.fill_between(x, y, 0, where=[v > 0 for v in y], alpha=0.5, label='positive')

    def test_fill_between_facecolor(self):
        fig, ax = plt.subplots()
        x = [0, 1, 2]
        ax.fill_between(x, [1, 2, 1], 0, facecolor='lightblue')

    def test_fill_between_edgecolor(self):
        fig, ax = plt.subplots()
        x = [0, 1, 2]
        ax.fill_between(x, [1, 2, 1], 0, edgecolor='blue', linewidth=1.5)

    def test_fill_between_confidence_band(self):
        """Common: plot line with confidence band."""
        fig, ax = plt.subplots()
        x = [0, 1, 2, 3, 4, 5]
        mean = [1, 1.5, 2, 1.8, 2.5, 3]
        lower = [0.8, 1.2, 1.7, 1.5, 2.1, 2.6]
        upper = [1.2, 1.8, 2.3, 2.1, 2.9, 3.4]
        ax.plot(x, mean, 'b-', label='mean')
        ax.fill_between(x, lower, upper, alpha=0.2, label='95% CI')
        ax.legend()

    def test_fill_betweenx_basic(self):
        """Horizontal fill."""
        fig, ax = plt.subplots()
        y = [0, 1, 2, 3]
        x1 = [0, 1, 2, 1]
        x2 = [0, 0, 0, 0]
        ax.fill_betweenx(y, x1, x2, alpha=0.5)

    def test_fill_between_step_post(self):
        fig, ax = plt.subplots()
        x = [0, 1, 2, 3]
        y = [1, 2, 1, 3]
        ax.fill_between(x, y, 0, step='post')

    def test_fill_between_step_pre(self):
        fig, ax = plt.subplots()
        x = [0, 1, 2, 3]
        y = [1, 2, 1, 3]
        ax.fill_between(x, y, 0, step='pre')

    def test_stacked_area_chart(self):
        """Stacked area chart pattern."""
        fig, ax = plt.subplots()
        x = [0, 1, 2, 3, 4]
        y1 = [1, 2, 1, 3, 2]
        y2 = [0.5, 1, 0.5, 1, 1]
        y3 = [0.3, 0.5, 0.3, 0.7, 0.5]
        ax.fill_between(x, y1, label='A', alpha=0.7)
        ax.fill_between(x, y2, label='B', alpha=0.7)
        ax.fill_between(x, y3, label='C', alpha=0.7)
        ax.legend()


class TestContourPlots:
    """Tests for contour and contourf patterns."""

    def teardown_method(self):
        plt.close('all')

    def test_contour_basic(self):
        x = [0, 1, 2]
        y = [0, 1, 2]
        z = [[0, 1, 2], [1, 2, 3], [2, 3, 4]]
        fig, ax = plt.subplots()
        cs = ax.contour(x, y, z)
        assert cs is not None

    def test_contour_levels(self):
        x = [0, 1, 2]
        y = [0, 1, 2]
        z = [[0, 1, 2], [1, 2, 3], [2, 3, 4]]
        fig, ax = plt.subplots()
        ax.contour(x, y, z, levels=5)

    def test_contour_levels_list(self):
        x = [0, 1, 2]
        y = [0, 1, 2]
        z = [[0, 1, 2], [1, 2, 3], [2, 3, 4]]
        fig, ax = plt.subplots()
        ax.contour(x, y, z, levels=[1, 2, 3])

    def test_contour_cmap(self):
        x = [0, 1, 2]
        y = [0, 1, 2]
        z = [[0, 1, 2], [1, 2, 3], [2, 3, 4]]
        fig, ax = plt.subplots()
        ax.contour(x, y, z, cmap='viridis')

    def test_contour_colors(self):
        x = [0, 1, 2]
        y = [0, 1, 2]
        z = [[0, 1, 2], [1, 2, 3], [2, 3, 4]]
        fig, ax = plt.subplots()
        ax.contour(x, y, z, colors='black')

    def test_contourf_basic(self):
        x = [0, 1, 2]
        y = [0, 1, 2]
        z = [[0, 1, 2], [1, 2, 3], [2, 3, 4]]
        fig, ax = plt.subplots()
        cs = ax.contourf(x, y, z)
        assert cs is not None

    def test_contourf_with_colorbar(self):
        x = [0, 1, 2]
        y = [0, 1, 2]
        z = [[0, 1, 2], [1, 2, 3], [2, 3, 4]]
        fig, ax = plt.subplots()
        cs = ax.contourf(x, y, z, cmap='hot')
        plt.colorbar(cs, ax=ax)

    def test_contour_clabel(self):
        x = [0, 1, 2]
        y = [0, 1, 2]
        z = [[0, 1, 2], [1, 2, 3], [2, 3, 4]]
        fig, ax = plt.subplots()
        cs = ax.contour(x, y, z)
        ax.clabel(cs, inline=True, fontsize=8)

    def test_contourf_alpha(self):
        x = [0, 1, 2]
        y = [0, 1, 2]
        z = [[0, 1, 2], [1, 2, 3], [2, 3, 4]]
        fig, ax = plt.subplots()
        ax.contourf(x, y, z, alpha=0.7)

    def test_contourf_over_contour(self):
        """Common: filled contour with outline contour over it."""
        x = [0, 1, 2, 3]
        y = [0, 1, 2, 3]
        z = [[0, 1, 2, 3], [1, 2, 3, 4], [2, 3, 4, 5], [3, 4, 5, 6]]
        fig, ax = plt.subplots()
        cf = ax.contourf(x, y, z, cmap='RdYlBu', levels=10)
        cs = ax.contour(x, y, z, colors='black', linewidths=0.5)
        plt.colorbar(cf, ax=ax)
