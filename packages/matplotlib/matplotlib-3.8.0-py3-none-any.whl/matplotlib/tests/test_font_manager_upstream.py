"""Tests for matplotlib.font_manager — FontProperties and font utilities."""

import pytest
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties


class TestFontProperties:
    def test_font_properties_default(self):
        """FontProperties() creates default props."""
        fp = FontProperties()
        assert fp is not None

    def test_font_properties_size(self):
        """FontProperties(size=14) stores size."""
        fp = FontProperties(size=14)
        assert fp.get_size_in_points() == 14 or fp.get_size() == 14

    def test_font_properties_family(self):
        """FontProperties(family='sans-serif') stores family."""
        fp = FontProperties(family='sans-serif')
        assert fp is not None

    def test_font_properties_weight(self):
        """FontProperties(weight='bold') stores weight."""
        fp = FontProperties(weight='bold')
        assert fp.get_weight() == 'bold'

    def test_font_properties_style(self):
        """FontProperties(style='italic') stores style."""
        fp = FontProperties(style='italic')
        assert fp.get_style() == 'italic'

    def test_font_properties_set_size(self):
        """FontProperties.set_size changes size."""
        fp = FontProperties()
        fp.set_size(16)
        assert fp.get_size() == 16 or fp.get_size_in_points() == 16

    def test_font_properties_set_family(self):
        """FontProperties.set_family changes family."""
        fp = FontProperties()
        fp.set_family('monospace')
        assert fp is not None

    def test_font_properties_set_weight(self):
        """FontProperties.set_weight changes weight."""
        fp = FontProperties()
        fp.set_weight('bold')
        assert fp.get_weight() == 'bold'

    def test_font_properties_copy(self):
        """FontProperties can be copied."""
        fp = FontProperties(size=12, weight='bold')
        fp2 = FontProperties(fp)
        assert fp2 is not None

    def test_font_properties_kwargs_in_plot(self):
        """fontproperties kwarg in text does not raise."""
        fig, ax = plt.subplots()
        fp = FontProperties(size=12, weight='bold')
        ax.text(0.5, 0.5, 'hello', fontproperties=fp)
        plt.close('all')

    def test_font_size_numeric_string(self):
        """FontProperties accepts string size."""
        fp = FontProperties(size='large')
        assert fp is not None

    def test_font_name_kwarg(self):
        """FontProperties(fname=...) is not a typical user API but size/style works."""
        fp = FontProperties(size=10, style='normal', weight='normal')
        assert fp is not None


class TestFontManagerModule:
    def test_font_manager_importable(self):
        """matplotlib.font_manager is importable."""
        import matplotlib.font_manager as fm
        assert fm is not None

    def test_fontproperties_accessible(self):
        """FontProperties is accessible via font_manager."""
        from matplotlib.font_manager import FontProperties
        fp = FontProperties()
        assert fp is not None

    def test_font_family_list_exists(self):
        """Font families can be set on rcParams."""
        import matplotlib
        matplotlib.rcParams['font.family'] = 'sans-serif'

    def test_findfont_does_not_raise(self):
        """font_manager.findfont() does not raise (may return None or path)."""
        try:
            from matplotlib.font_manager import findfont, FontProperties
            fp = FontProperties(family='sans-serif')
            result = findfont(fp)
            # result may be None or a path string
        except (ImportError, AttributeError):
            pytest.skip("findfont not available")


class TestFontInPlot:
    def test_title_with_fontsize(self):
        """title with fontsize kwarg does not raise."""
        fig, ax = plt.subplots()
        ax.set_title('My Title', fontsize=16)
        plt.close('all')

    def test_xlabel_with_fontweight(self):
        """xlabel with fontweight does not raise."""
        fig, ax = plt.subplots()
        ax.set_xlabel('X', fontweight='bold')
        plt.close('all')

    def test_text_with_fontstyle(self):
        """text with fontstyle does not raise."""
        fig, ax = plt.subplots()
        ax.text(0.5, 0.5, 'italic text', fontstyle='italic')
        plt.close('all')

    def test_tick_params_labelsize(self):
        """tick_params with labelsize does not raise."""
        fig, ax = plt.subplots()
        ax.tick_params(labelsize=8)
        plt.close('all')

    def test_suptitle_fontsize(self):
        """suptitle with fontsize kwarg does not raise."""
        fig, ax = plt.subplots()
        fig.suptitle('Title', fontsize=18)
        plt.close('all')
