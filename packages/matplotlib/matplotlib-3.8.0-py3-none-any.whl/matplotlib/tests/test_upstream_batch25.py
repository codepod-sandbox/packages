"""
Upstream tests — batch 25.
Focus: Comprehensive norm tests, colormap sequences, scatter/bar_label edge cases,
       histogram variants, and more detailed checks from upstream.
Adapted from matplotlib upstream tests (no canvas rendering, no image comparison).
"""
import math
import pytest
import numpy as np
import random
import matplotlib.pyplot as plt
from matplotlib.figure import Figure
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle
from matplotlib.colors import (
    Normalize, LogNorm, TwoSlopeNorm, BoundaryNorm, PowerNorm, SymLogNorm,
    to_rgba, to_hex, is_color_like,
)
from matplotlib.ticker import (
    MaxNLocator, AutoLocator, MultipleLocator, FixedLocator, LogLocator,
    ScalarFormatter, LogFormatter, PercentFormatter, FuncFormatter,
    NullLocator, NullFormatter,
)
import matplotlib.cm as cm
from matplotlib.cm import get_cmap


def close(a, b, tol=1e-6):
    """Check approximate equality."""
    if b == 0:
        return abs(a) < tol
    return abs(a - b) / abs(b) < tol


# ------------------------------------------------------------------
# SymLogNorm tests
# ------------------------------------------------------------------

class TestSymLogNorm:
    def test_basic(self):
        norm = SymLogNorm(linthresh=1.0, vmin=-10, vmax=10)
        assert norm is not None

    def test_zero_maps_to_midpoint(self):
        norm = SymLogNorm(linthresh=1.0, vmin=-10, vmax=10)
        result = norm(0)
        assert abs(result - 0.5) < 0.1  # Near middle

    def test_positive_values(self):
        norm = SymLogNorm(linthresh=1.0, vmin=-10, vmax=10)
        result = norm(5)
        assert result > 0.5  # Positive values should be > midpoint

    def test_negative_values(self):
        norm = SymLogNorm(linthresh=1.0, vmin=-10, vmax=10)
        result = norm(-5)
        assert result < 0.5  # Negative values should be < midpoint

    def test_repr(self):
        norm = SymLogNorm(linthresh=1.0, vmin=-10, vmax=10)
        r = repr(norm)
        assert 'SymLogNorm' in r

    def test_list_input(self):
        norm = SymLogNorm(linthresh=1.0, vmin=-10, vmax=10)
        result = norm([-5, 0, 5])
        assert len(result) == 3
        assert result[0] < result[1] < result[2]


# ------------------------------------------------------------------
# Color edge case tests
# ------------------------------------------------------------------

class TestColorEdgeCases:
    def test_rgba_tuple_3(self):
        r, g, b, a = to_rgba((0.5, 0.3, 0.1))
        assert close(r, 0.5)
        assert close(g, 0.3)
        assert close(b, 0.1)
        assert close(a, 1.0)

    def test_rgba_tuple_4(self):
        r, g, b, a = to_rgba((0.5, 0.3, 0.1, 0.8))
        assert close(a, 0.8)

    def test_alpha_override(self):
        r, g, b, a = to_rgba('red', alpha=0.3)
        assert close(a, 0.3)
        assert close(r, 1.0)

    def test_hex_3digit(self):
        r, g, b, a = to_rgba('#f00')
        assert close(r, 1.0)
        assert close(g, 0.0)
        assert close(b, 0.0)

    def test_hex_6digit(self):
        r, g, b, a = to_rgba('#ff8800')
        assert close(r, 1.0)
        assert close(g, 136/255, tol=1e-3)
        assert close(b, 0.0)

    def test_named_colors(self):
        colors = ['aqua', 'azure', 'beige', 'coral', 'crimson',
                  'cyan', 'darkblue', 'darkgreen', 'gold', 'indigo',
                  'ivory', 'lavender', 'lime', 'magenta', 'maroon',
                  'navy', 'olive', 'orange', 'orchid', 'peru',
                  'pink', 'plum', 'purple', 'red', 'salmon',
                  'sienna', 'silver', 'tan', 'teal', 'tomato',
                  'turquoise', 'violet', 'wheat', 'yellow']
        for c in colors:
            assert is_color_like(c), f'{c} should be a valid color'

    def test_short_names(self):
        # Matplotlib single-letter shortcuts
        assert is_color_like('b')  # blue
        assert is_color_like('g')  # green
        assert is_color_like('r')  # red
        assert is_color_like('c')  # cyan
        assert is_color_like('m')  # magenta
        assert is_color_like('y')  # yellow
        assert is_color_like('k')  # black
        assert is_color_like('w')  # white

    def test_to_hex_round_trip(self):
        original = (0.7, 0.3, 0.5)
        hex_color = to_hex(original)
        restored = to_rgba(hex_color)[:3]
        for o, rr in zip(original, restored):
            assert abs(o - rr) < 1/255 + 0.001  # within rounding error


# ------------------------------------------------------------------
# Colormap detailed tests
# ------------------------------------------------------------------

class TestColormapDetailed:
    def test_hot_cmap(self):
        cmap = get_cmap('hot')
        c = cmap(0.5)
        assert len(c) == 4

    def test_cool_cmap(self):
        cmap = get_cmap('cool')
        c = cmap(0.5)
        assert len(c) == 4

    def test_listed_colormap_mapping(self):
        colors = ['red', 'green', 'blue', 'yellow']
        cmap = cm.ListedColormap(colors)
        # 0 -> red, 0.5 -> blue (index 2), 1.0 -> yellow (last)
        c0 = cmap(0.0)
        c1 = cmap(1.0)
        assert c0 != c1

    def test_listed_colormap_reversed(self):
        colors = ['red', 'green', 'blue']
        cmap = cm.ListedColormap(colors)
        rev = cmap.reversed()
        assert rev is not None

    def test_linear_segmented_from_list(self):
        colors = ['navy', 'white', 'firebrick']
        cmap = cm.LinearSegmentedColormap.from_list('my_cmap', colors)
        c_low = cmap(0.0)
        c_mid = cmap(0.5)
        c_high = cmap(1.0)
        assert c_low != c_high
        assert c_mid is not None

    def test_cmap_resampled(self):
        cmap = get_cmap('viridis')
        resampled = cmap.resampled(10)
        assert resampled is not None

    def test_listed_cmap_colors_property(self):
        colors = ['red', 'blue', 'green']
        cmap = cm.ListedColormap(colors)
        cs = cmap.colors
        assert len(cs) >= 1


# ------------------------------------------------------------------
# Ticker advanced tests
# ------------------------------------------------------------------

class TestTickerAdvanced:
    def test_scalar_formatter_format_data(self):
        f = ScalarFormatter()
        result = f.format_data(1234.5)
        assert result is not None

    def test_scalar_formatter_format_data_short(self):
        f = ScalarFormatter()
        result = f.format_data_short(1234.5)
        assert result is not None

    def test_log_formatter_labelonly_base(self):
        f = LogFormatter(base=10.0, labelOnlyBase=True)
        # Should format powers of 10
        r = f(100.0, 0)
        assert r is not None

    def test_func_formatter_custom(self):
        f = FuncFormatter(lambda x, pos: f'{x:.0f} km')
        assert f(100, 0) == '100 km'
        assert f(250, 0) == '250 km'

    def test_null_formatter_always_empty(self):
        f = NullFormatter()
        for val in [0, 1, 100, -5, 3.14]:
            assert f(val) == ''

    def test_null_locator_empty(self):
        loc = NullLocator()
        assert loc.tick_values(-100, 100) == []
        assert loc() == []

    def test_max_n_locator_view_limits(self):
        loc = MaxNLocator(nbins=5)
        vmin, vmax = loc.view_limits(0, 100)
        assert vmin <= 0
        assert vmax >= 100

    def test_multiple_locator_view_limits(self):
        loc = MultipleLocator(base=5)
        vmin, vmax = loc.view_limits(0, 100)
        assert vmin % 5 == 0 or abs(vmin % 5) < 1e-10
        assert vmax % 5 == 0 or abs(vmax % 5) < 1e-10

    def test_log_locator_numticks(self):
        loc = LogLocator(base=10, numticks=15)
        ticks = loc.tick_values(1, 1e10)
        assert len(ticks) >= 5

    def test_auto_minor_locator_ticks(self):
        from matplotlib.ticker import AutoMinorLocator
        loc = AutoMinorLocator(n=5)
        ticks = loc.tick_values(0, 10)
        assert isinstance(ticks, list)


# ------------------------------------------------------------------
# Bar label advanced
# ------------------------------------------------------------------

class TestBarLabelAdvanced:
    def test_bar_label_with_labels_list(self):
        fig, ax = plt.subplots()
        bc = ax.bar([0, 1, 2], [3, 5, 2])
        labels = ax.bar_label(bc, labels=['A', 'B', 'C'])
        assert len(labels) == 3
        assert labels[0].get_text() == 'A'
        assert labels[1].get_text() == 'B'

    def test_bar_label_label_type_center(self):
        fig, ax = plt.subplots()
        bc = ax.bar([0, 1, 2], [3, 5, 2])
        labels = ax.bar_label(bc, label_type='center')
        assert len(labels) == 3

    def test_bar_label_fontsize(self):
        fig, ax = plt.subplots()
        bc = ax.bar([0, 1, 2], [3, 5, 2])
        labels = ax.bar_label(bc, fontsize=10)
        assert len(labels) == 3

    def test_bar_label_color(self):
        fig, ax = plt.subplots()
        bc = ax.bar([0, 1, 2], [3, 5, 2])
        labels = ax.bar_label(bc, color='red')
        assert len(labels) == 3


# ------------------------------------------------------------------
# Figure and axes misc tests
# ------------------------------------------------------------------

class TestFigureAxesMisc:
    def test_figure_number(self):
        fig = plt.figure(num=42)
        assert fig.number == 42
        plt.close(42)

    def test_figure_label_num(self):
        fig = plt.figure()
        assert fig.number >= 1
        plt.close('all')

    def test_axes_has_lines(self):
        fig, ax = plt.subplots()
        assert isinstance(ax.lines, list)

    def test_axes_has_patches(self):
        fig, ax = plt.subplots()
        assert isinstance(ax.patches, list)

    def test_axes_has_collections(self):
        fig, ax = plt.subplots()
        assert isinstance(ax.collections, list)

    def test_axes_has_texts(self):
        fig, ax = plt.subplots()
        assert isinstance(ax.texts, list)

    def test_axes_has_images(self):
        fig, ax = plt.subplots()
        assert isinstance(ax.images, list)

    def test_axes_has_containers(self):
        fig, ax = plt.subplots()
        assert isinstance(ax.containers, list)

    def test_bar_container_in_containers(self):
        fig, ax = plt.subplots()
        bc = ax.bar([0, 1, 2], [3, 5, 2])
        assert bc in ax.containers

    def test_errorbar_container_in_containers(self):
        fig, ax = plt.subplots()
        ec = ax.errorbar([0, 1], [0, 1], yerr=[0.1, 0.1])
        assert ec in ax.containers

    def test_stem_container_in_containers(self):
        fig, ax = plt.subplots()
        sc = ax.stem([0, 1, 2], [1, 2, 1])
        assert sc in ax.containers

    def test_text_in_ax_texts(self):
        fig, ax = plt.subplots()
        t = ax.text(0.5, 0.5, 'hello')
        assert t in ax.texts

    def test_patch_in_ax_patches(self):
        fig, ax = plt.subplots()
        r = Rectangle((0, 0), 1, 1)
        ax.add_patch(r)
        assert r in ax.patches

    def test_line_in_ax_lines(self):
        fig, ax = plt.subplots()
        line, = ax.plot([0, 1], [0, 1])
        assert line in ax.lines

    def test_imshow_in_ax_images(self):
        fig, ax = plt.subplots()
        im = ax.imshow([[1, 2], [3, 4]])
        assert im in ax.images

    def test_multiple_subplots_figure_axes(self):
        fig, axes = plt.subplots(2, 3)
        all_ax = fig.get_axes()
        assert len(all_ax) == 6

    def test_add_subplot_numbered(self):
        fig = Figure()
        ax1 = fig.add_subplot(3, 1, 1)
        ax2 = fig.add_subplot(3, 1, 2)
        ax3 = fig.add_subplot(3, 1, 3)
        assert len(fig.get_axes()) == 3


# ------------------------------------------------------------------
# Histogram stacked/step tests
# ------------------------------------------------------------------

class TestHistogramVariants:
    def test_hist_stacked(self):
        fig, ax = plt.subplots()
        data1 = [1, 2, 3, 4]
        data2 = [2, 3, 4, 5]
        result = ax.hist([data1, data2], bins=4, stacked=True)
        assert result is not None

    def test_hist_step(self):
        fig, ax = plt.subplots()
        data = [1, 2, 2, 3, 3, 3, 4]
        n, bins, patches = ax.hist(data, bins=4, histtype='step')
        assert len(n) == 4

    def test_hist_stepfilled(self):
        fig, ax = plt.subplots()
        data = [1, 2, 2, 3, 3, 3, 4]
        n, bins, patches = ax.hist(data, bins=4, histtype='stepfilled')
        assert len(n) == 4

    def test_hist_bar(self):
        fig, ax = plt.subplots()
        data = [1, 2, 2, 3, 3, 3, 4]
        n, bins, patches = ax.hist(data, bins=4, histtype='bar')
        assert len(n) == 4

    def test_hist_barstacked(self):
        fig, ax = plt.subplots()
        data = [[1, 2, 3], [2, 3, 4]]
        result = ax.hist(data, bins=4, histtype='barstacked')
        assert result is not None

    def test_hist_weights(self):
        fig, ax = plt.subplots()
        data = [1, 2, 3, 4, 5]
        weights = [1, 2, 3, 2, 1]
        n, bins, patches = ax.hist(data, bins=4, weights=weights)
        assert len(n) == 4

    def test_hist_cumulative(self):
        fig, ax = plt.subplots()
        data = [1, 2, 3, 4, 5]
        n, bins, patches = ax.hist(data, bins=5, cumulative=True)
        # Cumulative should be monotonically increasing
        for i in range(1, len(n)):
            assert n[i] >= n[i-1]

    def test_hist_align_left(self):
        fig, ax = plt.subplots()
        data = [1, 2, 2, 3, 3, 3]
        n, bins, patches = ax.hist(data, bins=3, align='left')
        assert len(n) == 3

    def test_hist_color(self):
        fig, ax = plt.subplots()
        data = [1, 2, 3]
        n, bins, patches = ax.hist(data, bins=3, color='red')
        assert n is not None
