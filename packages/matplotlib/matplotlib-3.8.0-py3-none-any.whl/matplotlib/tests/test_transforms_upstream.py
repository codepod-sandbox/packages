"""Tests for matplotlib.transforms — Transform system."""

import pytest
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.transforms as transforms


class TestBasicTransforms:
    def test_transform_module_importable(self):
        import matplotlib.transforms as t
        assert t is not None

    def test_blended_transform_factory(self):
        fig, ax = plt.subplots()
        t = transforms.blended_transform_factory(ax.transAxes, ax.transData)
        assert t is not None
        plt.close('all')

    def test_transform_transData_exists(self):
        fig, ax = plt.subplots()
        assert ax.transData is not None
        plt.close('all')

    def test_transform_transAxes_exists(self):
        fig, ax = plt.subplots()
        assert ax.transAxes is not None
        plt.close('all')

    def test_offset_copy(self):
        fig, ax = plt.subplots()
        t = transforms.offset_copy(ax.transData, fig=fig, x=10, y=10, units='points')
        assert t is not None
        plt.close('all')

    def test_transform_classes_exist(self):
        assert hasattr(transforms, 'Transform') or hasattr(transforms, 'Bbox')


class TestBbox:
    def test_bbox_from_extents(self):
        bbox = transforms.Bbox.from_extents(0, 0, 1, 1)
        assert bbox is not None

    def test_bbox_attributes(self):
        bbox = transforms.Bbox([[0, 0], [1, 1]])
        assert bbox.x0 == 0
        assert bbox.y0 == 0
        assert bbox.x1 == 1
        assert bbox.y1 == 1

    def test_bbox_width_height(self):
        bbox = transforms.Bbox([[1, 2], [4, 6]])
        assert bbox.width == 3
        assert bbox.height == 4

    def test_bbox_from_bounds(self):
        bbox = transforms.Bbox.from_bounds(1, 2, 3, 4)
        assert bbox.x0 == 1
        assert bbox.y0 == 2
        assert bbox.width == 3
        assert bbox.height == 4

    def test_bbox_unit(self):
        bbox = transforms.Bbox.unit()
        assert bbox.x0 == 0
        assert bbox.y0 == 0
        assert bbox.x1 == 1
        assert bbox.y1 == 1

    def test_bbox_null(self):
        bbox = transforms.Bbox.null()
        assert bbox is not None

    def test_bbox_union(self):
        b1 = transforms.Bbox([[0, 0], [1, 1]])
        b2 = transforms.Bbox([[0.5, 0.5], [2, 2]])
        merged = transforms.Bbox.union([b1, b2])
        assert merged.x0 == 0
        assert merged.y0 == 0
        assert merged.x1 == 2
        assert merged.y1 == 2

    def test_bbox_contains(self):
        bbox = transforms.Bbox([[0, 0], [1, 1]])
        assert bbox.contains(0.5, 0.5)
        assert not bbox.contains(2.0, 0.5)

    def test_bbox_get_points(self):
        bbox = transforms.Bbox([[0, 0], [1, 1]])
        pts = bbox.get_points()
        assert len(pts) == 2

    def test_transformed_bbox(self):
        fig, ax = plt.subplots()
        bbox = transforms.Bbox([[0, 0], [1, 1]])
        tb = transforms.TransformedBbox(bbox, ax.transAxes)
        assert tb is not None
        plt.close('all')


class TestTransformUsage:
    def test_text_with_transaxes(self):
        fig, ax = plt.subplots()
        ax.text(0.5, 0.5, 'center', transform=ax.transAxes)
        plt.close('all')

    def test_axhline_uses_transform(self):
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3])
        ax.axhline(y=1.5)
        plt.close('all')

    def test_annotation_transaxes(self):
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3])
        ax.annotate('test', xy=(1, 1), xytext=(0.5, 0.9),
                    textcoords='axes fraction',
                    arrowprops=dict(arrowstyle='->'))
        plt.close('all')

    def test_scatter_with_transform(self):
        fig, ax = plt.subplots()
        ax.scatter([0.5], [0.5], transform=ax.transAxes)
        plt.close('all')
