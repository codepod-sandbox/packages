"""Tests for text formatting, fonts, alignment, and annotations."""

import pytest
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.text as mtext


# ---------------------------------------------------------------------------
# Text properties
# ---------------------------------------------------------------------------

class TestTextProperties:
    def test_text_fontsize(self):
        """Text with fontsize does not raise."""
        fig, ax = plt.subplots()
        t = ax.text(0.5, 0.5, 'hello', fontsize=14)
        assert t is not None
        plt.close('all')

    def test_text_fontweight(self):
        """Text with fontweight='bold' does not raise."""
        fig, ax = plt.subplots()
        t = ax.text(0.5, 0.5, 'bold', fontweight='bold')
        assert t is not None
        plt.close('all')

    def test_text_fontstyle_italic(self):
        """Text with fontstyle='italic' does not raise."""
        fig, ax = plt.subplots()
        t = ax.text(0.5, 0.5, 'italic', fontstyle='italic')
        assert t is not None
        plt.close('all')

    def test_text_color(self):
        """Text with color does not raise."""
        fig, ax = plt.subplots()
        t = ax.text(0.5, 0.5, 'colored', color='red')
        assert t is not None
        plt.close('all')

    def test_text_ha_va(self):
        """Text with horizontalalignment and verticalalignment does not raise."""
        fig, ax = plt.subplots()
        t = ax.text(0.5, 0.5, 'centered',
                    horizontalalignment='center',
                    verticalalignment='center')
        assert t is not None
        plt.close('all')

    def test_text_rotation(self):
        """Text with rotation does not raise."""
        fig, ax = plt.subplots()
        t = ax.text(0.5, 0.5, 'rotated', rotation=45)
        assert t is not None
        plt.close('all')

    def test_text_alpha(self):
        """Text with alpha does not raise."""
        fig, ax = plt.subplots()
        t = ax.text(0.5, 0.5, 'faded', alpha=0.5)
        assert t is not None
        plt.close('all')

    def test_text_bbox(self):
        """Text with bbox does not raise."""
        fig, ax = plt.subplots()
        t = ax.text(0.5, 0.5, 'boxed',
                    bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
        assert t is not None
        plt.close('all')

    def test_text_transform_axes(self):
        """Text with transform=ax.transAxes does not raise."""
        fig, ax = plt.subplots()
        t = ax.text(0.5, 0.5, 'axes coords', transform=ax.transAxes)
        assert t is not None
        plt.close('all')

    def test_text_get_text(self):
        """Text.get_text returns the string."""
        fig, ax = plt.subplots()
        t = ax.text(0.5, 0.5, 'hello world')
        assert t.get_text() == 'hello world'
        plt.close('all')

    def test_text_set_text(self):
        """Text.set_text updates the string."""
        fig, ax = plt.subplots()
        t = ax.text(0.5, 0.5, 'original')
        t.set_text('updated')
        assert t.get_text() == 'updated'
        plt.close('all')


# ---------------------------------------------------------------------------
# plt.text wrapper
# ---------------------------------------------------------------------------

class TestPltText:
    def test_plt_text_basic(self):
        """plt.text() does not raise."""
        plt.figure()
        plt.text(0.5, 0.5, 'hello')
        plt.close('all')

    def test_plt_text_fontsize(self):
        """plt.text() with fontsize does not raise."""
        plt.figure()
        plt.text(0.5, 0.5, 'big', fontsize=20)
        plt.close('all')


# ---------------------------------------------------------------------------
# Title and axis labels
# ---------------------------------------------------------------------------

class TestTitleLabels:
    def test_set_title_fontsize(self):
        """set_title with fontsize does not raise."""
        fig, ax = plt.subplots()
        ax.set_title('My Plot', fontsize=16)
        plt.close('all')

    def test_set_title_fontweight(self):
        """set_title with fontweight does not raise."""
        fig, ax = plt.subplots()
        ax.set_title('Bold Title', fontweight='bold')
        plt.close('all')

    def test_set_xlabel_fontsize(self):
        """set_xlabel with fontsize does not raise."""
        fig, ax = plt.subplots()
        ax.set_xlabel('X axis', fontsize=12)
        plt.close('all')

    def test_set_ylabel_fontsize(self):
        """set_ylabel with fontsize does not raise."""
        fig, ax = plt.subplots()
        ax.set_ylabel('Y axis', fontsize=12)
        plt.close('all')

    def test_suptitle(self):
        """fig.suptitle() does not raise."""
        fig, axes = plt.subplots(1, 2)
        fig.suptitle('Figure Title')
        plt.close('all')

    def test_suptitle_fontsize(self):
        """fig.suptitle() with fontsize does not raise."""
        fig, axes = plt.subplots(1, 2)
        fig.suptitle('Big Title', fontsize=18)
        plt.close('all')

    def test_plt_suptitle(self):
        """plt.suptitle() wrapper does not raise."""
        fig, axes = plt.subplots(1, 2)
        plt.suptitle('Title')
        plt.close('all')


# ---------------------------------------------------------------------------
# Tick labels
# ---------------------------------------------------------------------------

class TestTickLabels:
    def test_set_xticklabels(self):
        """set_xticklabels does not raise."""
        fig, ax = plt.subplots()
        ax.set_xticks([0, 1, 2, 3])
        ax.set_xticklabels(['a', 'b', 'c', 'd'])
        plt.close('all')

    def test_set_yticklabels(self):
        """set_yticklabels does not raise."""
        fig, ax = plt.subplots()
        ax.set_yticks([0, 1, 2, 3])
        ax.set_yticklabels(['w', 'x', 'y', 'z'])
        plt.close('all')

    def test_set_xticklabels_rotation(self):
        """set_xticklabels with rotation does not raise."""
        fig, ax = plt.subplots()
        ax.set_xticks([0, 1, 2])
        ax.set_xticklabels(['label1', 'label2', 'label3'], rotation=45)
        plt.close('all')

    def test_tick_params_labelsize(self):
        """tick_params with labelsize does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        ax.tick_params(labelsize=8)
        plt.close('all')

    def test_tick_params_axis_x(self):
        """tick_params with axis='x' does not raise."""
        fig, ax = plt.subplots()
        ax.tick_params(axis='x', rotation=30)
        plt.close('all')

    def test_tick_params_axis_y(self):
        """tick_params with axis='y' does not raise."""
        fig, ax = plt.subplots()
        ax.tick_params(axis='y', labelsize=10)
        plt.close('all')

    def test_tick_params_direction(self):
        """tick_params with direction does not raise."""
        fig, ax = plt.subplots()
        ax.tick_params(direction='in')
        plt.close('all')

    def test_tick_params_length(self):
        """tick_params with length does not raise."""
        fig, ax = plt.subplots()
        ax.tick_params(length=8)
        plt.close('all')

    def test_plt_xticks_labels(self):
        """plt.xticks() with labels does not raise."""
        plt.figure()
        plt.plot([0, 1, 2], [3, 1, 4])
        plt.xticks([0, 1, 2], ['zero', 'one', 'two'])
        plt.close('all')

    def test_plt_yticks_labels(self):
        """plt.yticks() with labels does not raise."""
        plt.figure()
        plt.plot([0, 1, 2], [3, 1, 4])
        plt.yticks([1, 3, 4], ['low', 'mid', 'high'])
        plt.close('all')
