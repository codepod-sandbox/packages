"""Upstream-style test batch 6: additional coverage for 500+ new test target."""

import math
import pytest
from matplotlib.tests._approx import approx

from matplotlib.figure import Figure
from matplotlib.colors import (
    Normalize, LogNorm, TwoSlopeNorm, BoundaryNorm,
    PowerNorm, SymLogNorm, NoNorm,
    to_rgba, to_hex, to_rgb, is_color_like, same_color,
    to_rgba_array, _has_alpha_channel,
    CSS4_COLORS, TABLEAU_COLORS, BASE_COLORS, DEFAULT_CYCLE,
    _colors_full_map, _CallbackRegistry,
)
from matplotlib.cm import (
    Colormap, ListedColormap, LinearSegmentedColormap, get_cmap,
    ScalarMappable, register_cmap, _colormaps,
)
from matplotlib.ticker import (
    Locator, Formatter,
    NullLocator, FixedLocator, MaxNLocator, AutoLocator,
    MultipleLocator, LogLocator, LinearLocator, IndexLocator,
    AutoMinorLocator, SymmetricalLogLocator,
    NullFormatter, FixedFormatter, FuncFormatter, FormatStrFormatter,
    StrMethodFormatter, ScalarFormatter, PercentFormatter, LogFormatter,
)
from matplotlib.text import Text, Annotation
from matplotlib.cycler import cycler, Cycler
from matplotlib.artist import Artist


# ===================================================================
# CSS4 and named color coverage
# ===================================================================

class TestNamedColors:
    def test_all_css4_are_valid(self):
        for name in CSS4_COLORS:
            assert is_color_like(name), f"{name} not recognized"

    def test_all_tableau_are_valid(self):
        for name in TABLEAU_COLORS:
            assert is_color_like(name), f"{name} not recognized"

    def test_all_base_are_valid(self):
        for name in BASE_COLORS:
            assert is_color_like(name), f"{name} not recognized"

    def test_cn_colors_0_to_9(self):
        for i in range(10):
            assert is_color_like(f'C{i}')

    def test_cn_wraps(self):
        # C10 should work by wrapping
        rgba = to_rgba('C10')
        assert rgba == to_rgba('C0')

    def test_css4_count(self):
        assert len(CSS4_COLORS) > 140

    def test_tableau_count(self):
        assert len(TABLEAU_COLORS) == 10

    def test_base_count(self):
        assert len(BASE_COLORS) == 8

    def test_default_cycle_count(self):
        assert len(DEFAULT_CYCLE) == 10

    def test_colors_full_map_has_grey_gray(self):
        assert 'gray' in _colors_full_map
        assert 'grey' in _colors_full_map


# ===================================================================
# CallbackRegistry tests
# ===================================================================

class TestCallbackRegistry:
    def test_connect_and_process(self):
        reg = _CallbackRegistry()
        results = []
        reg.connect('signal', lambda: results.append(1))
        reg.process('signal')
        assert results == [1]

    def test_disconnect(self):
        reg = _CallbackRegistry()
        results = []
        cid = reg.connect('signal', lambda: results.append(1))
        reg.disconnect(cid)
        reg.process('signal')
        assert results == []

    def test_multiple_callbacks(self):
        reg = _CallbackRegistry()
        results = []
        reg.connect('sig', lambda: results.append('a'))
        reg.connect('sig', lambda: results.append('b'))
        reg.process('sig')
        assert len(results) == 2

    def test_different_signals(self):
        reg = _CallbackRegistry()
        results = []
        reg.connect('sig1', lambda: results.append('a'))
        reg.connect('sig2', lambda: results.append('b'))
        reg.process('sig1')
        assert results == ['a']


# ===================================================================
# Artist base class tests
# ===================================================================

class TestArtistExtended:
    def test_artist_default_visible(self):
        a = Artist()
        assert a.get_visible() is True

    def test_artist_set_visible(self):
        a = Artist()
        a.set_visible(False)
        assert a.get_visible() is False

    def test_artist_alpha(self):
        a = Artist()
        assert a.get_alpha() is None
        a.set_alpha(0.5)
        assert a.get_alpha() == 0.5

    def test_artist_label(self):
        a = Artist()
        a.set_label('test')
        assert a.get_label() == 'test'

    def test_artist_label_none(self):
        a = Artist()
        a.set_label(None)
        assert a.get_label() == '_nolegend_'

    def test_artist_zorder(self):
        a = Artist()
        a.set_zorder(10)
        assert a.get_zorder() == 10

    def test_artist_set_batch(self):
        a = Artist()
        a.set(visible=False, alpha=0.3)
        assert a.get_visible() is False
        assert a.get_alpha() == 0.3

    def test_artist_update(self):
        a = Artist()
        a.update({'visible': False, 'alpha': 0.7})
        assert a.get_visible() is False
        assert a.get_alpha() == 0.7

    def test_artist_update_none(self):
        a = Artist()
        a.update(None)  # should not raise

    def test_artist_stale(self):
        a = Artist()
        assert a.stale is True
        a.stale = False
        assert a.stale is False

    def test_artist_pchanged(self):
        a = Artist()
        a.stale = False
        a.pchanged()
        assert a.stale is True

    def test_artist_clip_on(self):
        a = Artist()
        a.set_clip_on(False)
        assert a.get_clip_on() is False

    def test_artist_animated(self):
        a = Artist()
        assert a.get_animated() is False
        a.set_animated(True)
        assert a.get_animated() is True

    def test_artist_rasterized(self):
        a = Artist()
        assert a.get_rasterized() is None
        a.set_rasterized(True)
        assert a.get_rasterized() is True

    def test_artist_url(self):
        a = Artist()
        assert a.get_url() is None
        a.set_url('http://example.com')
        assert a.get_url() == 'http://example.com'

    def test_artist_gid(self):
        a = Artist()
        assert a.get_gid() is None
        a.set_gid('my_id')
        assert a.get_gid() == 'my_id'

    def test_artist_picker(self):
        a = Artist()
        assert a.get_picker() is None
        assert a.pickable() is False
        a.set_picker(True)
        assert a.pickable() is True

    def test_artist_in_layout(self):
        a = Artist()
        assert a.get_in_layout() is True
        a.set_in_layout(False)
        assert a.get_in_layout() is False

    def test_artist_snap(self):
        a = Artist()
        assert a.get_snap() is None
        a.set_snap(True)
        assert a.get_snap() is True

    def test_artist_sketch_params(self):
        a = Artist()
        assert a.get_sketch_params() is None
        a.set_sketch_params(scale=5)
        params = a.get_sketch_params()
        assert params[0] == 5

    def test_artist_sketch_params_none(self):
        a = Artist()
        a.set_sketch_params(scale=5)
        a.set_sketch_params()  # reset
        assert a.get_sketch_params() is None

    def test_artist_path_effects(self):
        a = Artist()
        assert a.get_path_effects() == []
        a.set_path_effects(['effect1'])
        assert a.get_path_effects() == ['effect1']

    def test_artist_transform(self):
        a = Artist()
        assert a.get_transform() is None
        assert a.is_transform_set() is False
        a.set_transform('mock_transform')
        assert a.is_transform_set() is True

    def test_artist_properties(self):
        a = Artist()
        props = a.properties()
        assert isinstance(props, dict)
        assert 'visible' in props

    def test_artist_findobj_all(self):
        a = Artist()
        found = a.findobj()
        assert a in found

    def test_artist_findobj_by_type(self):
        a = Artist()
        found = a.findobj(Artist)
        assert a in found

    def test_artist_figure(self):
        a = Artist()
        assert a.get_figure() is None
        fig = Figure()
        a.set_figure(fig)
        assert a.get_figure() is fig


# ===================================================================
# Colormap base class tests
# ===================================================================

class TestColormapBase:
    def test_colormap_abstract_map(self):
        """Base Colormap maps to grayscale by default."""
        cmap = Colormap('test_base', N=100)
        rgba = cmap(0.5)
        assert rgba == approx((0.5, 0.5, 0.5, 1.0))

    def test_colormap_repr(self):
        cmap = Colormap('test', N=100)
        r = repr(cmap)
        assert 'Colormap' in r

    def test_colormap_eq_same(self):
        a = Colormap('test', N=100)
        b = Colormap('test', N=100)
        assert a == b

    def test_colormap_ne_name(self):
        a = Colormap('a', N=100)
        b = Colormap('b', N=100)
        assert a != b

    def test_colormap_ne_N(self):
        a = Colormap('test', N=100)
        b = Colormap('test', N=200)
        assert a != b

    def test_colormap_ne_type(self):
        a = Colormap('test', N=100)
        assert a != 42

    def test_colormap_set_bad(self):
        cmap = Colormap('test')
        cmap.set_bad('red')
        bad = cmap.get_bad()
        assert bad[0] > 0.9

    def test_colormap_set_under(self):
        cmap = Colormap('test')
        cmap.set_under('blue')
        under = cmap.get_under()
        assert under[2] > 0.9

    def test_colormap_set_over(self):
        cmap = Colormap('test')
        cmap.set_over('green', alpha=0.5)
        over = cmap.get_over()
        assert over[1] > 0.4
        assert over[3] == approx(0.5)

    def test_colormap_resampled(self):
        cmap = Colormap('test', N=256)
        resampled = cmap.resampled(10)
        assert resampled.N == 10


# ===================================================================
# More ScalarMappable tests
# ===================================================================

class TestScalarMappableDetailed:
    def test_sm_no_norm(self):
        sm = ScalarMappable(norm=None)
        assert sm.norm is None

    def test_sm_norm_setter_none(self):
        sm = ScalarMappable()
        sm.norm = None
        assert isinstance(sm.norm, Normalize)

    def test_sm_cmap_string(self):
        sm = ScalarMappable()
        sm.cmap = 'hot'
        assert sm.cmap.name == 'hot'

    def test_sm_get_clim_no_norm(self):
        sm = ScalarMappable(norm=None)
        vmin, vmax = sm.get_clim()
        assert vmin is None
        assert vmax is None

    def test_sm_set_clim_creates_norm(self):
        sm = ScalarMappable(norm=None)
        sm.set_clim(0, 10)
        assert sm.norm is not None
        assert sm.norm.vmin == 0

    def test_sm_autoscale_none(self):
        sm = ScalarMappable(norm=Normalize(vmin=5))
        sm.set_array([1, 2, 3, 10])
        sm.autoscale_None()
        assert sm.norm.vmin == 5  # not changed
        assert sm.norm.vmax == 10

    def test_sm_to_rgba_no_norm(self):
        sm = ScalarMappable(norm=Normalize(0, 1), cmap='gray')
        rgba = sm.to_rgba(0.5, norm=False)
        # Without normalization, 0.5 should be passed directly to cmap
        assert len(rgba) == 4

    def test_sm_to_rgba_alpha(self):
        sm = ScalarMappable(norm=Normalize(0, 1), cmap='gray')
        rgba = sm.to_rgba(0.5, alpha=0.3)
        assert rgba[3] == approx(0.3)


# ===================================================================
# BoundaryNorm detailed
# ===================================================================

class TestBoundaryNormDetailed:
    def test_two_boundaries(self):
        norm = BoundaryNorm([0, 1], ncolors=1)
        result = norm(0.5)
        assert isinstance(result, float)

    def test_many_boundaries(self):
        boundaries = [i * 0.1 for i in range(11)]
        norm = BoundaryNorm(boundaries, ncolors=10)
        for v in [0.05, 0.15, 0.25, 0.55, 0.95]:
            result = norm(v)
            assert 0 <= result <= 1

    def test_clip_above(self):
        norm = BoundaryNorm([0, 1, 2], ncolors=2, clip=True)
        result = norm(5)
        assert 0 <= result <= 1

    def test_ncolors_property(self):
        norm = BoundaryNorm([0, 5, 10], ncolors=100)
        assert norm.Ncmap == 100


# ===================================================================
# MaxNLocator detailed
# ===================================================================

class TestMaxNLocatorDetailed:
    def test_integer_mode(self):
        loc = MaxNLocator(integer=True, nbins=5)
        ticks = loc.tick_values(0.5, 9.5)
        for t in ticks:
            assert t == int(t), f"Expected integer tick, got {t}"

    def test_reversed_range(self):
        loc = MaxNLocator(nbins=5)
        ticks = loc.tick_values(10, 0)
        assert len(ticks) >= 2

    def test_zero_to_zero(self):
        loc = MaxNLocator(nbins=5)
        ticks = loc.tick_values(0, 0)
        assert len(ticks) >= 2

    def test_very_small_range(self):
        loc = MaxNLocator(nbins=5)
        ticks = loc.tick_values(1e-15, 2e-15)
        assert len(ticks) >= 2

    def test_custom_steps(self):
        loc = MaxNLocator(steps=[1, 2, 5, 10], nbins=5)
        ticks = loc.tick_values(0, 100)
        # Step should be from the given steps
        if len(ticks) >= 3:
            step = ticks[1] - ticks[0]
            assert step > 0


# ===================================================================
# Formatter detailed
# ===================================================================

class TestFormatterDetailed:
    def test_fixed_formatter_many(self):
        labels = [f'label_{i}' for i in range(20)]
        fmt = FixedFormatter(labels)
        for i in range(20):
            assert fmt(0, pos=i) == f'label_{i}'

    def test_func_formatter_none_pos(self):
        fmt = FuncFormatter(lambda x, pos: f'{x}')
        assert fmt(42, pos=None) == '42'

    def test_percent_zero_decimals(self):
        fmt = PercentFormatter(decimals=0)
        result = fmt(33.3)
        assert result == '33%'

    def test_log_formatter_power_of_ten(self):
        fmt = LogFormatter(base=10)
        result = fmt(10000)
        assert '4' in result  # 10^4

    def test_scalar_formatter_large(self):
        fmt = ScalarFormatter()
        result = fmt(1e6)
        assert '1' in result
