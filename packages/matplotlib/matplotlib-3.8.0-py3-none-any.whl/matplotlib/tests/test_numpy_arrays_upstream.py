"""Tests for numpy array integration, meshgrid, linspace patterns LLMs use."""

import pytest
import numpy as np
import matplotlib.pyplot as plt


# ---------------------------------------------------------------------------
# linspace / arange patterns
# ---------------------------------------------------------------------------

class TestLinspacePatterns:
    def test_linspace_plot(self):
        """np.linspace with plot does not raise."""
        fig, ax = plt.subplots()
        x = np.linspace(0, 10, 100)
        y = np.sin(x)
        ax.plot(x, y)
        plt.close('all')

    def test_arange_plot(self):
        """np.arange with plot does not raise."""
        fig, ax = plt.subplots()
        x = np.arange(0, 10, 0.1)
        y = np.cos(x)
        ax.plot(x, y)
        plt.close('all')

    def test_multiple_linspace_functions(self):
        """Multiple trig functions plotted together."""
        fig, ax = plt.subplots()
        x = np.linspace(0, 2 * np.pi, 200)
        ax.plot(x, np.sin(x), label='sin')
        ax.plot(x, np.cos(x), label='cos')
        ax.plot(x, np.sin(2 * x), label='sin(2x)')
        ax.legend()
        plt.close('all')

    def test_polynomial_plot(self):
        """Polynomial from numpy array does not raise."""
        fig, ax = plt.subplots()
        x = np.linspace(-3, 3, 100)
        y = x**3 - 3 * x**2 + 2
        ax.plot(x, y)
        plt.close('all')

    def test_exponential_plot(self):
        """Exponential function plots correctly."""
        fig, ax = plt.subplots()
        x = np.linspace(0, 3, 50)
        ax.plot(x, np.exp(x), label='e^x')
        ax.plot(x, np.exp(-x), label='e^-x')
        plt.close('all')


# ---------------------------------------------------------------------------
# meshgrid / 2D array operations
# ---------------------------------------------------------------------------

class TestMeshgridPatterns:
    def test_meshgrid_imshow(self):
        """meshgrid data shown with imshow does not raise."""
        x = np.linspace(-2, 2, 20)
        y = np.linspace(-2, 2, 20)
        X, Y = np.meshgrid(x, y)
        Z = np.sin(X) * np.cos(Y)
        fig, ax = plt.subplots()
        ax.imshow(Z, cmap='viridis')
        plt.close('all')

    def test_meshgrid_pcolormesh(self):
        """meshgrid data shown with pcolormesh does not raise."""
        x = np.linspace(0, 5, 10)
        y = np.linspace(0, 5, 10)
        X, Y = np.meshgrid(x, y)
        Z = X + Y
        fig, ax = plt.subplots()
        ax.pcolormesh(X, Y, Z)
        plt.close('all')

    def test_2d_array_as_image(self):
        """2D numpy array as image does not raise."""
        fig, ax = plt.subplots()
        data = np.random.default_rng(42).random((20, 20))
        ax.imshow(data, cmap='hot')
        plt.close('all')

    def test_3d_array_rgb_image(self):
        """3D numpy array (H x W x 3) shown as RGB image."""
        fig, ax = plt.subplots()
        rgb = np.zeros((10, 10, 3))
        rgb[:, :, 0] = 1.0  # red channel
        ax.imshow(rgb)
        plt.close('all')

    def test_3d_array_rgba_image(self):
        """3D numpy array (H x W x 4) shown as RGBA image."""
        fig, ax = plt.subplots()
        rgba = np.ones((10, 10, 4))
        rgba[:, :, 3] = 0.5  # alpha
        ax.imshow(rgba)
        plt.close('all')


# ---------------------------------------------------------------------------
# Statistical operations with numpy
# ---------------------------------------------------------------------------

class TestStatisticalPlots:
    def test_histogram_numpy(self):
        """hist with numpy array does not raise."""
        rng = np.random.default_rng(42)
        data = rng.normal(0, 1, 200)
        fig, ax = plt.subplots()
        ax.hist(data)
        plt.close('all')

    def test_scatter_numpy(self):
        """scatter with numpy arrays does not raise."""
        rng = np.random.default_rng(42)
        x = rng.random(50)
        y = rng.random(50)
        c = rng.random(50)
        fig, ax = plt.subplots()
        ax.scatter(x, y, c=c, cmap='viridis')
        plt.close('all')

    def test_bar_numpy(self):
        """bar with numpy arrays does not raise."""
        x = np.arange(5)
        heights = np.array([3.2, 1.5, 4.7, 2.1, 3.8])
        fig, ax = plt.subplots()
        ax.bar(x, heights)
        plt.close('all')

    def test_errorbar_numpy_arrays(self):
        """errorbar with numpy error arrays does not raise."""
        x = np.arange(5)
        y = np.array([2.0, 3.0, 2.5, 4.0, 3.5])
        yerr = np.array([0.2, 0.3, 0.1, 0.4, 0.2])
        fig, ax = plt.subplots()
        ax.errorbar(x, y, yerr=yerr)
        plt.close('all')

    def test_fill_between_numpy(self):
        """fill_between with numpy arrays does not raise."""
        x = np.linspace(0, 2 * np.pi, 100)
        y1 = np.sin(x)
        y2 = np.sin(x) + 0.5
        fig, ax = plt.subplots()
        ax.fill_between(x, y1, y2, alpha=0.3)
        plt.close('all')


# ---------------------------------------------------------------------------
# Slicing and indexing
# ---------------------------------------------------------------------------

class TestArraySlicingPlots:
    def test_plot_array_slice(self):
        """Plotting a slice of a numpy array does not raise."""
        data = np.arange(100).reshape(10, 10)
        fig, ax = plt.subplots()
        ax.plot(data[0, :])   # first row
        ax.plot(data[:, 0])   # first column
        plt.close('all')

    def test_imshow_slice(self):
        """imshow with a 2D slice of a 3D array does not raise."""
        data = np.ones((5, 10, 3))
        fig, ax = plt.subplots()
        ax.imshow(data[:, :, 0])
        plt.close('all')

    def test_contourf_computed_grid(self):
        """contourf with a computed numpy grid does not raise."""
        x = np.linspace(-np.pi, np.pi, 30)
        y = np.linspace(-np.pi, np.pi, 30)
        X, Y = np.meshgrid(x, y)
        Z = np.sin(X) * np.sin(Y)
        fig, ax = plt.subplots()
        ax.contourf(X, Y, Z, cmap='RdBu')
        plt.close('all')

    def test_plot_boolean_mask(self):
        """Plotting with a boolean mask does not raise."""
        x = np.linspace(0, 10, 100)
        y = np.sin(x)
        mask = y > 0
        fig, ax = plt.subplots()
        ax.plot(x[mask], y[mask], 'r.')  # only positive values
        plt.close('all')
