"""Tests for hexbin, violinplot, and related plot types used by LLMs."""

import pytest
import numpy as np
import matplotlib.pyplot as plt


class TestHexbin:
    def test_hexbin_basic(self):
        """ax.hexbin() with x, y data."""
        fig, ax = plt.subplots()
        x = [1.0, 2.0, 3.0, 1.5, 2.5, 3.5, 1.0, 2.0]
        y = [1.0, 2.0, 3.0, 1.5, 2.5, 3.5, 2.0, 3.0]
        hb = ax.hexbin(x, y)
        assert hb is not None
        plt.close('all')

    def test_hexbin_gridsize(self):
        """hexbin with gridsize."""
        fig, ax = plt.subplots()
        x = [1.0, 2.0, 3.0, 1.5, 2.5]
        y = [1.0, 2.0, 3.0, 1.5, 2.5]
        hb = ax.hexbin(x, y, gridsize=10)
        assert hb is not None
        plt.close('all')

    def test_hexbin_cmap(self):
        """hexbin with colormap."""
        fig, ax = plt.subplots()
        x = [1.0, 2.0, 3.0, 1.5, 2.5]
        y = [1.0, 2.0, 3.0, 1.5, 2.5]
        hb = ax.hexbin(x, y, cmap='Blues')
        assert hb is not None
        plt.close('all')

    def test_hexbin_mincnt(self):
        """hexbin with mincnt."""
        fig, ax = plt.subplots()
        x = [1.0, 2.0, 3.0, 1.5, 2.5, 1.0]
        y = [1.0, 2.0, 3.0, 1.5, 2.5, 1.0]
        hb = ax.hexbin(x, y, mincnt=1)
        assert hb is not None
        plt.close('all')

    def test_hexbin_colorbar(self):
        """hexbin + colorbar."""
        fig, ax = plt.subplots()
        x = [1.0, 2.0, 3.0, 1.5, 2.5]
        y = [1.0, 2.0, 3.0, 1.5, 2.5]
        hb = ax.hexbin(x, y)
        fig.colorbar(hb, ax=ax)
        plt.close('all')

    def test_plt_hexbin(self):
        """plt.hexbin() shortcut."""
        fig, ax = plt.subplots()
        x = [1.0, 2.0, 3.0]
        y = [1.0, 2.0, 3.0]
        hb = plt.hexbin(x, y)
        assert hb is not None
        plt.close('all')


class TestViolinplot:
    def test_violinplot_basic(self):
        """ax.violinplot() with dataset."""
        fig, ax = plt.subplots()
        data = [[1.0, 2.0, 3.0, 4.0, 5.0],
                [2.0, 3.0, 4.0, 5.0, 6.0],
                [1.5, 2.5, 3.5, 4.5, 5.5]]
        vp = ax.violinplot(data)
        assert vp is not None
        plt.close('all')

    def test_violinplot_single(self):
        """violinplot with single dataset."""
        fig, ax = plt.subplots()
        data = [1.0, 2.0, 3.0, 2.5, 1.5, 3.5, 2.0]
        vp = ax.violinplot(data)
        assert vp is not None
        plt.close('all')

    def test_violinplot_positions(self):
        """violinplot with positions."""
        fig, ax = plt.subplots()
        data = [[1.0, 2.0, 3.0], [2.0, 3.0, 4.0]]
        vp = ax.violinplot(data, positions=[1, 3])
        assert vp is not None
        plt.close('all')

    def test_violinplot_showmeans(self):
        """violinplot with showmeans."""
        fig, ax = plt.subplots()
        data = [1.0, 2.0, 3.0, 2.5]
        vp = ax.violinplot(data, showmeans=True)
        assert vp is not None
        plt.close('all')

    def test_violinplot_showmedians(self):
        """violinplot with showmedians."""
        fig, ax = plt.subplots()
        data = [1.0, 2.0, 3.0, 2.5]
        vp = ax.violinplot(data, showmedians=True)
        assert vp is not None
        plt.close('all')

    def test_violinplot_showextrema(self):
        """violinplot with showextrema=False."""
        fig, ax = plt.subplots()
        data = [1.0, 2.0, 3.0, 2.5]
        vp = ax.violinplot(data, showextrema=False)
        assert vp is not None
        plt.close('all')

    def test_plt_violinplot(self):
        """plt.violinplot() shortcut."""
        fig, ax = plt.subplots()
        data = [1.0, 2.0, 3.0, 2.5]
        vp = plt.violinplot(data)
        assert vp is not None
        plt.close('all')


class TestBoxplotAdvanced:
    def test_boxplot_vert_false(self):
        """boxplot(vert=False) horizontal boxes."""
        fig, ax = plt.subplots()
        data = [[1.0, 2.0, 3.0, 4.0, 5.0]]
        ax.boxplot(data, vert=False)
        plt.close('all')

    def test_boxplot_notch(self):
        """boxplot(notch=True) notched boxes."""
        fig, ax = plt.subplots()
        data = [1.0, 2.0, 3.0, 4.0, 5.0, 2.5, 3.5]
        ax.boxplot(data, notch=True)
        plt.close('all')

    def test_boxplot_widths(self):
        """boxplot with custom widths."""
        fig, ax = plt.subplots()
        data = [[1.0, 2.0, 3.0], [2.0, 3.0, 4.0]]
        ax.boxplot(data, widths=[0.3, 0.5])
        plt.close('all')

    def test_boxplot_patch_artist(self):
        """boxplot with patch_artist=True."""
        fig, ax = plt.subplots()
        data = [1.0, 2.0, 3.0, 4.0, 5.0]
        bp = ax.boxplot(data, patch_artist=True)
        assert bp is not None
        plt.close('all')

    def test_boxplot_multiple(self):
        """boxplot with multiple datasets."""
        fig, ax = plt.subplots()
        data = [[1.0, 2.0, 3.0, 4.0], [2.0, 3.0, 4.0, 5.0], [3.0, 4.0, 5.0, 6.0]]
        ax.boxplot(data)
        plt.close('all')

    def test_boxplot_labels(self):
        """boxplot with labels."""
        fig, ax = plt.subplots()
        data = [[1.0, 2.0, 3.0], [2.0, 3.0, 4.0]]
        ax.boxplot(data, labels=['A', 'B'])
        plt.close('all')
