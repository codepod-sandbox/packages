"""Tests for matplotlib.collections — advanced features."""

import pytest
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.collections as mcollections
import matplotlib.colors as mcolors


class TestLineCollection:
    def test_line_collection_basic(self):
        """LineCollection() does not raise."""
        segs = [[(0, 0), (1, 1)], [(1, 0), (2, 1)]]
        lc = mcollections.LineCollection(segs)
        assert lc is not None

    def test_line_collection_add_to_axes(self):
        """Adding LineCollection to axes does not raise."""
        fig, ax = plt.subplots()
        segs = [[(0, 0), (1, 1)], [(0, 1), (1, 0)]]
        lc = mcollections.LineCollection(segs, colors=['red', 'blue'])
        ax.add_collection(lc)
        plt.close('all')

    def test_line_collection_colormap(self):
        """LineCollection with colormap and norm does not raise."""
        fig, ax = plt.subplots()
        segs = [[(i, 0), (i, 1)] for i in range(5)]
        lc = mcollections.LineCollection(segs, cmap='viridis',
                                          norm=mcolors.Normalize(0, 4))
        lc.set_array(np.arange(5.0))
        ax.add_collection(lc)
        ax.autoscale()
        plt.close('all')

    def test_line_collection_linewidth(self):
        """LineCollection with linewidth does not raise."""
        fig, ax = plt.subplots()
        segs = [[(0, 0), (1, 1)], [(1, 0), (0, 1)]]
        lc = mcollections.LineCollection(segs, linewidths=2.0)
        ax.add_collection(lc)
        plt.close('all')

    def test_line_collection_set_array(self):
        """LineCollection.set_array() does not raise."""
        segs = [[(i, 0), (i, 1)] for i in range(5)]
        lc = mcollections.LineCollection(segs)
        lc.set_array(np.linspace(0, 1, 5))

    def test_line_collection_get_segments(self):
        """LineCollection.get_segments() returns segments."""
        segs = [[(0, 0), (1, 1)], [(1, 0), (2, 1)]]
        lc = mcollections.LineCollection(segs)
        result = lc.get_segments()
        assert len(result) == 2


class TestPatchCollection:
    def test_patch_collection_basic(self):
        """PatchCollection() does not raise."""
        import matplotlib.patches as mpatches
        patches = [mpatches.Circle((i, 0), 0.3) for i in range(3)]
        pc = mcollections.PatchCollection(patches)
        assert pc is not None

    def test_patch_collection_add_to_axes(self):
        """Adding PatchCollection to axes does not raise."""
        import matplotlib.patches as mpatches
        fig, ax = plt.subplots()
        patches = [mpatches.Rectangle((i, 0), 0.8, 0.8) for i in range(3)]
        pc = mcollections.PatchCollection(patches, cmap='viridis')
        pc.set_array(np.array([1.0, 2.0, 3.0]))
        ax.add_collection(pc)
        ax.set_xlim(0, 4)
        ax.set_ylim(-1, 2)
        plt.close('all')

    def test_patch_collection_facecolor(self):
        """PatchCollection with facecolor does not raise."""
        import matplotlib.patches as mpatches
        fig, ax = plt.subplots()
        patches = [mpatches.Circle((i, 0), 0.3) for i in range(3)]
        pc = mcollections.PatchCollection(patches, facecolors=['red', 'blue', 'green'])
        ax.add_collection(pc)
        plt.close('all')


class TestPolyCollection:
    def test_poly_collection_basic(self):
        """PolyCollection() does not raise."""
        verts = [[(0, 0), (1, 0), (0.5, 1)], [(1, 0), (2, 0), (1.5, 1)]]
        pc = mcollections.PolyCollection(verts)
        assert pc is not None

    def test_poly_collection_add_to_axes(self):
        """Adding PolyCollection to axes does not raise."""
        fig, ax = plt.subplots()
        verts = [[(0, 0), (1, 0), (0.5, 1)]]
        pc = mcollections.PolyCollection(verts, facecolors=['blue'])
        ax.add_collection(pc)
        ax.set_xlim(-0.5, 2)
        ax.set_ylim(-0.5, 2)
        plt.close('all')


class TestQuadMesh:
    def test_pcolormesh_basic(self):
        """ax.pcolormesh() does not raise."""
        fig, ax = plt.subplots()
        Z = np.random.rand(4, 4)
        ax.pcolormesh(Z)
        plt.close('all')

    def test_pcolormesh_with_xy(self):
        """ax.pcolormesh() with x, y arrays does not raise."""
        fig, ax = plt.subplots()
        x = np.linspace(0, 2, 5)
        y = np.linspace(0, 1, 5)
        Z = np.random.rand(4, 4)
        ax.pcolormesh(x, y, Z)
        plt.close('all')

    def test_pcolor_basic(self):
        """ax.pcolor() does not raise."""
        fig, ax = plt.subplots()
        Z = np.random.rand(3, 3)
        ax.pcolor(Z)
        plt.close('all')


class TestEventCollection:
    def test_event_collection_basic(self):
        """EventCollection() does not raise."""
        ec = mcollections.EventCollection([1, 2, 3, 4, 5])
        assert ec is not None

    def test_event_collection_add_to_axes(self):
        """Adding EventCollection to axes does not raise."""
        fig, ax = plt.subplots()
        ec = mcollections.EventCollection([1, 2, 3], color='red', linewidth=2)
        ax.add_collection(ec)
        plt.close('all')
