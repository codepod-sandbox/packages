"""
Upstream matplotlib test_colors.py tests — batch 12.
Focus: TwoSlopeNorm, PowerNorm, SymLogNorm, BoundaryNorm, Normalize.
"""
import math
import pytest
import matplotlib.colors as mcolors
import matplotlib.pyplot as plt


# ------------------------------------------------------------------
# TwoSlopeNorm
# ------------------------------------------------------------------

class TestTwoSlopeNorm:
    def test_even(self):
        norm = mcolors.TwoSlopeNorm(vmin=-1, vcenter=0, vmax=4)
        vals = [-1.0, -0.5, 0.0, 1.0, 2.0, 3.0, 4.0]
        expected = [0.0, 0.25, 0.5, 0.625, 0.75, 0.875, 1.0]
        result = norm(vals)
        for r, e in zip(result, expected):
            assert abs(r - e) < 1e-10, f"{r} != {e}"

    def test_odd(self):
        norm = mcolors.TwoSlopeNorm(vmin=-2, vcenter=0, vmax=5)
        vals = [-2.0, -1.0, 0.0, 1.0, 2.0, 3.0, 4.0, 5.0]
        expected = [0.0, 0.25, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]
        result = norm(vals)
        for r, e in zip(result, expected):
            assert abs(r - e) < 1e-10, f"{r} != {e}"

    def test_vmin_gt_vcenter(self):
        with pytest.raises(ValueError):
            mcolors.TwoSlopeNorm(vmin=10, vcenter=0, vmax=20)

    def test_vcenter_gt_vmax(self):
        with pytest.raises(ValueError):
            mcolors.TwoSlopeNorm(vmin=10, vcenter=25, vmax=20)

    def test_vmax_equals_vcenter(self):
        with pytest.raises(ValueError):
            mcolors.TwoSlopeNorm(vmin=-2, vcenter=2, vmax=2)

    def test_vmin_equals_vcenter(self):
        with pytest.raises(ValueError):
            mcolors.TwoSlopeNorm(vmin=-2, vcenter=-2, vmax=2)

    def test_vmin_gt_vmax(self):
        with pytest.raises(ValueError):
            mcolors.TwoSlopeNorm(vmin=10, vcenter=0, vmax=5)

    def test_scale(self):
        norm = mcolors.TwoSlopeNorm(2)
        assert norm.scaled is False
        norm([1, 2, 3, 4])
        assert norm.scaled is True

    def test_premature_scaling(self):
        norm = mcolors.TwoSlopeNorm(vcenter=2)
        with pytest.raises(ValueError):
            norm.inverse([0.1, 0.5, 0.9])

    def test_autoscale(self):
        norm = mcolors.TwoSlopeNorm(vcenter=20)
        norm.autoscale([10, 20, 30, 40])
        assert norm.vmin == 10.0
        assert norm.vmax == 40.0

    def test_autoscale_none_vmin(self):
        norm = mcolors.TwoSlopeNorm(2, vmin=0, vmax=None)
        norm.autoscale_None([1, 2, 3, 4, 5])
        assert norm(5) == 1
        assert norm.vmax == 5

    def test_autoscale_none_vmax(self):
        norm = mcolors.TwoSlopeNorm(2, vmin=None, vmax=10)
        norm.autoscale_None([1, 2, 3, 4, 5])
        assert norm(1) == 0
        assert norm.vmin == 1

    def test_repr(self):
        norm = mcolors.TwoSlopeNorm(vcenter=0, vmin=-1, vmax=1)
        r = repr(norm)
        assert 'TwoSlopeNorm' in r

    def test_inverse_basic(self):
        norm = mcolors.TwoSlopeNorm(vmin=-1, vcenter=0, vmax=1)
        # 0 -> -1, 0.5 -> 0, 1 -> 1
        assert abs(norm.inverse(0.0) - (-1.0)) < 1e-10
        assert abs(norm.inverse(0.5) - 0.0) < 1e-10
        assert abs(norm.inverse(1.0) - 1.0) < 1e-10

    def test_scaleout_center(self):
        """vmin never goes above vcenter when autoscaling."""
        norm = mcolors.TwoSlopeNorm(vcenter=0)
        norm([0, 1, 2, 3, 5])
        assert norm.vmin == -5
        assert norm.vmax == 5

    def test_scaleout_center_max(self):
        """vmax never goes below vcenter when autoscaling."""
        norm = mcolors.TwoSlopeNorm(vcenter=0)
        norm([0, -1, -2, -3, -5])
        assert norm.vmax == 5
        assert norm.vmin == -5


# ------------------------------------------------------------------
# PowerNorm
# ------------------------------------------------------------------

class TestPowerNorm:
    def test_gamma_1_matches_normalize(self):
        """Exponent of 1 gives same results as normal Normalize."""
        a = [0, 0.5, 1, 1.5]
        pnorm = mcolors.PowerNorm(1, vmin=0, vmax=1.5)
        norm = mcolors.Normalize(vmin=0, vmax=1.5)
        for v in a:
            assert abs(pnorm(v) - norm(v)) < 1e-6

    def test_gamma_2(self):
        pnorm = mcolors.PowerNorm(2, vmin=0, vmax=8)
        assert abs(pnorm(0) - 0) < 1e-10
        assert abs(pnorm(8) - 1) < 1e-10

    def test_inverse(self):
        pnorm = mcolors.PowerNorm(2, vmin=0, vmax=8)
        for v in [0, 2, 4, 8]:
            normed = pnorm(v)
            back = pnorm.inverse(normed)
            assert abs(back - v) < 1e-6, f"inverse({normed}) = {back}, expected {v}"

    def test_repr(self):
        pnorm = mcolors.PowerNorm(2, vmin=0, vmax=10)
        r = repr(pnorm)
        assert 'PowerNorm' in r

    def test_translation_invariance(self):
        """PowerNorm should be translation invariant."""
        a = [0, 0.5, 1.0]
        expected = []
        pnorm = mcolors.PowerNorm(vmin=0, vmax=1, gamma=3)
        for v in a:
            expected.append(pnorm(v))
        pnorm2 = mcolors.PowerNorm(vmin=-2, vmax=-1, gamma=3)
        for v, e in zip(a, expected):
            result = pnorm2(v - 2)
            assert abs(result - e) < 1e-6


# ------------------------------------------------------------------
# SymLogNorm
# ------------------------------------------------------------------

class TestSymLogNorm:
    def test_basic(self):
        norm = mcolors.SymLogNorm(1, vmin=-1000, vmax=1000, base=10)
        assert abs(norm(0) - 0.5) < 1e-6

    def test_symmetric(self):
        norm = mcolors.SymLogNorm(1, vmin=-100, vmax=100, base=10)
        for v in [10, 50, 100]:
            pos = norm(v)
            neg = norm(-v)
            assert abs(pos + neg - 1.0) < 1e-6, \
                f"norm({v})={pos}, norm({-v})={neg}, sum={pos+neg}"

    def test_repr(self):
        norm = mcolors.SymLogNorm(1, vmin=-10, vmax=10)
        r = repr(norm)
        assert 'SymLogNorm' in r

    def test_inverse(self):
        norm = mcolors.SymLogNorm(1, vmin=-100, vmax=100, base=10)
        for v in [-100, -10, -1, 0, 1, 10, 100]:
            normed = norm(v)
            back = norm.inverse(normed)
            assert abs(back - v) < 1e-4, f"inverse of norm({v})={normed} gave {back}"


# ------------------------------------------------------------------
# BoundaryNorm
# ------------------------------------------------------------------

class TestBoundaryNorm:
    def test_basic(self):
        boundaries = [0, 1, 2, 3]
        bn = mcolors.BoundaryNorm(boundaries, ncolors=3)
        # In-bounds values should map to something in [0, 1]
        r0 = bn(0.5)
        r1 = bn(1.5)
        r2 = bn(2.5)
        assert r0 < r1 < r2  # monotonic

    def test_out_of_bounds_below(self):
        bn = mcolors.BoundaryNorm([0, 1, 2], ncolors=2)
        result = bn(-1)
        assert result < 0  # below range

    def test_out_of_bounds_above(self):
        bn = mcolors.BoundaryNorm([0, 1, 2], ncolors=2)
        result = bn(3)
        assert result > 0  # above range

    def test_scalar_return_type(self):
        bn = mcolors.BoundaryNorm([0, 1, 2], ncolors=2)
        result = bn(0.5)
        assert isinstance(result, (int, float))

    def test_repr(self):
        bn = mcolors.BoundaryNorm([0, 1, 2], ncolors=2)
        r = repr(bn)
        assert 'BoundaryNorm' in r

    def test_inverse_raises(self):
        bn = mcolors.BoundaryNorm([0, 1, 2], ncolors=2)
        with pytest.raises(ValueError):
            bn.inverse(0.5)

    def test_extend_neither(self):
        bn = mcolors.BoundaryNorm([0, 1, 2], ncolors=2, extend='neither')
        assert bn.ncolors == 2

    def test_extend_min(self):
        bn = mcolors.BoundaryNorm([0, 1, 2], ncolors=3, extend='min')
        assert bn.ncolors == 3

    def test_extend_max(self):
        bn = mcolors.BoundaryNorm([0, 1, 2], ncolors=3, extend='max')
        assert bn.ncolors == 3

    def test_extend_both(self):
        bn = mcolors.BoundaryNorm([0, 1, 2], ncolors=4, extend='both')
        assert bn.ncolors == 4

    def test_boundaries_attr(self):
        bn = mcolors.BoundaryNorm([0, 1, 2], ncolors=2)
        assert bn.boundaries == [0, 1, 2]

    def test_clip(self):
        bn = mcolors.BoundaryNorm([0, 1, 2], ncolors=2, clip=True)
        # Should clip out-of-bounds
        result = bn(-1)
        assert result >= 0


# ------------------------------------------------------------------
# Normalize
# ------------------------------------------------------------------

class TestNormalize:
    def test_basic(self):
        norm = mcolors.Normalize(vmin=0, vmax=10)
        assert norm(0) == 0.0
        assert norm(10) == 1.0
        assert abs(norm(5) - 0.5) < 1e-10

    def test_scalar(self):
        norm = mcolors.Normalize(vmin=0, vmax=10)
        result = norm(5)
        assert isinstance(result, float)

    def test_list(self):
        norm = mcolors.Normalize(vmin=0, vmax=10)
        result = norm([0, 5, 10])
        assert len(result) == 3

    def test_clip(self):
        norm = mcolors.Normalize(vmin=0, vmax=10, clip=True)
        assert norm(-5) == 0.0
        assert norm(15) == 1.0

    def test_inverse(self):
        norm = mcolors.Normalize(vmin=0, vmax=10)
        for v in [0, 2.5, 5, 7.5, 10]:
            normed = norm(v)
            back = norm.inverse(normed)
            assert abs(back - v) < 1e-10

    def test_autoscale(self):
        norm = mcolors.Normalize()
        norm.autoscale([1, 2, 3, 4, 5])
        assert norm.vmin == 1
        assert norm.vmax == 5

    def test_autoscale_None(self):
        norm = mcolors.Normalize(vmin=0)
        norm.autoscale_None([1, 2, 3, 4, 5])
        assert norm.vmin == 0  # not changed
        assert norm.vmax == 5

    def test_scaled(self):
        norm = mcolors.Normalize()
        assert norm.scaled is False
        norm.autoscale([1, 2, 3])
        assert norm.scaled is True

    def test_eq(self):
        n1 = mcolors.Normalize(vmin=0, vmax=10)
        n2 = mcolors.Normalize(vmin=0, vmax=10)
        assert n1 == n2

    def test_neq(self):
        n1 = mcolors.Normalize(vmin=0, vmax=10)
        n2 = mcolors.Normalize(vmin=0, vmax=20)
        assert n1 != n2

    def test_repr(self):
        norm = mcolors.Normalize(vmin=0, vmax=10)
        r = repr(norm)
        assert 'Normalize' in r


# ------------------------------------------------------------------
# LogNorm
# ------------------------------------------------------------------

class TestLogNorm:
    def test_basic(self):
        norm = mcolors.LogNorm(vmin=1, vmax=100)
        assert abs(norm(1) - 0.0) < 1e-10
        assert abs(norm(100) - 1.0) < 1e-10

    def test_midpoint(self):
        norm = mcolors.LogNorm(vmin=1, vmax=100)
        assert abs(norm(10) - 0.5) < 1e-10

    def test_inverse(self):
        norm = mcolors.LogNorm(vmin=1, vmax=100)
        for v in [1, 10, 100]:
            normed = norm(v)
            back = norm.inverse(normed)
            assert abs(back - v) < 1e-6


# ------------------------------------------------------------------
# NoNorm
# ------------------------------------------------------------------

class TestNoNorm:
    def test_passthrough(self):
        norm = mcolors.NoNorm()
        assert norm(0.5) == 0.5
        assert norm(42) == 42

    def test_inverse(self):
        norm = mcolors.NoNorm()
        assert norm.inverse(0.7) == 0.7


# ------------------------------------------------------------------
# Color functions
# ------------------------------------------------------------------

class TestColorFunctions:
    def test_to_rgba_named(self):
        r, g, b, a = mcolors.to_rgba('red')
        assert r == 1.0 and g == 0.0 and b == 0.0 and a == 1.0

    def test_to_rgba_hex(self):
        r, g, b, a = mcolors.to_rgba('#ff0000')
        assert r == 1.0 and g == 0.0 and b == 0.0

    def test_to_rgba_tuple(self):
        r, g, b, a = mcolors.to_rgba((0.5, 0.5, 0.5))
        assert abs(r - 0.5) < 1e-6

    def test_to_rgba_with_alpha(self):
        r, g, b, a = mcolors.to_rgba('blue', alpha=0.5)
        assert a == 0.5

    def test_to_hex(self):
        h = mcolors.to_hex('red')
        assert h.lower() == '#ff0000'

    def test_to_hex_from_tuple(self):
        h = mcolors.to_hex((1.0, 0.0, 0.0))
        assert h.lower() == '#ff0000'

    def test_to_rgb(self):
        r, g, b = mcolors.to_rgb('green')
        assert g > 0

    def test_is_color_like(self):
        assert mcolors.is_color_like('red') is True
        assert mcolors.is_color_like('#ff0000') is True
        assert mcolors.is_color_like((1, 0, 0)) is True
        assert mcolors.is_color_like('not_a_color') is False

    def test_same_color(self):
        assert mcolors.same_color('red', '#ff0000') is True
        assert mcolors.same_color('red', 'blue') is False
        assert mcolors.same_color((1, 0, 0), 'red') is True

    def test_to_rgba_array(self):
        result = mcolors.to_rgba_array(['red', 'blue', 'green'])
        assert len(result) == 3
        assert len(result[0]) == 4

    def test_to_rgba_c_string(self):
        # C0, C1, etc.
        r, g, b, a = mcolors.to_rgba('C0')
        assert isinstance(r, float)

    def test_to_rgba_single_char(self):
        r, g, b, a = mcolors.to_rgba('r')
        assert r == 1.0 and g == 0.0 and b == 0.0

    def test_to_rgba_grayscale(self):
        r, g, b, a = mcolors.to_rgba('0.5')
        assert abs(r - 0.5) < 1e-6
        assert abs(g - 0.5) < 1e-6

    def test_to_hex_keep_alpha(self):
        h = mcolors.to_hex((1.0, 0.0, 0.0, 0.5), keep_alpha=True)
        assert len(h) == 9  # #RRGGBBAA


# ------------------------------------------------------------------
# CallbackRegistry (used by Normalize)
# ------------------------------------------------------------------

class TestCallbackRegistry:
    def test_connect_and_process(self):
        registry = mcolors._CallbackRegistry()
        calls = []
        registry.connect('signal', lambda: calls.append(1))
        registry.process('signal')
        assert len(calls) == 1

    def test_disconnect(self):
        registry = mcolors._CallbackRegistry()
        calls = []
        cid = registry.connect('signal', lambda: calls.append(1))
        registry.disconnect(cid)
        registry.process('signal')
        assert len(calls) == 0

    def test_multiple_callbacks(self):
        registry = mcolors._CallbackRegistry()
        calls = []
        registry.connect('s', lambda: calls.append('a'))
        registry.connect('s', lambda: calls.append('b'))
        registry.process('s')
        assert calls == ['a', 'b']


# ------------------------------------------------------------------
# is_color_sequence / has_alpha_channel
# ------------------------------------------------------------------

class TestColorHelpers:
    def test_is_color_sequence_true(self):
        assert mcolors._is_color_sequence(['red', 'blue']) is True

    def test_is_color_sequence_false(self):
        assert mcolors._is_color_sequence('red') is False

    def test_is_color_sequence_empty(self):
        assert mcolors._is_color_sequence([]) is True

    def test_has_alpha_4tuple(self):
        assert mcolors._has_alpha_channel((1, 0, 0, 0.5)) is True

    def test_has_alpha_3tuple(self):
        assert mcolors._has_alpha_channel((1, 0, 0)) is False


# ------------------------------------------------------------------
# DEFAULT_CYCLE
# ------------------------------------------------------------------

def test_default_cycle_exists():
    assert len(mcolors.DEFAULT_CYCLE) > 0
    assert isinstance(mcolors.DEFAULT_CYCLE[0], str)


# ------------------------------------------------------------------
# parse_fmt
# ------------------------------------------------------------------

class TestParseFmt:
    def test_empty(self):
        color, marker, linestyle = mcolors.parse_fmt('')
        assert color is None
        assert marker is None
        assert linestyle is None

    def test_color_only(self):
        color, marker, linestyle = mcolors.parse_fmt('r')
        assert color == 'r'

    def test_marker_only(self):
        color, marker, linestyle = mcolors.parse_fmt('o')
        assert marker == 'o'

    def test_linestyle_only(self):
        color, marker, linestyle = mcolors.parse_fmt('--')
        assert linestyle == '--'

    def test_color_and_marker(self):
        color, marker, linestyle = mcolors.parse_fmt('ro')
        assert color == 'r'
        assert marker == 'o'

    def test_full_format(self):
        color, marker, linestyle = mcolors.parse_fmt('r--')
        assert color == 'r'
        assert linestyle == '--'

    def test_marker_and_linestyle(self):
        color, marker, linestyle = mcolors.parse_fmt('o-')
        assert marker == 'o'
        assert linestyle == '-'
