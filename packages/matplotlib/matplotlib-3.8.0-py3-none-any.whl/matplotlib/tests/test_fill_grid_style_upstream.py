"""Tests for fill_between, fill, ax.grid(), axis styling, and related features."""

import pytest
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors


# ---------------------------------------------------------------------------
# ax.fill_between()
# ---------------------------------------------------------------------------

class TestFillBetween:
    def test_fill_between_basic(self):
        """fill_between(x, y1, y2) does not raise."""
        fig, ax = plt.subplots()
        x = [0, 1, 2, 3]
        ax.fill_between(x, [0, 1, 2, 1], [1, 2, 3, 2])
        plt.close('all')

    def test_fill_between_returns_artist(self):
        """fill_between returns an artist (not None)."""
        fig, ax = plt.subplots()
        result = ax.fill_between([0, 1, 2], [0, 1, 0], [1, 2, 1])
        assert result is not None
        plt.close('all')

    def test_fill_between_scalar_y2(self):
        """fill_between with scalar y2 does not raise."""
        fig, ax = plt.subplots()
        ax.fill_between([0, 1, 2, 3], [1, 2, 3, 2], 0)
        plt.close('all')

    def test_fill_between_with_alpha(self):
        """fill_between with alpha does not raise."""
        fig, ax = plt.subplots()
        ax.fill_between([0, 1, 2], [0, 1, 0], [1, 2, 1], alpha=0.5)
        plt.close('all')

    def test_fill_between_with_color(self):
        """fill_between with color does not raise."""
        fig, ax = plt.subplots()
        ax.fill_between([0, 1, 2], [0, 1, 0], [1, 2, 1], color='blue', alpha=0.3)
        plt.close('all')

    def test_fill_between_svg_renders(self):
        """fill_between renders to SVG."""
        fig, ax = plt.subplots()
        x = [0, 1, 2, 3, 4]
        y1 = [1, 2, 1, 3, 2]
        y2 = [0, 1, 0, 2, 1]
        ax.fill_between(x, y1, y2, alpha=0.4)
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_fill_between_with_plot(self):
        """fill_between combined with plot does not raise."""
        fig, ax = plt.subplots()
        x = [0, 1, 2, 3]
        y_mean = [1, 2, 1.5, 2.5]
        y_std = [0.2, 0.3, 0.2, 0.4]
        ax.plot(x, y_mean, 'b-')
        ax.fill_between(x,
                        [m - s for m, s in zip(y_mean, y_std)],
                        [m + s for m, s in zip(y_mean, y_std)],
                        alpha=0.2)
        plt.close('all')

    def test_plt_fill_between(self):
        """plt.fill_between() wrapper works."""
        plt.figure()
        plt.fill_between([0, 1, 2], [0, 1, 0], [1, 2, 1])
        plt.close('all')


# ---------------------------------------------------------------------------
# ax.fill()
# ---------------------------------------------------------------------------

class TestFill:
    def test_fill_polygon(self):
        """fill with polygon vertices does not raise."""
        fig, ax = plt.subplots()
        ax.fill([0, 1, 0.5], [0, 0, 1], color='red')
        plt.close('all')

    def test_fill_closed_polygon(self):
        """fill creates closed polygon."""
        fig, ax = plt.subplots()
        result = ax.fill([0, 1, 1, 0], [0, 0, 1, 1])
        assert result is not None
        plt.close('all')

    def test_fill_alpha(self):
        """fill with alpha does not raise."""
        fig, ax = plt.subplots()
        ax.fill([0, 1, 0.5], [0, 0, 1], alpha=0.5)
        plt.close('all')

    def test_fill_svg_renders(self):
        """fill renders to SVG."""
        fig, ax = plt.subplots()
        ax.fill([0, 1, 0.5], [0, 0, 1], color='green', alpha=0.4)
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')


# ---------------------------------------------------------------------------
# ax.grid()
# ---------------------------------------------------------------------------

class TestGrid:
    def test_grid_on(self):
        """grid(True) does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        ax.grid(True)
        plt.close('all')

    def test_grid_off(self):
        """grid(False) does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        ax.grid(False)
        plt.close('all')

    def test_grid_no_arg(self):
        """grid() with no arg does not raise."""
        fig, ax = plt.subplots()
        ax.grid()
        plt.close('all')

    def test_grid_with_style(self):
        """grid with linestyle/color does not raise."""
        fig, ax = plt.subplots()
        ax.grid(True, linestyle='--', color='gray', alpha=0.5)
        plt.close('all')

    def test_grid_axis_x(self):
        """grid with axis='x' does not raise."""
        fig, ax = plt.subplots()
        ax.grid(True, axis='x')
        plt.close('all')

    def test_grid_axis_y(self):
        """grid with axis='y' does not raise."""
        fig, ax = plt.subplots()
        ax.grid(True, axis='y')
        plt.close('all')

    def test_plt_grid(self):
        """plt.grid() wrapper does not raise."""
        plt.figure()
        plt.plot([0, 1], [0, 1])
        plt.grid(True)
        plt.close('all')

    def test_grid_svg_renders(self):
        """Figure with grid renders to SVG."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2], [0, 1, 4])
        ax.grid(True, linestyle='--', alpha=0.7)
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')


# ---------------------------------------------------------------------------
# ax.set_aspect()
# ---------------------------------------------------------------------------

class TestSetAspect:
    def test_set_aspect_equal(self):
        """set_aspect('equal') does not raise."""
        fig, ax = plt.subplots()
        ax.set_aspect('equal')
        plt.close('all')

    def test_set_aspect_auto(self):
        """set_aspect('auto') does not raise."""
        fig, ax = plt.subplots()
        ax.set_aspect('auto')
        plt.close('all')

    def test_set_aspect_numeric(self):
        """set_aspect with float does not raise."""
        fig, ax = plt.subplots()
        ax.set_aspect(2.0)
        plt.close('all')

    def test_set_aspect_equal_box(self):
        """set_aspect('equal', adjustable='box') does not raise."""
        fig, ax = plt.subplots()
        ax.set_aspect('equal', adjustable='box')
        plt.close('all')


# ---------------------------------------------------------------------------
# axis() shortcut for limits
# ---------------------------------------------------------------------------

class TestAxisShortcut:
    def test_axis_returns_limits(self):
        """ax.axis() returns (xmin, xmax, ymin, ymax) tuple."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        result = ax.axis()
        assert result is not None
        plt.close('all')

    def test_axis_set_limits(self):
        """ax.axis([xmin, xmax, ymin, ymax]) sets limits."""
        fig, ax = plt.subplots()
        ax.axis([0, 10, 0, 20])
        assert ax.get_xlim() == pytest.approx((0, 10))
        assert ax.get_ylim() == pytest.approx((0, 20))
        plt.close('all')

    def test_axis_equal(self):
        """ax.axis('equal') does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        ax.axis('equal')
        plt.close('all')

    def test_axis_off(self):
        """ax.axis('off') does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        ax.axis('off')
        plt.close('all')

    def test_axis_tight(self):
        """ax.axis('tight') does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        ax.axis('tight')
        plt.close('all')


# ---------------------------------------------------------------------------
# ax.set_visible() / ax.get_visible()
# ---------------------------------------------------------------------------

class TestVisibility:
    def test_set_visible_false(self):
        """set_visible(False) does not raise."""
        fig, ax = plt.subplots()
        ax.set_visible(False)
        plt.close('all')

    def test_get_visible_default_true(self):
        """Axes is visible by default."""
        fig, ax = plt.subplots()
        assert ax.get_visible() is True
        plt.close('all')

    def test_set_visible_roundtrip(self):
        """set_visible / get_visible round-trip."""
        fig, ax = plt.subplots()
        ax.set_visible(False)
        assert ax.get_visible() is False
        ax.set_visible(True)
        assert ax.get_visible() is True
        plt.close('all')


# ---------------------------------------------------------------------------
# Colors utilities
# ---------------------------------------------------------------------------

class TestColorUtils:
    def test_normalize_rgb(self):
        """mcolors normalizes RGB tuples."""
        assert mcolors.to_hex((1, 0, 0)) == '#ff0000'
        assert mcolors.to_hex((0, 1, 0)) == '#00ff00'
        assert mcolors.to_hex((0, 0, 1)) == '#0000ff'

    def test_is_color_like(self):
        """is_color_like works for common color formats."""
        assert mcolors.is_color_like('red')
        assert mcolors.is_color_like('#ff0000')
        assert mcolors.is_color_like((1, 0, 0))
        assert not mcolors.is_color_like('notacolor')

    def test_to_rgba_with_named_colors(self):
        """to_rgba works for CSS color names."""
        r, g, b, a = mcolors.to_rgba('cyan')
        assert r == pytest.approx(0.0)
        assert g == pytest.approx(1.0)
        assert b == pytest.approx(1.0)
        assert a == pytest.approx(1.0)

    def test_hsv_to_rgb(self):
        """hsv_to_rgb basic conversion."""
        rgb = mcolors.hsv_to_rgb([0.0, 1.0, 1.0])  # pure red in HSV
        # (1, 0, 0) expected
        assert len(rgb) == 3
