"""Tests for line styles, markers, and plot formatting options."""

import pytest
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.lines as mlines


# ---------------------------------------------------------------------------
# Line styles
# ---------------------------------------------------------------------------

class TestLineStyles:
    def test_solid_linestyle(self):
        """linestyle='-' does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1], linestyle='-')
        plt.close('all')

    def test_dashed_linestyle(self):
        """linestyle='--' does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1], linestyle='--')
        plt.close('all')

    def test_dotted_linestyle(self):
        """linestyle=':' does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1], linestyle=':')
        plt.close('all')

    def test_dashdot_linestyle(self):
        """linestyle='-.' does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1], linestyle='-.')
        plt.close('all')

    def test_none_linestyle(self):
        """linestyle='None' (no line) does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2], [0, 1, 0], linestyle='None', marker='o')
        plt.close('all')

    def test_linewidth_variations(self):
        """Various linewidths do not raise."""
        fig, ax = plt.subplots()
        for lw in [0.5, 1.0, 2.0, 3.0, 5.0]:
            ax.plot([0, 1], [0, 1], linewidth=lw)
        plt.close('all')

    def test_ls_alias(self):
        """ls= alias for linestyle does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1], ls='--')
        plt.close('all')

    def test_lw_alias(self):
        """lw= alias for linewidth does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1], lw=3.0)
        plt.close('all')


# ---------------------------------------------------------------------------
# Markers
# ---------------------------------------------------------------------------

class TestMarkers:
    def test_circle_marker(self):
        """marker='o' does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2], [0, 1, 0], marker='o')
        plt.close('all')

    def test_square_marker(self):
        """marker='s' does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2], [0, 1, 0], marker='s')
        plt.close('all')

    def test_triangle_marker(self):
        """marker='^' does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2], [0, 1, 0], marker='^')
        plt.close('all')

    def test_diamond_marker(self):
        """marker='D' does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2], [0, 1, 0], marker='D')
        plt.close('all')

    def test_plus_marker(self):
        """marker='+' does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2], [0, 1, 0], marker='+')
        plt.close('all')

    def test_x_marker(self):
        """marker='x' does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2], [0, 1, 0], marker='x')
        plt.close('all')

    def test_star_marker(self):
        """marker='*' does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2], [0, 1, 0], marker='*')
        plt.close('all')

    def test_markersize(self):
        """ms= alias for markersize does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2], [0, 1, 0], marker='o', ms=10)
        plt.close('all')

    def test_markeredgecolor(self):
        """markeredgecolor does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2], [0, 1, 0], marker='o',
                markeredgecolor='black', markerfacecolor='red')
        plt.close('all')


# ---------------------------------------------------------------------------
# Format string shorthand
# ---------------------------------------------------------------------------

class TestFormatStrings:
    def test_fmt_red_circle(self):
        """'ro' format string does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2], [0, 1, 0], 'ro')
        plt.close('all')

    def test_fmt_blue_dashed(self):
        """'b--' format string does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2], [0, 1, 0], 'b--')
        plt.close('all')

    def test_fmt_green_dotted_square(self):
        """'g:s' format string does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2], [0, 1, 0], 'g:s')
        plt.close('all')

    def test_fmt_black_dashdot_triangle(self):
        """'k-.^' format string does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2], [0, 1, 0], 'k-.^')
        plt.close('all')

    def test_multiple_format_strings(self):
        """Multiple plot() calls with format strings do not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2], [0, 1, 0], 'r-')
        ax.plot([0, 1, 2], [0, 2, 1], 'b--')
        ax.plot([0, 1, 2], [1, 0, 2], 'g:')
        plt.close('all')


# ---------------------------------------------------------------------------
# Line2D standalone
# ---------------------------------------------------------------------------

class TestLine2DStandalone:
    def test_line2d_creation(self):
        """Line2D can be created standalone."""
        line = mlines.Line2D([0, 1], [0, 1])
        assert line is not None

    def test_line2d_xdata(self):
        """Line2D get_xdata returns x values."""
        line = mlines.Line2D([1, 2, 3], [4, 5, 6])
        xdata = line.get_xdata()
        assert len(xdata) == 3

    def test_line2d_ydata(self):
        """Line2D get_ydata returns y values."""
        line = mlines.Line2D([1, 2, 3], [4, 5, 6])
        ydata = line.get_ydata()
        assert ydata[0] == 4

    def test_line2d_set_data(self):
        """Line2D.set_data updates both arrays."""
        line = mlines.Line2D([0, 1], [0, 1])
        line.set_xdata([10, 20, 30])
        line.set_ydata([1, 4, 9])
        assert len(line.get_xdata()) == 3
        assert len(line.get_ydata()) == 3

    def test_line2d_add_to_axes(self):
        """Line2D can be added to axes with add_line."""
        fig, ax = plt.subplots()
        line = mlines.Line2D([0, 1], [0, 1], color='red')
        ax.add_line(line)
        plt.close('all')


# ---------------------------------------------------------------------------
# SVG rendering with styles
# ---------------------------------------------------------------------------

class TestStyledSVG:
    def test_styled_multiline_svg(self):
        """Multiple styled lines render to SVG."""
        fig, ax = plt.subplots()
        x = np.linspace(0, 2 * np.pi, 50)
        ax.plot(x, np.sin(x), 'r-', linewidth=2, label='sin')
        ax.plot(x, np.cos(x), 'b--', linewidth=2, label='cos')
        ax.plot(x, np.sin(x) * np.cos(x), 'g:', linewidth=1, label='product')
        ax.legend()
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_marker_plot_svg(self):
        """Plot with markers renders to SVG."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2, 3, 4], [0, 1, 4, 9, 16], 'ro-', markersize=8)
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')
