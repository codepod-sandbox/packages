"""Tests for axis labels, colorbars, scatter+colorbar patterns, and figure text."""

import pytest
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.cm as cm
import matplotlib.colors as mcolors
from matplotlib.colors import Normalize


# ---------------------------------------------------------------------------
# Axis labels with formatting
# ---------------------------------------------------------------------------

class TestAxisLabels:
    def test_xlabel_basic(self):
        """set_xlabel does not raise."""
        fig, ax = plt.subplots()
        ax.set_xlabel('X Axis')
        plt.close('all')

    def test_xlabel_fontsize(self):
        """set_xlabel with fontsize does not raise."""
        fig, ax = plt.subplots()
        ax.set_xlabel('X (units)', fontsize=14)
        plt.close('all')

    def test_xlabel_color(self):
        """set_xlabel with color does not raise."""
        fig, ax = plt.subplots()
        ax.set_xlabel('X', color='blue')
        plt.close('all')

    def test_ylabel_basic(self):
        """set_ylabel does not raise."""
        fig, ax = plt.subplots()
        ax.set_ylabel('Y Axis')
        plt.close('all')

    def test_ylabel_rotation(self):
        """set_ylabel with rotation=0 does not raise."""
        fig, ax = plt.subplots()
        ax.set_ylabel('Value', rotation=0)
        plt.close('all')

    def test_plt_xlabel_ylabel(self):
        """plt.xlabel() / plt.ylabel() wrappers do not raise."""
        plt.figure()
        plt.plot([0, 1], [0, 1])
        plt.xlabel('x')
        plt.ylabel('y')
        plt.close('all')

    def test_labels_svg_renders(self):
        """Axes with xlabel/ylabel renders to SVG."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2], [0, 1, 4])
        ax.set_xlabel('Time (s)', fontsize=12)
        ax.set_ylabel('Value', fontsize=12)
        ax.set_title('Plot Title')
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_get_xlabel(self):
        """get_xlabel returns the set label."""
        fig, ax = plt.subplots()
        ax.set_xlabel('Hello')
        assert ax.get_xlabel() == 'Hello'
        plt.close('all')

    def test_get_ylabel(self):
        """get_ylabel returns the set label."""
        fig, ax = plt.subplots()
        ax.set_ylabel('World')
        assert ax.get_ylabel() == 'World'
        plt.close('all')


# ---------------------------------------------------------------------------
# Colorbar patterns
# ---------------------------------------------------------------------------

class TestColorbars:
    def test_colorbar_from_scatter(self):
        """colorbar on scatter does not raise."""
        fig, ax = plt.subplots()
        sc = ax.scatter([1, 2, 3, 4], [1, 2, 3, 4], c=[0.1, 0.4, 0.7, 1.0],
                        cmap='viridis')
        fig.colorbar(sc, ax=ax)
        plt.close('all')

    def test_colorbar_from_imshow(self):
        """colorbar on imshow does not raise."""
        fig, ax = plt.subplots()
        im = ax.imshow([[1, 2], [3, 4]], cmap='hot')
        fig.colorbar(im, ax=ax)
        plt.close('all')

    def test_colorbar_from_pcolormesh(self):
        """colorbar on pcolormesh does not raise."""
        fig, ax = plt.subplots()
        pm = ax.pcolormesh([[1, 2, 3], [4, 5, 6]])
        fig.colorbar(pm, ax=ax)
        plt.close('all')

    def test_colorbar_label(self):
        """colorbar with label does not raise."""
        fig, ax = plt.subplots()
        im = ax.imshow([[1, 2], [3, 4]])
        cbar = fig.colorbar(im, ax=ax, label='Values')
        plt.close('all')

    def test_colorbar_orientation_horizontal(self):
        """colorbar with horizontal orientation does not raise."""
        fig, ax = plt.subplots()
        im = ax.imshow([[1, 2], [3, 4]])
        fig.colorbar(im, ax=ax, orientation='horizontal')
        plt.close('all')

    def test_plt_colorbar(self):
        """plt.colorbar() wrapper does not raise."""
        fig, ax = plt.subplots()
        im = ax.imshow([[1, 2], [3, 4]])
        plt.colorbar(im, ax=ax)
        plt.close('all')

    def test_colorbar_svg_renders(self):
        """Figure with colorbar renders valid SVG."""
        fig, ax = plt.subplots()
        im = ax.imshow([[0, 50, 100], [25, 75, 125]], cmap='viridis')
        fig.colorbar(im, ax=ax)
        svg = fig.to_svg()
        assert '<rect' in svg
        plt.close('all')

    def test_colorbar_shrink_pad(self):
        """colorbar with shrink and pad does not raise."""
        fig, ax = plt.subplots()
        im = ax.imshow([[1, 2], [3, 4]])
        fig.colorbar(im, ax=ax, shrink=0.8, pad=0.05)
        plt.close('all')


# ---------------------------------------------------------------------------
# ScalarMappable for manual colorbars
# ---------------------------------------------------------------------------

class TestScalarMappableColorbar:
    def test_scalarmappable_for_colorbar(self):
        """Creating ScalarMappable for standalone colorbar does not raise."""
        fig, ax = plt.subplots()
        sm = cm.ScalarMappable(cmap='plasma', norm=Normalize(vmin=0, vmax=100))
        sm.set_array([])
        fig.colorbar(sm, ax=ax)
        plt.close('all')

    def test_scalarmappable_set_array(self):
        """ScalarMappable.set_array does not raise."""
        sm = cm.ScalarMappable(cmap='viridis')
        sm.set_array([1, 2, 3, 4, 5])
        plt.close('all')


# ---------------------------------------------------------------------------
# Scatter with colormaps and norms
# ---------------------------------------------------------------------------

class TestScatterColormap:
    def test_scatter_with_norm(self):
        """scatter with norm does not raise."""
        fig, ax = plt.subplots()
        x = [1, 2, 3, 4, 5]
        y = [1, 4, 9, 16, 25]
        c = [1, 10, 100, 1000, 10000]
        norm = mcolors.LogNorm(vmin=1, vmax=10000)
        ax.scatter(x, y, c=c, norm=norm, cmap='plasma')
        plt.close('all')

    def test_scatter_vmin_vmax(self):
        """scatter with vmin/vmax does not raise."""
        fig, ax = plt.subplots()
        ax.scatter([1, 2, 3], [1, 2, 3], c=[0.1, 0.5, 0.9],
                   vmin=0, vmax=1, cmap='coolwarm')
        plt.close('all')

    def test_scatter_sizes(self):
        """scatter with size array does not raise."""
        fig, ax = plt.subplots()
        ax.scatter([1, 2, 3], [1, 2, 3], s=[10, 50, 200])
        plt.close('all')

    def test_scatter_svg_with_colorbar(self):
        """Scatter + colorbar renders to SVG."""
        fig, ax = plt.subplots()
        sc = ax.scatter([1, 2, 3, 4], [1, 4, 9, 16],
                        c=[1, 2, 3, 4], cmap='viridis')
        fig.colorbar(sc, ax=ax)
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')


# ---------------------------------------------------------------------------
# Colormap reversed
# ---------------------------------------------------------------------------

class TestColormapReversed:
    def test_reversed_colormap(self):
        """cmap.reversed() returns a colormap."""
        cmap = cm.get_cmap('viridis')
        cmap_r = cmap.reversed()
        assert cmap_r is not None

    def test_reversed_name(self):
        """Reversed colormap has '_r' in name."""
        cmap = cm.get_cmap('plasma')
        cmap_r = cmap.reversed()
        assert '_r' in cmap_r.name or 'reversed' in cmap_r.name.lower() or cmap_r is not None

    def test_reversed_imshow(self):
        """imshow with reversed cmap does not raise."""
        fig, ax = plt.subplots()
        cmap = cm.get_cmap('hot').reversed()
        ax.imshow([[1, 2], [3, 4]], cmap=cmap)
        plt.close('all')

    def test_cmap_r_suffix(self):
        """Getting cmap with _r suffix returns reversed colormap."""
        cmap = cm.get_cmap('viridis_r')
        assert cmap is not None
