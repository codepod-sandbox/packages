"""Tests for histogram and bar chart patterns used by LLMs."""

import pytest
import io
import matplotlib.pyplot as plt


class TestHistogramPatterns:
    def test_hist_basic(self):
        """Basic histogram."""
        fig, ax = plt.subplots()
        data = [1, 2, 2, 3, 3, 3, 4, 4, 5]
        n, bins, patches = ax.hist(data)
        assert n is not None
        assert bins is not None
        assert patches is not None
        plt.close('all')

    def test_hist_bins_int(self):
        """Histogram with integer bin count."""
        fig, ax = plt.subplots()
        data = [1.0, 2.0, 2.5, 3.0, 3.5, 4.0, 4.5, 5.0]
        ax.hist(data, bins=5)
        plt.close('all')

    def test_hist_bins_list(self):
        """Histogram with explicit bin edges."""
        fig, ax = plt.subplots()
        data = [1.0, 2.0, 2.5, 3.0, 3.5, 4.0]
        ax.hist(data, bins=[1, 2, 3, 4, 5])
        plt.close('all')

    def test_hist_density(self):
        """Histogram with density normalization."""
        fig, ax = plt.subplots()
        data = [1.0, 2.0, 2.5, 3.0, 3.5, 4.0, 4.5, 5.0]
        ax.hist(data, density=True)
        plt.close('all')

    def test_hist_normed_style(self):
        """Histogram density (normed style)."""
        fig, ax = plt.subplots()
        data = [1.0, 2.0, 3.0, 4.0, 5.0]
        ax.hist(data, bins=5, density=True, alpha=0.7)
        plt.close('all')

    def test_hist_color(self):
        """Histogram with color."""
        fig, ax = plt.subplots()
        data = [1.0, 2.0, 2.5, 3.0, 3.5, 4.0]
        ax.hist(data, color='steelblue', edgecolor='white')
        plt.close('all')

    def test_hist_horizontal(self):
        """Horizontal histogram (orientation)."""
        fig, ax = plt.subplots()
        data = [1.0, 2.0, 2.5, 3.0, 3.5, 4.0]
        ax.hist(data, orientation='horizontal')
        plt.close('all')

    def test_hist_step(self):
        """Step histogram."""
        fig, ax = plt.subplots()
        data = [1.0, 2.0, 3.0, 4.0, 5.0]
        ax.hist(data, histtype='step', color='blue')
        plt.close('all')

    def test_hist_stepfilled(self):
        """Stepfilled histogram."""
        fig, ax = plt.subplots()
        data = [1.0, 2.0, 3.0, 4.0, 5.0]
        ax.hist(data, histtype='stepfilled', alpha=0.5)
        plt.close('all')

    def test_hist_label(self):
        """Histogram with label."""
        fig, ax = plt.subplots()
        data = [1.0, 2.0, 3.0, 4.0, 5.0]
        ax.hist(data, label='Distribution')
        ax.legend()
        plt.close('all')

    def test_hist_rwidth(self):
        """Histogram with relative width."""
        fig, ax = plt.subplots()
        data = [1.0, 2.0, 2.5, 3.0, 3.5, 4.0]
        ax.hist(data, rwidth=0.8)
        plt.close('all')

    def test_hist_cumulative(self):
        """Cumulative histogram."""
        fig, ax = plt.subplots()
        data = [1.0, 2.0, 3.0, 4.0, 5.0]
        ax.hist(data, cumulative=True)
        plt.close('all')

    def test_hist_range(self):
        """Histogram with explicit range."""
        fig, ax = plt.subplots()
        data = [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0]
        ax.hist(data, range=(2, 8))
        plt.close('all')

    def test_hist_log_scale(self):
        """Histogram with log y-scale."""
        fig, ax = plt.subplots()
        data = [1.0, 1.0, 2.0, 2.0, 2.0, 3.0, 3.0, 3.0, 3.0, 4.0]
        ax.hist(data, log=True)
        plt.close('all')


class TestBarPatterns:
    def test_bar_basic(self):
        """Basic bar chart."""
        fig, ax = plt.subplots()
        ax.bar(['A', 'B', 'C'], [1, 2, 3])
        plt.close('all')

    def test_bar_numeric_x(self):
        """Bar chart with numeric x."""
        fig, ax = plt.subplots()
        ax.bar([1, 2, 3, 4], [5, 3, 8, 6])
        plt.close('all')

    def test_bar_width(self):
        """Bar chart with custom width."""
        fig, ax = plt.subplots()
        ax.bar([1, 2, 3], [4, 5, 6], width=0.5)
        plt.close('all')

    def test_bar_color_list(self):
        """Bar chart with list of colors."""
        fig, ax = plt.subplots()
        ax.bar(['A', 'B', 'C', 'D'], [1, 2, 3, 4],
               color=['red', 'green', 'blue', 'orange'])
        plt.close('all')

    def test_bar_edgecolor(self):
        """Bar chart with edge color."""
        fig, ax = plt.subplots()
        ax.bar(['A', 'B', 'C'], [1, 2, 3], edgecolor='black', linewidth=1)
        plt.close('all')

    def test_bar_bottom(self):
        """Bar chart with bottom offset."""
        fig, ax = plt.subplots()
        ax.bar(['A', 'B', 'C'], [3, 2, 4], bottom=[1, 2, 0])
        plt.close('all')

    def test_bar_align(self):
        """Bar chart with center alignment."""
        fig, ax = plt.subplots()
        ax.bar([0, 1, 2], [1, 2, 3], align='center')
        plt.close('all')

    def test_bar_yerr(self):
        """Bar chart with error bars."""
        fig, ax = plt.subplots()
        ax.bar(['A', 'B', 'C'], [1, 2, 3], yerr=[0.1, 0.2, 0.15])
        plt.close('all')

    def test_bar_with_text_labels(self):
        """Bar chart with value labels."""
        fig, ax = plt.subplots()
        values = [10, 25, 15, 30]
        bars = ax.bar(['A', 'B', 'C', 'D'], values)
        for bar in bars:
            ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.5,
                    f'{bar.get_height():.0f}', ha='center', va='bottom')
        plt.close('all')

    def test_barh_basic(self):
        """Horizontal bar chart."""
        fig, ax = plt.subplots()
        ax.barh(['A', 'B', 'C'], [1, 2, 3])
        plt.close('all')

    def test_barh_color(self):
        """Horizontal bar with color."""
        fig, ax = plt.subplots()
        ax.barh(['X', 'Y', 'Z'], [30, 20, 40], color='steelblue')
        plt.close('all')

    def test_barh_height(self):
        """Horizontal bar with height."""
        fig, ax = plt.subplots()
        ax.barh(['A', 'B'], [10, 20], height=0.5)
        plt.close('all')

    def test_grouped_bars_manual(self):
        """Manually grouped bar charts."""
        fig, ax = plt.subplots()
        x = [0, 1, 2, 3]
        width = 0.35
        groups = ['Q1', 'Q2', 'Q3', 'Q4']
        product_a = [10, 15, 12, 18]
        product_b = [8, 12, 14, 16]
        bars1 = ax.bar([xi - width / 2 for xi in x], product_a, width, label='A')
        bars2 = ax.bar([xi + width / 2 for xi in x], product_b, width, label='B')
        ax.set_xticks(x)
        ax.set_xticklabels(groups)
        ax.legend()
        plt.close('all')

    def test_stacked_bars(self):
        """Stacked bar chart."""
        fig, ax = plt.subplots()
        x = ['Q1', 'Q2', 'Q3', 'Q4']
        a = [10, 15, 12, 18]
        b = [8, 12, 14, 16]
        c = [5, 7, 9, 11]
        ax.bar(x, a, label='Product A')
        ax.bar(x, b, bottom=a, label='Product B')
        ax.bar(x, c, bottom=[ai + bi for ai, bi in zip(a, b)], label='Product C')
        ax.legend()
        plt.close('all')
