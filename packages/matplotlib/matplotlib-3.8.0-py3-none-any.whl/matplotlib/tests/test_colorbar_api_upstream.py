"""Tests for colorbar API."""

import pytest
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors


class TestColorbarCreation:
    def test_colorbar_basic(self):
        """fig.colorbar() with imshow does not raise."""
        fig, ax = plt.subplots()
        im = ax.imshow(np.random.rand(10, 10), cmap='viridis')
        cb = fig.colorbar(im)
        assert cb is not None
        plt.close('all')

    def test_colorbar_with_ax(self):
        """fig.colorbar(mappable, ax=ax) does not raise."""
        fig, ax = plt.subplots()
        im = ax.imshow(np.zeros((5, 5)), cmap='plasma')
        cb = fig.colorbar(im, ax=ax)
        assert cb is not None
        plt.close('all')

    def test_colorbar_from_scatter(self):
        """Colorbar from scatter does not raise."""
        fig, ax = plt.subplots()
        sc = ax.scatter([1, 2, 3], [1, 2, 3], c=[1.0, 2.0, 3.0], cmap='hot')
        cb = fig.colorbar(sc)
        assert cb is not None
        plt.close('all')

    def test_plt_colorbar(self):
        """plt.colorbar() does not raise."""
        fig, ax = plt.subplots()
        im = ax.imshow(np.zeros((5, 5)))
        plt.colorbar(im, ax=ax)
        plt.close('all')

    def test_colorbar_label(self):
        """Colorbar.set_label() does not raise."""
        fig, ax = plt.subplots()
        im = ax.imshow(np.zeros((5, 5)))
        cb = fig.colorbar(im)
        cb.set_label('Intensity')
        plt.close('all')

    def test_colorbar_ticks(self):
        """Colorbar.set_ticks() does not raise."""
        fig, ax = plt.subplots()
        im = ax.imshow(np.zeros((5, 5)), vmin=0, vmax=1)
        cb = fig.colorbar(im)
        cb.set_ticks([0, 0.25, 0.5, 0.75, 1.0])
        plt.close('all')

    def test_colorbar_tick_labels(self):
        """Colorbar.set_ticklabels() does not raise."""
        fig, ax = plt.subplots()
        im = ax.imshow(np.zeros((5, 5)), vmin=0, vmax=1)
        cb = fig.colorbar(im)
        cb.set_ticks([0, 0.5, 1.0])
        cb.set_ticklabels(['low', 'mid', 'high'])
        plt.close('all')

    def test_colorbar_orientation_horizontal(self):
        """Colorbar with orientation='horizontal' does not raise."""
        fig, ax = plt.subplots()
        im = ax.imshow(np.zeros((5, 5)))
        cb = fig.colorbar(im, orientation='horizontal')
        assert cb is not None
        plt.close('all')

    def test_colorbar_shrink(self):
        """Colorbar with shrink does not raise."""
        fig, ax = plt.subplots()
        im = ax.imshow(np.zeros((5, 5)))
        cb = fig.colorbar(im, shrink=0.6)
        assert cb is not None
        plt.close('all')

    def test_colorbar_extend(self):
        """Colorbar with extend does not raise."""
        fig, ax = plt.subplots()
        data = np.random.rand(10, 10)
        im = ax.imshow(data, vmin=0.2, vmax=0.8)
        cb = fig.colorbar(im, extend='both')
        assert cb is not None
        plt.close('all')

    def test_colorbar_svg(self):
        """Figure with colorbar renders to SVG."""
        fig, ax = plt.subplots()
        data = np.arange(25).reshape(5, 5).astype(float)
        im = ax.imshow(data, cmap='viridis')
        fig.colorbar(im)
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')


class TestColorbarNormalization:
    def test_norm_linear(self):
        """Normalize works correctly."""
        norm = mcolors.Normalize(vmin=0, vmax=10)
        assert norm(5) == 0.5

    def test_norm_log(self):
        """LogNorm does not raise."""
        norm = mcolors.LogNorm(vmin=1, vmax=100)
        assert norm is not None

    def test_norm_symmetric_log(self):
        """SymLogNorm does not raise."""
        try:
            norm = mcolors.SymLogNorm(linthresh=0.1, vmin=-10, vmax=10)
            assert norm is not None
        except AttributeError:
            pytest.skip("SymLogNorm not implemented")

    def test_boundary_norm(self):
        """BoundaryNorm does not raise."""
        try:
            bounds = [0, 1, 2, 3, 4, 5]
            norm = mcolors.BoundaryNorm(bounds, ncolors=256)
            assert norm is not None
        except AttributeError:
            pytest.skip("BoundaryNorm not implemented")

    def test_two_slope_norm(self):
        """TwoSlopeNorm does not raise."""
        try:
            norm = mcolors.TwoSlopeNorm(vcenter=0, vmin=-5, vmax=10)
            assert norm is not None
        except AttributeError:
            pytest.skip("TwoSlopeNorm not implemented")
