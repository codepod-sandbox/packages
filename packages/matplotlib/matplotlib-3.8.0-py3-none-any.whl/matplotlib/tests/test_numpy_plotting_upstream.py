"""
Upstream tests for numpy-heavy plotting patterns commonly used by LLMs.
"""

import numpy as np
import pytest
import matplotlib.pyplot as plt


class TestNumpyPlotting:
    """Tests for plots with numpy arrays."""

    def teardown_method(self):
        plt.close('all')

    def test_plot_numpy_arrays(self):
        x = np.linspace(0, 2 * np.pi, 100)
        y = np.sin(x)
        fig, ax = plt.subplots()
        ax.plot(x, y)

    def test_plot_sin_cos(self):
        x = np.linspace(0, 4 * np.pi, 200)
        fig, ax = plt.subplots()
        ax.plot(x, np.sin(x), label='sin')
        ax.plot(x, np.cos(x), label='cos')
        ax.legend()

    def test_scatter_numpy_random(self):
        rng = np.random.default_rng(42)
        x = rng.normal(0, 1, 50)
        y = rng.normal(0, 1, 50)
        fig, ax = plt.subplots()
        ax.scatter(x, y, alpha=0.5)

    def test_bar_numpy_arange(self):
        x = np.arange(5)
        y = np.array([10, 20, 15, 25, 18])
        fig, ax = plt.subplots()
        ax.bar(x, y)
        ax.set_xticks(x)
        ax.set_xticklabels(['A', 'B', 'C', 'D', 'E'])

    def test_hist_numpy_array(self):
        rng = np.random.default_rng(42)
        data = rng.normal(0, 1, 100)
        fig, ax = plt.subplots()
        ax.hist(data, bins=20)

    def test_imshow_zeros(self):
        data = np.zeros((5, 5))
        fig, ax = plt.subplots()
        ax.imshow(data)

    def test_imshow_linspace_2d(self):
        x = np.linspace(0, 1, 10)
        y = np.linspace(0, 1, 10)
        X, Y = np.meshgrid(x, y)
        Z = np.sin(X * np.pi) * np.cos(Y * np.pi)
        fig, ax = plt.subplots()
        im = ax.imshow(Z, cmap='RdYlBu')
        plt.colorbar(im)

    def test_contour_meshgrid(self):
        x = np.linspace(-3, 3, 20)
        y = np.linspace(-3, 3, 20)
        X, Y = np.meshgrid(x, y)
        Z = np.exp(-(X**2 + Y**2))
        fig, ax = plt.subplots()
        ax.contourf(X, Y, Z, cmap='hot')

    def test_fill_between_numpy(self):
        x = np.linspace(0, 10, 50)
        y1 = np.sin(x)
        y2 = np.cos(x)
        fig, ax = plt.subplots()
        ax.fill_between(x, y1, y2, alpha=0.3, where=y1 > y2)

    def test_errorbar_numpy(self):
        x = np.arange(5)
        y = np.array([1.0, 2.0, 1.5, 2.5, 2.0])
        yerr = np.array([0.1, 0.2, 0.15, 0.25, 0.2])
        fig, ax = plt.subplots()
        ax.errorbar(x, y, yerr=yerr, fmt='o-')

    def test_pcolormesh_numpy(self):
        x = np.linspace(0, 5, 10)
        y = np.linspace(0, 5, 10)
        Z = np.outer(np.sin(x), np.cos(y))
        fig, ax = plt.subplots()
        pc = ax.pcolormesh(x, y, Z, cmap='RdBu')
        plt.colorbar(pc)

    def test_multiple_plots_same_axis(self):
        x = np.linspace(0, 2 * np.pi, 50)
        fig, ax = plt.subplots()
        for i, amplitude in enumerate([1, 0.5, 0.25]):
            ax.plot(x, amplitude * np.sin(x + i), label=f'A={amplitude}')
        ax.legend()
        ax.grid(True)

    def test_log_scale_numpy(self):
        x = np.logspace(0, 3, 50)
        y = x**2
        fig, ax = plt.subplots()
        ax.loglog(x, y)

    def test_semilogy_numpy(self):
        x = np.linspace(0, 5, 50)
        y = np.exp(x)
        fig, ax = plt.subplots()
        ax.semilogy(x, y)

    def test_semilogx_numpy(self):
        x = np.logspace(-1, 2, 50)
        y = np.log(x)
        fig, ax = plt.subplots()
        ax.semilogx(x, y)

    def test_quiver_numpy(self):
        x = np.arange(0, 3)
        y = np.arange(0, 3)
        X, Y = np.meshgrid(x, y)
        U = np.ones_like(X)
        V = np.zeros_like(Y)
        fig, ax = plt.subplots()
        ax.quiver(X, Y, U, V)

    def test_streamplot_numpy(self):
        x = np.linspace(-2, 2, 10)
        y = np.linspace(-2, 2, 10)
        X, Y = np.meshgrid(x, y)
        U = -Y
        V = X
        fig, ax = plt.subplots()
        ax.streamplot(x, y, U, V)

    def test_boxplot_numpy(self):
        rng = np.random.default_rng(42)
        data = [rng.normal(i, 1, 30) for i in range(3)]
        fig, ax = plt.subplots()
        ax.boxplot(data)

    def test_violinplot_numpy(self):
        rng = np.random.default_rng(42)
        data = [rng.normal(i, 1, 30) for i in range(3)]
        fig, ax = plt.subplots()
        ax.violinplot(data)

    def test_stack_plots(self):
        x = np.arange(5)
        y1 = np.array([1, 2, 3, 2, 1])
        y2 = np.array([2, 1, 2, 3, 2])
        y3 = np.array([1, 3, 1, 2, 3])
        fig, ax = plt.subplots()
        ax.stackplot(x, y1, y2, y3, alpha=0.5)
