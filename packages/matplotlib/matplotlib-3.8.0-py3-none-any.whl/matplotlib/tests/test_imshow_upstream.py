"""Tests for imshow and image-related functionality."""

import pytest
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors


class TestImshow:
    def test_imshow_basic_2d(self):
        """imshow with 2D array does not raise."""
        fig, ax = plt.subplots()
        data = np.zeros((10, 10))
        im = ax.imshow(data)
        assert im is not None
        plt.close('all')

    def test_imshow_rgb(self):
        """imshow with RGB array does not raise."""
        fig, ax = plt.subplots()
        data = np.zeros((10, 10, 3))
        im = ax.imshow(data)
        assert im is not None
        plt.close('all')

    def test_imshow_rgba(self):
        """imshow with RGBA array does not raise."""
        fig, ax = plt.subplots()
        data = np.ones((5, 5, 4))
        im = ax.imshow(data)
        assert im is not None
        plt.close('all')

    def test_imshow_cmap(self):
        """imshow with cmap does not raise."""
        fig, ax = plt.subplots()
        data = np.random.rand(10, 10)
        im = ax.imshow(data, cmap='viridis')
        assert im is not None
        plt.close('all')

    def test_imshow_origin(self):
        """imshow with origin='lower' does not raise."""
        fig, ax = plt.subplots()
        data = np.zeros((10, 10))
        ax.imshow(data, origin='lower')
        plt.close('all')

    def test_imshow_vmin_vmax(self):
        """imshow with vmin/vmax does not raise."""
        fig, ax = plt.subplots()
        data = np.linspace(0, 10, 100).reshape(10, 10)
        ax.imshow(data, vmin=0, vmax=5)
        plt.close('all')

    def test_imshow_aspect(self):
        """imshow with aspect='auto' does not raise."""
        fig, ax = plt.subplots()
        data = np.zeros((5, 10))
        ax.imshow(data, aspect='auto')
        plt.close('all')

    def test_imshow_interpolation(self):
        """imshow with interpolation does not raise."""
        fig, ax = plt.subplots()
        data = np.zeros((5, 5))
        ax.imshow(data, interpolation='nearest')
        plt.close('all')

    def test_imshow_extent(self):
        """imshow with extent does not raise."""
        fig, ax = plt.subplots()
        data = np.zeros((5, 5))
        ax.imshow(data, extent=[0, 1, 0, 1])
        plt.close('all')

    def test_imshow_alpha(self):
        """imshow with alpha does not raise."""
        fig, ax = plt.subplots()
        data = np.zeros((5, 5))
        ax.imshow(data, alpha=0.5)
        plt.close('all')

    def test_imshow_returns_axesimage(self):
        """imshow returns an AxesImage."""
        from matplotlib.image import AxesImage
        fig, ax = plt.subplots()
        im = ax.imshow(np.zeros((5, 5)))
        assert isinstance(im, AxesImage)
        plt.close('all')

    def test_imshow_with_colorbar(self):
        """imshow with colorbar does not raise."""
        fig, ax = plt.subplots()
        data = np.random.rand(10, 10)
        im = ax.imshow(data, cmap='plasma')
        fig.colorbar(im)
        plt.close('all')

    def test_imshow_svg(self):
        """Figure with imshow renders to SVG."""
        fig, ax = plt.subplots()
        data = np.arange(100).reshape(10, 10)
        ax.imshow(data, cmap='gray')
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_plt_imshow(self):
        """plt.imshow() does not raise."""
        plt.figure()
        plt.imshow(np.zeros((5, 5)))
        plt.close('all')

    def test_imshow_get_array(self):
        """AxesImage.get_array() returns data."""
        fig, ax = plt.subplots()
        data = np.ones((5, 5)) * 3.0
        im = ax.imshow(data)
        arr = im.get_array()
        assert arr is not None
        plt.close('all')

    def test_imshow_set_clim(self):
        """AxesImage.set_clim() does not raise."""
        fig, ax = plt.subplots()
        im = ax.imshow(np.zeros((5, 5)))
        im.set_clim(0, 1)
        plt.close('all')

    def test_imshow_get_clim(self):
        """AxesImage.get_clim() returns (vmin, vmax)."""
        fig, ax = plt.subplots()
        im = ax.imshow(np.zeros((5, 5)), vmin=0, vmax=1)
        clim = im.get_clim()
        assert clim is not None
        plt.close('all')

    def test_imshow_axis_off(self):
        """imshow with axis('off') does not raise."""
        fig, ax = plt.subplots()
        ax.imshow(np.zeros((5, 5)))
        ax.axis('off')
        plt.close('all')


class TestPltImshow:
    def test_plt_imshow_cmap(self):
        """plt.imshow with cmap does not raise."""
        plt.figure()
        plt.imshow(np.random.rand(10, 10), cmap='hot')
        plt.close('all')

    def test_plt_imshow_with_colorbar(self):
        """plt.imshow then plt.colorbar does not raise."""
        fig, ax = plt.subplots()
        im = ax.imshow(np.random.rand(5, 5))
        plt.colorbar(im, ax=ax)
        plt.close('all')
