"""Tests for image processing, PIL backend, RGBA handling, and image features."""

import pytest
import io
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
import matplotlib.cm as cm


# ---------------------------------------------------------------------------
# imshow features
# ---------------------------------------------------------------------------

class TestImshowFeatures:
    def test_imshow_extent(self):
        """imshow with extent parameter does not raise."""
        fig, ax = plt.subplots()
        data = [[1, 2, 3], [4, 5, 6]]
        ax.imshow(data, extent=[0, 10, 0, 5])
        plt.close('all')

    def test_imshow_origin_upper(self):
        """imshow with origin='upper' does not raise."""
        fig, ax = plt.subplots()
        data = [[1, 2, 3], [4, 5, 6]]
        ax.imshow(data, origin='upper')
        plt.close('all')

    def test_imshow_origin_lower(self):
        """imshow with origin='lower' does not raise."""
        fig, ax = plt.subplots()
        data = [[1, 2, 3], [4, 5, 6]]
        ax.imshow(data, origin='lower')
        plt.close('all')

    def test_imshow_interpolation(self):
        """imshow with interpolation='nearest' does not raise."""
        fig, ax = plt.subplots()
        data = [[1, 2], [3, 4]]
        ax.imshow(data, interpolation='nearest')
        plt.close('all')

    def test_imshow_vmin_vmax(self):
        """imshow with vmin/vmax does not raise."""
        fig, ax = plt.subplots()
        data = [[0, 50, 100], [200, 150, 75]]
        ax.imshow(data, vmin=0, vmax=200, cmap='gray')
        plt.close('all')

    def test_imshow_aspect_auto(self):
        """imshow with aspect='auto' does not raise."""
        fig, ax = plt.subplots()
        data = [[1, 2, 3, 4, 5], [6, 7, 8, 9, 10]]
        ax.imshow(data, aspect='auto')
        plt.close('all')

    def test_imshow_returns_axesimage(self):
        """imshow returns an AxesImage object."""
        from matplotlib.image import AxesImage
        fig, ax = plt.subplots()
        im = ax.imshow([[1, 2], [3, 4]])
        assert isinstance(im, AxesImage)
        plt.close('all')

    def test_imshow_get_clim(self):
        """imshow get_clim returns vmin, vmax."""
        fig, ax = plt.subplots()
        im = ax.imshow([[0, 100], [50, 75]], vmin=0, vmax=100)
        vmin, vmax = im.get_clim()
        assert vmin == pytest.approx(0)
        assert vmax == pytest.approx(100)
        plt.close('all')

    def test_imshow_set_clim(self):
        """imshow set_clim changes the colormap range."""
        fig, ax = plt.subplots()
        im = ax.imshow([[0, 100], [50, 75]])
        im.set_clim(0, 200)
        vmin, vmax = im.get_clim()
        assert vmax == pytest.approx(200)
        plt.close('all')

    def test_imshow_large_grid(self):
        """imshow with larger grid does not raise."""
        fig, ax = plt.subplots()
        data = [[i * j % 100 for j in range(20)] for i in range(20)]
        ax.imshow(data, cmap='viridis')
        plt.close('all')


# ---------------------------------------------------------------------------
# PNG save and byte content
# ---------------------------------------------------------------------------

class TestPNGSave:
    def test_savefig_png_bytes(self):
        """savefig PNG produces valid PNG bytes."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        buf = io.BytesIO()
        fig.savefig(buf, format='png')
        buf.seek(0)
        data = buf.read()
        assert data[:4] == b'\x89PNG'
        plt.close('all')

    def test_savefig_png_nonempty(self):
        """PNG output is non-empty."""
        fig, ax = plt.subplots()
        ax.bar([1, 2, 3], [3, 7, 5])
        buf = io.BytesIO()
        fig.savefig(buf, format='png')
        assert buf.tell() > 100
        plt.close('all')

    def test_savefig_svg_bytes(self):
        """savefig SVG produces UTF-8 SVG bytes."""
        fig, ax = plt.subplots()
        ax.scatter([0, 1, 2], [0, 1, 4])
        buf = io.BytesIO()
        fig.savefig(buf, format='svg')
        buf.seek(0)
        content = buf.read().decode('utf-8')
        assert '<svg' in content
        plt.close('all')

    def test_savefig_dpi(self):
        """savefig with dpi does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        buf = io.BytesIO()
        fig.savefig(buf, format='png', dpi=72)
        assert buf.tell() > 0
        plt.close('all')

    def test_plt_savefig_png(self):
        """plt.savefig() wrapper produces PNG."""
        plt.figure()
        plt.plot([0, 1], [0, 1])
        buf = io.BytesIO()
        plt.savefig(buf, format='png')
        buf.seek(0)
        assert buf.read(4) == b'\x89PNG'
        plt.close('all')


# ---------------------------------------------------------------------------
# Colormap clipping and normalization edge cases
# ---------------------------------------------------------------------------

class TestColormapEdgeCases:
    def test_cmap_out_of_range_low(self):
        """cmap(-1) is handled gracefully (returns under/over color)."""
        cmap = cm.get_cmap('viridis')
        # Should not raise, returns RGBA (possibly 'under' color)
        result = cmap(-1)
        assert len(result) == 4

    def test_cmap_out_of_range_high(self):
        """cmap(2.0) is handled gracefully (returns over color)."""
        cmap = cm.get_cmap('viridis')
        result = cmap(2.0)
        assert len(result) == 4

    def test_norm_clip_true(self):
        """Normalize with clip=True clamps to [0, 1]."""
        from matplotlib.colors import Normalize
        norm = Normalize(vmin=0, vmax=10, clip=True)
        assert norm(-5) == pytest.approx(0.0)
        assert norm(20) == pytest.approx(1.0)

    def test_norm_clip_false(self):
        """Normalize with clip=False allows out-of-range values."""
        from matplotlib.colors import Normalize
        norm = Normalize(vmin=0, vmax=10, clip=False)
        # Values outside range produce masked/out-of-range results
        # Just check it doesn't raise
        val = norm(15)
        assert val is not None

    def test_power_norm(self):
        """PowerNorm normalizes with power scaling."""
        from matplotlib.colors import PowerNorm
        norm = PowerNorm(gamma=2.0, vmin=0, vmax=100)
        assert norm is not None
        # Power norm: 50 ^ 2 / 100 ^ 2 = 0.25
        val = norm(50)
        assert val is not None

    def test_centered_norm(self):
        """CenteredNorm maps around vcenter."""
        from matplotlib.colors import CenteredNorm
        norm = CenteredNorm(vcenter=0)
        assert norm is not None


# ---------------------------------------------------------------------------
# RGBA color manipulation
# ---------------------------------------------------------------------------

class TestRGBAManipulation:
    def test_to_rgba_array(self):
        """to_rgba_array converts list of color strings."""
        colors = ['red', 'blue', 'green']
        rgba_arr = mcolors.to_rgba_array(colors)
        assert len(rgba_arr) == 3

    def test_to_rgba_array_with_alpha(self):
        """to_rgba_array with alpha kwarg does not raise."""
        rgba_arr = mcolors.to_rgba_array(['red', 'blue'], alpha=0.5)
        assert len(rgba_arr) == 2

    def test_hsv_roundtrip(self):
        """HSV to RGB and back is consistent."""
        rgb_in = [0.5, 0.3, 0.8]
        hsv = mcolors.rgb_to_hsv(rgb_in)
        rgb_out = mcolors.hsv_to_rgb(hsv)
        assert rgb_out[0] == pytest.approx(rgb_in[0], abs=0.01)
        assert rgb_out[1] == pytest.approx(rgb_in[1], abs=0.01)
        assert rgb_out[2] == pytest.approx(rgb_in[2], abs=0.01)

    def test_color_sequence_rgba(self):
        """Multiple color formats convert to RGBA correctly."""
        test_cases = [
            ('red', (1, 0, 0, 1)),
            ('green', (0, 0.5019607843137255, 0, 1)),
            ('#ff0000', (1, 0, 0, 1)),
            ((1, 0, 0), (1, 0, 0, 1)),
        ]
        for color, expected_rgb_prefix in test_cases:
            rgba = mcolors.to_rgba(color)
            assert rgba[0] == pytest.approx(expected_rgb_prefix[0], abs=0.01)
            assert rgba[3] == pytest.approx(1.0)
