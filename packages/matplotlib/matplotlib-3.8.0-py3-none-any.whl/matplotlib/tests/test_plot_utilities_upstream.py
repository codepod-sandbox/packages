"""Tests for reference lines, bar_label, facecolor, margins, rcParams, and line styles."""

import pytest
import numpy as np
import matplotlib.pyplot as plt
import matplotlib


# ---------------------------------------------------------------------------
# ax.axhline() / ax.axvline() / ax.axhspan() / ax.axvspan()
# ---------------------------------------------------------------------------

class TestReferenceLines:
    def test_axhline_basic(self):
        """axhline does not raise."""
        fig, ax = plt.subplots()
        ax.axhline(y=0.5)
        plt.close('all')

    def test_axhline_returns_line(self):
        """axhline returns a Line2D."""
        fig, ax = plt.subplots()
        line = ax.axhline(0.5)
        assert line is not None
        plt.close('all')

    def test_axhline_with_style(self):
        """axhline with linestyle/color does not raise."""
        fig, ax = plt.subplots()
        ax.axhline(0.5, color='red', linestyle='--', linewidth=2)
        plt.close('all')

    def test_axvline_basic(self):
        """axvline does not raise."""
        fig, ax = plt.subplots()
        ax.axvline(x=1.0)
        plt.close('all')

    def test_axvline_with_style(self):
        """axvline with color/linestyle does not raise."""
        fig, ax = plt.subplots()
        ax.axvline(1.0, color='blue', linestyle=':')
        plt.close('all')

    def test_axhspan_basic(self):
        """axhspan does not raise."""
        fig, ax = plt.subplots()
        ax.axhspan(0.3, 0.7, facecolor='yellow', alpha=0.3)
        plt.close('all')

    def test_axvspan_basic(self):
        """axvspan does not raise."""
        fig, ax = plt.subplots()
        ax.axvspan(1.0, 2.0, facecolor='green', alpha=0.2)
        plt.close('all')

    def test_reference_lines_svg_renders(self):
        """Axes with reference lines renders to SVG."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2, 3], [0, 1, 4, 9])
        ax.axhline(2.0, color='red', linestyle='--')
        ax.axvline(1.5, color='blue', linestyle=':')
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_plt_axhline(self):
        """plt.axhline() wrapper does not raise."""
        plt.figure()
        plt.plot([0, 1], [0, 1])
        plt.axhline(0.5)
        plt.close('all')

    def test_plt_axvline(self):
        """plt.axvline() wrapper does not raise."""
        plt.figure()
        plt.plot([0, 1], [0, 1])
        plt.axvline(0.5)
        plt.close('all')


# ---------------------------------------------------------------------------
# ax.bar_label()
# ---------------------------------------------------------------------------

class TestBarLabel:
    def test_bar_label_basic(self):
        """bar_label on bar container does not raise."""
        fig, ax = plt.subplots()
        bars = ax.bar([1, 2, 3], [4, 7, 2])
        ax.bar_label(bars)
        plt.close('all')

    def test_bar_label_fmt(self):
        """bar_label with fmt does not raise."""
        fig, ax = plt.subplots()
        bars = ax.bar([1, 2, 3], [4.5, 7.2, 2.1])
        ax.bar_label(bars, fmt='%.1f')
        plt.close('all')

    def test_bar_label_padding(self):
        """bar_label with padding does not raise."""
        fig, ax = plt.subplots()
        bars = ax.bar([1, 2, 3], [4, 7, 2])
        ax.bar_label(bars, padding=3)
        plt.close('all')

    def test_bar_label_svg_renders(self):
        """Bars with labels renders to SVG."""
        fig, ax = plt.subplots()
        bars = ax.bar(['A', 'B', 'C'], [10, 20, 15])
        ax.bar_label(bars)
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')


# ---------------------------------------------------------------------------
# ax.set_facecolor() / fig.set_facecolor()
# ---------------------------------------------------------------------------

class TestFacecolor:
    def test_ax_set_facecolor(self):
        """ax.set_facecolor does not raise."""
        fig, ax = plt.subplots()
        ax.set_facecolor('lightblue')
        plt.close('all')

    def test_ax_get_facecolor(self):
        """ax.get_facecolor returns a value."""
        fig, ax = plt.subplots()
        ax.set_facecolor('lightyellow')
        fc = ax.get_facecolor()
        assert fc is not None
        plt.close('all')

    def test_fig_set_facecolor(self):
        """fig.set_facecolor does not raise."""
        fig, ax = plt.subplots()
        fig.set_facecolor('white')
        plt.close('all')

    def test_facecolor_svg_renders(self):
        """Axes with facecolor renders to SVG."""
        fig, ax = plt.subplots()
        ax.set_facecolor('#f0f0f0')
        ax.plot([0, 1], [0, 1])
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')


# ---------------------------------------------------------------------------
# ax.margins()
# ---------------------------------------------------------------------------

class TestMargins:
    def test_margins_basic(self):
        """margins() does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        ax.margins(0.1)
        plt.close('all')

    def test_margins_xy(self):
        """margins(x, y) does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        ax.margins(x=0.1, y=0.2)
        plt.close('all')

    def test_plt_margins(self):
        """plt.margins() does not raise."""
        plt.figure()
        plt.plot([0, 1], [0, 1])
        plt.margins(0.05)
        plt.close('all')


# ---------------------------------------------------------------------------
# Line styles and markers
# ---------------------------------------------------------------------------

class TestLineStyles:
    def test_linestyle_solid(self):
        """Plot with solid linestyle does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1], linestyle='-')
        plt.close('all')

    def test_linestyle_dashed(self):
        """Plot with dashed linestyle does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1], linestyle='--')
        plt.close('all')

    def test_linestyle_dotted(self):
        """Plot with dotted linestyle does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1], linestyle=':')
        plt.close('all')

    def test_linestyle_none(self):
        """Plot with linestyle='none' (no line) does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2], [0, 1, 4], linestyle='none', marker='o')
        plt.close('all')

    def test_marker_circle(self):
        """Plot with circle marker does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2], [0, 1, 4], marker='o')
        plt.close('all')

    def test_marker_square(self):
        """Plot with square marker does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2], [0, 1, 4], marker='s')
        plt.close('all')

    def test_marker_cross(self):
        """Plot with cross marker does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2], [0, 1, 4], marker='x')
        plt.close('all')

    def test_markersize(self):
        """Plot with markersize does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1], marker='o', markersize=8)
        plt.close('all')

    def test_linewidth(self):
        """Plot with linewidth does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1], linewidth=3)
        plt.close('all')

    def test_format_string(self):
        """Plot with format string shorthand (e.g. 'ro-') does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2], [0, 1, 4], 'ro-')
        plt.close('all')

    def test_line_svg_renders(self):
        """Styled lines render to SVG."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2], [0, 1, 4], 'b--o', linewidth=2, markersize=6)
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')


# ---------------------------------------------------------------------------
# rcParams manipulation
# ---------------------------------------------------------------------------

class TestRcParams:
    def test_rcparams_figure_figsize(self):
        """rcParams['figure.figsize'] can be set and read."""
        import matplotlib
        old = matplotlib.rcParams.get('figure.figsize', [6.4, 4.8])
        matplotlib.rcParams['figure.figsize'] = [10, 6]
        assert matplotlib.rcParams.get('figure.figsize') == [10, 6]
        matplotlib.rcParams['figure.figsize'] = old
        plt.close('all')

    def test_rcparams_lines_linewidth(self):
        """rcParams['lines.linewidth'] can be set."""
        import matplotlib
        matplotlib.rcParams['lines.linewidth'] = 2.0
        plt.close('all')

    def test_plt_rcparams_accessible(self):
        """plt.rcParams is accessible."""
        assert plt.rcParams is not None
        plt.close('all')

    def test_rc_context_manager(self):
        """rc_context temporarily overrides rcParams."""
        import matplotlib
        with matplotlib.rc_context({'lines.linewidth': 5.0}):
            val = matplotlib.rcParams.get('lines.linewidth')
            # Value should be set in context
            assert val is not None
        plt.close('all')
