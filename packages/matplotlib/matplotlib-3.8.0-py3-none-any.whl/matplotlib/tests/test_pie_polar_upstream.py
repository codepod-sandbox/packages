"""
Upstream tests for pie chart and polar axis patterns.
"""

import numpy as np
import pytest
import matplotlib.pyplot as plt


class TestPieCharts:
    """Pie chart patterns."""

    def teardown_method(self):
        plt.close('all')

    def test_pie_basic(self):
        fig, ax = plt.subplots()
        ax.pie([10, 20, 30, 40])

    def test_pie_labels(self):
        fig, ax = plt.subplots()
        ax.pie([10, 20, 30], labels=['A', 'B', 'C'])

    def test_pie_colors(self):
        fig, ax = plt.subplots()
        ax.pie([10, 20, 30], colors=['red', 'green', 'blue'])

    def test_pie_explode(self):
        fig, ax = plt.subplots()
        ax.pie([10, 20, 30], explode=[0, 0.1, 0])

    def test_pie_autopct(self):
        fig, ax = plt.subplots()
        ax.pie([10, 20, 30], autopct='%1.1f%%')

    def test_pie_autopct_function(self):
        fig, ax = plt.subplots()
        ax.pie([10, 20, 30], autopct=lambda p: f'{p:.0f}%')

    def test_pie_shadow(self):
        fig, ax = plt.subplots()
        ax.pie([10, 20, 30], shadow=True)

    def test_pie_startangle(self):
        fig, ax = plt.subplots()
        ax.pie([10, 20, 30], startangle=90)

    def test_pie_counterclock(self):
        fig, ax = plt.subplots()
        ax.pie([10, 20, 30], counterclock=False)

    def test_pie_returns_tuple(self):
        fig, ax = plt.subplots()
        result = ax.pie([10, 20, 30])
        # Returns (patches, texts) or (patches, texts, autotexts)
        assert len(result) >= 2

    def test_pie_pctdistance(self):
        fig, ax = plt.subplots()
        ax.pie([10, 20, 30], autopct='%1.1f%%', pctdistance=0.6)

    def test_pie_labeldistance(self):
        fig, ax = plt.subplots()
        ax.pie([10, 20, 30], labels=['A', 'B', 'C'], labeldistance=1.2)

    def test_pie_with_legend(self):
        """Common: pie with legend instead of labels."""
        fig, ax = plt.subplots()
        categories = ['A', 'B', 'C', 'D']
        values = [15, 30, 25, 30]
        patches, texts = ax.pie(values, startangle=90)
        ax.legend(patches, categories, loc='best')

    def test_donut_chart(self):
        """Common: donut chart using wedgeprops."""
        fig, ax = plt.subplots()
        ax.pie([10, 20, 30, 40],
               wedgeprops=dict(width=0.5),
               startangle=90)
        ax.set_aspect('equal')


class TestPolarAxes:
    """Polar axes patterns."""

    def teardown_method(self):
        plt.close('all')

    def test_polar_basic(self):
        fig, ax = plt.subplots(subplot_kw={'projection': 'polar'})
        theta = [0, 1, 2, 3, 4, 5, 6]
        r = [1, 2, 1, 3, 2, 1, 2]
        ax.plot(theta, r)

    def test_polar_scatter(self):
        fig, ax = plt.subplots(subplot_kw={'projection': 'polar'})
        theta = [0.5, 1.2, 2.1, 3.5, 4.7]
        r = [1, 2, 1.5, 3, 2]
        ax.scatter(theta, r)

    def test_polar_bar(self):
        fig, ax = plt.subplots(subplot_kw={'projection': 'polar'})
        N = 6
        theta = [2 * 3.14159 * i / N for i in range(N)]
        radii = [1, 2, 1.5, 3, 2, 2.5]
        ax.bar(theta, radii, width=0.5)

    def test_polar_fill(self):
        fig, ax = plt.subplots(subplot_kw={'projection': 'polar'})
        theta = [0, 1, 2, 3, 4, 5]
        r = [1, 2, 1, 3, 2, 1]
        ax.fill(theta, r, alpha=0.3)

    def test_polar_set_rlim(self):
        fig, ax = plt.subplots(subplot_kw={'projection': 'polar'})
        ax.plot([0, 1, 2], [1, 2, 1])
        ax.set_rlim(0, 3)

    def test_polar_set_theta_zero_location(self):
        fig, ax = plt.subplots(subplot_kw={'projection': 'polar'})
        ax.set_theta_zero_location('N')

    def test_polar_set_theta_direction(self):
        fig, ax = plt.subplots(subplot_kw={'projection': 'polar'})
        ax.set_theta_direction(-1)  # clockwise
        ax.set_theta_direction(1)   # counterclockwise

    def test_polar_grid(self):
        fig, ax = plt.subplots(subplot_kw={'projection': 'polar'})
        ax.plot([0, 1, 2], [1, 2, 1])
        ax.grid(True)

    def test_radar_chart_pattern(self):
        """Common: radar/spider chart pattern."""
        N = 5
        labels = ['Speed', 'Power', 'Range', 'Accuracy', 'Stealth']
        values = [4, 3, 5, 4, 2]

        import math
        angles = [2 * math.pi * i / N for i in range(N)]
        angles.append(angles[0])
        values_c = values + [values[0]]

        fig, ax = plt.subplots(subplot_kw={'projection': 'polar'})
        ax.plot(angles, values_c)
        ax.fill(angles, values_c, alpha=0.25)
        ax.set_xticks(angles[:-1])

    def test_polar_add_subplot(self):
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='polar')
        ax.plot([0, 1, 2, 3], [1, 2, 1, 2])

    def test_multiple_polar_plots(self):
        fig, ax = plt.subplots(subplot_kw={'projection': 'polar'})
        theta = [0, 1, 2, 3, 4, 5, 6]
        ax.plot(theta, [1] * 7, 'r-', label='circle')
        ax.plot(theta, [t/7 for t in theta], 'b-', label='spiral')
        ax.legend()
