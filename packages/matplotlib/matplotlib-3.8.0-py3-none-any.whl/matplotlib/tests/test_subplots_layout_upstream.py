"""Tests for subplot layouts, GridSpec, tight_layout, and figure sizing."""

import pytest
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec


# ---------------------------------------------------------------------------
# GridSpec
# ---------------------------------------------------------------------------

class TestGridSpec:
    def test_gridspec_basic(self):
        """GridSpec 2x2 does not raise."""
        fig = plt.figure()
        gs = gridspec.GridSpec(2, 2)
        ax1 = fig.add_subplot(gs[0, 0])
        ax2 = fig.add_subplot(gs[0, 1])
        ax3 = fig.add_subplot(gs[1, 0])
        ax4 = fig.add_subplot(gs[1, 1])
        assert ax1 is not None
        assert ax4 is not None
        plt.close('all')

    def test_gridspec_span(self):
        """GridSpec with spanning subplot does not raise."""
        fig = plt.figure()
        gs = gridspec.GridSpec(2, 2)
        ax_top = fig.add_subplot(gs[0, :])   # spans full top row
        ax_bl = fig.add_subplot(gs[1, 0])
        ax_br = fig.add_subplot(gs[1, 1])
        assert ax_top is not None
        plt.close('all')

    def test_gridspec_3x1(self):
        """GridSpec 3x1 does not raise."""
        fig = plt.figure()
        gs = gridspec.GridSpec(3, 1)
        for i in range(3):
            ax = fig.add_subplot(gs[i, 0])
            assert ax is not None
        plt.close('all')

    def test_gridspec_hspace_wspace(self):
        """GridSpec with hspace/wspace does not raise."""
        fig = plt.figure()
        gs = gridspec.GridSpec(2, 2, hspace=0.4, wspace=0.3)
        for row in range(2):
            for col in range(2):
                fig.add_subplot(gs[row, col])
        plt.close('all')

    def test_gridspec_svg_renders(self):
        """GridSpec layout renders to SVG."""
        fig = plt.figure()
        gs = gridspec.GridSpec(2, 2)
        for row in range(2):
            for col in range(2):
                ax = fig.add_subplot(gs[row, col])
                ax.plot([0, 1], [0, 1])
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')


# ---------------------------------------------------------------------------
# plt.subplots with nrows/ncols
# ---------------------------------------------------------------------------

class TestSubplotsLayout:
    def test_subplots_1x2(self):
        """plt.subplots(1, 2) returns two axes."""
        fig, axes = plt.subplots(1, 2)
        assert len(axes) == 2
        plt.close('all')

    def test_subplots_2x1(self):
        """plt.subplots(2, 1) returns two axes."""
        fig, axes = plt.subplots(2, 1)
        assert len(axes) == 2
        plt.close('all')

    def test_subplots_2x2(self):
        """plt.subplots(2, 2) returns 2x2 array of axes."""
        fig, axes = plt.subplots(2, 2)
        assert len(axes) == 2
        assert len(axes[0]) == 2
        plt.close('all')

    def test_subplots_sharex(self):
        """plt.subplots with sharex=True does not raise."""
        fig, axes = plt.subplots(2, 1, sharex=True)
        assert len(axes) == 2
        plt.close('all')

    def test_subplots_sharey(self):
        """plt.subplots with sharey=True does not raise."""
        fig, axes = plt.subplots(1, 2, sharey=True)
        assert len(axes) == 2
        plt.close('all')

    def test_subplots_figsize(self):
        """plt.subplots with figsize does not raise."""
        fig, axes = plt.subplots(1, 2, figsize=(10, 4))
        assert len(axes) == 2
        plt.close('all')

    def test_subplots_multiple_plot(self):
        """Plotting to multiple subplots does not raise."""
        fig, axes = plt.subplots(2, 2)
        data = [1, 2, 3, 4]
        for row in axes:
            for ax in row:
                ax.plot(data, data)
        plt.close('all')

    def test_subplots_svg_renders(self):
        """Multiple subplots render to SVG."""
        fig, axes = plt.subplots(2, 2, figsize=(8, 6))
        for row in axes:
            for ax in row:
                ax.plot([0, 1], [0, 1])
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')


# ---------------------------------------------------------------------------
# Figure sizing and DPI
# ---------------------------------------------------------------------------

class TestFigureSizing:
    def test_figure_figsize(self):
        """Figure can be created with figsize."""
        fig = plt.figure(figsize=(8, 6))
        assert fig is not None
        plt.close('all')

    def test_figure_dpi(self):
        """Figure can be created with dpi."""
        fig = plt.figure(dpi=150)
        assert fig is not None
        plt.close('all')

    def test_figure_set_size_inches(self):
        """set_size_inches does not raise."""
        fig, ax = plt.subplots()
        fig.set_size_inches(10, 8)
        plt.close('all')

    def test_figure_get_size_inches(self):
        """get_size_inches returns a tuple."""
        fig = plt.figure(figsize=(8, 6))
        size = fig.get_size_inches()
        assert size is not None
        plt.close('all')

    def test_figure_set_dpi(self):
        """set_dpi does not raise."""
        fig, ax = plt.subplots()
        fig.set_dpi(150)
        plt.close('all')

    def test_figure_get_dpi(self):
        """get_dpi returns a value."""
        fig = plt.figure(dpi=100)
        dpi = fig.get_dpi()
        assert dpi is not None
        plt.close('all')


# ---------------------------------------------------------------------------
# tight_layout
# ---------------------------------------------------------------------------

class TestTightLayout:
    def test_tight_layout_basic(self):
        """tight_layout does not raise."""
        fig, axes = plt.subplots(2, 2)
        for row in axes:
            for ax in row:
                ax.plot([0, 1], [0, 1])
                ax.set_title('title')
        fig.tight_layout()
        plt.close('all')

    def test_tight_layout_pad(self):
        """tight_layout with pad does not raise."""
        fig, axes = plt.subplots(1, 2)
        for ax in axes:
            ax.plot([0, 1], [0, 1])
        fig.tight_layout(pad=2.0)
        plt.close('all')

    def test_plt_tight_layout(self):
        """plt.tight_layout() wrapper does not raise."""
        fig, axes = plt.subplots(2, 1)
        for ax in axes:
            ax.plot([0, 1], [0, 1])
        plt.tight_layout()
        plt.close('all')
