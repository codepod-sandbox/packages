"""Tests for figure/axes management: clear, clf, subplot(), custom colormaps."""

import pytest
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.cm as cm
import matplotlib.colors as mcolors


# ---------------------------------------------------------------------------
# plt.subplot() (single-subplot form, not subplots)
# ---------------------------------------------------------------------------

class TestSubplot:
    def test_subplot_111(self):
        """plt.subplot(111) returns axes."""
        plt.figure()
        ax = plt.subplot(111)
        assert ax is not None
        plt.close('all')

    def test_subplot_211_212(self):
        """plt.subplot(211)/plt.subplot(212) creates 2-row layout."""
        plt.figure()
        ax1 = plt.subplot(211)
        ax2 = plt.subplot(212)
        assert ax1 is not None
        assert ax2 is not None
        plt.close('all')

    def test_subplot_current_axes(self):
        """plt.gca() after plt.subplot() returns that axes."""
        plt.figure()
        ax = plt.subplot(111)
        current = plt.gca()
        assert current is ax
        plt.close('all')

    def test_subplot_plot_renders(self):
        """Subplots with plots render to SVG."""
        fig = plt.figure()
        ax1 = plt.subplot(211)
        ax1.plot([0, 1], [0, 1])
        ax2 = plt.subplot(212)
        ax2.bar([1, 2], [3, 4])
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')


# ---------------------------------------------------------------------------
# ax.cla() / fig.clf()
# ---------------------------------------------------------------------------

class TestClearAxes:
    def test_cla_clears_lines(self):
        """ax.cla() clears lines from axes."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        assert len(ax.lines) == 1
        ax.cla()
        assert len(ax.lines) == 0
        plt.close('all')

    def test_cla_allows_reuse(self):
        """ax.cla() followed by new plot does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        ax.cla()
        ax.bar([1, 2], [3, 4])
        plt.close('all')

    def test_clear_alias(self):
        """ax.clear() is an alias for ax.cla()."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        ax.clear()
        assert len(ax.lines) == 0
        plt.close('all')

    def test_clf_clears_figure(self):
        """fig.clf() clears all axes from figure."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        fig.clf()
        assert len(fig.get_axes()) == 0
        plt.close('all')

    def test_plt_clf(self):
        """plt.clf() does not raise."""
        plt.figure()
        plt.plot([0, 1], [0, 1])
        plt.clf()
        plt.close('all')

    def test_plt_cla(self):
        """plt.cla() does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        plt.cla()
        plt.close('all')


# ---------------------------------------------------------------------------
# plt.pause()
# ---------------------------------------------------------------------------

class TestPause:
    def test_pause_does_not_raise(self):
        """plt.pause() does not raise."""
        plt.figure()
        plt.plot([0, 1], [0, 1])
        plt.pause(0.001)
        plt.close('all')


# ---------------------------------------------------------------------------
# Custom colormaps
# ---------------------------------------------------------------------------

class TestCustomColormaps:
    def test_from_list_basic(self):
        """LinearSegmentedColormap.from_list creates a colormap."""
        cmap = mcolors.LinearSegmentedColormap.from_list(
            'custom', ['blue', 'white', 'red']
        )
        assert cmap is not None
        assert cmap.name == 'custom'

    def test_from_list_callable(self):
        """Custom colormap can be called with 0-1 values."""
        cmap = mcolors.LinearSegmentedColormap.from_list(
            'mybw', ['black', 'white']
        )
        rgba0 = cmap(0.0)
        rgba1 = cmap(1.0)
        assert len(rgba0) == 4
        assert len(rgba1) == 4

    def test_from_list_with_n(self):
        """LinearSegmentedColormap.from_list with N colors does not raise."""
        cmap = mcolors.LinearSegmentedColormap.from_list(
            'custom', ['red', 'green', 'blue'], N=256
        )
        assert cmap is not None

    def test_listed_colormap(self):
        """ListedColormap from list of colors works."""
        colors = ['red', 'green', 'blue', 'yellow']
        cmap = mcolors.ListedColormap(colors)
        assert cmap is not None

    def test_listed_colormap_callable(self):
        """ListedColormap(0.0) returns valid RGBA."""
        cmap = mcolors.ListedColormap(['red', 'blue'])
        rgba = cmap(0.0)
        assert len(rgba) == 4

    def test_register_colormap(self):
        """Registering a custom colormap and using it by name does not raise."""
        import matplotlib
        cmap = mcolors.LinearSegmentedColormap.from_list('my_cmap', ['black', 'white'])
        matplotlib.colormaps.register(cmap, name='my_cmap', force=True)
        # Can retrieve it
        retrieved = cm.get_cmap('my_cmap')
        assert retrieved is not None

    def test_custom_cmap_in_imshow(self):
        """imshow with custom colormap does not raise."""
        fig, ax = plt.subplots()
        cmap = mcolors.LinearSegmentedColormap.from_list('rb', ['red', 'blue'])
        data = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
        ax.imshow(data, cmap=cmap)
        plt.close('all')


# ---------------------------------------------------------------------------
# Figure size and DPI
# ---------------------------------------------------------------------------

class TestFigureSize:
    def test_figure_with_figsize(self):
        """plt.figure(figsize=(10,5)) does not raise."""
        fig = plt.figure(figsize=(10, 5))
        assert fig is not None
        plt.close('all')

    def test_subplots_figsize(self):
        """plt.subplots(figsize=...) does not raise."""
        fig, ax = plt.subplots(figsize=(8, 6))
        assert ax is not None
        plt.close('all')

    def test_set_size_inches(self):
        """fig.set_size_inches does not raise."""
        fig, ax = plt.subplots()
        fig.set_size_inches(10, 8)
        plt.close('all')

    def test_get_size_inches(self):
        """fig.get_size_inches returns width and height."""
        fig = plt.figure(figsize=(8, 6))
        size = fig.get_size_inches()
        assert size is not None
        plt.close('all')


# ---------------------------------------------------------------------------
# Multiple figures
# ---------------------------------------------------------------------------

class TestMultipleFigures:
    def test_multiple_figures_independent(self):
        """Multiple figures can be created independently."""
        fig1 = plt.figure()
        fig2 = plt.figure()
        assert fig1 is not fig2
        plt.close('all')

    def test_plt_figure_num(self):
        """plt.figure(num) selects figure by number."""
        fig1 = plt.figure(1)
        plt.plot([0, 1], [0, 1])
        fig2 = plt.figure(2)
        plt.plot([0, 1], [1, 0])
        assert fig1 is not fig2
        plt.close('all')

    def test_plt_gcf_returns_current(self):
        """plt.gcf() returns current figure."""
        fig = plt.figure()
        assert plt.gcf() is fig
        plt.close('all')

    def test_close_all(self):
        """plt.close('all') does not raise."""
        plt.figure()
        plt.figure()
        plt.close('all')

    def test_get_fignums(self):
        """plt.get_fignums() returns list of figure numbers."""
        plt.close('all')
        fig1 = plt.figure()
        fig2 = plt.figure()
        nums = plt.get_fignums()
        assert len(nums) >= 2
        plt.close('all')
