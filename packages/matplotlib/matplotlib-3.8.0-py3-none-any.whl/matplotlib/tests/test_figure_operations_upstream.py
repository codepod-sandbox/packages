"""Tests for figure-level operations and common matplotlib workflows."""

import pytest
import io
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec


class TestFigureCreation:
    def test_figure_default(self):
        """Create default figure."""
        fig = plt.figure()
        assert fig is not None
        plt.close('all')

    def test_figure_figsize(self):
        """Create figure with figsize."""
        fig = plt.figure(figsize=(10, 6))
        assert fig.get_figwidth() == 10
        assert fig.get_figheight() == 6
        plt.close('all')

    def test_figure_dpi(self):
        """Create figure with dpi."""
        fig = plt.figure(dpi=150)
        assert fig.get_dpi() == 150
        plt.close('all')

    def test_subplots_1x1(self):
        """1x1 subplot."""
        fig, ax = plt.subplots()
        assert fig is not None
        assert ax is not None
        plt.close('all')

    def test_subplots_1x2(self):
        """1x2 subplots."""
        fig, (ax1, ax2) = plt.subplots(1, 2)
        assert ax1 is not None
        assert ax2 is not None
        plt.close('all')

    def test_subplots_2x2(self):
        """2x2 subplots."""
        fig, axes = plt.subplots(2, 2)
        assert len(axes) == 2
        assert len(axes[0]) == 2
        plt.close('all')

    def test_subplots_figsize(self):
        """Subplots with figsize."""
        fig, axes = plt.subplots(1, 3, figsize=(15, 5))
        assert fig.get_figwidth() == 15
        plt.close('all')

    def test_gcf_gca(self):
        """Get current figure and axes."""
        plt.plot([1, 2, 3], [1, 2, 3])
        fig = plt.gcf()
        ax = plt.gca()
        assert fig is not None
        assert ax is not None
        plt.close('all')

    def test_plt_close_all(self):
        """Close all figures."""
        for _ in range(5):
            plt.figure()
        plt.close('all')

    def test_plt_close_specific(self):
        """Close specific figure."""
        fig = plt.figure()
        plt.close(fig)


class TestFigureOutput:
    def test_savefig_png(self):
        """Save figure as PNG."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3])
        buf = io.BytesIO()
        fig.savefig(buf, format='png')
        buf.seek(0)
        data = buf.read()
        assert len(data) > 0
        assert data[:4] == b'\x89PNG'
        plt.close('all')

    def test_savefig_svg(self):
        """Save figure as SVG."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3])
        buf = io.StringIO()
        fig.savefig(buf, format='svg')
        buf.seek(0)
        content = buf.read()
        assert '<svg' in content
        plt.close('all')

    def test_savefig_to_file_path(self):
        """Save figure to file path."""
        import os, tempfile
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3])
        with tempfile.NamedTemporaryFile(suffix='.png', delete=False) as f:
            path = f.name
        try:
            fig.savefig(path)
            assert os.path.exists(path)
            assert os.path.getsize(path) > 0
        finally:
            os.unlink(path)
        plt.close('all')

    def test_to_svg(self):
        """Figure.to_svg() returns SVG string."""
        fig, ax = plt.subplots()
        ax.bar(['A', 'B', 'C'], [1, 2, 3])
        svg = fig.to_svg()
        assert isinstance(svg, str)
        assert '<svg' in svg
        assert len(svg) > 100
        plt.close('all')

    def test_savefig_dpi(self):
        """Save figure with custom DPI."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3])
        buf = io.BytesIO()
        fig.savefig(buf, format='png', dpi=72)
        buf.seek(0)
        assert len(buf.read()) > 0
        plt.close('all')

    def test_multiple_savefig(self):
        """Save same figure multiple times."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3])
        buf1 = io.BytesIO()
        buf2 = io.BytesIO()
        fig.savefig(buf1, format='png')
        fig.savefig(buf2, format='png')
        buf1.seek(0)
        buf2.seek(0)
        assert len(buf1.read()) > 0
        assert len(buf2.read()) > 0
        plt.close('all')


class TestPyplotInterface:
    def test_plt_plot(self):
        """plt.plot."""
        plt.plot([1, 2, 3], [1, 2, 3])
        plt.close('all')

    def test_plt_scatter(self):
        """plt.scatter."""
        plt.scatter([1.0, 2.0, 3.0], [1.0, 2.0, 3.0])
        plt.close('all')

    def test_plt_bar(self):
        """plt.bar."""
        plt.bar(['A', 'B', 'C'], [1, 2, 3])
        plt.close('all')

    def test_plt_hist(self):
        """plt.hist."""
        plt.hist([1.0, 2.0, 2.5, 3.0, 3.5, 4.0])
        plt.close('all')

    def test_plt_imshow(self):
        """plt.imshow."""
        plt.imshow([[1.0, 2.0], [3.0, 4.0]])
        plt.close('all')

    def test_plt_xlabel_ylabel(self):
        """plt.xlabel and plt.ylabel."""
        plt.plot([1, 2, 3], [1, 2, 3])
        plt.xlabel('X Axis')
        plt.ylabel('Y Axis')
        plt.close('all')

    def test_plt_title(self):
        """plt.title."""
        plt.plot([1, 2, 3], [1, 2, 3])
        plt.title('My Plot')
        plt.close('all')

    def test_plt_xlim_ylim(self):
        """plt.xlim and plt.ylim."""
        plt.plot([1, 2, 3], [1, 2, 3])
        plt.xlim(0, 5)
        plt.ylim(-1, 4)
        plt.close('all')

    def test_plt_legend(self):
        """plt.legend."""
        plt.plot([1, 2, 3], [1, 2, 3], label='Line A')
        plt.plot([1, 2, 3], [3, 2, 1], label='Line B')
        plt.legend()
        plt.close('all')

    def test_plt_grid(self):
        """plt.grid."""
        plt.plot([1, 2, 3], [1, 2, 3])
        plt.grid(True)
        plt.close('all')

    def test_plt_tight_layout(self):
        """plt.tight_layout."""
        fig, axes = plt.subplots(2, 2)
        plt.tight_layout()
        plt.close('all')

    def test_plt_savefig(self):
        """plt.savefig."""
        plt.plot([1, 2, 3], [1, 2, 3])
        buf = io.BytesIO()
        plt.savefig(buf, format='png')
        buf.seek(0)
        assert len(buf.read()) > 0
        plt.close('all')

    def test_plt_subplots_adjust(self):
        """plt.subplots_adjust."""
        fig, axes = plt.subplots(2, 2)
        plt.subplots_adjust(hspace=0.5, wspace=0.3)
        plt.close('all')

    def test_plt_xticks_yticks(self):
        """plt.xticks and plt.yticks."""
        plt.plot([1, 2, 3, 4], [1, 2, 3, 4])
        plt.xticks([1, 2, 3, 4], ['One', 'Two', 'Three', 'Four'])
        plt.yticks([1, 2, 3, 4])
        plt.close('all')
