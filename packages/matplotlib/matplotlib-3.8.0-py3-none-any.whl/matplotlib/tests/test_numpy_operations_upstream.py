"""
Upstream tests for numpy operations within matplotlib plotting context.
Focus on patterns LLMs frequently use when combining numpy computations with plots.
"""

import pytest
import numpy as np
import matplotlib.pyplot as plt


class TestNumpyMathPlotting:
    """Tests for numpy math operations in plot contexts."""

    def teardown_method(self):
        plt.close('all')

    def test_polyfit_plot(self):
        """Polynomial fitting with numpy."""
        x = np.array([1.0, 2.0, 3.0, 4.0, 5.0])
        y = np.array([2.1, 4.0, 9.2, 16.1, 25.3])
        coeffs = np.polyfit(x, y, 2)
        poly = np.poly1d(coeffs)
        x_fit = np.linspace(1, 5, 50)
        y_fit = poly(x_fit)
        fig, ax = plt.subplots()
        ax.scatter(x, y)
        ax.plot(x_fit, y_fit)
        assert coeffs is not None

    def test_fft_plot(self):
        """FFT spectrum plot."""
        t = np.linspace(0, 1, 1000)
        signal = np.sin(2 * np.pi * 10 * t) + 0.5 * np.sin(2 * np.pi * 25 * t)
        fft_vals = np.fft.fft(signal)
        freqs = np.fft.fftfreq(len(signal), t[1] - t[0])
        # Only positive frequencies
        pos_mask = freqs > 0
        fig, ax = plt.subplots()
        ax.plot(freqs[pos_mask], np.abs(fft_vals[pos_mask]))
        ax.set_xlabel('Frequency (Hz)')
        ax.set_ylabel('Amplitude')

    def test_histogram_numpy_computed(self):
        """numpy.histogram then manual bar plot."""
        rng = np.random.default_rng(42)
        data = rng.normal(0, 1, 100)
        counts, bin_edges = np.histogram(data, bins=15)
        centers = (bin_edges[:-1] + bin_edges[1:]) / 2
        widths = bin_edges[1:] - bin_edges[:-1]
        fig, ax = plt.subplots()
        ax.bar(centers, counts, width=widths * 0.9)
        assert len(counts) == 15

    def test_gradient_plot(self):
        """Numerical gradient with numpy."""
        x = np.linspace(0, 2 * np.pi, 100)
        y = np.sin(x)
        dy = np.gradient(y, x)
        fig, ax = plt.subplots()
        ax.plot(x, y, label='sin(x)')
        ax.plot(x, dy, label='d/dx sin(x)')
        ax.legend()

    def test_cumsum_plot(self):
        """Cumulative sum plot."""
        rng = np.random.default_rng(42)
        returns = rng.normal(0.001, 0.02, 100)
        cumulative = np.cumsum(returns)
        fig, ax = plt.subplots()
        ax.plot(cumulative)
        ax.axhline(0, color='black', linewidth=0.5)
        ax.set_title('Cumulative Returns')

    def test_diff_plot(self):
        """Difference plot."""
        y = np.array([1.0, 4.0, 9.0, 16.0, 25.0])
        dy = np.diff(y)
        fig, ax = plt.subplots()
        ax.plot(dy)
        ax.set_title('First Differences')

    def test_moving_average(self):
        """Moving average with convolution."""
        rng = np.random.default_rng(42)
        signal = np.cumsum(rng.randn(100))
        window = 5
        ma = np.convolve(signal, np.ones(window)/window, mode='valid')
        fig, ax = plt.subplots()
        ax.plot(signal, alpha=0.4, label='Raw')
        ax.plot(np.arange(window-1, len(signal)), ma, lw=2, label='MA(5)')
        ax.legend()

    def test_interpolation_plot(self):
        """Linear interpolation."""
        x_known = np.array([0.0, 1.0, 3.0, 5.0])
        y_known = np.array([0.0, 2.0, 1.5, 4.0])
        x_interp = np.linspace(0, 5, 50)
        y_interp = np.interp(x_interp, x_known, y_interp if False else x_interp * 0)
        y_interp = np.interp(x_interp, x_known, y_known)
        fig, ax = plt.subplots()
        ax.scatter(x_known, y_known, s=50, zorder=5)
        ax.plot(x_interp, y_interp)

    def test_percentile_band(self):
        """Plot median with percentile bands."""
        rng = np.random.default_rng(42)
        x = np.linspace(0, 10, 50)
        # 100 samples
        samples = np.array([np.sin(x) + rng.normal(0, 0.3, len(x)) for _ in range(100)])
        median = np.percentile(samples, 50, axis=0)
        p25 = np.percentile(samples, 25, axis=0)
        p75 = np.percentile(samples, 75, axis=0)
        fig, ax = plt.subplots()
        ax.plot(x, median, 'b-', lw=2, label='Median')
        ax.fill_between(x, p25, p75, alpha=0.3, label='IQR')
        ax.legend()

    def test_log_normal_fit(self):
        """Log-normal distribution fit."""
        rng = np.random.default_rng(42)
        data = rng.lognormal(0, 0.5, 200)
        log_data = np.log(data)
        mu = np.mean(log_data)
        sigma = np.std(log_data)
        fig, ax = plt.subplots()
        ax.hist(data, bins=30, density=True, alpha=0.7)
        x = np.linspace(0.01, 5, 100)
        pdf = np.exp(-(np.log(x) - mu)**2 / (2 * sigma**2)) / (x * sigma * np.sqrt(2 * np.pi))
        ax.plot(x, pdf, 'r-', lw=2)


class TestNumpyArrayPlotArguments:
    """Tests for passing numpy arrays directly to plot functions."""

    def teardown_method(self):
        plt.close('all')

    def test_plot_2d_array_column(self):
        """Plot columns of a 2D array."""
        data = np.random.rand(10, 3)
        fig, ax = plt.subplots()
        for col in data.T:
            ax.plot(col)
        assert len(ax.lines) == 3

    def test_scatter_ndarray_colors(self):
        """Scatter with ndarray color values."""
        rng = np.random.default_rng(42)
        x = rng.uniform(0, 10, 50)
        y = rng.uniform(0, 10, 50)
        c = np.sqrt(x**2 + y**2)
        fig, ax = plt.subplots()
        sc = ax.scatter(x, y, c=c, cmap='viridis')
        assert sc is not None

    def test_fill_between_computed(self):
        """fill_between with numpy computed bounds."""
        x = np.linspace(0, 10, 100)
        y = np.sin(x)
        std = 0.2 * np.ones_like(x)
        fig, ax = plt.subplots()
        ax.plot(x, y)
        ax.fill_between(x, y - std, y + std, alpha=0.3, color='blue')

    def test_errorbar_ndarray(self):
        """errorbar with ndarray errors."""
        x = np.arange(5)
        y = np.random.rand(5)
        yerr = np.random.rand(5) * 0.1
        fig, ax = plt.subplots()
        ax.errorbar(x, y, yerr=yerr, fmt='o-')

    def test_bar_ndarray_heights(self):
        """bar with ndarray heights."""
        x = np.arange(8)
        heights = np.random.rand(8) * 10
        fig, ax = plt.subplots()
        ax.bar(x, heights)
        assert len(ax.patches) == 8

    def test_imshow_computed_data(self):
        """imshow with numpy computed data."""
        x = np.linspace(-3, 3, 50)
        y = np.linspace(-3, 3, 50)
        X, Y = np.meshgrid(x, y)
        Z = np.exp(-(X**2 + Y**2)) + 0.5 * np.exp(-((X-1)**2 + (Y-1)**2))
        fig, ax = plt.subplots()
        im = ax.imshow(Z, extent=[-3, 3, -3, 3], origin='lower', cmap='hot')
        fig.colorbar(im, ax=ax)

    def test_boxplot_ndarray_list(self):
        """boxplot with list of ndarray."""
        rng = np.random.default_rng(42)
        data = [rng.normal(i, 1, 50) for i in range(4)]
        fig, ax = plt.subplots()
        ax.boxplot(data)

    def test_hist_flattened_2d(self):
        """hist with flattened 2D array."""
        rng = np.random.default_rng(42)
        data = rng.normal(0, 1, (10, 10)).flatten()
        fig, ax = plt.subplots()
        ax.hist(data, bins=20)
