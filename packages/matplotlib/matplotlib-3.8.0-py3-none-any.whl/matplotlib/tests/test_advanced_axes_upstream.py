"""
Upstream tests for advanced axes patterns - shared axes, inset axes,
projection handling, and axis manipulation.
"""

import numpy as np
import pytest
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec


class TestSharedAxes:
    """Tests for shared axes behavior."""

    def teardown_method(self):
        plt.close('all')

    def test_sharex_xlim_propagates(self):
        fig, (ax1, ax2) = plt.subplots(2, 1, sharex=True)
        ax1.set_xlim(0, 10)
        lo, hi = ax2.get_xlim()
        assert lo == 0
        assert hi == 10

    def test_sharey_ylim_propagates(self):
        fig, (ax1, ax2) = plt.subplots(1, 2, sharey=True)
        ax1.set_ylim(-5, 5)
        lo, hi = ax2.get_ylim()
        assert lo == -5
        assert hi == 5

    def test_sharex_all(self):
        fig, axes = plt.subplots(3, 1, sharex=True)
        axes[0].set_xlim(0, 100)
        for ax in axes[1:]:
            lo, hi = ax.get_xlim()
            assert lo == 0
            assert hi == 100

    def test_sharey_all(self):
        fig, axes = plt.subplots(1, 3, sharey=True)
        axes[0].set_ylim(-1, 1)
        for ax in axes[1:]:
            lo, hi = ax.get_ylim()
            assert lo == -1
            assert hi == 1

    def test_sharex_independent_y(self):
        fig, (ax1, ax2) = plt.subplots(2, 1, sharex=True)
        ax1.set_xlim(0, 10)
        ax1.set_ylim(0, 100)
        ax2.set_ylim(-5, 5)
        # y-axes are independent
        assert ax1.get_ylim() == (0, 100)
        assert ax2.get_ylim() == (-5, 5)
        # but x is shared
        assert ax1.get_xlim() == ax2.get_xlim()


class TestTwinAxes:
    """Tests for twin axes."""

    def teardown_method(self):
        plt.close('all')

    def test_twinx_basic(self):
        fig, ax1 = plt.subplots()
        ax2 = ax1.twinx()
        ax1.plot([1, 2, 3], [10, 20, 30])
        ax2.plot([1, 2, 3], [0.1, 0.2, 0.3])

    def test_twiny_basic(self):
        fig, ax1 = plt.subplots()
        ax2 = ax1.twiny()
        ax1.plot([1, 2, 3], [10, 20, 30])
        ax2.plot([10, 20, 30], [10, 20, 30])

    def test_twinx_independent_ylim(self):
        fig, ax1 = plt.subplots()
        ax2 = ax1.twinx()
        ax1.set_ylim(0, 100)
        ax2.set_ylim(-1, 1)
        assert ax1.get_ylim() == (0, 100)
        assert ax2.get_ylim() == (-1, 1)

    def test_twinx_shared_xlim(self):
        fig, ax1 = plt.subplots()
        ax2 = ax1.twinx()
        ax1.set_xlim(0, 10)
        # Twin axes typically share x-axis
        lo, hi = ax2.get_xlim()
        assert lo == 0
        assert hi == 10

    def test_twinx_labels(self):
        fig, ax1 = plt.subplots()
        ax2 = ax1.twinx()
        ax1.set_ylabel('Left Y', color='blue')
        ax2.set_ylabel('Right Y', color='red')

    def test_twinx_legend_combined(self):
        fig, ax1 = plt.subplots()
        ax2 = ax1.twinx()
        l1, = ax1.plot([1, 2, 3], [1, 2, 3], 'b-', label='left data')
        l2, = ax2.plot([1, 2, 3], [10, 5, 8], 'r-', label='right data')
        ax1.legend(handles=[l1, l2])


class TestAxisManipulation:
    """Tests for axis manipulation methods."""

    def teardown_method(self):
        plt.close('all')

    def test_cla_clears_content(self):
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3])
        ax.cla()
        assert len(ax.lines) == 0

    def test_clf_clears_figure(self):
        fig = plt.figure()
        ax = fig.add_subplot(111)
        ax.plot([1, 2, 3])
        fig.clf()

    def test_get_children(self):
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3])
        children = ax.get_children()
        assert isinstance(children, list)

    def test_get_title(self):
        fig, ax = plt.subplots()
        ax.set_title('Test Title')
        assert ax.get_title() == 'Test Title'

    def test_get_xlabel(self):
        fig, ax = plt.subplots()
        ax.set_xlabel('X Label')
        assert ax.get_xlabel() == 'X Label'

    def test_get_ylabel(self):
        fig, ax = plt.subplots()
        ax.set_ylabel('Y Label')
        assert ax.get_ylabel() == 'Y Label'

    def test_set_axis_off(self):
        fig, ax = plt.subplots()
        ax.set_axis_off()

    def test_set_axis_on(self):
        fig, ax = plt.subplots()
        ax.set_axis_off()
        ax.set_axis_on()

    def test_get_lines(self):
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3])
        ax.plot([4, 5, 6])
        assert len(ax.lines) == 2

    def test_get_patches(self):
        fig, ax = plt.subplots()
        import matplotlib.patches as mpatches
        ax.add_patch(mpatches.Rectangle((0, 0), 1, 1))
        # patches list has the rectangle plus axes background
        assert len(ax.patches) >= 1

    def test_get_images(self):
        fig, ax = plt.subplots()
        ax.imshow([[1, 2], [3, 4]])
        assert len(ax.images) == 1

    def test_get_collections(self):
        fig, ax = plt.subplots()
        ax.scatter([1, 2, 3], [4, 5, 6])
        assert len(ax.collections) >= 1

    def test_axhline(self):
        fig, ax = plt.subplots()
        line = ax.axhline(y=0, color='k', linestyle='--')
        assert line is not None

    def test_axvline(self):
        fig, ax = plt.subplots()
        line = ax.axvline(x=1, color='r', linewidth=2)
        assert line is not None

    def test_axhspan(self):
        fig, ax = plt.subplots()
        span = ax.axhspan(1, 2, alpha=0.3, color='yellow')
        assert span is not None

    def test_axvspan(self):
        fig, ax = plt.subplots()
        span = ax.axvspan(1, 2, alpha=0.3, color='green')
        assert span is not None

    def test_hlines(self):
        fig, ax = plt.subplots()
        ax.hlines([1, 2, 3], 0, 5)

    def test_vlines(self):
        fig, ax = plt.subplots()
        ax.vlines([1, 2, 3], 0, 5)

    def test_set_xscale_log(self):
        fig, ax = plt.subplots()
        ax.set_xscale('log')
        assert ax.get_xscale() == 'log'

    def test_set_yscale_log(self):
        fig, ax = plt.subplots()
        ax.set_yscale('log')
        assert ax.get_yscale() == 'log'

    def test_set_scale_linear(self):
        fig, ax = plt.subplots()
        ax.set_xscale('log')
        ax.set_xscale('linear')
        assert ax.get_xscale() == 'linear'
