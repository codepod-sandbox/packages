"""
Upstream tests for imshow, colormap, and pcolormesh patterns.
"""

import numpy as np
import pytest
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors


class TestImshow:
    """Tests for ax.imshow() usage."""

    def teardown_method(self):
        plt.close('all')

    def test_imshow_2d_array(self):
        data = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
        fig, ax = plt.subplots()
        im = ax.imshow(data)
        assert im is not None

    def test_imshow_cmap(self):
        data = [[1, 2], [3, 4]]
        fig, ax = plt.subplots()
        im = ax.imshow(data, cmap='viridis')
        cmap = im.get_cmap()
        name = cmap.name if hasattr(cmap, 'name') else cmap
        assert name == 'viridis'

    def test_imshow_cmaps_popular(self):
        data = [[1, 2], [3, 4]]
        for cmap in ['hot', 'cool', 'gray', 'jet', 'plasma', 'inferno',
                     'magma', 'RdYlGn', 'RdBu', 'Blues', 'Oranges']:
            fig, ax = plt.subplots()
            ax.imshow(data, cmap=cmap)
            plt.close('all')

    def test_imshow_vmin_vmax(self):
        data = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
        fig, ax = plt.subplots()
        im = ax.imshow(data, vmin=1, vmax=9)
        vmin, vmax = im.get_clim()
        assert vmin == 1
        assert vmax == 9

    def test_imshow_aspect_auto(self):
        data = [[1, 2, 3, 4], [5, 6, 7, 8]]
        fig, ax = plt.subplots()
        im = ax.imshow(data, aspect='auto')
        assert im is not None

    def test_imshow_aspect_equal(self):
        data = [[1, 2], [3, 4]]
        fig, ax = plt.subplots()
        ax.imshow(data, aspect='equal')

    def test_imshow_origin_upper(self):
        data = [[1, 2], [3, 4]]
        fig, ax = plt.subplots()
        ax.imshow(data, origin='upper')

    def test_imshow_origin_lower(self):
        data = [[1, 2], [3, 4]]
        fig, ax = plt.subplots()
        ax.imshow(data, origin='lower')

    def test_imshow_extent(self):
        data = [[1, 2], [3, 4]]
        fig, ax = plt.subplots()
        im = ax.imshow(data, extent=[0, 10, 0, 5])
        ext = im.get_extent()
        assert ext == (0, 10, 0, 5)

    def test_imshow_interpolation(self):
        data = [[1, 2], [3, 4]]
        for interp in ['nearest', 'bilinear', 'bicubic', 'none']:
            fig, ax = plt.subplots()
            ax.imshow(data, interpolation=interp)
            plt.close('all')

    def test_imshow_alpha(self):
        data = [[1, 2], [3, 4]]
        fig, ax = plt.subplots()
        im = ax.imshow(data, alpha=0.5)
        assert im.get_alpha() == 0.5

    def test_imshow_with_colorbar(self):
        data = [[1, 2, 3], [4, 5, 6]]
        fig, ax = plt.subplots()
        im = ax.imshow(data)
        cbar = fig.colorbar(im, ax=ax)
        assert cbar is not None

    def test_imshow_colorbar_label(self):
        data = [[1, 2, 3], [4, 5, 6]]
        fig, ax = plt.subplots()
        im = ax.imshow(data)
        cbar = fig.colorbar(im, ax=ax)
        cbar.set_label('Intensity')

    def test_imshow_set_axis_labels(self):
        data = [[1, 2, 3], [4, 5, 6]]
        fig, ax = plt.subplots()
        ax.imshow(data)
        ax.set_xticks([0, 1, 2])
        ax.set_xticklabels(['A', 'B', 'C'])
        ax.set_yticks([0, 1])
        ax.set_yticklabels(['X', 'Y'])

    def test_heatmap_pattern(self):
        """Classic heatmap pattern."""
        n = 5
        data = [[i * j for j in range(n)] for i in range(n)]
        fig, ax = plt.subplots()
        im = ax.imshow(data, cmap='YlOrRd')
        ax.set_xticks(range(n))
        ax.set_yticks(range(n))
        # Add text annotations
        for i in range(n):
            for j in range(n):
                ax.text(j, i, str(data[i][j]), ha='center', va='center')
        plt.colorbar(im, ax=ax)


class TestPcolormesh:
    """Tests for pcolormesh."""

    def teardown_method(self):
        plt.close('all')

    def test_pcolormesh_basic(self):
        x = [0, 1, 2, 3]
        y = [0, 1, 2]
        z = [[1, 2, 3], [4, 5, 6]]
        fig, ax = plt.subplots()
        pc = ax.pcolormesh(x, y, z)
        assert pc is not None

    def test_pcolormesh_cmap(self):
        x = [0, 1, 2]
        y = [0, 1]
        z = [[1, 2]]
        fig, ax = plt.subplots()
        ax.pcolormesh(x, y, z, cmap='hot')

    def test_pcolormesh_shading_auto(self):
        x = [0, 1, 2]
        y = [0, 1]
        z = [[1, 2], [3, 4]]
        fig, ax = plt.subplots()
        ax.pcolormesh(x, y, z, shading='auto')

    def test_pcolormesh_shading_gouraud(self):
        x = [0, 1, 2]
        y = [0, 1]
        z = [[1, 2], [3, 4]]
        fig, ax = plt.subplots()
        ax.pcolormesh(x, y, z, shading='gouraud')

    def test_pcolormesh_vmin_vmax(self):
        x = [0, 1, 2]
        y = [0, 1]
        z = [[1, 5], [3, 8]]
        fig, ax = plt.subplots()
        pc = ax.pcolormesh(x, y, z, vmin=0, vmax=10)
        clim = pc.get_clim()
        assert clim[0] == 0
        assert clim[1] == 10

    def test_pcolormesh_with_colorbar(self):
        x = [0, 1, 2]
        y = [0, 1]
        z = [[1, 2], [3, 4]]
        fig, ax = plt.subplots()
        pc = ax.pcolormesh(x, y, z)
        plt.colorbar(pc, ax=ax)


class TestColormapOperations:
    """Tests for colormap manipulation."""

    def teardown_method(self):
        plt.close('all')

    def test_get_cmap_string(self):
        cmap = plt.get_cmap('viridis')
        assert cmap.name == 'viridis'

    def test_get_cmap_various(self):
        for name in ['hot', 'cool', 'jet', 'gray', 'RdYlGn', 'Blues']:
            cmap = plt.get_cmap(name)
            assert cmap is not None

    def test_colormap_call(self):
        cmap = plt.get_cmap('viridis')
        color = cmap(0.5)
        assert len(color) == 4  # RGBA

    def test_colormap_range(self):
        cmap = plt.get_cmap('viridis')
        # 0.0 maps to first color, 1.0 to last
        c0 = cmap(0.0)
        c1 = cmap(1.0)
        assert c0 != c1

    def test_normalize_basic(self):
        norm = mcolors.Normalize(vmin=0, vmax=10)
        val = norm(5)
        assert abs(val - 0.5) < 1e-9

    def test_lognorm(self):
        norm = mcolors.LogNorm(vmin=1, vmax=100)
        val = norm(10)
        assert 0 < val < 1

    def test_twoslopenorm(self):
        norm = mcolors.TwoSlopeNorm(vcenter=0, vmin=-10, vmax=10)
        assert norm(0) == 0.5

    def test_boundary_norm(self):
        bounds = [0, 1, 2, 5, 10]
        norm = mcolors.BoundaryNorm(bounds, 4)
        assert norm is not None

    def test_colormap_reversed(self):
        cmap = plt.get_cmap('viridis_r')
        assert cmap is not None

    def test_cm_module_access(self):
        import matplotlib.cm as cm
        cmap = cm.get_cmap('hot')
        assert cmap is not None
