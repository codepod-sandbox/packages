"""Advanced scatter plot and Collection property tests."""

import pytest
import io
import matplotlib.pyplot as plt
import matplotlib.collections as mcollections


class TestScatterProperties:
    def test_scatter_return_type(self):
        """Scatter returns a PathCollection."""
        fig, ax = plt.subplots()
        sc = ax.scatter([1, 2, 3], [1, 2, 3])
        assert sc is not None
        plt.close('all')

    def test_scatter_get_offsets(self):
        """Get scatter offsets."""
        fig, ax = plt.subplots()
        x = [1.0, 2.0, 3.0]
        y = [4.0, 5.0, 6.0]
        sc = ax.scatter(x, y)
        offsets = sc.get_offsets()
        assert offsets is not None
        plt.close('all')

    def test_scatter_set_offsets(self):
        """Set scatter offsets."""
        fig, ax = plt.subplots()
        sc = ax.scatter([1.0, 2.0, 3.0], [1.0, 2.0, 3.0])
        new_offsets = [[4.0, 4.0], [5.0, 5.0], [6.0, 6.0]]
        sc.set_offsets(new_offsets)
        plt.close('all')

    def test_scatter_sizes(self):
        """Scatter with size array."""
        fig, ax = plt.subplots()
        sc = ax.scatter([1.0, 2.0, 3.0], [1.0, 2.0, 3.0], s=[50, 100, 200])
        assert sc is not None
        plt.close('all')

    def test_scatter_get_sizes(self):
        """Get scatter sizes."""
        fig, ax = plt.subplots()
        sc = ax.scatter([1.0, 2.0, 3.0], [1.0, 2.0, 3.0], s=[50, 100, 200])
        sizes = sc.get_sizes()
        assert sizes is not None
        plt.close('all')

    def test_scatter_set_sizes(self):
        """Set scatter sizes."""
        fig, ax = plt.subplots()
        sc = ax.scatter([1.0, 2.0, 3.0], [1.0, 2.0, 3.0])
        sc.set_sizes([100, 200, 300])
        plt.close('all')

    def test_scatter_facecolor(self):
        """Scatter facecolor."""
        fig, ax = plt.subplots()
        sc = ax.scatter([1.0, 2.0, 3.0], [1.0, 2.0, 3.0], facecolor='red')
        assert sc is not None
        plt.close('all')

    def test_scatter_edgecolor(self):
        """Scatter edgecolor."""
        fig, ax = plt.subplots()
        sc = ax.scatter([1.0, 2.0, 3.0], [1.0, 2.0, 3.0], edgecolor='black')
        assert sc is not None
        plt.close('all')

    def test_scatter_alpha(self):
        """Scatter alpha."""
        fig, ax = plt.subplots()
        sc = ax.scatter([1.0, 2.0, 3.0], [1.0, 2.0, 3.0], alpha=0.5)
        assert abs(sc.get_alpha() - 0.5) < 0.01
        plt.close('all')

    def test_scatter_cmap_norm(self):
        """Scatter with colormap and norm."""
        import matplotlib.colors as mcolors
        fig, ax = plt.subplots()
        x = [1.0, 2.0, 3.0, 4.0, 5.0]
        y = [5.0, 4.0, 3.0, 2.0, 1.0]
        c = [1.0, 10.0, 100.0, 1000.0, 10000.0]
        sc = ax.scatter(x, y, c=c, cmap='viridis',
                       norm=mcolors.LogNorm(vmin=1, vmax=10000))
        assert sc is not None
        plt.close('all')

    def test_scatter_marker_types(self):
        """Scatter with different markers."""
        for marker in ['o', 's', '^', 'D', 'v', '<', '>']:
            fig, ax = plt.subplots()
            ax.scatter([1.0, 2.0, 3.0], [1.0, 2.0, 3.0], marker=marker)
            plt.close('all')

    def test_scatter_single_color_list(self):
        """Scatter with list of colors."""
        fig, ax = plt.subplots()
        colors = ['red', 'green', 'blue', 'orange']
        ax.scatter([1.0, 2.0, 3.0, 4.0], [1.0, 2.0, 3.0, 4.0], c=colors)
        plt.close('all')

    def test_scatter_with_colorbar(self):
        """Scatter with colorbar."""
        fig, ax = plt.subplots()
        x = [1.0, 2.0, 3.0, 4.0, 5.0]
        y = [2.0, 4.0, 1.0, 3.0, 5.0]
        c = [10.0, 20.0, 30.0, 40.0, 50.0]
        sc = ax.scatter(x, y, c=c, cmap='plasma')
        cbar = plt.colorbar(sc)
        assert cbar is not None
        plt.close('all')


class TestCollectionProperties:
    def test_pathcollection_visible(self):
        """PathCollection visibility."""
        fig, ax = plt.subplots()
        sc = ax.scatter([1.0, 2.0], [1.0, 2.0])
        sc.set_visible(False)
        assert sc.get_visible() is False
        plt.close('all')

    def test_pathcollection_zorder(self):
        """PathCollection z-order."""
        fig, ax = plt.subplots()
        sc = ax.scatter([1.0, 2.0], [1.0, 2.0], zorder=10)
        assert sc.get_zorder() == 10
        plt.close('all')

    def test_pathcollection_label(self):
        """PathCollection label."""
        fig, ax = plt.subplots()
        sc = ax.scatter([1.0, 2.0], [1.0, 2.0], label='My Scatter')
        assert sc.get_label() == 'My Scatter'
        plt.close('all')

    def test_scatter_in_legend(self):
        """Scatter in legend."""
        fig, ax = plt.subplots()
        sc1 = ax.scatter([1.0, 2.0], [1.0, 2.0], color='red', label='Group A')
        sc2 = ax.scatter([3.0, 4.0], [3.0, 4.0], color='blue', label='Group B')
        ax.legend()
        plt.close('all')

    def test_scatter_update_colors(self):
        """Update scatter colors dynamically."""
        fig, ax = plt.subplots()
        sc = ax.scatter([1.0, 2.0, 3.0], [1.0, 2.0, 3.0])
        sc.set_facecolor(['red', 'green', 'blue'])
        plt.close('all')

    def test_line_collection_basic(self):
        """Basic LineCollection."""
        from matplotlib.collections import LineCollection
        fig, ax = plt.subplots()
        lines = [[(0, 1), (1, 1)], [(0, 2), (1, 2)], [(0, 3), (1, 3)]]
        lc = LineCollection(lines, colors=['red', 'green', 'blue'])
        ax.add_collection(lc)
        ax.autoscale()
        plt.close('all')

    def test_patch_collection_basic(self):
        """Basic PatchCollection."""
        import matplotlib.patches as mpatches
        from matplotlib.collections import PatchCollection
        fig, ax = plt.subplots()
        patches = [mpatches.Circle((0.5, 0.5), 0.2), mpatches.Circle((0.2, 0.2), 0.1)]
        pc = PatchCollection(patches, alpha=0.4)
        ax.add_collection(pc)
        plt.close('all')


class TestScatterUseCases:
    def test_bubble_chart(self):
        """Bubble chart (scatter with sizes proportional to values)."""
        fig, ax = plt.subplots()
        companies = [1, 2, 3, 4, 5]
        revenue = [100.0, 200.0, 150.0, 300.0, 250.0]
        employees = [50, 100, 75, 150, 120]
        profit = [10.0, 25.0, 15.0, 40.0, 30.0]
        # Size proportional to employees
        sc = ax.scatter(companies, revenue, s=[e * 2 for e in employees],
                       c=profit, cmap='RdYlGn', alpha=0.7)
        plt.colorbar(sc, label='Profit')
        ax.set_xlabel('Company')
        ax.set_ylabel('Revenue ($K)')
        plt.close('all')

    def test_two_group_scatter(self):
        """Two-group scatter (classification visualization)."""
        fig, ax = plt.subplots()
        # Group A
        xa = [1.0, 1.5, 2.0, 1.2, 1.8]
        ya = [1.0, 1.3, 1.6, 0.8, 1.4]
        # Group B
        xb = [3.0, 3.5, 4.0, 3.2, 3.8]
        yb = [3.0, 3.3, 3.6, 2.8, 3.4]
        ax.scatter(xa, ya, color='red', label='Class A', marker='o')
        ax.scatter(xb, yb, color='blue', label='Class B', marker='^')
        ax.legend()
        plt.close('all')

    def test_residual_scatter(self):
        """Residual scatter plot."""
        fig, axes = plt.subplots(1, 2, figsize=(12, 5))
        x = [1.0, 2.0, 3.0, 4.0, 5.0]
        y = [2.1, 4.0, 5.9, 8.1, 10.0]
        predicted = [2.0, 4.0, 6.0, 8.0, 10.0]
        residuals = [a - b for a, b in zip(y, predicted)]
        axes[0].scatter(x, y)
        axes[0].plot(x, predicted, 'r-')
        axes[0].set_title('Fit')
        axes[1].scatter(x, residuals)
        axes[1].axhline(0, color='red')
        axes[1].set_title('Residuals')
        plt.close('all')
