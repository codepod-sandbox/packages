"""
Upstream tests for common LLM workflow patterns with matplotlib.
These test end-to-end patterns that LLMs frequently write.
"""

import numpy as np
import pytest
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec


class TestCommonPlotPatterns:
    """Common single-axes plot patterns."""

    def teardown_method(self):
        plt.close('all')

    def test_simple_line_with_labels(self):
        x = [1, 2, 3, 4, 5]
        y = [1, 4, 9, 16, 25]
        fig, ax = plt.subplots()
        ax.plot(x, y, 'b-o', label='y=x^2')
        ax.set_xlabel('X values')
        ax.set_ylabel('Y values')
        ax.set_title('Simple Line Plot')
        ax.legend()

    def test_multiple_lines(self):
        x = [1, 2, 3]
        fig, ax = plt.subplots()
        ax.plot(x, [1, 2, 3], 'r-', label='linear')
        ax.plot(x, [1, 4, 9], 'b--', label='quadratic')
        ax.plot(x, [1, 8, 27], 'g:', label='cubic')
        ax.legend()

    def test_scatter_with_colormap(self):
        n = 50
        x = list(range(n))
        y = list(range(n))
        c = list(range(n))
        fig, ax = plt.subplots()
        sc = ax.scatter(x, y, c=c, cmap='viridis')
        fig.colorbar(sc, ax=ax)

    def test_bar_chart_with_labels(self):
        categories = ['A', 'B', 'C', 'D']
        values = [10, 25, 15, 30]
        fig, ax = plt.subplots()
        bars = ax.bar(categories, values, color='steelblue')
        ax.set_xlabel('Category')
        ax.set_ylabel('Count')
        ax.set_title('Bar Chart')

    def test_histogram_with_density(self):
        data = [1, 1, 2, 2, 2, 3, 3, 3, 3, 4, 4, 5]
        fig, ax = plt.subplots()
        ax.hist(data, bins=5, density=True, color='steelblue', alpha=0.7)
        ax.set_xlabel('Value')
        ax.set_ylabel('Density')

    def test_imshow_with_colorbar(self):
        data = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
        fig, ax = plt.subplots()
        im = ax.imshow(data, cmap='hot', aspect='auto')
        cbar = fig.colorbar(im, ax=ax)
        cbar.set_label('Intensity')

    def test_errorbar_plot(self):
        x = [1, 2, 3, 4]
        y = [1, 4, 9, 16]
        yerr = [0.5, 0.5, 0.5, 0.5]
        fig, ax = plt.subplots()
        ax.errorbar(x, y, yerr=yerr, fmt='o-', capsize=5, label='data ± σ')
        ax.legend()

    def test_fill_between_shading(self):
        x = [0, 1, 2, 3, 4, 5]
        y1 = [0, 1, 2, 1, 2, 1]
        y2 = [0, 0.5, 1, 0.5, 1, 0.5]
        fig, ax = plt.subplots()
        ax.plot(x, y1, 'b-', label='upper')
        ax.plot(x, y2, 'r-', label='lower')
        ax.fill_between(x, y1, y2, alpha=0.3, label='range')
        ax.legend()

    def test_twin_axes_different_scales(self):
        x = [1, 2, 3, 4, 5]
        y1 = [10, 20, 30, 40, 50]
        y2 = [0.1, 0.2, 0.15, 0.3, 0.25]
        fig, ax1 = plt.subplots()
        ax2 = ax1.twinx()
        ax1.plot(x, y1, 'b-', label='primary')
        ax2.plot(x, y2, 'r-', label='secondary')
        ax1.set_ylabel('Primary', color='b')
        ax2.set_ylabel('Secondary', color='r')


class TestMultiPanelPatterns:
    """Multi-panel figure patterns."""

    def teardown_method(self):
        plt.close('all')

    def test_2x2_subplots(self):
        fig, axes = plt.subplots(2, 2, figsize=(8, 6))
        fig.suptitle('2x2 Layout')
        data_sets = [
            ([1, 2, 3], [1, 4, 9]),
            ([1, 2, 3], [1, 2, 3]),
            ([1, 2, 3], [3, 2, 1]),
            ([1, 2, 3], [1, 8, 27]),
        ]
        for i, (row_axes) in enumerate(axes):
            for j, ax in enumerate(row_axes):
                idx = i * 2 + j
                x, y = data_sets[idx]
                ax.plot(x, y)
                ax.set_title(f'Panel {idx+1}')
        plt.tight_layout()

    def test_1x3_subplots_shared_x(self):
        fig, axes = plt.subplots(1, 3, sharex=True)
        for i, ax in enumerate(axes):
            ax.plot([1, 2, 3], [i+1, i+2, i+3])
            ax.set_title(f'Plot {i+1}')
        plt.tight_layout()

    def test_3x1_subplots_shared_y(self):
        fig, axes = plt.subplots(3, 1, sharey=True)
        for i, ax in enumerate(axes):
            ax.plot([1, 2, 3], [i+1, i+2, i+3])
        plt.tight_layout()

    def test_gridspec_unequal(self):
        fig = plt.figure(figsize=(8, 6))
        gs = gridspec.GridSpec(2, 3)
        ax_main = fig.add_subplot(gs[0, :])
        ax1 = fig.add_subplot(gs[1, 0])
        ax2 = fig.add_subplot(gs[1, 1])
        ax3 = fig.add_subplot(gs[1, 2])
        ax_main.plot([1, 2, 3])
        ax_main.set_title('Main')
        for ax in [ax1, ax2, ax3]:
            ax.plot([1, 2])
        plt.tight_layout()

    def test_figure_with_suptitle(self):
        fig, axes = plt.subplots(1, 2)
        fig.suptitle('Overall Title', fontsize=14)
        axes[0].plot([1, 2, 3])
        axes[1].scatter([1, 2, 3], [3, 2, 1])
        plt.subplots_adjust(top=0.88)

    def test_add_subplot_manual(self):
        fig = plt.figure()
        ax1 = fig.add_subplot(2, 1, 1)
        ax2 = fig.add_subplot(2, 1, 2)
        ax1.plot([1, 2])
        ax2.bar([1, 2], [3, 4])


class TestSaveAndOutput:
    """Save and output patterns."""

    def teardown_method(self):
        plt.close('all')

    def test_savefig_png_bytes(self):
        import io
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3])
        buf = io.BytesIO()
        fig.savefig(buf, format='png')
        buf.seek(0)
        assert len(buf.read()) > 0

    def test_savefig_svg_bytes(self):
        import io
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3])
        buf = io.BytesIO()
        fig.savefig(buf, format='svg')
        buf.seek(0)
        content = buf.read()
        assert len(content) > 0

    def test_savefig_dpi(self):
        import io
        fig, ax = plt.subplots()
        ax.plot([1, 2])
        buf = io.BytesIO()
        fig.savefig(buf, format='png', dpi=72)
        buf.seek(0)
        assert len(buf.read()) > 0

    def test_savefig_bbox_inches_tight(self):
        import io
        fig, ax = plt.subplots()
        ax.plot([1, 2])
        ax.set_xlabel('X label')
        buf = io.BytesIO()
        fig.savefig(buf, format='png', bbox_inches='tight')
        buf.seek(0)
        assert len(buf.read()) > 0


class TestStatisticalPatterns:
    """Statistical visualization patterns."""

    def teardown_method(self):
        plt.close('all')

    def test_box_and_whisker(self):
        data = [[1, 2, 3, 4, 5], [2, 3, 4, 5, 6], [3, 4, 5, 6, 7]]
        fig, ax = plt.subplots()
        bp = ax.boxplot(data, labels=['A', 'B', 'C'])
        assert 'boxes' in bp

    def test_violin_with_data(self):
        data = [[1, 2, 3, 4], [2, 3, 4, 5, 6], [1, 3, 5, 7, 9]]
        fig, ax = plt.subplots()
        vp = ax.violinplot(data)
        assert 'bodies' in vp

    def test_contour_with_labels(self):
        x = [0, 1, 2]
        y = [0, 1, 2]
        z = [[0, 1, 2], [1, 2, 3], [2, 3, 4]]
        fig, ax = plt.subplots()
        cs = ax.contour(x, y, z, levels=3)
        ax.clabel(cs, inline=True)

    def test_heatmap_pattern(self):
        data = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
        fig, ax = plt.subplots()
        im = ax.imshow(data, cmap='RdYlGn', aspect='auto')
        ax.set_xticks([0, 1, 2])
        ax.set_yticks([0, 1, 2])
        ax.set_xticklabels(['A', 'B', 'C'])
        ax.set_yticklabels(['X', 'Y', 'Z'])
        plt.colorbar(im, ax=ax)
