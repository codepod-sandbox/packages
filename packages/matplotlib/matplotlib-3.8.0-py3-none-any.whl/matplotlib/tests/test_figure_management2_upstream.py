"""
Upstream tests for figure management, pyplot API, and output patterns.
"""

import io
import pytest
import matplotlib.pyplot as plt
import matplotlib as mpl


class TestPyplotAPI:
    """Tests for pyplot module-level functions."""

    def teardown_method(self):
        plt.close('all')

    def test_plt_figure(self):
        fig = plt.figure()
        assert fig is not None

    def test_plt_figure_figsize(self):
        fig = plt.figure(figsize=(10, 8))
        w, h = fig.get_size_inches()
        assert w == 10.0
        assert h == 8.0

    def test_plt_figure_dpi(self):
        fig = plt.figure(dpi=150)
        assert fig.get_dpi() == 150

    def test_plt_subplot(self):
        ax = plt.subplot(1, 1, 1)
        assert ax is not None

    def test_plt_subplot_211(self):
        ax1 = plt.subplot(2, 1, 1)
        ax2 = plt.subplot(2, 1, 2)
        assert ax1 is not None
        assert ax2 is not None

    def test_plt_gca(self):
        fig, ax = plt.subplots()
        current = plt.gca()
        assert current is ax

    def test_plt_gcf(self):
        fig, ax = plt.subplots()
        current = plt.gcf()
        assert current is fig

    def test_plt_cla(self):
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3])
        plt.cla()
        assert len(ax.lines) == 0

    def test_plt_clf(self):
        fig = plt.figure()
        ax = fig.add_subplot(111)
        ax.plot([1, 2])
        plt.clf()

    def test_plt_close_fig(self):
        fig = plt.figure()
        plt.close(fig)

    def test_plt_close_all(self):
        for _ in range(3):
            plt.figure()
        plt.close('all')

    def test_plt_get_fignums(self):
        plt.close('all')
        fig1 = plt.figure()
        fig2 = plt.figure()
        nums = plt.get_fignums()
        assert len(nums) == 2

    def test_plt_get_figlabels(self):
        plt.close('all')
        plt.figure('fig1')
        plt.figure('fig2')
        labels = plt.get_figlabels()
        assert 'fig1' in labels
        assert 'fig2' in labels

    def test_plt_plot(self):
        fig, ax = plt.subplots()
        plt.plot([1, 2, 3], [4, 5, 6])

    def test_plt_scatter(self):
        fig, ax = plt.subplots()
        plt.scatter([1, 2], [3, 4])

    def test_plt_bar(self):
        fig, ax = plt.subplots()
        plt.bar([1, 2, 3], [4, 5, 6])

    def test_plt_hist(self):
        fig, ax = plt.subplots()
        plt.hist([1, 2, 2, 3, 3, 3])

    def test_plt_imshow(self):
        fig, ax = plt.subplots()
        plt.imshow([[1, 2], [3, 4]])

    def test_plt_title(self):
        fig, ax = plt.subplots()
        plt.title('My Title')

    def test_plt_xlabel(self):
        fig, ax = plt.subplots()
        plt.xlabel('X axis')

    def test_plt_ylabel(self):
        fig, ax = plt.subplots()
        plt.ylabel('Y axis')

    def test_plt_xlim(self):
        fig, ax = plt.subplots()
        plt.xlim(0, 10)

    def test_plt_ylim(self):
        fig, ax = plt.subplots()
        plt.ylim(-5, 5)

    def test_plt_axis(self):
        fig, ax = plt.subplots()
        plt.axis([0, 5, 0, 3])

    def test_plt_xticks(self):
        fig, ax = plt.subplots()
        plt.xticks([0, 1, 2, 3])

    def test_plt_yticks(self):
        fig, ax = plt.subplots()
        plt.yticks([0, 1, 2])

    def test_plt_xticks_labels(self):
        fig, ax = plt.subplots()
        plt.xticks([0, 1, 2], ['a', 'b', 'c'])

    def test_plt_legend(self):
        fig, ax = plt.subplots()
        plt.plot([1, 2], label='data')
        plt.legend()

    def test_plt_grid(self):
        fig, ax = plt.subplots()
        plt.grid(True)

    def test_plt_colorbar(self):
        fig, ax = plt.subplots()
        im = ax.imshow([[1, 2], [3, 4]])
        plt.colorbar(im)

    def test_plt_tight_layout(self):
        fig, ax = plt.subplots()
        ax.plot([1, 2])
        plt.tight_layout()

    def test_plt_savefig_bytes(self):
        fig, ax = plt.subplots()
        ax.plot([1, 2])
        buf = io.BytesIO()
        plt.savefig(buf, format='png')
        buf.seek(0)
        assert len(buf.read()) > 0


class TestFigureMultipleAxes:
    """Tests for figures with multiple axes."""

    def teardown_method(self):
        plt.close('all')

    def test_subplots_returns_correct_shape(self):
        fig, axes = plt.subplots(2, 3)
        assert len(axes) == 2
        assert len(axes[0]) == 3

    def test_subplots_1d_array(self):
        fig, axes = plt.subplots(1, 3)
        assert len(axes) == 3

    def test_subplots_single(self):
        fig, ax = plt.subplots(1, 1)
        # When squeeze=True (default), single axes is returned directly
        assert ax is not None

    def test_subplots_no_squeeze(self):
        fig, axes = plt.subplots(1, 1, squeeze=False)
        assert len(axes) == 1
        assert len(axes[0]) == 1

    def test_add_subplot_number(self):
        fig = plt.figure()
        ax = fig.add_subplot(111)
        assert ax is not None

    def test_add_subplot_rowcolnum(self):
        fig = plt.figure()
        ax1 = fig.add_subplot(2, 2, 1)
        ax2 = fig.add_subplot(2, 2, 2)
        ax3 = fig.add_subplot(2, 2, 3)
        ax4 = fig.add_subplot(2, 2, 4)
        assert len(fig.axes) == 4

    def test_axes_list(self):
        fig, axes = plt.subplots(2, 2)
        assert len(fig.axes) == 4

    def test_figure_number(self):
        plt.close('all')
        fig1 = plt.figure()
        fig2 = plt.figure()
        assert fig1.number != fig2.number

    def test_figure_labeled(self):
        plt.close('all')
        fig = plt.figure('my_figure')
        assert plt.figure('my_figure') is fig


class TestSavefigOptions:
    """Tests for savefig options."""

    def teardown_method(self):
        plt.close('all')

    def test_savefig_png(self):
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3])
        buf = io.BytesIO()
        fig.savefig(buf, format='png')
        buf.seek(0)
        assert len(buf.read()) > 0

    def test_savefig_svg(self):
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3])
        buf = io.BytesIO()
        fig.savefig(buf, format='svg')
        buf.seek(0)
        content = buf.read()
        assert len(content) > 100

    def test_savefig_dpi_72(self):
        fig, ax = plt.subplots()
        ax.plot([1, 2])
        buf = io.BytesIO()
        fig.savefig(buf, format='png', dpi=72)
        buf.seek(0)
        assert len(buf.read()) > 0

    def test_savefig_dpi_300(self):
        fig, ax = plt.subplots()
        ax.plot([1, 2])
        buf = io.BytesIO()
        fig.savefig(buf, format='png', dpi=300)
        buf.seek(0)
        assert len(buf.read()) > 0

    def test_savefig_bbox_tight(self):
        fig, ax = plt.subplots()
        ax.set_xlabel('X')
        buf = io.BytesIO()
        fig.savefig(buf, format='png', bbox_inches='tight')
        buf.seek(0)
        assert len(buf.read()) > 0

    def test_savefig_transparent(self):
        fig, ax = plt.subplots()
        ax.plot([1, 2])
        buf = io.BytesIO()
        fig.savefig(buf, format='png', transparent=True)
        buf.seek(0)
        assert len(buf.read()) > 0

    def test_savefig_facecolor(self):
        fig, ax = plt.subplots()
        ax.plot([1, 2])
        buf = io.BytesIO()
        fig.savefig(buf, format='png', facecolor='white')
        buf.seek(0)
        assert len(buf.read()) > 0
