"""Tests for common data visualization patterns used by LLMs."""

import pytest
import io
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.colors as mcolors


class TestTimeSeriesPatterns:
    def test_line_with_shaded_confidence(self):
        """Line plot with shaded confidence interval."""
        fig, ax = plt.subplots()
        x = [0.0, 1.0, 2.0, 3.0, 4.0, 5.0]
        mean = [1.0, 2.0, 1.5, 3.0, 2.5, 4.0]
        lower = [0.5, 1.5, 1.0, 2.5, 2.0, 3.5]
        upper = [1.5, 2.5, 2.0, 3.5, 3.0, 4.5]
        ax.plot(x, mean, 'b-', label='Mean')
        ax.fill_between(x, lower, upper, alpha=0.3, label='95% CI')
        ax.legend()
        plt.close('all')

    def test_multiple_lines_same_axes(self):
        """Multiple time series on same axes."""
        fig, ax = plt.subplots()
        x = list(range(10))
        for i in range(5):
            y = [j * (i + 1) * 0.5 for j in x]
            ax.plot(x, y, label=f'Series {i+1}')
        ax.legend()
        ax.set_xlabel('Time')
        ax.set_ylabel('Value')
        plt.close('all')

    def test_dual_axis_time_series(self):
        """Dual Y-axis time series."""
        fig, ax1 = plt.subplots(figsize=(10, 6))
        x = list(range(12))
        temp = [20.0, 22.0, 25.0, 28.0, 32.0, 35.0, 34.0, 31.0, 27.0, 23.0, 20.0, 18.0]
        rain = [50.0, 40.0, 30.0, 20.0, 10.0, 5.0, 8.0, 15.0, 35.0, 55.0, 60.0, 65.0]
        ax1.plot(x, temp, 'r-', label='Temperature')
        ax1.set_ylabel('Temperature (°C)', color='red')
        ax2 = ax1.twinx()
        ax2.bar(x, rain, alpha=0.4, color='blue', label='Rainfall')
        ax2.set_ylabel('Rainfall (mm)', color='blue')
        plt.close('all')

    def test_rolling_average_pattern(self):
        """Rolling average visualization."""
        fig, ax = plt.subplots()
        x = list(range(20))
        raw = [1.0, 3.0, 2.0, 4.0, 3.0, 5.0, 4.0, 6.0, 5.0, 7.0,
               6.0, 8.0, 7.0, 9.0, 8.0, 10.0, 9.0, 11.0, 10.0, 12.0]
        # Simple rolling average
        window = 3
        avg = []
        for i in range(len(raw)):
            start = max(0, i - window + 1)
            avg.append(sum(raw[start:i+1]) / (i - start + 1))
        ax.plot(x, raw, alpha=0.4, color='gray', label='Raw')
        ax.plot(x, avg, 'b-', linewidth=2, label=f'{window}-pt avg')
        ax.legend()
        plt.close('all')


class TestDistributionPatterns:
    def test_histogram_with_kde_style(self):
        """Histogram with density overlay line."""
        fig, ax = plt.subplots()
        data = [1.0, 2.0, 2.5, 3.0, 3.5, 3.0, 2.5, 2.0, 1.5, 1.0,
                4.0, 3.5, 3.0, 2.5, 2.0, 1.5, 1.0, 0.5, 4.5, 5.0]
        ax.hist(data, bins=10, density=True, alpha=0.7, label='Histogram')
        ax.legend()
        plt.close('all')

    def test_comparison_histograms(self):
        """Two overlapping histograms."""
        fig, ax = plt.subplots()
        data1 = [1.0, 2.0, 2.5, 3.0, 3.5, 3.0, 2.5, 2.0, 1.5, 1.0]
        data2 = [2.0, 3.0, 3.5, 4.0, 4.5, 4.0, 3.5, 3.0, 2.5, 2.0]
        ax.hist(data1, bins=8, alpha=0.5, label='Group A', color='blue')
        ax.hist(data2, bins=8, alpha=0.5, label='Group B', color='red')
        ax.legend()
        plt.close('all')

    def test_boxplot_multiple_groups(self):
        """Boxplot with multiple groups."""
        fig, ax = plt.subplots()
        data = [
            [1.0, 2.0, 3.0, 4.0, 5.0],
            [2.0, 3.0, 4.0, 5.0, 6.0],
            [1.5, 2.5, 3.5, 4.5, 5.5],
        ]
        ax.boxplot(data, labels=['Group A', 'Group B', 'Group C'])
        plt.close('all')

    def test_scatter_with_size_color(self):
        """Scatter plot with size and color encoding."""
        fig, ax = plt.subplots()
        x = [1.0, 2.0, 3.0, 4.0, 5.0, 6.0]
        y = [2.0, 1.0, 4.0, 3.0, 5.0, 2.5]
        sizes = [100, 200, 50, 300, 150, 80]
        colors = [0.1, 0.3, 0.5, 0.7, 0.9, 0.4]
        sc = ax.scatter(x, y, s=sizes, c=colors, cmap='viridis', alpha=0.7)
        plt.colorbar(sc)
        plt.close('all')


class TestCategoricalPatterns:
    def test_grouped_bar_chart(self):
        """Grouped bar chart."""
        import numpy as np
        fig, ax = plt.subplots()
        categories = ['Cat A', 'Cat B', 'Cat C', 'Cat D']
        values1 = [10.0, 20.0, 15.0, 25.0]
        values2 = [15.0, 18.0, 22.0, 12.0]
        x = list(range(len(categories)))
        width = 0.35
        bars1 = ax.bar([xi - width/2 for xi in x], values1, width, label='Group 1')
        bars2 = ax.bar([xi + width/2 for xi in x], values2, width, label='Group 2')
        ax.set_xticks(x)
        ax.set_xticklabels(categories)
        ax.legend()
        plt.close('all')

    def test_stacked_bar_chart(self):
        """Stacked bar chart."""
        fig, ax = plt.subplots()
        categories = ['Q1', 'Q2', 'Q3', 'Q4']
        product_a = [30.0, 40.0, 35.0, 45.0]
        product_b = [20.0, 25.0, 30.0, 35.0]
        product_c = [10.0, 15.0, 20.0, 25.0]
        x = list(range(len(categories)))
        ax.bar(x, product_a, label='Product A')
        ax.bar(x, product_b, bottom=product_a, label='Product B')
        ax.bar(x, product_c, bottom=[a + b for a, b in zip(product_a, product_b)],
               label='Product C')
        ax.set_xticks(x)
        ax.set_xticklabels(categories)
        ax.legend()
        plt.close('all')

    def test_horizontal_bar_ranked(self):
        """Horizontal bar chart ranked."""
        fig, ax = plt.subplots()
        items = ['Item E', 'Item D', 'Item C', 'Item B', 'Item A']
        values = [20.0, 35.0, 50.0, 65.0, 80.0]
        bars = ax.barh(items, values)
        ax.set_xlabel('Score')
        plt.close('all')

    def test_pie_chart(self):
        """Pie chart."""
        fig, ax = plt.subplots()
        sizes = [30, 25, 20, 15, 10]
        labels = ['A', 'B', 'C', 'D', 'E']
        ax.pie(sizes, labels=labels, autopct='%1.1f%%')
        plt.close('all')

    def test_donut_chart(self):
        """Donut chart (pie with wedgeprops)."""
        fig, ax = plt.subplots()
        sizes = [40, 30, 20, 10]
        labels = ['Category 1', 'Category 2', 'Category 3', 'Category 4']
        ax.pie(sizes, labels=labels, wedgeprops=dict(width=0.5), autopct='%1.0f%%')
        plt.close('all')


class TestHeatmapPatterns:
    def test_correlation_heatmap(self):
        """Correlation matrix heatmap."""
        fig, ax = plt.subplots()
        corr = [
            [1.00, 0.80, 0.40, 0.10],
            [0.80, 1.00, 0.60, 0.30],
            [0.40, 0.60, 1.00, 0.70],
            [0.10, 0.30, 0.70, 1.00],
        ]
        im = ax.imshow(corr, cmap='coolwarm', vmin=-1, vmax=1)
        plt.colorbar(im)
        labels = ['A', 'B', 'C', 'D']
        ax.set_xticks(list(range(4)))
        ax.set_yticks(list(range(4)))
        ax.set_xticklabels(labels)
        ax.set_yticklabels(labels)
        plt.close('all')

    def test_annotated_heatmap(self):
        """Heatmap with text annotations."""
        fig, ax = plt.subplots()
        data = [[1.0, 2.0, 3.0], [4.0, 5.0, 6.0], [7.0, 8.0, 9.0]]
        im = ax.imshow(data, cmap='YlOrRd')
        for i in range(3):
            for j in range(3):
                ax.text(j, i, f'{data[i][j]:.0f}',
                        ha='center', va='center', color='black')
        plt.close('all')

    def test_imshow_aspect(self):
        """imshow with aspect ratio."""
        fig, ax = plt.subplots()
        data = [[1.0, 2.0, 3.0, 4.0, 5.0],
                [6.0, 7.0, 8.0, 9.0, 10.0]]
        ax.imshow(data, aspect='auto', cmap='viridis')
        plt.close('all')


class TestAnnotationPatterns:
    def test_bar_chart_with_values(self):
        """Bar chart with value labels on top."""
        fig, ax = plt.subplots()
        categories = ['A', 'B', 'C', 'D']
        values = [10, 25, 15, 30]
        bars = ax.bar(categories, values)
        for bar, val in zip(bars, values):
            ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.5,
                    str(val), ha='center', va='bottom')
        plt.close('all')

    def test_scatter_with_point_labels(self):
        """Scatter plot with labels on each point."""
        fig, ax = plt.subplots()
        points = {'Alpha': (1.0, 2.0), 'Beta': (2.0, 3.0), 'Gamma': (3.0, 1.0)}
        for name, (x, y) in points.items():
            ax.scatter([x], [y])
            ax.annotate(name, (x, y), textcoords='offset points', xytext=(5, 5))
        plt.close('all')

    def test_threshold_line_annotation(self):
        """Plot with threshold line and annotation."""
        fig, ax = plt.subplots()
        x = list(range(10))
        y = [1.0, 3.0, 2.0, 5.0, 4.0, 7.0, 6.0, 8.0, 5.0, 9.0]
        threshold = 5.0
        ax.plot(x, y, 'b-o')
        ax.axhline(y=threshold, color='red', linestyle='--', label='Threshold')
        ax.text(9, threshold + 0.2, f'Threshold: {threshold}',
                color='red', ha='right')
        ax.legend()
        plt.close('all')


class TestOutputPatterns:
    def test_savefig_png_tight(self):
        """Save figure as PNG with tight bbox."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 1])
        ax.set_title('Test')
        buf = io.BytesIO()
        fig.savefig(buf, format='png', bbox_inches='tight')
        buf.seek(0)
        assert len(buf.read()) > 0
        plt.close('all')

    def test_savefig_svg(self):
        """Save figure as SVG."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [3, 1, 2])
        buf = io.BytesIO()
        fig.savefig(buf, format='svg')
        buf.seek(0)
        content = buf.read().decode('utf-8')
        assert '<svg' in content
        plt.close('all')

    def test_figure_to_svg_string(self):
        """Figure.to_svg() returns SVG string."""
        fig, ax = plt.subplots()
        ax.bar(['A', 'B', 'C'], [1, 2, 3])
        svg = fig.to_svg()
        assert isinstance(svg, str)
        assert '<svg' in svg
        plt.close('all')

    def test_multipage_style(self):
        """Create multiple figures for multi-page style."""
        figs = []
        for i in range(3):
            fig, ax = plt.subplots()
            ax.plot([1, 2, 3], [i, i+1, i+2])
            ax.set_title(f'Page {i+1}')
            figs.append(fig)
        for fig in figs:
            plt.close(fig)
