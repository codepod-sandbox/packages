"""Tests for advanced Axes methods useful to LLMs."""

import pytest
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker


class TestAxSpan:
    def test_axhspan(self):
        """axhspan() does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2], [0, 1, 0])
        ax.axhspan(0.2, 0.8, alpha=0.3)
        plt.close('all')

    def test_axvspan(self):
        """axvspan() does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2], [0, 1, 0])
        ax.axvspan(0.5, 1.5, alpha=0.5, color='yellow')
        plt.close('all')

    def test_axhspan_with_color(self):
        """axhspan with facecolor does not raise."""
        fig, ax = plt.subplots()
        ax.axhspan(0, 1, facecolor='lightblue', edgecolor='blue')
        plt.close('all')

    def test_axvspan_returns_patch(self):
        """axvspan returns a Polygon patch."""
        fig, ax = plt.subplots()
        p = ax.axvspan(0.5, 1.5)
        assert p is not None
        plt.close('all')


class TestAxLine:
    def test_axhline_basic(self):
        """axhline() does not raise."""
        fig, ax = plt.subplots()
        ax.axhline(y=0.5)
        plt.close('all')

    def test_axvline_basic(self):
        """axvline() does not raise."""
        fig, ax = plt.subplots()
        ax.axvline(x=1.0)
        plt.close('all')

    def test_axhline_styled(self):
        """axhline with style does not raise."""
        fig, ax = plt.subplots()
        ax.axhline(y=0, color='r', linestyle='--', linewidth=2)
        plt.close('all')

    def test_axvline_returns_line(self):
        """axvline returns a Line2D."""
        from matplotlib.lines import Line2D
        fig, ax = plt.subplots()
        line = ax.axvline(x=0)
        assert line is not None
        plt.close('all')


class TestHLines:
    def test_hlines_basic(self):
        """hlines() does not raise."""
        fig, ax = plt.subplots()
        ax.hlines([1, 2, 3], xmin=0, xmax=4)
        plt.close('all')

    def test_hlines_with_colors(self):
        """hlines with colors list does not raise."""
        fig, ax = plt.subplots()
        ax.hlines([1, 2], xmin=[0, 0], xmax=[3, 4], colors=['r', 'b'])
        plt.close('all')

    def test_vlines_basic(self):
        """vlines() does not raise."""
        fig, ax = plt.subplots()
        ax.vlines([1, 2, 3], ymin=0, ymax=5)
        plt.close('all')

    def test_vlines_returns_collection(self):
        """vlines returns a LineCollection."""
        fig, ax = plt.subplots()
        lc = ax.vlines([1, 2], 0, 1)
        assert lc is not None
        plt.close('all')


class TestFill:
    def test_fill_between_basic(self):
        """fill_between does not raise."""
        fig, ax = plt.subplots()
        x = np.linspace(0, 2 * np.pi, 50)
        ax.fill_between(x, np.sin(x), 0)
        plt.close('all')

    def test_fill_between_y1_y2(self):
        """fill_between with y1 and y2 does not raise."""
        fig, ax = plt.subplots()
        x = np.linspace(0, 5, 50)
        ax.fill_between(x, x**2, x**3, alpha=0.4)
        plt.close('all')

    def test_fill_betweenx(self):
        """fill_betweenx does not raise."""
        fig, ax = plt.subplots()
        y = np.linspace(0, 2 * np.pi, 50)
        ax.fill_betweenx(y, np.sin(y), 0)
        plt.close('all')

    def test_fill_between_where(self):
        """fill_between with where does not raise."""
        fig, ax = plt.subplots()
        x = np.linspace(0, 5, 50)
        y = np.sin(x)
        ax.fill_between(x, y, 0, where=y > 0, alpha=0.3)
        plt.close('all')


class TestStep:
    def test_step_pre(self):
        """ax.step() with where='pre' does not raise."""
        fig, ax = plt.subplots()
        ax.step([1, 2, 3, 4], [1, 4, 2, 3], where='pre')
        plt.close('all')

    def test_step_post(self):
        """ax.step() with where='post' does not raise."""
        fig, ax = plt.subplots()
        ax.step([1, 2, 3, 4], [1, 4, 2, 3], where='post')
        plt.close('all')

    def test_step_mid(self):
        """ax.step() with where='mid' does not raise."""
        fig, ax = plt.subplots()
        ax.step([1, 2, 3, 4], [1, 4, 2, 3], where='mid')
        plt.close('all')

    def test_step_styled(self):
        """ax.step() with color and linestyle does not raise."""
        fig, ax = plt.subplots()
        ax.step([0, 1, 2], [0, 1, 0], color='red', linewidth=2)
        plt.close('all')


class TestBrokenBarh:
    def test_broken_barh(self):
        """ax.broken_barh() does not raise."""
        fig, ax = plt.subplots()
        ax.broken_barh([(10, 50), (100, 20), (130, 10)], (10, 9))
        plt.close('all')

    def test_broken_barh_multiple_rows(self):
        """broken_barh with multiple y ranges does not raise."""
        fig, ax = plt.subplots()
        ax.broken_barh([(10, 30), (60, 20)], (20, 5), facecolors='blue')
        ax.broken_barh([(15, 40)], (30, 5), facecolors='green')
        plt.close('all')


class TestBandwidth:
    def test_set_xlim_auto(self):
        """set_xlim() with auto=True does not raise."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3])
        ax.set_xlim(auto=True)
        plt.close('all')

    def test_set_ylim_auto(self):
        """set_ylim() with auto=True does not raise."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3])
        ax.set_ylim(auto=True)
        plt.close('all')

    def test_margins(self):
        """ax.margins() does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2])
        ax.margins(0.1)
        plt.close('all')

    def test_margins_xy(self):
        """ax.margins(x=0.1, y=0.2) does not raise."""
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2])
        ax.margins(x=0.05, y=0.1)
        plt.close('all')
