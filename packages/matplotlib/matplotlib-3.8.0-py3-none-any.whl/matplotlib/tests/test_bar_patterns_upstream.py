"""
Upstream tests for bar chart patterns commonly used by LLMs.
"""

import numpy as np
import pytest
import matplotlib.pyplot as plt


class TestBarCharts:
    """Bar chart patterns."""

    def teardown_method(self):
        plt.close('all')

    def test_bar_basic(self):
        fig, ax = plt.subplots()
        ax.bar([1, 2, 3], [4, 5, 6])

    def test_bar_categories(self):
        fig, ax = plt.subplots()
        cats = ['A', 'B', 'C', 'D']
        vals = [10, 25, 15, 30]
        ax.bar(cats, vals)

    def test_bar_color(self):
        fig, ax = plt.subplots()
        ax.bar([1, 2, 3], [4, 5, 6], color='steelblue')

    def test_bar_color_list(self):
        fig, ax = plt.subplots()
        ax.bar([1, 2, 3], [4, 5, 6], color=['red', 'green', 'blue'])

    def test_bar_edgecolor(self):
        fig, ax = plt.subplots()
        ax.bar([1, 2, 3], [4, 5, 6], edgecolor='black', linewidth=1)

    def test_bar_alpha(self):
        fig, ax = plt.subplots()
        ax.bar([1, 2, 3], [4, 5, 6], alpha=0.7)

    def test_bar_width(self):
        fig, ax = plt.subplots()
        ax.bar([1, 2, 3], [4, 5, 6], width=0.5)

    def test_bar_label(self):
        fig, ax = plt.subplots()
        ax.bar([1, 2], [3, 4], label='Group A')
        ax.legend()

    def test_bar_returns_container(self):
        fig, ax = plt.subplots()
        bars = ax.bar([1, 2, 3], [4, 5, 6])
        assert bars is not None

    def test_bar_align_center(self):
        fig, ax = plt.subplots()
        ax.bar([1, 2, 3], [4, 5, 6], align='center')

    def test_bar_align_edge(self):
        fig, ax = plt.subplots()
        ax.bar([1, 2, 3], [4, 5, 6], align='edge')

    def test_bar_bottom(self):
        """Stacked bars using bottom parameter."""
        fig, ax = plt.subplots()
        ax.bar([1, 2, 3], [4, 5, 6])
        ax.bar([1, 2, 3], [1, 2, 1], bottom=[4, 5, 6])

    def test_grouped_bar(self):
        """Grouped bar chart pattern."""
        fig, ax = plt.subplots()
        x = [0, 1, 2]
        width = 0.35
        ax.bar([xi - width/2 for xi in x], [10, 20, 15], width=width, label='Group A')
        ax.bar([xi + width/2 for xi in x], [15, 10, 25], width=width, label='Group B')
        ax.legend()

    def test_stacked_bar(self):
        """Stacked bar chart pattern."""
        fig, ax = plt.subplots()
        x = [1, 2, 3]
        bottom1 = [0, 0, 0]
        vals1 = [10, 20, 15]
        vals2 = [5, 10, 8]
        ax.bar(x, vals1, label='Part 1')
        ax.bar(x, vals2, bottom=vals1, label='Part 2')
        ax.legend()

    def test_bar_yerr(self):
        """Bar chart with error bars."""
        fig, ax = plt.subplots()
        ax.bar([1, 2, 3], [10, 20, 15],
               yerr=[1, 2, 1.5], capsize=5)

    def test_barh_basic(self):
        """Horizontal bar chart."""
        fig, ax = plt.subplots()
        ax.barh([1, 2, 3], [4, 5, 6])

    def test_barh_color(self):
        fig, ax = plt.subplots()
        ax.barh(['A', 'B', 'C'], [10, 20, 15], color='coral')

    def test_barh_height(self):
        """Height parameter for barh (equivalent to width in bar)."""
        fig, ax = plt.subplots()
        ax.barh([1, 2, 3], [4, 5, 6], height=0.5)

    def test_barh_xerr(self):
        fig, ax = plt.subplots()
        ax.barh([1, 2, 3], [10, 20, 15], xerr=[1, 2, 1.5], capsize=5)

    def test_bar_tick_labels(self):
        """Common pattern: set_xticks with string labels."""
        fig, ax = plt.subplots()
        categories = ['Jan', 'Feb', 'Mar', 'Apr']
        values = [10, 25, 20, 30]
        x = range(len(categories))
        ax.bar(x, values)
        ax.set_xticks(list(x))
        ax.set_xticklabels(categories, rotation=45)

    def test_bar_value_labels(self):
        """Common pattern: add value labels on top of bars."""
        fig, ax = plt.subplots()
        categories = ['A', 'B', 'C']
        values = [10, 20, 15]
        bars = ax.bar(categories, values)
        for bar, val in zip(bars, values):
            h = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2, h,
                   f'{val}', ha='center', va='bottom')


class TestHistograms:
    """Histogram patterns."""

    def teardown_method(self):
        plt.close('all')

    def test_hist_basic(self):
        fig, ax = plt.subplots()
        data = [1, 1, 2, 2, 2, 3, 3, 3, 3, 4, 4, 5]
        ax.hist(data)

    def test_hist_bins_int(self):
        fig, ax = plt.subplots()
        data = list(range(100))
        ax.hist(data, bins=20)

    def test_hist_bins_list(self):
        fig, ax = plt.subplots()
        data = [1, 2, 3, 4, 5]
        ax.hist(data, bins=[0.5, 1.5, 2.5, 3.5, 4.5, 5.5])

    def test_hist_density(self):
        fig, ax = plt.subplots()
        data = list(range(20))
        n, bins, patches = ax.hist(data, density=True)
        assert n is not None

    def test_hist_cumulative(self):
        fig, ax = plt.subplots()
        data = list(range(20))
        ax.hist(data, cumulative=True)

    def test_hist_color(self):
        fig, ax = plt.subplots()
        ax.hist([1, 2, 3, 4], color='steelblue')

    def test_hist_alpha(self):
        fig, ax = plt.subplots()
        ax.hist([1, 2, 3, 4], alpha=0.7)

    def test_hist_edgecolor(self):
        fig, ax = plt.subplots()
        ax.hist([1, 2, 3, 4], edgecolor='black')

    def test_hist_label(self):
        fig, ax = plt.subplots()
        ax.hist([1, 2, 3], label='sample')
        ax.legend()

    def test_hist_multiple_overlapping(self):
        """Overlapping histograms pattern."""
        fig, ax = plt.subplots()
        data1 = [1, 2, 2, 3, 3, 3, 4]
        data2 = [2, 3, 3, 4, 4, 5]
        ax.hist(data1, alpha=0.5, label='A')
        ax.hist(data2, alpha=0.5, label='B')
        ax.legend()

    def test_hist_orientation_horizontal(self):
        fig, ax = plt.subplots()
        ax.hist([1, 2, 3, 4], orientation='horizontal')

    def test_hist_returns_tuple(self):
        fig, ax = plt.subplots()
        result = ax.hist([1, 2, 3, 4, 5])
        # Should return (n, bins, patches)
        assert len(result) == 3

    def test_hist_range(self):
        fig, ax = plt.subplots()
        data = list(range(10))
        ax.hist(data, range=(2, 8))

    def test_hist_stacked(self):
        fig, ax = plt.subplots()
        data1 = [1, 2, 3, 4]
        data2 = [2, 3, 4, 5]
        ax.hist([data1, data2], stacked=True)
