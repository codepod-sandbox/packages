"""Tests for axis formatting, ticks, and spines."""

import pytest
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker


class TestTickFormatters:
    def test_format_str_formatter(self):
        """FormatStrFormatter does not raise."""
        fig, ax = plt.subplots()
        ax.xaxis.set_major_formatter(ticker.FormatStrFormatter('%.2f'))
        ax.plot([1, 2, 3])
        plt.close('all')

    def test_func_formatter(self):
        """FuncFormatter does not raise."""
        fig, ax = plt.subplots()
        ax.xaxis.set_major_formatter(ticker.FuncFormatter(lambda x, p: f'{x:.1f}'))
        ax.plot([1, 2, 3])
        plt.close('all')

    def test_scalar_formatter(self):
        """ScalarFormatter does not raise."""
        fig, ax = plt.subplots()
        fmt = ticker.ScalarFormatter()
        ax.xaxis.set_major_formatter(fmt)
        ax.plot([1000, 2000, 3000])
        plt.close('all')

    def test_log_formatter(self):
        """LogFormatter does not raise."""
        fig, ax = plt.subplots()
        fmt = ticker.LogFormatter()
        ax.set_xscale('log')
        ax.xaxis.set_major_formatter(fmt)
        ax.plot([1, 10, 100])
        plt.close('all')

    def test_null_formatter(self):
        """NullFormatter removes tick labels."""
        fig, ax = plt.subplots()
        ax.xaxis.set_major_formatter(ticker.NullFormatter())
        ax.plot([1, 2, 3])
        plt.close('all')

    def test_percent_formatter(self):
        """PercentFormatter does not raise."""
        fig, ax = plt.subplots()
        try:
            ax.xaxis.set_major_formatter(ticker.PercentFormatter(xmax=1.0))
        except AttributeError:
            pytest.skip("PercentFormatter not available")
        plt.close('all')


class TestTickLocators:
    def test_fixed_locator(self):
        """FixedLocator does not raise."""
        fig, ax = plt.subplots()
        ax.xaxis.set_major_locator(ticker.FixedLocator([0, 0.5, 1.0, 1.5, 2.0]))
        ax.plot([0, 1, 2])
        plt.close('all')

    def test_multiple_locator(self):
        """MultipleLocator does not raise."""
        fig, ax = plt.subplots()
        ax.xaxis.set_major_locator(ticker.MultipleLocator(0.5))
        ax.plot([0, 1, 2])
        plt.close('all')

    def test_max_n_locator(self):
        """MaxNLocator does not raise."""
        fig, ax = plt.subplots()
        ax.xaxis.set_major_locator(ticker.MaxNLocator(5))
        ax.plot([0, 100, 200])
        plt.close('all')

    def test_auto_locator(self):
        """AutoLocator does not raise."""
        fig, ax = plt.subplots()
        ax.xaxis.set_major_locator(ticker.AutoLocator())
        ax.plot([0, 1, 2])
        plt.close('all')

    def test_log_locator(self):
        """LogLocator does not raise."""
        fig, ax = plt.subplots()
        ax.set_xscale('log')
        ax.xaxis.set_major_locator(ticker.LogLocator())
        ax.plot([1, 10, 100, 1000])
        plt.close('all')

    def test_null_locator(self):
        """NullLocator removes tick marks."""
        fig, ax = plt.subplots()
        ax.xaxis.set_major_locator(ticker.NullLocator())
        ax.plot([1, 2, 3])
        plt.close('all')


class TestAxisSetup:
    def test_set_xticks_xticklabels(self):
        """set_xticks + set_xticklabels does not raise."""
        fig, ax = plt.subplots()
        ax.set_xticks([1, 2, 3, 4])
        ax.set_xticklabels(['A', 'B', 'C', 'D'])
        plt.close('all')

    def test_set_yticks_yticklabels(self):
        """set_yticks + set_yticklabels does not raise."""
        fig, ax = plt.subplots()
        ax.set_yticks([0, 25, 50, 75, 100])
        ax.set_yticklabels(['0%', '25%', '50%', '75%', '100%'])
        plt.close('all')

    def test_tick_params_direction(self):
        """tick_params with direction does not raise."""
        fig, ax = plt.subplots()
        ax.tick_params(direction='in')
        plt.close('all')

    def test_tick_params_top_right(self):
        """tick_params with top/right does not raise."""
        fig, ax = plt.subplots()
        ax.tick_params(top=True, right=True)
        plt.close('all')

    def test_tick_params_length_width(self):
        """tick_params with length/width does not raise."""
        fig, ax = plt.subplots()
        ax.tick_params(length=6, width=1.5)
        plt.close('all')

    def test_tick_params_color_labelcolor(self):
        """tick_params with colors does not raise."""
        fig, ax = plt.subplots()
        ax.tick_params(color='red', labelcolor='blue')
        plt.close('all')

    def test_axis_formatter_set_scientific(self):
        """ScalarFormatter with useMathText does not raise."""
        fig, ax = plt.subplots()
        fmt = ticker.ScalarFormatter(useMathText=True)
        ax.yaxis.set_major_formatter(fmt)
        plt.close('all')


class TestSpines:
    def test_spines_accessible(self):
        """ax.spines is accessible."""
        fig, ax = plt.subplots()
        spines = ax.spines
        assert spines is not None
        plt.close('all')

    def test_spine_set_visible_false(self):
        """ax.spines['top'].set_visible(False) does not raise."""
        fig, ax = plt.subplots()
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        plt.close('all')

    def test_spine_set_color(self):
        """Spine set_color does not raise."""
        fig, ax = plt.subplots()
        ax.spines['bottom'].set_color('red')
        plt.close('all')

    def test_spine_set_linewidth(self):
        """Spine set_linewidth does not raise."""
        fig, ax = plt.subplots()
        ax.spines['left'].set_linewidth(2.0)
        plt.close('all')

    def test_spine_set_position(self):
        """Spine set_position does not raise."""
        fig, ax = plt.subplots()
        try:
            ax.spines['left'].set_position(('data', 0))
        except Exception:
            pytest.skip("set_position not implemented")
        plt.close('all')

    def test_all_spines(self):
        """All four spine names are accessible."""
        fig, ax = plt.subplots()
        for spine_name in ['top', 'bottom', 'left', 'right']:
            spine = ax.spines[spine_name]
            assert spine is not None
        plt.close('all')
