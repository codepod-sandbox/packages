"""Tests for 2D histogram patterns (hist2d, hexbin)."""

import pytest
import matplotlib.pyplot as plt


class TestHist2d:
    def test_hist2d_basic(self):
        """Basic 2D histogram."""
        fig, ax = plt.subplots()
        x = [1.0, 2.0, 3.0, 4.0, 5.0, 2.0, 3.0, 4.0, 3.0, 2.0]
        y = [1.0, 2.0, 3.0, 2.0, 1.0, 3.0, 2.0, 3.0, 4.0, 5.0]
        h, xedges, yedges, im = ax.hist2d(x, y)
        assert h is not None
        plt.close('all')

    def test_hist2d_bins_int(self):
        """2D histogram with integer bins."""
        fig, ax = plt.subplots()
        x = [1.0, 2.0, 3.0, 4.0, 5.0]
        y = [1.0, 2.0, 3.0, 4.0, 5.0]
        ax.hist2d(x, y, bins=5)
        plt.close('all')

    def test_hist2d_bins_tuple(self):
        """2D histogram with tuple bins."""
        fig, ax = plt.subplots()
        x = [1.0, 2.0, 3.0, 4.0, 5.0]
        y = [1.0, 2.0, 3.0, 4.0, 5.0]
        ax.hist2d(x, y, bins=(5, 4))
        plt.close('all')

    def test_hist2d_cmap(self):
        """2D histogram with colormap."""
        fig, ax = plt.subplots()
        x = [1.0, 2.0, 3.0, 4.0, 5.0, 3.0, 3.0]
        y = [1.0, 2.0, 3.0, 4.0, 5.0, 3.0, 4.0]
        ax.hist2d(x, y, cmap='Blues')
        plt.close('all')

    def test_hist2d_with_colorbar(self):
        """2D histogram with colorbar."""
        fig, ax = plt.subplots()
        x = [1.0, 2.0, 3.0, 4.0, 5.0, 3.0, 3.0]
        y = [1.0, 2.0, 3.0, 4.0, 5.0, 3.0, 4.0]
        h, xedges, yedges, im = ax.hist2d(x, y)
        cbar = plt.colorbar(im)
        assert cbar is not None
        plt.close('all')

    def test_hist2d_density(self):
        """2D histogram with density."""
        fig, ax = plt.subplots()
        x = [1.0, 2.0, 3.0, 4.0, 5.0]
        y = [1.0, 2.0, 3.0, 4.0, 5.0]
        ax.hist2d(x, y, density=True)
        plt.close('all')

    def test_hist2d_range(self):
        """2D histogram with range."""
        fig, ax = plt.subplots()
        x = [1.0, 2.0, 3.0, 4.0, 5.0]
        y = [1.0, 2.0, 3.0, 4.0, 5.0]
        ax.hist2d(x, y, range=[[1, 5], [1, 5]])
        plt.close('all')


class TestHexbin:
    def test_hexbin_basic(self):
        """Basic hexbin plot."""
        fig, ax = plt.subplots()
        x = [1.0, 2.0, 3.0, 4.0, 5.0, 2.0, 3.0, 4.0, 3.0]
        y = [1.0, 2.0, 3.0, 2.0, 1.0, 3.0, 2.0, 3.0, 4.0]
        hb = ax.hexbin(x, y)
        assert hb is not None
        plt.close('all')

    def test_hexbin_gridsize(self):
        """Hexbin with gridsize."""
        fig, ax = plt.subplots()
        x = [1.0, 2.0, 3.0, 4.0, 5.0, 3.0, 3.0]
        y = [1.0, 2.0, 3.0, 4.0, 5.0, 3.0, 4.0]
        ax.hexbin(x, y, gridsize=5)
        plt.close('all')

    def test_hexbin_cmap(self):
        """Hexbin with colormap."""
        fig, ax = plt.subplots()
        x = [1.0, 2.0, 3.0, 4.0, 5.0]
        y = [1.0, 2.0, 3.0, 4.0, 5.0]
        ax.hexbin(x, y, cmap='hot_r')
        plt.close('all')

    def test_hexbin_with_colorbar(self):
        """Hexbin with colorbar."""
        fig, ax = plt.subplots()
        x = [1.0, 2.0, 3.0, 4.0, 5.0, 3.0, 3.0]
        y = [1.0, 2.0, 3.0, 4.0, 5.0, 3.0, 4.0]
        hb = ax.hexbin(x, y, cmap='viridis')
        cbar = plt.colorbar(hb)
        assert cbar is not None
        plt.close('all')

    def test_hexbin_mincnt(self):
        """Hexbin with mincnt."""
        fig, ax = plt.subplots()
        x = [1.0, 2.0, 3.0, 4.0, 5.0, 3.0]
        y = [1.0, 2.0, 3.0, 4.0, 5.0, 3.0]
        ax.hexbin(x, y, mincnt=2)
        plt.close('all')


class TestComplexMultiPanel:
    def test_multi_panel_analysis(self):
        """Multi-panel analysis figure."""
        fig, axes = plt.subplots(2, 2, figsize=(12, 10))
        fig.suptitle('Analysis Dashboard', fontsize=14)

        # Top-left: time series
        axes[0][0].plot([0, 1, 2, 3, 4], [1, 3, 2, 4, 3], 'b-o')
        axes[0][0].set_title('Time Series')

        # Top-right: histogram
        data = [1.0, 2.0, 2.5, 3.0, 3.5, 2.0, 2.5]
        axes[0][1].hist(data, bins=6, color='steelblue')
        axes[0][1].set_title('Distribution')

        # Bottom-left: scatter
        axes[1][0].scatter([1.0, 2.0, 3.0, 4.0], [2.0, 1.0, 4.0, 3.0],
                           c=[1.0, 2.0, 3.0, 4.0], cmap='viridis')
        axes[1][0].set_title('Scatter')

        # Bottom-right: bar
        axes[1][1].bar(['A', 'B', 'C', 'D'], [10, 20, 15, 25])
        axes[1][1].set_title('Bar Chart')

        plt.tight_layout()
        import io
        buf = io.BytesIO()
        fig.savefig(buf, format='png')
        buf.seek(0)
        assert len(buf.read()) > 0
        plt.close('all')

    def test_report_figure(self):
        """Report-style figure with multiple elements."""
        import io
        fig = plt.figure(figsize=(10, 8))

        # Main plot area
        ax_main = fig.add_subplot(2, 1, 1)
        x = list(range(10))
        y1 = [1.0, 3.0, 2.0, 4.0, 3.0, 5.0, 4.0, 6.0, 5.0, 7.0]
        y2 = [0.5, 1.5, 1.0, 2.5, 2.0, 3.5, 3.0, 4.5, 4.0, 5.5]
        ax_main.plot(x, y1, 'b-', label='Series A')
        ax_main.fill_between(x, y1, y2, alpha=0.3)
        ax_main.set_title('Performance Over Time')
        ax_main.legend()
        ax_main.grid(True, alpha=0.3)

        # Summary table
        ax_table = fig.add_subplot(2, 1, 2)
        ax_table.axis('off')
        data = [['Mean', '3.5'], ['Std', '2.0'], ['Max', '7.0']]
        ax_table.table(cellText=data, colLabels=['Metric', 'Value'], loc='center')

        plt.tight_layout()
        buf = io.BytesIO()
        fig.savefig(buf, format='png')
        buf.seek(0)
        assert len(buf.read()) > 0
        plt.close('all')

    def test_comparison_figure(self):
        """Side-by-side comparison figure."""
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))

        # Before
        categories = ['A', 'B', 'C', 'D']
        before = [10, 25, 15, 30]
        after = [15, 22, 20, 35]
        x = list(range(len(categories)))

        ax1.bar(x, before, color='lightblue', label='Before')
        ax1.bar(x, after, color='lightgreen', alpha=0.7, label='After')
        ax1.set_xticks(x)
        ax1.set_xticklabels(categories)
        ax1.legend()
        ax1.set_title('Before vs After')

        # Difference
        diff = [a - b for a, b in zip(after, before)]
        colors = ['green' if d > 0 else 'red' for d in diff]
        ax2.bar(x, diff, color=colors)
        ax2.set_xticks(x)
        ax2.set_xticklabels(categories)
        ax2.axhline(0, color='black', linewidth=0.5)
        ax2.set_title('Difference')

        import io
        buf = io.BytesIO()
        fig.savefig(buf, format='png')
        buf.seek(0)
        assert len(buf.read()) > 0
        plt.close('all')
