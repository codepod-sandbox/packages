"""
Upstream tests for text and title property patterns.
"""

import pytest
import matplotlib.pyplot as plt
import matplotlib.text as mtext


class TestTitleProperties:
    """Tests for axes title properties."""

    def teardown_method(self):
        plt.close('all')

    def test_title_basic(self):
        fig, ax = plt.subplots()
        ax.set_title('My Title')
        assert ax.get_title() == 'My Title'

    def test_title_fontsize(self):
        fig, ax = plt.subplots()
        ax.set_title('Title', fontsize=16)

    def test_title_fontweight(self):
        fig, ax = plt.subplots()
        ax.set_title('Title', fontweight='bold')

    def test_title_loc_center(self):
        fig, ax = plt.subplots()
        ax.set_title('Center', loc='center')

    def test_title_loc_left(self):
        fig, ax = plt.subplots()
        ax.set_title('Left', loc='left')

    def test_title_loc_right(self):
        fig, ax = plt.subplots()
        ax.set_title('Right', loc='right')

    def test_title_color(self):
        fig, ax = plt.subplots()
        ax.set_title('Title', color='red')

    def test_title_fontstyle(self):
        fig, ax = plt.subplots()
        ax.set_title('Title', fontstyle='italic')

    def test_title_pad(self):
        fig, ax = plt.subplots()
        ax.set_title('Title', pad=10)

    def test_title_returns_text(self):
        fig, ax = plt.subplots()
        t = ax.set_title('Title')
        assert hasattr(t, 'get_text')
        assert t.get_text() == 'Title'

    def test_title_update(self):
        fig, ax = plt.subplots()
        ax.set_title('First')
        ax.set_title('Second')
        assert ax.get_title() == 'Second'


class TestXYLabels:
    """Tests for axis label properties."""

    def teardown_method(self):
        plt.close('all')

    def test_xlabel_basic(self):
        fig, ax = plt.subplots()
        ax.set_xlabel('X Axis')
        assert ax.get_xlabel() == 'X Axis'

    def test_ylabel_basic(self):
        fig, ax = plt.subplots()
        ax.set_ylabel('Y Axis')
        assert ax.get_ylabel() == 'Y Axis'

    def test_xlabel_fontsize(self):
        fig, ax = plt.subplots()
        ax.set_xlabel('X', fontsize=12)

    def test_ylabel_fontsize(self):
        fig, ax = plt.subplots()
        ax.set_ylabel('Y', fontsize=12)

    def test_xlabel_labelpad(self):
        fig, ax = plt.subplots()
        ax.set_xlabel('X', labelpad=10)

    def test_ylabel_labelpad(self):
        fig, ax = plt.subplots()
        ax.set_ylabel('Y', labelpad=10)

    def test_xlabel_color(self):
        fig, ax = plt.subplots()
        ax.set_xlabel('X', color='blue')

    def test_ylabel_fontweight(self):
        fig, ax = plt.subplots()
        ax.set_ylabel('Y', fontweight='bold')

    def test_xlabel_sets_label(self):
        fig, ax = plt.subplots()
        ax.set_xlabel('X Label')
        assert ax.get_xlabel() == 'X Label'

    def test_labels_all_together(self):
        fig, ax = plt.subplots()
        ax.set_title('Title', fontsize=14, fontweight='bold')
        ax.set_xlabel('X axis', fontsize=12)
        ax.set_ylabel('Y axis', fontsize=12)


class TestTextObject:
    """Tests for Text artist properties."""

    def teardown_method(self):
        plt.close('all')

    def test_text_get_text(self):
        t = mtext.Text(0, 0, 'hello')
        assert t.get_text() == 'hello'

    def test_text_set_text(self):
        t = mtext.Text(0, 0, 'hello')
        t.set_text('world')
        assert t.get_text() == 'world'

    def test_text_get_position(self):
        t = mtext.Text(1, 2, 'text')
        x, y = t.get_position()
        assert x == 1
        assert y == 2

    def test_text_set_position(self):
        t = mtext.Text(0, 0, 'text')
        t.set_position((3, 4))
        x, y = t.get_position()
        assert x == 3
        assert y == 4

    def test_text_fontsize(self):
        t = mtext.Text(0, 0, 'text', fontsize=14)
        assert t.get_fontsize() == 14

    def test_text_set_fontsize(self):
        t = mtext.Text(0, 0, 'text')
        t.set_fontsize(16)
        assert t.get_fontsize() == 16

    def test_text_fontweight(self):
        t = mtext.Text(0, 0, 'text', fontweight='bold')
        assert t.get_fontweight() == 'bold'

    def test_text_fontstyle(self):
        t = mtext.Text(0, 0, 'text', fontstyle='italic')
        assert t.get_fontstyle() == 'italic'

    def test_text_ha_center(self):
        t = mtext.Text(0, 0, 'text', ha='center')
        assert t.get_ha() == 'center'

    def test_text_ha_right(self):
        t = mtext.Text(0, 0, 'text', ha='right')
        assert t.get_ha() == 'right'

    def test_text_va_center(self):
        t = mtext.Text(0, 0, 'text', va='center')
        assert t.get_va() == 'center'

    def test_text_va_top(self):
        t = mtext.Text(0, 0, 'text', va='top')
        assert t.get_va() == 'top'

    def test_text_rotation_float(self):
        t = mtext.Text(0, 0, 'text', rotation=45)
        assert t.get_rotation() == 45.0

    def test_text_rotation_horizontal(self):
        t = mtext.Text(0, 0, 'text', rotation='horizontal')
        assert t.get_rotation() == 0.0

    def test_text_rotation_vertical(self):
        t = mtext.Text(0, 0, 'text', rotation='vertical')
        assert t.get_rotation() == 90.0

    def test_text_color(self):
        t = mtext.Text(0, 0, 'text', color='red')
        assert t.get_color() == 'red'

    def test_text_alpha(self):
        t = mtext.Text(0, 0, 'text', alpha=0.5)
        assert t.get_alpha() == 0.5

    def test_text_visible(self):
        t = mtext.Text(0, 0, 'text')
        assert t.get_visible() is True
        t.set_visible(False)
        assert t.get_visible() is False

    def test_text_repr(self):
        t = mtext.Text(1, 2, 'hello')
        r = repr(t)
        assert 'hello' in r

    def test_text_zorder(self):
        t = mtext.Text(0, 0, 'text')
        t.set_zorder(5)
        assert t.get_zorder() == 5
