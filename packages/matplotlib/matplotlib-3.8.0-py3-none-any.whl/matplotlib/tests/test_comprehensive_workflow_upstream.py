"""Tests for complete real-world matplotlib workflow patterns as an LLM would use them."""

import pytest
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.colors as mcolors


# ---------------------------------------------------------------------------
# Complete data visualization workflows
# ---------------------------------------------------------------------------

class TestDataVisualizationWorkflows:
    def test_timeseries_plot(self):
        """Full timeseries plot workflow does not raise."""
        fig, ax = plt.subplots(figsize=(10, 4))
        x = list(range(100))
        y = [i + i * 0.1 * ((-1) ** i) for i in x]
        ax.plot(x, y, 'b-', linewidth=1.5, label='Signal')
        ax.axhline(y=50, color='red', linestyle='--', label='Threshold')
        ax.set_xlabel('Time (s)')
        ax.set_ylabel('Value')
        ax.set_title('Time Series')
        ax.legend()
        ax.grid(True, alpha=0.3)
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_comparison_bar_chart(self):
        """Side-by-side bar chart workflow does not raise."""
        fig, ax = plt.subplots(figsize=(8, 5))
        categories = ['A', 'B', 'C', 'D']
        values1 = [3, 7, 2, 5]
        values2 = [4, 6, 3, 7]
        x = list(range(len(categories)))
        width = 0.35
        ax.bar([xi - width/2 for xi in x], values1, width, label='Group 1')
        ax.bar([xi + width/2 for xi in x], values2, width, label='Group 2')
        ax.set_xticks(x)
        ax.set_xticklabels(categories)
        ax.set_ylabel('Count')
        ax.set_title('Comparison')
        ax.legend()
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_heatmap_workflow(self):
        """Heatmap (imshow + colorbar) workflow does not raise."""
        fig, ax = plt.subplots(figsize=(8, 6))
        data = [[i * j for j in range(1, 6)] for i in range(1, 6)]
        im = ax.imshow(data, cmap='YlOrRd', aspect='auto')
        fig.colorbar(im, ax=ax, label='Value')
        ax.set_title('Heatmap')
        ax.set_xticks(list(range(5)))
        ax.set_yticks(list(range(5)))
        ax.set_xticklabels(['Mon', 'Tue', 'Wed', 'Thu', 'Fri'])
        ax.set_yticklabels(['A', 'B', 'C', 'D', 'E'])
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_scatter_analysis_workflow(self):
        """Scatter analysis workflow does not raise."""
        import random
        random.seed(42)
        fig, ax = plt.subplots()
        x = [random.gauss(0, 1) for _ in range(50)]
        y = [xi * 2 + random.gauss(0, 0.5) for xi in x]
        colors = [xi for xi in x]
        sc = ax.scatter(x, y, c=colors, cmap='coolwarm', alpha=0.7, s=50)
        fig.colorbar(sc, ax=ax, label='x value')
        ax.set_xlabel('X')
        ax.set_ylabel('Y')
        ax.set_title('Scatter Analysis')
        ax.grid(True, alpha=0.3)
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_multi_panel_figure(self):
        """Multi-panel figure with 2x2 subplots does not raise."""
        fig, axes = plt.subplots(2, 2, figsize=(10, 8))
        # Panel 1: line plot
        axes[0][0].plot([0, 1, 2, 3], [0, 1, 4, 9])
        axes[0][0].set_title('Line')
        # Panel 2: bar chart
        axes[0][1].bar(['A', 'B', 'C'], [3, 7, 5])
        axes[0][1].set_title('Bar')
        # Panel 3: scatter
        axes[1][0].scatter([1, 2, 3], [1, 4, 9])
        axes[1][0].set_title('Scatter')
        # Panel 4: histogram
        axes[1][1].hist([1, 2, 2, 3, 3, 3, 4, 4, 4, 4], bins=4)
        axes[1][1].set_title('Histogram')
        fig.tight_layout()
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_annotated_peaks_workflow(self):
        """Annotating peaks on a plot does not raise."""
        fig, ax = plt.subplots()
        x = [0, 1, 2, 3, 4, 5]
        y = [0, 4, 1, 9, 2, 0]
        ax.plot(x, y, 'b-o')
        # Annotate peaks
        for xi, yi in zip(x, y):
            if yi > 3:
                ax.annotate(f'{yi}', xy=(xi, yi), xytext=(xi, yi + 0.5),
                             ha='center', fontsize=9)
        ax.set_ylim(-1, 12)
        plt.close('all')

    def test_dual_axis_workflow(self):
        """Dual y-axis workflow does not raise."""
        fig, ax1 = plt.subplots()
        ax2 = ax1.twinx()
        x = [0, 1, 2, 3, 4]
        ax1.plot(x, [1, 4, 9, 16, 25], 'b-', label='Quadratic')
        ax1.set_ylabel('Quadratic', color='blue')
        ax2.plot(x, [0.01, 0.1, 1, 10, 100], 'r-', label='Exponential')
        ax2.set_ylabel('Exponential', color='red')
        ax1.set_xlabel('X')
        ax1.set_title('Dual Axis')
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_distribution_comparison_workflow(self):
        """Distribution comparison with multiple histograms does not raise."""
        fig, ax = plt.subplots()
        import random
        random.seed(42)
        for mu, label, color in [(0, 'Group A', 'blue'), (2, 'Group B', 'orange')]:
            data = [random.gauss(mu, 1) for _ in range(100)]
            ax.hist(data, bins=20, alpha=0.5, label=label, color=color)
        ax.set_xlabel('Value')
        ax.set_ylabel('Frequency')
        ax.set_title('Distribution Comparison')
        ax.legend()
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')


# ---------------------------------------------------------------------------
# Common data science patterns
# ---------------------------------------------------------------------------

class TestDataSciencePatterns:
    def test_confusion_matrix_heatmap(self):
        """Confusion matrix heatmap pattern does not raise."""
        fig, ax = plt.subplots()
        cm = [[85, 15], [10, 90]]
        im = ax.imshow(cm, cmap='Blues')
        ax.set_xticks([0, 1])
        ax.set_yticks([0, 1])
        ax.set_xticklabels(['Predicted 0', 'Predicted 1'])
        ax.set_yticklabels(['Actual 0', 'Actual 1'])
        for i in range(2):
            for j in range(2):
                ax.text(j, i, str(cm[i][j]), ha='center', va='center')
        ax.set_title('Confusion Matrix')
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_learning_curve_pattern(self):
        """Learning curve (train/val loss) pattern does not raise."""
        fig, ax = plt.subplots()
        epochs = list(range(1, 21))
        train_loss = [1.0 / (1 + 0.3 * e) + 0.05 for e in epochs]
        val_loss = [1.0 / (1 + 0.2 * e) + 0.1 for e in epochs]
        ax.plot(epochs, train_loss, 'b-', label='Training Loss')
        ax.plot(epochs, val_loss, 'r--', label='Validation Loss')
        ax.set_xlabel('Epoch')
        ax.set_ylabel('Loss')
        ax.set_title('Learning Curve')
        ax.legend()
        ax.grid(True, alpha=0.3)
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_feature_importance_barh(self):
        """Horizontal bar chart for feature importance does not raise."""
        fig, ax = plt.subplots()
        features = ['feat_a', 'feat_b', 'feat_c', 'feat_d', 'feat_e']
        importance = [0.35, 0.25, 0.20, 0.12, 0.08]
        y_pos = list(range(len(features)))
        ax.barh(y_pos, importance)
        ax.set_yticks(y_pos)
        ax.set_yticklabels(features)
        ax.set_xlabel('Importance')
        ax.set_title('Feature Importance')
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_correlation_heatmap(self):
        """Correlation heatmap pattern does not raise."""
        fig, ax = plt.subplots()
        # Simple correlation-like matrix
        corr = [
            [1.0, 0.8, -0.5, 0.2],
            [0.8, 1.0, -0.3, 0.4],
            [-0.5, -0.3, 1.0, -0.1],
            [0.2, 0.4, -0.1, 1.0],
        ]
        im = ax.imshow(corr, cmap='RdBu', vmin=-1, vmax=1)
        fig.colorbar(im, ax=ax)
        labels = ['A', 'B', 'C', 'D']
        ax.set_xticks(list(range(4)))
        ax.set_yticks(list(range(4)))
        ax.set_xticklabels(labels)
        ax.set_yticklabels(labels)
        ax.set_title('Correlation Matrix')
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_box_whisker_comparison(self):
        """Box plot comparison does not raise."""
        fig, ax = plt.subplots()
        import random
        random.seed(42)
        data = [
            [random.gauss(0, 1) for _ in range(50)],
            [random.gauss(1, 1.5) for _ in range(50)],
            [random.gauss(-0.5, 0.8) for _ in range(50)],
        ]
        ax.boxplot(data, labels=['Group A', 'Group B', 'Group C'])
        ax.set_ylabel('Value')
        ax.set_title('Group Comparison')
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')
