"""
Upstream tests for tick_params, tick formatting, and tick label styling.
"""

import numpy as np
import pytest
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker


class TestTickParams:
    def setup_method(self):
        self.fig, self.ax = plt.subplots()

    def teardown_method(self):
        plt.close('all')

    def test_tick_params_default(self):
        self.ax.tick_params()  # no-op is fine

    def test_tick_params_labelsize(self):
        self.ax.tick_params(labelsize=14)

    def test_tick_params_labelrotation(self):
        self.ax.tick_params(labelrotation=45)

    def test_tick_params_length(self):
        self.ax.tick_params(length=8)

    def test_tick_params_width(self):
        self.ax.tick_params(width=2)

    def test_tick_params_direction(self):
        self.ax.tick_params(direction='in')
        self.ax.tick_params(direction='out')
        self.ax.tick_params(direction='inout')

    def test_tick_params_axis_x(self):
        self.ax.tick_params(axis='x', labelsize=10)

    def test_tick_params_axis_y(self):
        self.ax.tick_params(axis='y', labelsize=10)

    def test_tick_params_axis_both(self):
        self.ax.tick_params(axis='both', labelsize=10)

    def test_tick_params_which(self):
        self.ax.tick_params(which='major', labelsize=12)
        self.ax.tick_params(which='minor', length=3)
        self.ax.tick_params(which='both', width=1)

    def test_tick_params_color(self):
        self.ax.tick_params(color='red')

    def test_tick_params_labelcolor(self):
        self.ax.tick_params(labelcolor='blue')

    def test_tick_params_pad(self):
        self.ax.tick_params(pad=6)

    def test_tick_params_bottom_top(self):
        self.ax.tick_params(bottom=True, top=False)

    def test_tick_params_left_right(self):
        self.ax.tick_params(left=True, right=False)

    def test_tick_params_labelbottom(self):
        self.ax.tick_params(labelbottom=False)

    def test_tick_params_labeltop(self):
        self.ax.tick_params(labeltop=True)

    def test_tick_params_labelleft(self):
        self.ax.tick_params(labelleft=True)

    def test_tick_params_labelright(self):
        self.ax.tick_params(labelright=False)

    def test_set_xticks_manual(self):
        self.ax.set_xticks([0, 1, 2, 3])
        ticks = self.ax.get_xticks()
        assert list(ticks) == [0, 1, 2, 3]

    def test_set_yticks_manual(self):
        self.ax.set_yticks([0.0, 0.5, 1.0])
        ticks = self.ax.get_yticks()
        assert len(ticks) == 3

    def test_set_xticklabels(self):
        self.ax.set_xticks([0, 1, 2])
        self.ax.set_xticklabels(['a', 'b', 'c'])

    def test_set_yticklabels(self):
        self.ax.set_yticks([0, 1, 2])
        self.ax.set_yticklabels(['x', 'y', 'z'])

    def test_set_xticklabels_rotation(self):
        self.ax.set_xticks([0, 1, 2])
        self.ax.set_xticklabels(['Jan', 'Feb', 'Mar'], rotation=45)

    def test_set_xticklabels_ha(self):
        self.ax.set_xticks([0, 1, 2])
        self.ax.set_xticklabels(['a', 'b', 'c'], ha='right')

    def test_xaxis_set_major_formatter(self):
        self.ax.xaxis.set_major_formatter(ticker.FormatStrFormatter('%.2f'))

    def test_yaxis_set_major_formatter(self):
        self.ax.yaxis.set_major_formatter(ticker.FormatStrFormatter('%d'))

    def test_xaxis_set_major_locator(self):
        self.ax.xaxis.set_major_locator(ticker.MultipleLocator(5))

    def test_yaxis_set_major_locator(self):
        self.ax.yaxis.set_major_locator(ticker.MultipleLocator(2))

    def test_xaxis_set_minor_locator(self):
        self.ax.xaxis.set_minor_locator(ticker.AutoMinorLocator())

    def test_yaxis_set_minor_locator(self):
        self.ax.yaxis.set_minor_locator(ticker.AutoMinorLocator(4))

    def test_minorticks_on(self):
        self.ax.minorticks_on()

    def test_minorticks_off(self):
        self.ax.minorticks_off()

    def test_tick_params_combined(self):
        self.ax.tick_params(
            axis='x',
            which='major',
            direction='in',
            length=6,
            width=1.5,
            labelsize=12,
            labelcolor='black',
            pad=5,
        )
