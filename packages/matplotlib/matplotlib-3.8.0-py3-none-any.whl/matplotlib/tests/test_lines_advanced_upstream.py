"""Tests for advanced Line2D and plot features."""

import pytest
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.lines as mlines


class TestLine2DCreation:
    def test_line2d_basic(self):
        """Line2D() does not raise."""
        line = mlines.Line2D([0, 1], [0, 1])
        assert line is not None

    def test_line2d_with_style(self):
        """Line2D with linestyle, color, linewidth does not raise."""
        line = mlines.Line2D([0, 1], [0, 1], linestyle='--', color='red',
                              linewidth=2.0)
        assert line.get_color() == 'red' or line.get_color() is not None

    def test_line2d_marker(self):
        """Line2D with marker does not raise."""
        line = mlines.Line2D([0, 1, 2], [0, 1, 0], marker='o', markersize=8)
        assert line is not None

    def test_line2d_add_to_axes(self):
        """Adding Line2D to axes does not raise."""
        fig, ax = plt.subplots()
        line = mlines.Line2D([0, 1], [0, 1], color='blue')
        ax.add_line(line)
        plt.close('all')

    def test_line2d_get_data(self):
        """Line2D.get_data() returns xdata, ydata."""
        line = mlines.Line2D([1, 2, 3], [4, 5, 6])
        xdata, ydata = line.get_data()
        assert list(xdata) == [1, 2, 3]
        assert list(ydata) == [4, 5, 6]

    def test_line2d_get_xdata(self):
        """Line2D.get_xdata() returns x values."""
        line = mlines.Line2D([1, 2, 3], [4, 5, 6])
        xdata = line.get_xdata()
        assert list(xdata) == [1, 2, 3]

    def test_line2d_get_ydata(self):
        """Line2D.get_ydata() returns y values."""
        line = mlines.Line2D([1, 2, 3], [4, 5, 6])
        ydata = line.get_ydata()
        assert list(ydata) == [4, 5, 6]

    def test_line2d_set_data(self):
        """Line2D.set_data() updates data."""
        line = mlines.Line2D([1, 2], [1, 2])
        line.set_data([3, 4, 5], [6, 7, 8])
        xdata, ydata = line.get_data()
        assert list(xdata) == [3, 4, 5]

    def test_line2d_set_color(self):
        """Line2D.set_color() updates color."""
        line = mlines.Line2D([0, 1], [0, 1])
        line.set_color('green')
        # Should not raise

    def test_line2d_get_linestyle(self):
        """Line2D.get_linestyle() returns linestyle."""
        line = mlines.Line2D([0, 1], [0, 1], linestyle='--')
        ls = line.get_linestyle()
        assert ls is not None

    def test_line2d_alpha(self):
        """Line2D with alpha does not raise."""
        line = mlines.Line2D([0, 1], [0, 1], alpha=0.5)
        assert line.get_alpha() == 0.5

    def test_line2d_zorder(self):
        """Line2D with zorder does not raise."""
        line = mlines.Line2D([0, 1], [0, 1], zorder=10)
        assert line.get_zorder() == 10


class TestPlotStyles:
    def test_plot_linestyle_variations(self):
        """Various linestyles do not raise."""
        fig, ax = plt.subplots()
        styles = ['-', '--', '-.', ':', 'solid', 'dashed', 'dashdot', 'dotted']
        for style in styles:
            ax.plot([1, 2, 3], linestyle=style)
        plt.close('all')

    def test_plot_marker_variations(self):
        """Various markers do not raise."""
        fig, ax = plt.subplots()
        markers = ['o', 's', '^', 'v', '<', '>', 'D', 'd', 'p', '*', '+', 'x', '.', ',']
        for m in markers:
            ax.plot([1, 2, 3], marker=m)
        plt.close('all')

    def test_plot_color_cycle(self):
        """Multiple plots use color cycle."""
        fig, ax = plt.subplots()
        lines = [ax.plot([1, 2, 3], [i, i+1, i+2]) for i in range(5)]
        assert len(lines) == 5
        plt.close('all')

    def test_plot_format_string_with_color(self):
        """Format strings with color are parsed correctly."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], 'r-')   # red solid
        ax.plot([1, 2, 3], 'b--')  # blue dashed
        ax.plot([1, 2, 3], 'g.')   # green dots
        plt.close('all')

    def test_plot_with_label(self):
        """plot() with label for legend works."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], label='series 1')
        ax.plot([3, 2, 1], label='series 2')
        ax.legend()
        plt.close('all')

    def test_plot_returns_list(self):
        """ax.plot() returns a list of Line2D."""
        fig, ax = plt.subplots()
        lines = ax.plot([1, 2, 3], [4, 5, 6])
        assert isinstance(lines, list)
        assert len(lines) == 1
        plt.close('all')

    def test_ax_lines_attribute(self):
        """ax.lines contains plotted lines."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3])
        ax.plot([3, 2, 1])
        assert len(ax.lines) == 2
        plt.close('all')

    def test_ax_get_lines(self):
        """ax.get_lines() returns lines."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3])
        lines = ax.get_lines()
        assert len(lines) == 1
        plt.close('all')


class TestMultiplePlots:
    def test_multiple_plots_different_styles(self):
        """Multiple plots with different styles on same axes."""
        fig, ax = plt.subplots()
        x = np.linspace(0, 2 * np.pi, 50)
        ax.plot(x, np.sin(x), 'b-', label='sin')
        ax.plot(x, np.cos(x), 'r--', label='cos')
        ax.plot(x, np.sin(2*x), 'g:', label='sin(2x)')
        ax.legend()
        plt.close('all')

    def test_plot_numpy_sequence(self):
        """plot() with numpy linspace does not raise."""
        fig, ax = plt.subplots()
        x = np.linspace(-np.pi, np.pi, 100)
        y = np.sin(x)
        ax.plot(x, y)
        plt.close('all')

    def test_plot_set_xlim_ylim(self):
        """set_xlim/set_ylim after plotting works."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 4, 2])
        ax.set_xlim(0, 4)
        ax.set_ylim(-1, 5)
        assert ax.get_xlim() == (0, 4)
        assert ax.get_ylim() == (-1, 5)
        plt.close('all')
