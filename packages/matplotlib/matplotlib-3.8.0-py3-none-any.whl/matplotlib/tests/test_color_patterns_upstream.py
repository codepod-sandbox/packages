"""
Upstream tests for color specification and manipulation patterns commonly used by LLMs.
"""

import pytest
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors


class TestColorSpecification:
    """Tests for various color specification methods."""

    def teardown_method(self):
        plt.close('all')

    def test_named_color(self):
        fig, ax = plt.subplots()
        l, = ax.plot([1, 2, 3], color='blue')
        assert l.get_color() is not None

    def test_hex_color(self):
        fig, ax = plt.subplots()
        l, = ax.plot([1, 2, 3], color='#3498db')
        assert l.get_color().lower() == '#3498db'

    def test_short_hex_color(self):
        fig, ax = plt.subplots()
        l, = ax.plot([1, 2, 3], color='#f00')
        assert l.get_color() is not None

    def test_rgb_tuple(self):
        fig, ax = plt.subplots()
        l, = ax.plot([1, 2, 3], color=(0.2, 0.6, 0.8))
        assert l.get_color() is not None

    def test_rgba_tuple(self):
        fig, ax = plt.subplots()
        l, = ax.plot([1, 2, 3], color=(0.2, 0.6, 0.8, 0.5))
        assert l.get_color() is not None

    def test_css4_colors(self):
        """Test common CSS4 named colors."""
        colors = ['steelblue', 'tomato', 'forestgreen', 'goldenrod', 'mediumpurple']
        fig, ax = plt.subplots()
        for i, c in enumerate(colors):
            ax.plot([i], [i], 'o', color=c)

    def test_tableau_colors(self):
        """Test tableau color shorthand (C0, C1, etc.)."""
        fig, ax = plt.subplots()
        for i in range(5):
            ax.plot([i, i+1], [i, i+1], color=f'C{i}')

    def test_grayscale_string(self):
        """String floats for grayscale ('0.5', '0.8')."""
        fig, ax = plt.subplots()
        l, = ax.plot([1, 2, 3], color='0.5')
        assert l.get_color() is not None

    def test_color_x_notation(self):
        """'xkcd:...' color name."""
        # xkcd colors may not be in our impl; just test basic named
        fig, ax = plt.subplots()
        l, = ax.plot([1, 2], color='navy')
        assert l.get_color() is not None

    def test_facecolor_edgecolor_scatter(self):
        fig, ax = plt.subplots()
        ax.scatter([1, 2, 3], [1, 2, 3],
                   facecolor='white', edgecolors='black', s=100)

    def test_bar_color_list(self):
        """Different color per bar using list."""
        fig, ax = plt.subplots()
        colors = ['red', 'green', 'blue', 'orange', 'purple']
        ax.bar(range(5), [3, 5, 2, 4, 6], color=colors)

    def test_alpha_in_color(self):
        fig, ax = plt.subplots()
        ax.fill_between([0, 1, 2], [0, 1, 0], color='blue', alpha=0.3)


class TestColorConversion:
    """Tests for color conversion utilities."""

    def test_to_rgb(self):
        rgb = mcolors.to_rgb('blue')
        assert len(rgb) == 3
        assert rgb == (0.0, 0.0, 1.0)

    def test_to_rgba(self):
        rgba = mcolors.to_rgba('red')
        assert len(rgba) == 4
        assert rgba[3] == 1.0

    def test_to_rgba_with_alpha(self):
        rgba = mcolors.to_rgba('green', alpha=0.5)
        assert rgba[3] == 0.5

    def test_to_hex(self):
        hex_color = mcolors.to_hex('blue')
        assert hex_color.startswith('#')
        assert len(hex_color) == 7

    def test_to_hex_from_tuple(self):
        hex_color = mcolors.to_hex((1.0, 0.0, 0.0))
        assert hex_color.lower() == '#ff0000'

    def test_is_color_like_true(self):
        assert mcolors.is_color_like('blue')
        assert mcolors.is_color_like('#ff0000')
        assert mcolors.is_color_like((0.5, 0.5, 0.5))

    def test_is_color_like_false(self):
        assert not mcolors.is_color_like('notacolor')

    def test_normalize_basic(self):
        norm = mcolors.Normalize(vmin=0, vmax=10)
        assert norm(5) == 0.5

    def test_normalize_clip(self):
        norm = mcolors.Normalize(vmin=0, vmax=10, clip=True)
        assert norm(15) == 1.0
        assert norm(-5) == 0.0

    def test_lognorm(self):
        norm = mcolors.LogNorm(vmin=1, vmax=100)
        val = norm(10)
        assert 0.0 < val < 1.0

    def test_boundary_norm(self):
        bounds = [0, 1, 2, 5, 10]
        norm = mcolors.BoundaryNorm(bounds, ncolors=4)
        assert norm is not None

    def test_two_slope_norm(self):
        norm = mcolors.TwoSlopeNorm(vmin=-5, vcenter=0, vmax=10)
        assert norm(0) == 0.5


class TestColormapOperations:
    """Tests for colormap operations."""

    def teardown_method(self):
        plt.close('all')

    def test_get_cmap_viridis(self):
        cmap = plt.get_cmap('viridis')
        assert cmap is not None

    def test_cmap_call_single(self):
        cmap = plt.get_cmap('viridis')
        color = cmap(0.5)
        assert len(color) == 4  # RGBA

    def test_cmap_call_array(self):
        cmap = plt.get_cmap('plasma')
        values = np.linspace(0, 1, 10)
        colors = cmap(values)
        assert colors.shape == (10, 4)

    def test_cmap_reversed(self):
        cmap = plt.get_cmap('viridis_r')
        assert cmap is not None

    def test_cmap_with_norm(self):
        """Apply colormap with custom norm."""
        cmap = plt.get_cmap('coolwarm')
        norm = mcolors.Normalize(vmin=-1, vmax=1)
        data = np.array([-0.5, 0, 0.5])
        colors = [cmap(norm(v)) for v in data]
        assert len(colors) == 3

    def test_listed_colormap(self):
        """Create a ListedColormap."""
        colors = ['red', 'green', 'blue', 'yellow']
        cmap = mcolors.ListedColormap(colors)
        assert cmap is not None

    def test_linear_segmented_colormap(self):
        """Create a LinearSegmentedColormap."""
        cdict = {
            'red': [(0, 0, 0), (1, 1, 1)],
            'green': [(0, 0, 0), (1, 0, 0)],
            'blue': [(0, 1, 1), (1, 0, 0)],
        }
        cmap = mcolors.LinearSegmentedColormap('my_cmap', cdict)
        assert cmap is not None
