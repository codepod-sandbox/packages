"""Tests for matplotlib.table — Table creation."""

import pytest
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.table as mtable
from matplotlib.table import Table


class TestTableBasic:
    def test_table_from_ax(self):
        """ax.table() does not raise."""
        fig, ax = plt.subplots()
        data = [[1, 2], [3, 4]]
        table = ax.table(cellText=data, loc='bottom')
        assert table is not None
        plt.close('all')

    def test_table_with_col_labels(self):
        """ax.table() with colLabels does not raise."""
        fig, ax = plt.subplots()
        data = [[1, 2], [3, 4]]
        table = ax.table(cellText=data, colLabels=['A', 'B'], loc='bottom')
        assert table is not None
        plt.close('all')

    def test_table_with_row_labels(self):
        """ax.table() with rowLabels does not raise."""
        fig, ax = plt.subplots()
        data = [[1, 2], [3, 4]]
        table = ax.table(cellText=data, rowLabels=['r1', 'r2'], loc='center')
        assert table is not None
        plt.close('all')

    def test_table_with_all_labels(self):
        """ax.table() with both rowLabels and colLabels does not raise."""
        fig, ax = plt.subplots()
        data = [[10, 20, 30], [40, 50, 60]]
        table = ax.table(
            cellText=data,
            rowLabels=['Row 1', 'Row 2'],
            colLabels=['A', 'B', 'C'],
            loc='bottom'
        )
        assert table is not None
        plt.close('all')

    def test_table_returns_table_object(self):
        """ax.table() returns a Table instance."""
        fig, ax = plt.subplots()
        data = [[1, 2]]
        table = ax.table(cellText=data, loc='bottom')
        assert isinstance(table, Table)
        plt.close('all')

    def test_table_auto_set_column_width(self):
        """Table.auto_set_column_width() does not raise."""
        fig, ax = plt.subplots()
        data = [['alpha', 'beta'], ['gamma', 'delta']]
        table = ax.table(cellText=data, loc='bottom')
        table.auto_set_column_width([0, 1])
        plt.close('all')

    def test_table_set_fontsize(self):
        """Table.auto_set_font_size() does not raise."""
        fig, ax = plt.subplots()
        data = [[1, 2], [3, 4]]
        table = ax.table(cellText=data, loc='bottom')
        table.auto_set_font_size(False)
        table.set_fontsize(12)
        plt.close('all')

    def test_table_scale(self):
        """Table.scale() does not raise."""
        fig, ax = plt.subplots()
        data = [[1, 2], [3, 4]]
        table = ax.table(cellText=data, loc='bottom')
        table.scale(1, 1.5)
        plt.close('all')

    def test_table_loc_options(self):
        """ax.table() with various loc options does not raise."""
        for loc in ['top', 'bottom', 'center', 'right', 'left', 'best']:
            fig, ax = plt.subplots()
            table = ax.table(cellText=[[1, 2]], loc=loc)
            assert table is not None
            plt.close('all')

    def test_table_cell_access(self):
        """Table cells are accessible via table[row, col]."""
        fig, ax = plt.subplots()
        data = [[1, 2], [3, 4]]
        table = ax.table(cellText=data, loc='bottom')
        # Cells indexed as (row+1, col) due to header row offset
        cell = table[1, 0]
        assert cell is not None
        plt.close('all')

    def test_table_svg(self):
        """Figure with table renders to SVG."""
        fig, ax = plt.subplots()
        ax.axis('off')
        data = [['A', 'B'], ['1', '2']]
        table = ax.table(cellText=data, colLabels=['X', 'Y'], loc='center')
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')


class TestTableModule:
    def test_table_module_importable(self):
        """matplotlib.table is importable."""
        import matplotlib.table as t
        assert t is not None

    def test_Table_class_importable(self):
        """matplotlib.table.Table is importable."""
        from matplotlib.table import Table
        assert Table is not None

    def test_plt_table(self):
        """plt.table() does not raise."""
        fig, ax = plt.subplots()
        data = [['a', 'b'], ['c', 'd']]
        try:
            table = plt.table(cellText=data, loc='bottom')
            assert table is not None
        except AttributeError:
            pytest.skip("plt.table not yet exposed")
        plt.close('all')
