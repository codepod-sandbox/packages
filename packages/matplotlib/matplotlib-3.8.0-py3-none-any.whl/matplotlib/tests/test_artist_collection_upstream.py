"""
Upstream tests for artist properties and collections used in common LLM patterns.
"""

import numpy as np
import pytest
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.collections as mcollections
from matplotlib.lines import Line2D


class TestLine2DProperties:
    def teardown_method(self):
        plt.close('all')

    def test_line2d_standalone(self):
        line = Line2D([0, 1, 2], [0, 1, 0])
        assert line.get_xdata() == [0, 1, 2]

    def test_line2d_color(self):
        line = Line2D([0, 1], [0, 1], color='red')
        assert line.get_color() == 'red'

    def test_line2d_linewidth(self):
        line = Line2D([0, 1], [0, 1], linewidth=2.5)
        assert line.get_linewidth() == 2.5

    def test_line2d_linestyle(self):
        line = Line2D([0, 1], [0, 1], linestyle='--')
        assert line.get_linestyle() == '--'

    def test_line2d_marker(self):
        line = Line2D([0, 1], [0, 1], marker='o')
        assert line.get_marker() == 'o'

    def test_line2d_markersize(self):
        line = Line2D([0, 1], [0, 1], markersize=8)
        assert line.get_markersize() == 8

    def test_line2d_alpha(self):
        line = Line2D([0, 1], [0, 1], alpha=0.5)
        assert line.get_alpha() == 0.5

    def test_line2d_label(self):
        line = Line2D([0, 1], [0, 1], label='my line')
        assert line.get_label() == 'my line'

    def test_line2d_zorder(self):
        line = Line2D([0, 1], [0, 1], zorder=5)
        assert line.get_zorder() == 5

    def test_line2d_set_data(self):
        line = Line2D([0, 1], [0, 1])
        line.set_xdata([0, 2])
        line.set_ydata([0, 4])
        assert line.get_xdata() == [0, 2]
        assert line.get_ydata() == [0, 4]

    def test_line2d_set_color(self):
        line = Line2D([0, 1], [0, 1])
        line.set_color('blue')
        assert line.get_color() == 'blue'

    def test_line2d_visible(self):
        line = Line2D([0, 1], [0, 1])
        assert line.get_visible() is True
        line.set_visible(False)
        assert line.get_visible() is False

    def test_plot_returns_lines(self):
        fig, ax = plt.subplots()
        lines = ax.plot([1, 2, 3], [4, 5, 6])
        assert len(lines) == 1
        assert isinstance(lines[0], Line2D)

    def test_plot_line_access(self):
        fig, ax = plt.subplots()
        lines = ax.plot([1, 2], [3, 4], 'r-', linewidth=2)
        line = lines[0]
        # color may be stored as hex '#ff0000' or 'r'
        color = line.get_color()
        assert color in ('r', '#ff0000', 'red') or str(color).startswith('#')
        assert line.get_linewidth() == 2


class TestPatchProperties:
    def teardown_method(self):
        plt.close('all')

    def test_rectangle_basic(self):
        fig, ax = plt.subplots()
        rect = mpatches.Rectangle((0, 0), 1, 1)
        ax.add_patch(rect)

    def test_rectangle_facecolor(self):
        rect = mpatches.Rectangle((0, 0), 1, 1, facecolor='blue')
        assert rect.get_facecolor() is not None

    def test_rectangle_edgecolor(self):
        rect = mpatches.Rectangle((0, 0), 1, 1, edgecolor='black')
        assert rect.get_edgecolor() is not None

    def test_rectangle_linewidth(self):
        rect = mpatches.Rectangle((0, 0), 1, 1, linewidth=2)
        assert rect.get_linewidth() == 2

    def test_rectangle_alpha(self):
        rect = mpatches.Rectangle((0, 0), 1, 1, alpha=0.5)
        assert rect.get_alpha() == 0.5

    def test_circle_basic(self):
        fig, ax = plt.subplots()
        circ = mpatches.Circle((0.5, 0.5), 0.3)
        ax.add_patch(circ)

    def test_circle_radius(self):
        circ = mpatches.Circle((0, 0), 0.5)
        assert circ.get_radius() == 0.5

    def test_ellipse_basic(self):
        fig, ax = plt.subplots()
        ell = mpatches.Ellipse((0.5, 0.5), 0.4, 0.2)
        ax.add_patch(ell)

    def test_arrow_basic(self):
        fig, ax = plt.subplots()
        arrow = mpatches.Arrow(0, 0, 0.5, 0.5)
        ax.add_patch(arrow)

    def test_fancy_arrowpatch(self):
        fig, ax = plt.subplots()
        patch = mpatches.FancyArrowPatch(
            (0, 0), (1, 1), arrowstyle='->', linewidth=1.5
        )
        ax.add_patch(patch)

    def test_polygon_basic(self):
        fig, ax = plt.subplots()
        poly = mpatches.Polygon([[0, 0], [1, 0], [0.5, 1]])
        ax.add_patch(poly)

    def test_wedge_basic(self):
        fig, ax = plt.subplots()
        wedge = mpatches.Wedge((0.5, 0.5), 0.3, 0, 90)
        ax.add_patch(wedge)

    def test_patch_visible(self):
        rect = mpatches.Rectangle((0, 0), 1, 1)
        assert rect.get_visible() is True
        rect.set_visible(False)
        assert rect.get_visible() is False

    def test_patch_zorder(self):
        rect = mpatches.Rectangle((0, 0), 1, 1)
        rect.set_zorder(3)
        assert rect.get_zorder() == 3

    def test_patch_label(self):
        rect = mpatches.Rectangle((0, 0), 1, 1, label='box')
        assert rect.get_label() == 'box'


class TestCollectionProperties:
    def teardown_method(self):
        plt.close('all')

    def test_scatter_returns_pathcollection(self):
        fig, ax = plt.subplots()
        sc = ax.scatter([1, 2, 3], [4, 5, 6])
        assert hasattr(sc, 'get_offsets')

    def test_scatter_get_offsets(self):
        fig, ax = plt.subplots()
        sc = ax.scatter([1, 2], [3, 4])
        offsets = sc.get_offsets()
        assert len(offsets) == 2

    def test_scatter_get_facecolor(self):
        fig, ax = plt.subplots()
        sc = ax.scatter([1, 2], [3, 4], c='blue')
        fc = sc.get_facecolor()
        assert fc is not None

    def test_scatter_set_alpha(self):
        fig, ax = plt.subplots()
        sc = ax.scatter([1, 2], [3, 4])
        sc.set_alpha(0.5)
        assert sc.get_alpha() == 0.5

    def test_scatter_set_visible(self):
        fig, ax = plt.subplots()
        sc = ax.scatter([1, 2], [3, 4])
        sc.set_visible(False)
        assert sc.get_visible() is False

    def test_scatter_zorder(self):
        fig, ax = plt.subplots()
        sc = ax.scatter([1, 2], [3, 4], zorder=3)
        assert sc.get_zorder() == 3

    def test_line_collection_basic(self):
        fig, ax = plt.subplots()
        segments = [[[0, 0], [1, 1]], [[2, 0], [3, 1]]]
        lc = mcollections.LineCollection(segments)
        ax.add_collection(lc)

    def test_poly_collection_basic(self):
        fig, ax = plt.subplots()
        verts = [[[0, 0], [1, 0], [0.5, 1]]]
        pc = mcollections.PolyCollection(verts)
        ax.add_collection(pc)
