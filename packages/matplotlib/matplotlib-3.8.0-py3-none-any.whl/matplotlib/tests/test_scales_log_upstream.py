"""Tests for log scale and related patterns."""

import pytest
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker


class TestLogScale:
    def test_set_xscale_log(self):
        """set_xscale('log')."""
        fig, ax = plt.subplots()
        ax.plot([1, 10, 100, 1000], [1, 2, 3, 4])
        ax.set_xscale('log')
        plt.close('all')

    def test_set_yscale_log(self):
        """set_yscale('log')."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3, 4], [1, 10, 100, 1000])
        ax.set_yscale('log')
        plt.close('all')

    def test_loglog(self):
        """loglog plot."""
        fig, ax = plt.subplots()
        ax.loglog([1, 10, 100], [1, 100, 10000])
        plt.close('all')

    def test_semilogx(self):
        """semilogx plot."""
        fig, ax = plt.subplots()
        ax.semilogx([1, 10, 100, 1000], [4, 3, 2, 1])
        plt.close('all')

    def test_semilogy(self):
        """semilogy plot."""
        fig, ax = plt.subplots()
        ax.semilogy([1, 2, 3, 4], [10, 100, 1000, 10000])
        plt.close('all')

    def test_log_axis_positive_values(self):
        """Log scale requires positive values."""
        fig, ax = plt.subplots()
        ax.plot([0.1, 1.0, 10.0, 100.0], [1, 4, 9, 16])
        ax.set_xscale('log')
        plt.close('all')

    def test_log_scale_with_grid(self):
        """Log scale with grid."""
        fig, ax = plt.subplots()
        ax.plot([1, 10, 100, 1000], [1, 2, 3, 4])
        ax.set_xscale('log')
        ax.grid(True, which='both')
        plt.close('all')

    def test_log_scale_labels(self):
        """Log scale with formatter."""
        fig, ax = plt.subplots()
        ax.plot([1, 10, 100, 1000], [1, 2, 3, 4])
        ax.set_xscale('log')
        ax.xaxis.set_major_formatter(mticker.LogFormatter())
        plt.close('all')

    def test_logscale_power_of_10(self):
        """Log scale with powers of 10."""
        fig, ax = plt.subplots()
        x = [10.0 ** i for i in range(5)]
        y = list(range(5))
        ax.plot(x, y)
        ax.set_xscale('log')
        ax.set_xlim(1, 1e4)
        plt.close('all')

    def test_both_log(self):
        """Both axes log scale."""
        fig, ax = plt.subplots()
        ax.plot([1, 10, 100], [0.1, 1, 10])
        ax.set_xscale('log')
        ax.set_yscale('log')
        plt.close('all')

    def test_log_scatter(self):
        """Scatter on log scale."""
        fig, ax = plt.subplots()
        x = [1.0, 10.0, 100.0, 1000.0]
        y = [1.0, 2.0, 3.0, 4.0]
        ax.scatter(x, y)
        ax.set_xscale('log')
        plt.close('all')

    def test_log_bar(self):
        """Bar chart on log scale."""
        fig, ax = plt.subplots()
        ax.bar(['A', 'B', 'C'], [10, 100, 1000])
        ax.set_yscale('log')
        plt.close('all')

    def test_log_symlog(self):
        """Symlog scale for data with both positive and negative values."""
        fig, ax = plt.subplots()
        ax.plot([-100, -10, -1, 0, 1, 10, 100], [1, 2, 3, 4, 5, 6, 7])
        ax.set_xscale('symlog')
        plt.close('all')


class TestLinearScale:
    def test_linear_scale_default(self):
        """Default linear scale."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3, 4], [1, 2, 3, 4])
        ax.set_xscale('linear')
        ax.set_yscale('linear')
        plt.close('all')

    def test_xlim_ylim(self):
        """Setting axis limits."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3])
        ax.set_xlim(0, 5)
        ax.set_ylim(-1, 4)
        assert ax.get_xlim() == (0, 5)
        assert ax.get_ylim() == (-1, 4)
        plt.close('all')

    def test_axis_equal(self):
        """Equal aspect ratio."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        ax.set_aspect('equal')
        plt.close('all')

    def test_axis_square(self):
        """Square aspect ratio."""
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        ax.axis('square')
        plt.close('all')

    def test_axis_tight(self):
        """Tight axis."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3, 4, 5], [1, 4, 9, 16, 25])
        ax.axis('tight')
        plt.close('all')

    def test_axis_off(self):
        """Turn off axis."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 2, 3])
        ax.axis('off')
        plt.close('all')


class TestPolarPatterns:
    def test_polar_basic(self):
        """Basic polar plot."""
        fig, ax = plt.subplots(subplot_kw={'projection': 'polar'})
        theta = [0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0]
        r = [1.0, 2.0, 1.5, 3.0, 2.5, 2.0, 1.0]
        ax.plot(theta, r)
        plt.close('all')

    def test_polar_scatter(self):
        """Scatter on polar axes."""
        fig, ax = plt.subplots(subplot_kw={'projection': 'polar'})
        theta = [0.0, 1.0, 2.0, 3.0, 4.0, 5.0]
        r = [1.0, 2.0, 1.5, 3.0, 2.5, 2.0]
        ax.scatter(theta, r)
        plt.close('all')

    def test_polar_fill(self):
        """Fill on polar axes."""
        fig, ax = plt.subplots(subplot_kw={'projection': 'polar'})
        theta = [0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0]
        r = [1.0, 2.0, 1.5, 3.0, 2.5, 2.0, 1.0]
        ax.fill(theta, r, alpha=0.3)
        plt.close('all')

    def test_polar_bar(self):
        """Bar chart on polar axes."""
        import math
        fig, ax = plt.subplots(subplot_kw={'projection': 'polar'})
        N = 6
        theta = [2 * math.pi * i / N for i in range(N)]
        r = [1.0, 2.0, 1.5, 3.0, 2.5, 2.0]
        ax.bar(theta, r, width=2 * math.pi / N, alpha=0.5)
        plt.close('all')

    def test_polar_set_rticks(self):
        """Set r-ticks on polar plot."""
        fig, ax = plt.subplots(subplot_kw={'projection': 'polar'})
        theta = [0.0, 1.0, 2.0, 3.0]
        ax.plot(theta, [1.0, 2.0, 1.0, 2.0])
        ax.set_rticks([0.5, 1.0, 1.5, 2.0])
        plt.close('all')

    def test_polar_set_theta_zero_location(self):
        """Set theta zero location."""
        fig, ax = plt.subplots(subplot_kw={'projection': 'polar'})
        ax.plot([0.0, 1.0, 2.0], [1.0, 2.0, 1.0])
        ax.set_theta_zero_location('N')
        plt.close('all')

    def test_polar_set_theta_direction(self):
        """Set theta direction."""
        fig, ax = plt.subplots(subplot_kw={'projection': 'polar'})
        ax.plot([0.0, 1.0, 2.0], [1.0, 2.0, 1.0])
        ax.set_theta_direction(-1)
        plt.close('all')
