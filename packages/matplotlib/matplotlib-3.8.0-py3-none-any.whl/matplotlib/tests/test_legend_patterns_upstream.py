"""
Upstream tests for legend patterns commonly used by LLMs.
"""

import numpy as np
import pytest
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.lines import Line2D


class TestLegendBasic:
    """Basic legend patterns."""

    def teardown_method(self):
        plt.close('all')

    def test_legend_from_labels(self):
        fig, ax = plt.subplots()
        ax.plot([1, 2], label='Line 1')
        ax.plot([2, 1], label='Line 2')
        leg = ax.legend()
        assert leg is not None

    def test_legend_explicit_handles_labels(self):
        fig, ax = plt.subplots()
        line1, = ax.plot([1, 2])
        line2, = ax.plot([2, 1])
        leg = ax.legend([line1, line2], ['A', 'B'])
        assert leg is not None

    def test_legend_loc_string(self):
        fig, ax = plt.subplots()
        ax.plot([1, 2], label='data')
        for loc in ['best', 'upper right', 'upper left', 'lower left',
                    'lower right', 'center', 'upper center', 'lower center']:
            ax.legend(loc=loc)

    def test_legend_loc_integer(self):
        fig, ax = plt.subplots()
        ax.plot([1, 2], label='data')
        for loc in [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]:
            ax.legend(loc=loc)

    def test_legend_title(self):
        fig, ax = plt.subplots()
        ax.plot([1, 2], label='data')
        leg = ax.legend(title='Legend Title')
        assert leg.get_title().get_text() == 'Legend Title'

    def test_legend_fontsize(self):
        fig, ax = plt.subplots()
        ax.plot([1, 2], label='data')
        ax.legend(fontsize=10)

    def test_legend_ncol(self):
        fig, ax = plt.subplots()
        for i in range(4):
            ax.plot([1, 2], label=f'item {i}')
        ax.legend(ncol=2)

    def test_legend_frameon(self):
        fig, ax = plt.subplots()
        ax.plot([1, 2], label='data')
        ax.legend(frameon=True)
        ax.legend(frameon=False)

    def test_legend_framealpha(self):
        fig, ax = plt.subplots()
        ax.plot([1, 2], label='data')
        ax.legend(framealpha=0.5)

    def test_legend_edgecolor(self):
        fig, ax = plt.subplots()
        ax.plot([1, 2], label='data')
        ax.legend(edgecolor='black')

    def test_legend_facecolor(self):
        fig, ax = plt.subplots()
        ax.plot([1, 2], label='data')
        ax.legend(facecolor='lightyellow')

    def test_legend_bbox_to_anchor(self):
        fig, ax = plt.subplots()
        ax.plot([1, 2], label='data')
        ax.legend(bbox_to_anchor=(1.05, 1), loc='upper left')

    def test_legend_outside_axes(self):
        fig, ax = plt.subplots()
        ax.plot([1, 2], label='A')
        ax.plot([2, 1], label='B')
        ax.legend(bbox_to_anchor=(1.04, 1), loc='upper left', borderaxespad=0)
        plt.tight_layout()

    def test_legend_handlelength(self):
        fig, ax = plt.subplots()
        ax.plot([1, 2], label='data')
        ax.legend(handlelength=3)

    def test_legend_handletextpad(self):
        fig, ax = plt.subplots()
        ax.plot([1, 2], label='data')
        ax.legend(handletextpad=1.5)

    def test_legend_borderpad(self):
        fig, ax = plt.subplots()
        ax.plot([1, 2], label='data')
        ax.legend(borderpad=1.0)

    def test_legend_labelspacing(self):
        fig, ax = plt.subplots()
        ax.plot([1, 2], label='A')
        ax.plot([2, 1], label='B')
        ax.legend(labelspacing=1.0)

    def test_legend_markerscale(self):
        fig, ax = plt.subplots()
        ax.scatter([1, 2], [3, 4], label='scatter')
        ax.legend(markerscale=2.0)


class TestLegendCustomHandles:
    """Tests for custom legend handles."""

    def teardown_method(self):
        plt.close('all')

    def test_custom_patch_handles(self):
        fig, ax = plt.subplots()
        red_patch = mpatches.Patch(color='red', label='Red')
        blue_patch = mpatches.Patch(color='blue', label='Blue')
        ax.legend(handles=[red_patch, blue_patch])

    def test_custom_line_handles(self):
        fig, ax = plt.subplots()
        solid = Line2D([0], [0], color='blue', lw=2, label='Solid')
        dashed = Line2D([0], [0], color='red', lw=2, linestyle='--', label='Dashed')
        ax.legend(handles=[solid, dashed])

    def test_custom_marker_handles(self):
        fig, ax = plt.subplots()
        handle = Line2D([0], [0], marker='o', color='w', markerfacecolor='blue',
                       markersize=8, label='Marker')
        ax.legend(handles=[handle])

    def test_legend_scatter_with_colors(self):
        fig, ax = plt.subplots()
        sc1 = ax.scatter([1], [1], c='blue', label='Group A')
        sc2 = ax.scatter([2], [2], c='red', label='Group B')
        ax.legend()

    def test_legend_mixed_artists(self):
        fig, ax = plt.subplots()
        ax.plot([1, 2], 'b-', label='line')
        ax.scatter([1, 2], [3, 4], c='r', label='scatter')
        ax.bar([1, 2], [5, 6], alpha=0.5, label='bar')
        ax.legend()

    def test_figlegend(self):
        fig, (ax1, ax2) = plt.subplots(1, 2)
        l1, = ax1.plot([1, 2], label='A')
        l2, = ax2.plot([2, 1], label='B')
        fig.legend(handles=[l1, l2], loc='upper center')


class TestLegendAccess:
    """Tests for accessing legend objects."""

    def teardown_method(self):
        plt.close('all')

    def test_get_legend(self):
        fig, ax = plt.subplots()
        ax.plot([1, 2], label='data')
        ax.legend()
        leg = ax.get_legend()
        assert leg is not None

    def test_get_legend_handles_labels(self):
        fig, ax = plt.subplots()
        ax.plot([1, 2], label='Line A')
        ax.scatter([1, 2], [3, 4], label='Scatter B')
        handles, labels = ax.get_legend_handles_labels()
        assert 'Line A' in labels
        assert 'Scatter B' in labels

    def test_legend_set_visible(self):
        fig, ax = plt.subplots()
        ax.plot([1, 2], label='data')
        leg = ax.legend()
        leg.set_visible(False)
        assert leg.get_visible() is False

    def test_legend_remove(self):
        fig, ax = plt.subplots()
        ax.plot([1, 2], label='data')
        leg = ax.legend()
        leg.remove()
        assert ax.get_legend() is None

    def test_legend_no_label_prefix(self):
        """Artists with labels starting with '_' are excluded from legend."""
        fig, ax = plt.subplots()
        ax.plot([1, 2], label='_hidden')
        ax.plot([2, 1], label='visible')
        handles, labels = ax.get_legend_handles_labels()
        assert 'visible' in labels
        assert '_hidden' not in labels
