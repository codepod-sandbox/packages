"""Tests for vector field plots and fill patterns."""

import pytest
import matplotlib.pyplot as plt


class TestQuiver:
    def test_quiver_basic(self):
        """Basic quiver plot."""
        fig, ax = plt.subplots()
        x = [0.0, 1.0, 2.0]
        y = [0.0, 1.0, 2.0]
        u = [1.0, 0.0, -1.0]
        v = [0.0, 1.0, 0.0]
        q = ax.quiver(x, y, u, v)
        assert q is not None
        plt.close('all')

    def test_quiver_with_color(self):
        """Quiver with color."""
        fig, ax = plt.subplots()
        x = [0.0, 1.0, 2.0, 3.0]
        y = [0.0, 1.0, 2.0, 3.0]
        u = [1.0, 0.0, -1.0, 0.0]
        v = [0.0, 1.0, 0.0, -1.0]
        q = ax.quiver(x, y, u, v, color='red')
        assert q is not None
        plt.close('all')

    def test_quiver_scale(self):
        """Quiver with scale."""
        fig, ax = plt.subplots()
        x = [0.0, 1.0, 2.0]
        y = [0.0, 1.0, 2.0]
        u = [1.0, 0.0, -1.0]
        v = [0.0, 1.0, 0.0]
        ax.quiver(x, y, u, v, scale=5)
        plt.close('all')

    def test_quiver_no_xy(self):
        """Quiver with just u, v (auto grid)."""
        fig, ax = plt.subplots()
        u = [[1.0, 0.0], [0.0, 1.0]]
        v = [[0.0, 1.0], [1.0, 0.0]]
        q = ax.quiver(u, v)
        assert q is not None
        plt.close('all')

    def test_quiver_angles(self):
        """Quiver with angles parameter."""
        fig, ax = plt.subplots()
        x = [0.0, 1.0, 2.0]
        y = [0.0, 1.0, 2.0]
        u = [1.0, 1.0, 1.0]
        v = [0.0, 1.0, 0.0]
        ax.quiver(x, y, u, v, angles='xy')
        plt.close('all')


class TestFillBetweenAdvanced:
    def test_fill_between_where(self):
        """fill_between with where condition."""
        fig, ax = plt.subplots()
        x = [0.0, 1.0, 2.0, 3.0, 4.0]
        y1 = [1.0, 2.0, 3.0, 2.0, 1.0]
        y2 = [0.5, 1.5, 2.5, 1.5, 0.5]
        ax.fill_between(x, y1, y2, where=[y > 0.5 for y in y1], alpha=0.3)
        plt.close('all')

    def test_fill_between_y2_zero(self):
        """fill_between with y2=0."""
        fig, ax = plt.subplots()
        x = [0.0, 1.0, 2.0, 3.0, 4.0]
        y1 = [1.0, 2.0, 3.0, 2.0, 1.0]
        ax.plot(x, y1)
        ax.fill_between(x, y1, 0, alpha=0.3)
        plt.close('all')

    def test_fill_between_color(self):
        """fill_between with color."""
        fig, ax = plt.subplots()
        x = [0.0, 1.0, 2.0, 3.0]
        ax.fill_between(x, [1.0, 2.0, 2.0, 1.0], [0.0, 0.5, 0.5, 0.0],
                        color='blue', alpha=0.5, label='Area')
        ax.legend()
        plt.close('all')

    def test_fill_between_step(self):
        """fill_between with step."""
        fig, ax = plt.subplots()
        x = [0.0, 1.0, 2.0, 3.0, 4.0]
        y1 = [1.0, 2.0, 1.0, 2.0, 1.0]
        ax.fill_between(x, y1, step='pre', alpha=0.3)
        plt.close('all')

    def test_fill_betweenx_basic(self):
        """fill_betweenx (horizontal fill)."""
        fig, ax = plt.subplots()
        y = [0.0, 1.0, 2.0, 3.0]
        x1 = [0.0, 1.0, 2.0, 1.0]
        x2 = [1.0, 2.0, 3.0, 2.0]
        ax.fill_betweenx(y, x1, x2, alpha=0.3)
        plt.close('all')

    def test_fill_polygon(self):
        """ax.fill with polygon."""
        fig, ax = plt.subplots()
        x = [0.0, 1.0, 1.0, 0.0]
        y = [0.0, 0.0, 1.0, 1.0]
        ax.fill(x, y, alpha=0.3, color='blue')
        plt.close('all')


class TestVlines:
    def test_vlines_basic(self):
        """Basic vlines."""
        fig, ax = plt.subplots()
        ax.vlines([1, 2, 3], 0, 1)
        plt.close('all')

    def test_vlines_ymin_ymax(self):
        """vlines with ymin/ymax arrays."""
        fig, ax = plt.subplots()
        ax.vlines([1, 2, 3], [0.1, 0.2, 0.3], [0.8, 0.7, 0.9])
        plt.close('all')

    def test_vlines_styled(self):
        """vlines with style."""
        fig, ax = plt.subplots()
        ax.vlines([1, 2], 0, 1, colors='red', linestyles='dashed', linewidth=2)
        plt.close('all')

    def test_hlines_basic(self):
        """Basic hlines."""
        fig, ax = plt.subplots()
        ax.hlines([1, 2, 3], 0, 4)
        plt.close('all')

    def test_hlines_styled(self):
        """hlines with style."""
        fig, ax = plt.subplots()
        ax.hlines([1.5, 2.5], 0, 4, colors=['blue', 'red'],
                  linestyles=['solid', 'dashed'])
        plt.close('all')


class TestErrorBars:
    def test_errorbar_basic(self):
        """Basic errorbar plot."""
        fig, ax = plt.subplots()
        x = [1, 2, 3, 4, 5]
        y = [2.0, 3.5, 2.5, 4.0, 3.0]
        yerr = [0.2, 0.3, 0.15, 0.4, 0.25]
        eb = ax.errorbar(x, y, yerr=yerr)
        assert eb is not None
        plt.close('all')

    def test_errorbar_xerr(self):
        """Errorbar with x errors."""
        fig, ax = plt.subplots()
        x = [1.0, 2.0, 3.0]
        y = [2.0, 3.0, 2.5]
        ax.errorbar(x, y, xerr=[0.1, 0.2, 0.15])
        plt.close('all')

    def test_errorbar_both(self):
        """Errorbar with both x and y errors."""
        fig, ax = plt.subplots()
        x = [1.0, 2.0, 3.0]
        y = [2.0, 3.0, 2.5]
        ax.errorbar(x, y, xerr=[0.1, 0.2, 0.15], yerr=[0.2, 0.3, 0.25])
        plt.close('all')

    def test_errorbar_capsize(self):
        """Errorbar with cap size."""
        fig, ax = plt.subplots()
        ax.errorbar([1, 2, 3], [2.0, 3.0, 2.5], yerr=[0.2, 0.3, 0.25],
                    capsize=5, fmt='o')
        plt.close('all')

    def test_errorbar_fmt(self):
        """Errorbar with format string."""
        fig, ax = plt.subplots()
        ax.errorbar([1, 2, 3], [2.0, 3.0, 2.5], yerr=[0.2, 0.3, 0.25],
                    fmt='r-o', label='Data')
        ax.legend()
        plt.close('all')

    def test_errorbar_asymmetric(self):
        """Errorbar with asymmetric errors."""
        fig, ax = plt.subplots()
        x = [1, 2, 3]
        y = [2.0, 3.0, 2.5]
        yerr = [[0.1, 0.2, 0.15], [0.3, 0.2, 0.4]]  # [lower, upper]
        ax.errorbar(x, y, yerr=yerr)
        plt.close('all')
