"""Tests for numpy array integration with matplotlib plots."""

import pytest
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors


# ---------------------------------------------------------------------------
# numpy arrays as plot inputs
# ---------------------------------------------------------------------------

class TestNumpyArrayInputs:
    def test_plot_numpy_array(self):
        """plot() accepts numpy arrays."""
        fig, ax = plt.subplots()
        x = np.linspace(0, 2 * np.pi, 100)
        y = np.sin(x)
        ax.plot(x, y)
        assert len(ax.lines) == 1
        plt.close('all')

    def test_plot_numpy_2d_grid(self):
        """Multiple plots from numpy columns do not raise."""
        fig, ax = plt.subplots()
        t = np.linspace(0, 1, 50)
        for freq in [1, 2, 3]:
            ax.plot(t, np.sin(2 * np.pi * freq * t))
        assert len(ax.lines) == 3
        plt.close('all')

    def test_scatter_numpy(self):
        """scatter with numpy arrays does not raise."""
        fig, ax = plt.subplots()
        rng = np.random.default_rng(42)
        x = rng.normal(0, 1, 50)
        y = rng.normal(0, 1, 50)
        ax.scatter(x.tolist(), y.tolist())
        plt.close('all')

    def test_bar_numpy(self):
        """bar with numpy array heights does not raise."""
        fig, ax = plt.subplots()
        x = np.arange(5)
        heights = np.array([3, 7, 2, 5, 8])
        ax.bar(x.tolist(), heights.tolist())
        plt.close('all')

    def test_imshow_numpy_2d(self):
        """imshow with numpy 2D array does not raise."""
        fig, ax = plt.subplots()
        data = np.random.default_rng(42).random((10, 10))
        ax.imshow(data.tolist())
        plt.close('all')

    def test_fill_between_numpy(self):
        """fill_between with numpy arrays does not raise."""
        fig, ax = plt.subplots()
        x = np.linspace(0, 2 * np.pi, 50)
        y1 = np.sin(x)
        y2 = np.cos(x)
        ax.fill_between(x.tolist(), y1.tolist(), y2.tolist(), alpha=0.3)
        plt.close('all')

    def test_hist_numpy(self):
        """hist with numpy array does not raise."""
        fig, ax = plt.subplots()
        rng = np.random.default_rng(42)
        data = rng.normal(0, 1, 100)
        ax.hist(data.tolist(), bins=20)
        plt.close('all')


# ---------------------------------------------------------------------------
# Meshgrid + contour
# ---------------------------------------------------------------------------

class TestMeshgridContour:
    def test_meshgrid_linspace(self):
        """contourf with meshgrid from linspace does not raise."""
        fig, ax = plt.subplots()
        x = np.linspace(-2, 2, 20)
        y = np.linspace(-2, 2, 20)
        X, Y = np.meshgrid(x, y)
        Z = X**2 + Y**2
        ax.contourf(x.tolist(), y.tolist(), Z.tolist())
        plt.close('all')

    def test_meshgrid_contour_svg(self):
        """Meshgrid contour renders to SVG."""
        fig, ax = plt.subplots()
        x = np.linspace(-1, 1, 10)
        y = np.linspace(-1, 1, 10)
        X, Y = np.meshgrid(x, y)
        Z = (X**2 + Y**2).tolist()
        ax.contourf(x.tolist(), y.tolist(), Z)
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_pcolormesh_meshgrid(self):
        """pcolormesh with meshgrid does not raise."""
        fig, ax = plt.subplots()
        x = np.linspace(0, 4, 5)
        y = np.linspace(0, 3, 4)
        X, Y = np.meshgrid(x, y)
        C = np.sin(X) + np.cos(Y)
        ax.pcolormesh(X.tolist(), Y.tolist(), C.tolist())
        plt.close('all')


# ---------------------------------------------------------------------------
# Plot with error bars (numpy-style)
# ---------------------------------------------------------------------------

class TestErrorbarNumpy:
    def test_errorbar_numpy_arrays(self):
        """errorbar with numpy arrays for yerr does not raise."""
        fig, ax = plt.subplots()
        x = np.arange(5)
        y = np.array([1, 2, 1.5, 3, 2.5])
        yerr = np.array([0.2, 0.3, 0.1, 0.4, 0.2])
        ax.errorbar(x.tolist(), y.tolist(), yerr=yerr.tolist())
        plt.close('all')

    def test_errorbar_both_xy_error(self):
        """errorbar with both xerr and yerr does not raise."""
        fig, ax = plt.subplots()
        x = [1, 2, 3]
        y = [1, 4, 9]
        ax.errorbar(x, y, xerr=[0.1, 0.1, 0.1], yerr=[0.5, 0.5, 0.5])
        plt.close('all')


# ---------------------------------------------------------------------------
# numpy statistics in plots
# ---------------------------------------------------------------------------

class TestNumpyStats:
    def test_plot_cumsum(self):
        """Plotting cumulative sum does not raise."""
        fig, ax = plt.subplots()
        rng = np.random.default_rng(42)
        data = rng.normal(0, 1, 100)
        ax.plot(np.cumsum(data).tolist())
        plt.close('all')

    def test_scatter_with_color_array(self):
        """scatter with color values from numpy array does not raise."""
        fig, ax = plt.subplots()
        x = [1, 2, 3, 4, 5]
        y = [1, 4, 9, 16, 25]
        c = [0.1, 0.3, 0.5, 0.7, 0.9]
        ax.scatter(x, y, c=c, cmap='viridis')
        plt.close('all')

    def test_plot_sin_cos_together(self):
        """Plotting sin and cos on same axes renders correctly."""
        fig, ax = plt.subplots()
        x = np.linspace(0, 4 * np.pi, 200)
        ax.plot(x.tolist(), np.sin(x).tolist(), label='sin')
        ax.plot(x.tolist(), np.cos(x).tolist(), label='cos')
        ax.legend()
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_logspace_plot(self):
        """Plotting logspace data does not raise."""
        fig, ax = plt.subplots()
        x = np.logspace(0, 3, 50)
        y = np.sqrt(x)
        ax.plot(x.tolist(), y.tolist())
        plt.close('all')

    def test_loglog_scale(self):
        """loglog scale with numpy data does not raise."""
        fig, ax = plt.subplots()
        x = np.logspace(0, 3, 50)
        y = x ** 2
        ax.loglog(x.tolist(), y.tolist())
        plt.close('all')


# ---------------------------------------------------------------------------
# Histogram with numpy
# ---------------------------------------------------------------------------

class TestHistogramFeatures:
    def test_hist_density(self):
        """hist with density=True does not raise."""
        fig, ax = plt.subplots()
        rng = np.random.default_rng(42)
        data = rng.normal(0, 1, 200)
        ax.hist(data.tolist(), bins=30, density=True)
        plt.close('all')

    def test_hist_multiple_datasets(self):
        """hist with multiple datasets does not raise."""
        fig, ax = plt.subplots()
        rng = np.random.default_rng(42)
        data1 = rng.normal(0, 1, 100)
        data2 = rng.normal(2, 1, 100)
        ax.hist(data1.tolist(), bins=20, alpha=0.5, label='A')
        ax.hist(data2.tolist(), bins=20, alpha=0.5, label='B')
        ax.legend()
        plt.close('all')

    def test_hist_stepfilled(self):
        """hist with histtype='stepfilled' does not raise."""
        fig, ax = plt.subplots()
        rng = np.random.default_rng(42)
        data = rng.normal(0, 1, 100)
        ax.hist(data.tolist(), bins=20, histtype='stepfilled', alpha=0.5)
        plt.close('all')

    def test_hist_step(self):
        """hist with histtype='step' does not raise."""
        fig, ax = plt.subplots()
        rng = np.random.default_rng(42)
        data = rng.normal(0, 1, 100)
        ax.hist(data.tolist(), bins=20, histtype='step')
        plt.close('all')


# ---------------------------------------------------------------------------
# Image with numpy
# ---------------------------------------------------------------------------

class TestImageNumpy:
    def test_imshow_rgb_array(self):
        """imshow with RGB array (NxMx3) does not raise."""
        fig, ax = plt.subplots()
        rng = np.random.default_rng(42)
        img = (rng.random((10, 10, 3)) * 255).astype(int).tolist()
        ax.imshow(img)
        plt.close('all')

    def test_imshow_grayscale(self):
        """imshow with grayscale array does not raise."""
        fig, ax = plt.subplots()
        data = [[i + j for j in range(10)] for i in range(10)]
        ax.imshow(data, cmap='gray')
        plt.close('all')

    def test_imshow_with_colorbar(self):
        """imshow + colorbar with numpy data renders to SVG."""
        fig, ax = plt.subplots()
        data = [[i * j for j in range(5)] for i in range(5)]
        im = ax.imshow(data, cmap='viridis')
        fig.colorbar(im, ax=ax)
        svg = fig.to_svg()
        assert '<rect' in svg
        plt.close('all')
