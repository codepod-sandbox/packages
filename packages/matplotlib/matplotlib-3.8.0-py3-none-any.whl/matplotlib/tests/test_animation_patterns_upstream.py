"""
Upstream tests for matplotlib animation patterns commonly used by LLMs.
These tests check that animation infrastructure is importable and functional.
"""

import pytest
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation


class TestFuncAnimation:
    """Tests for FuncAnimation patterns."""

    def teardown_method(self):
        plt.close('all')

    def test_funcanimation_basic(self):
        fig, ax = plt.subplots()
        line, = ax.plot([], [])

        def init():
            line.set_data([], [])
            return (line,)

        def update(frame):
            x = np.linspace(0, 2 * np.pi, 100)
            line.set_data(x, np.sin(x + frame / 10))
            return (line,)

        anim = animation.FuncAnimation(fig, update, init_func=init,
                                       frames=10, blit=True)
        assert anim is not None

    def test_funcanimation_interval(self):
        fig, ax = plt.subplots()
        line, = ax.plot([1, 2, 3], [1, 2, 3])

        def update(frame):
            return (line,)

        anim = animation.FuncAnimation(fig, update, frames=5, interval=200)
        assert anim is not None

    def test_funcanimation_repeat(self):
        fig, ax = plt.subplots()
        line, = ax.plot([1, 2], [1, 2])

        def update(frame):
            return (line,)

        anim = animation.FuncAnimation(fig, update, frames=10, repeat=False)
        assert anim is not None

    def test_funcanimation_with_data(self):
        """Common LLM pattern: animate scatter positions."""
        fig, ax = plt.subplots()
        ax.set_xlim(0, 2 * np.pi)
        ax.set_ylim(-1.5, 1.5)
        line, = ax.plot([], [], 'b-', lw=2)
        time_text = ax.text(0.05, 0.9, '', transform=ax.transAxes)

        def init():
            line.set_data([], [])
            time_text.set_text('')
            return line, time_text

        def animate(i):
            x = np.linspace(0, 2 * np.pi, 200)
            y = np.sin(x + i / 5)
            line.set_data(x, y)
            time_text.set_text(f'frame = {i}')
            return line, time_text

        anim = animation.FuncAnimation(fig, animate, init_func=init,
                                       frames=20, interval=50, blit=True)
        assert anim is not None

    def test_funcanimation_imshow(self):
        """Animate imshow data."""
        fig, ax = plt.subplots()
        data = np.random.rand(10, 10)
        im = ax.imshow(data, animated=True)

        def update(frame):
            im.set_data(np.random.rand(10, 10))
            return (im,)

        anim = animation.FuncAnimation(fig, update, frames=5)
        assert anim is not None


class TestArtistAnimation:
    """Tests for ArtistAnimation patterns."""

    def teardown_method(self):
        plt.close('all')

    def test_artistanimation_basic(self):
        fig, ax = plt.subplots()
        frames = []
        for i in range(5):
            line, = ax.plot([1, 2, 3], [i, i + 1, i + 2])
            frames.append([line])
        anim = animation.ArtistAnimation(fig, frames)
        assert anim is not None

    def test_artistanimation_images(self):
        fig, ax = plt.subplots()
        frames = []
        for i in range(3):
            data = np.random.rand(5, 5)
            im = ax.imshow(data)
            frames.append([im])
        anim = animation.ArtistAnimation(fig, frames, interval=200)
        assert anim is not None


class TestAnimationImports:
    """Tests that animation module is importable."""

    def test_funcanimation_importable(self):
        from matplotlib.animation import FuncAnimation
        assert FuncAnimation is not None

    def test_artistanimation_importable(self):
        from matplotlib.animation import ArtistAnimation
        assert ArtistAnimation is not None

    def test_animation_module_importable(self):
        import matplotlib.animation as anim
        assert hasattr(anim, 'FuncAnimation')
        assert hasattr(anim, 'ArtistAnimation')
