"""Tests for animation stubs and FuncAnimation basics."""

import pytest
import matplotlib.pyplot as plt
import matplotlib.animation as animation


# ---------------------------------------------------------------------------
# FuncAnimation creation
# ---------------------------------------------------------------------------

class TestFuncAnimation:
    def test_funcanimation_creation(self):
        """FuncAnimation can be created without raising."""
        fig, ax = plt.subplots()
        line, = ax.plot([], [])

        def init():
            line.set_data([], [])
            return (line,)

        def update(frame):
            line.set_data([0, frame], [0, frame])
            return (line,)

        anim = animation.FuncAnimation(
            fig, update, frames=10, init_func=init,
            blit=True, interval=100
        )
        assert anim is not None
        plt.close('all')

    def test_funcanimation_no_init(self):
        """FuncAnimation without init_func does not raise."""
        fig, ax = plt.subplots()
        line, = ax.plot([0, 1], [0, 1])

        def update(frame):
            line.set_ydata([frame / 10, 1 - frame / 10])
            return (line,)

        anim = animation.FuncAnimation(fig, update, frames=10)
        assert anim is not None
        plt.close('all')

    def test_funcanimation_list_frames(self):
        """FuncAnimation with explicit frame list does not raise."""
        fig, ax = plt.subplots()
        line, = ax.plot([0, 1], [0, 1])

        def update(val):
            line.set_ydata([0, val])
            return (line,)

        anim = animation.FuncAnimation(
            fig, update, frames=[0.1, 0.5, 0.9, 0.5, 0.1])
        assert anim is not None
        plt.close('all')


# ---------------------------------------------------------------------------
# ArtistAnimation
# ---------------------------------------------------------------------------

class TestArtistAnimation:
    def test_artistanimation_creation(self):
        """ArtistAnimation can be created."""
        fig, ax = plt.subplots()
        frames = []
        for i in range(5):
            line, = ax.plot([0, 1], [0, i / 4])
            frames.append([line])
        anim = animation.ArtistAnimation(fig, frames, interval=100)
        assert anim is not None
        plt.close('all')


# ---------------------------------------------------------------------------
# Writers (stubs / availability check)
# ---------------------------------------------------------------------------

class TestWriters:
    def test_writer_registry_exists(self):
        """animation.writers exists."""
        assert animation.writers is not None

    def test_pillow_writer_available(self):
        """PillowWriter class exists in animation."""
        assert hasattr(animation, 'PillowWriter')

    def test_ffmpeg_writer_class(self):
        """FFMpegWriter class exists in animation."""
        assert hasattr(animation, 'FFMpegWriter')


# ---------------------------------------------------------------------------
# Pausing / interval
# ---------------------------------------------------------------------------

class TestAnimationProperties:
    def test_funcanimation_interval(self):
        """FuncAnimation interval property is accessible."""
        fig, ax = plt.subplots()
        line, = ax.plot([0, 1], [0, 1])

        def update(frame):
            return (line,)

        anim = animation.FuncAnimation(fig, update, frames=5, interval=200)
        # Just check it was created
        assert anim is not None
        plt.close('all')
