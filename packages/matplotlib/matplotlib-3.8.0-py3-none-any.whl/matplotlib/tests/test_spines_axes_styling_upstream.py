"""Tests for spines and axes styling patterns used by LLMs."""

import pytest
import numpy as np
import matplotlib.pyplot as plt


class TestSpines:
    def test_spines_access(self):
        """ax.spines is accessible."""
        fig, ax = plt.subplots()
        spines = ax.spines
        assert spines is not None
        plt.close('all')

    def test_spines_keys(self):
        """ax.spines has top/bottom/left/right."""
        fig, ax = plt.subplots()
        for key in ['top', 'bottom', 'left', 'right']:
            assert key in ax.spines
        plt.close('all')

    def test_spine_set_visible(self):
        """spine.set_visible(False) hides spine."""
        fig, ax = plt.subplots()
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        plt.close('all')

    def test_spine_set_linewidth(self):
        """spine.set_linewidth() changes width."""
        fig, ax = plt.subplots()
        ax.spines['bottom'].set_linewidth(2)
        plt.close('all')

    def test_spine_set_color(self):
        """spine.set_color() changes color."""
        fig, ax = plt.subplots()
        ax.spines['left'].set_color('red')
        plt.close('all')

    def test_spine_set_position(self):
        """spine.set_position() repositions spine."""
        fig, ax = plt.subplots()
        ax.spines['bottom'].set_position('zero')
        plt.close('all')

    def test_despine_pattern(self):
        """Common 'despine' pattern."""
        fig, ax = plt.subplots()
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        ax.plot([1, 2, 3])
        plt.close('all')


class TestAxesProperties:
    def test_set_aspect_equal(self):
        """ax.set_aspect('equal')."""
        fig, ax = plt.subplots()
        ax.set_aspect('equal')
        assert ax.get_aspect() == 'equal'
        plt.close('all')

    def test_set_aspect_auto(self):
        """ax.set_aspect('auto')."""
        fig, ax = plt.subplots()
        ax.set_aspect('auto')
        assert ax.get_aspect() == 'auto'
        plt.close('all')

    def test_set_aspect_ratio(self):
        """ax.set_aspect(float)."""
        fig, ax = plt.subplots()
        ax.set_aspect(1.5)
        assert ax.get_aspect() == 1.5
        plt.close('all')

    def test_invert_xaxis(self):
        """ax.invert_xaxis() inverts x axis."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3])
        ax.invert_xaxis()
        plt.close('all')

    def test_invert_yaxis(self):
        """ax.invert_yaxis() inverts y axis."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3])
        ax.invert_yaxis()
        plt.close('all')

    def test_xaxis_inverted(self):
        """ax.xaxis_inverted() returns bool."""
        fig, ax = plt.subplots()
        result = ax.xaxis_inverted()
        assert isinstance(result, bool)
        plt.close('all')

    def test_yaxis_inverted(self):
        """ax.yaxis_inverted() returns bool."""
        fig, ax = plt.subplots()
        result = ax.yaxis_inverted()
        assert isinstance(result, bool)
        plt.close('all')

    def test_set_frame_on(self):
        """ax.set_frame_on() controls frame display."""
        fig, ax = plt.subplots()
        ax.set_frame_on(False)
        plt.close('all')

    def test_get_frame_on(self):
        """ax.get_frame_on() returns bool."""
        fig, ax = plt.subplots()
        result = ax.get_frame_on()
        assert isinstance(result, bool)
        plt.close('all')

    def test_set_facecolor(self):
        """ax.set_facecolor() sets background color."""
        fig, ax = plt.subplots()
        ax.set_facecolor('lightgray')
        plt.close('all')

    def test_get_facecolor(self):
        """ax.get_facecolor() returns color."""
        fig, ax = plt.subplots()
        ax.set_facecolor('lightyellow')
        fc = ax.get_facecolor()
        assert fc is not None
        plt.close('all')


class TestGridStyling:
    def test_grid_on(self):
        """ax.grid(True) enables grid."""
        fig, ax = plt.subplots()
        ax.grid(True)
        plt.close('all')

    def test_grid_off(self):
        """ax.grid(False) disables grid."""
        fig, ax = plt.subplots()
        ax.grid(False)
        plt.close('all')

    def test_grid_axis_x(self):
        """ax.grid(axis='x') grid on x only."""
        fig, ax = plt.subplots()
        ax.grid(True, axis='x')
        plt.close('all')

    def test_grid_axis_y(self):
        """ax.grid(axis='y') grid on y only."""
        fig, ax = plt.subplots()
        ax.grid(True, axis='y')
        plt.close('all')

    def test_grid_linestyle(self):
        """ax.grid with linestyle."""
        fig, ax = plt.subplots()
        ax.grid(True, linestyle='--', alpha=0.7)
        plt.close('all')

    def test_grid_color(self):
        """ax.grid with color."""
        fig, ax = plt.subplots()
        ax.grid(True, color='lightgray', linewidth=0.5)
        plt.close('all')

    def test_grid_which_minor(self):
        """ax.grid on minor ticks."""
        fig, ax = plt.subplots()
        ax.grid(True, which='minor', alpha=0.3)
        plt.close('all')

    def test_grid_both(self):
        """ax.grid on both major and minor."""
        fig, ax = plt.subplots()
        ax.grid(True, which='both')
        plt.close('all')


class TestAxisFormatting:
    def test_xaxis_label_position(self):
        """xaxis.set_label_position."""
        fig, ax = plt.subplots()
        ax.xaxis.set_label_position('top')
        plt.close('all')

    def test_yaxis_label_position(self):
        """yaxis.set_label_position."""
        fig, ax = plt.subplots()
        ax.yaxis.set_label_position('right')
        plt.close('all')

    def test_xaxis_tick_params(self):
        """Tick params on xaxis."""
        fig, ax = plt.subplots()
        ax.xaxis.set_tick_params(labelsize=8)
        plt.close('all')

    def test_axis_off(self):
        """ax.axis('off') hides axes."""
        fig, ax = plt.subplots()
        ax.axis('off')
        plt.close('all')

    def test_axis_on(self):
        """ax.axis('on') shows axes."""
        fig, ax = plt.subplots()
        ax.axis('off')
        ax.axis('on')
        plt.close('all')

    def test_axis_equal(self):
        """ax.axis('equal') sets equal scaling."""
        fig, ax = plt.subplots()
        ax.axis('equal')
        plt.close('all')

    def test_axis_tight(self):
        """ax.axis('tight') adjusts limits to data."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [1, 4, 9])
        ax.axis('tight')
        plt.close('all')

    def test_axis_limits_tuple(self):
        """ax.axis([x0, x1, y0, y1]) sets all limits."""
        fig, ax = plt.subplots()
        ax.axis([0, 10, -1, 1])
        plt.close('all')
