"""Tests for patches (Ellipse, Arc, FancyArrowPatch, FancyBboxPatch), LineCollection,
add_collection, subplots_adjust, tight_layout, and prop_cycle."""

import pytest
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import Ellipse, Arc, Circle, Rectangle, FancyArrowPatch
from matplotlib.collections import LineCollection


# ---------------------------------------------------------------------------
# ax.add_collection() with LineCollection
# ---------------------------------------------------------------------------

class TestAddCollection:
    def test_add_linecollection_basic(self):
        """add_collection with LineCollection does not raise."""
        fig, ax = plt.subplots()
        segments = [[[0, 0], [1, 1]], [[0, 1], [1, 0]]]
        lc = LineCollection(segments)
        ax.add_collection(lc)
        assert len(ax.collections) == 1
        plt.close('all')

    def test_add_collection_returns_collection(self):
        """add_collection returns the collection."""
        fig, ax = plt.subplots()
        lc = LineCollection([[[0, 0], [1, 1]]])
        result = ax.add_collection(lc)
        assert result is lc
        plt.close('all')

    def test_add_multiple_collections(self):
        """Multiple collections can be added."""
        fig, ax = plt.subplots()
        lc1 = LineCollection([[[0, 0], [1, 1]]])
        lc2 = LineCollection([[[0, 1], [1, 0]]])
        ax.add_collection(lc1)
        ax.add_collection(lc2)
        assert len(ax.collections) == 2
        plt.close('all')

    def test_linecollection_with_color(self):
        """LineCollection with colors does not raise."""
        fig, ax = plt.subplots()
        segments = [[[0, 0], [1, 1]], [[0, 1], [1, 0]]]
        lc = LineCollection(segments, colors=['red', 'blue'])
        ax.add_collection(lc)
        assert len(ax.collections) == 1
        plt.close('all')

    def test_linecollection_with_linewidths(self):
        """LineCollection with linewidths does not raise."""
        fig, ax = plt.subplots()
        segments = [[[0, 0], [1, 1]]]
        lc = LineCollection(segments, linewidths=[2.0])
        ax.add_collection(lc)
        plt.close('all')

    def test_add_collection_svg_renders(self):
        """add_collection renders to SVG."""
        fig, ax = plt.subplots()
        lc = LineCollection([[[0, 0], [1, 1]], [[0.5, 0], [0.5, 1]]])
        ax.add_collection(lc)
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')


# ---------------------------------------------------------------------------
# matplotlib.patches - Ellipse
# ---------------------------------------------------------------------------

class TestEllipse:
    def test_ellipse_basic(self):
        """Ellipse can be created and added to axes."""
        fig, ax = plt.subplots()
        e = Ellipse((0.5, 0.5), 0.4, 0.2)
        ax.add_patch(e)
        assert len(ax.patches) >= 1
        plt.close('all')

    def test_ellipse_with_angle(self):
        """Ellipse with angle does not raise."""
        fig, ax = plt.subplots()
        e = Ellipse((0.5, 0.5), 0.4, 0.2, angle=45)
        ax.add_patch(e)
        plt.close('all')

    def test_ellipse_with_color(self):
        """Ellipse with facecolor and edgecolor does not raise."""
        fig, ax = plt.subplots()
        e = Ellipse((0.5, 0.5), 0.3, 0.1, facecolor='blue', edgecolor='black')
        ax.add_patch(e)
        plt.close('all')

    def test_ellipse_svg_renders(self):
        """Ellipse renders to SVG."""
        fig, ax = plt.subplots()
        e = Ellipse((0.5, 0.5), 0.4, 0.2, facecolor='red')
        ax.add_patch(e)
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_ellipse_get_center(self):
        """Ellipse center is set correctly."""
        e = Ellipse((0.5, 0.3), 0.4, 0.2)
        cx, cy = e.center
        assert cx == pytest.approx(0.5)
        assert cy == pytest.approx(0.3)

    def test_ellipse_get_width_height(self):
        """Ellipse width/height are set correctly."""
        e = Ellipse((0.5, 0.5), 0.4, 0.2)
        assert e.width == pytest.approx(0.4)
        assert e.height == pytest.approx(0.2)

    def test_ellipse_fill(self):
        """Ellipse fill kwarg does not raise."""
        fig, ax = plt.subplots()
        e = Ellipse((0.5, 0.5), 0.3, 0.1, fill=False)
        ax.add_patch(e)
        plt.close('all')


# ---------------------------------------------------------------------------
# matplotlib.patches - Arc
# ---------------------------------------------------------------------------

class TestArc:
    def test_arc_basic(self):
        """Arc can be created and added to axes."""
        fig, ax = plt.subplots()
        a = Arc((0.5, 0.5), 0.3, 0.3)
        ax.add_patch(a)
        assert len(ax.patches) >= 1
        plt.close('all')

    def test_arc_with_angles(self):
        """Arc with theta1/theta2 does not raise."""
        fig, ax = plt.subplots()
        a = Arc((0.5, 0.5), 0.3, 0.3, theta1=0, theta2=180)
        ax.add_patch(a)
        plt.close('all')

    def test_arc_svg_renders(self):
        """Arc renders to SVG."""
        fig, ax = plt.subplots()
        a = Arc((0.5, 0.5), 0.4, 0.2, theta1=45, theta2=270)
        ax.add_patch(a)
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_arc_semicircle(self):
        """Arc semicircle (theta1=0, theta2=180) does not raise."""
        fig, ax = plt.subplots()
        a = Arc((0.5, 0.5), 0.5, 0.5, theta1=0, theta2=180)
        ax.add_patch(a)
        plt.close('all')

    def test_arc_full_circle(self):
        """Arc full circle (theta2=360) does not raise."""
        fig, ax = plt.subplots()
        a = Arc((0.5, 0.5), 0.4, 0.4, theta1=0, theta2=360)
        ax.add_patch(a)
        plt.close('all')


# ---------------------------------------------------------------------------
# matplotlib.patches - FancyArrowPatch
# ---------------------------------------------------------------------------

class TestFancyArrowPatch:
    def test_fancy_arrow_basic(self):
        """FancyArrowPatch can be created and added to axes."""
        fig, ax = plt.subplots()
        fa = mpatches.FancyArrowPatch((0, 0), (1, 1), arrowstyle='->')
        ax.add_patch(fa)
        assert len(ax.patches) >= 1
        plt.close('all')

    def test_fancy_arrow_various_styles(self):
        """FancyArrowPatch with various arrowstyles does not raise."""
        fig, ax = plt.subplots()
        for style in ['->', '<->', '-|>', 'simple']:
            fa = mpatches.FancyArrowPatch((0, 0), (1, 1), arrowstyle=style)
            ax.add_patch(fa)
        plt.close('all')

    def test_fancy_arrow_svg_renders(self):
        """FancyArrowPatch renders to SVG."""
        fig, ax = plt.subplots()
        fa = mpatches.FancyArrowPatch((0, 0), (1, 1), arrowstyle='->')
        ax.add_patch(fa)
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_fancy_arrow_with_color(self):
        """FancyArrowPatch with color does not raise."""
        fig, ax = plt.subplots()
        fa = mpatches.FancyArrowPatch((0, 0), (1, 1), arrowstyle='->', color='red')
        ax.add_patch(fa)
        plt.close('all')

    def test_fancy_arrow_connectionstyle(self):
        """FancyArrowPatch with connectionstyle does not raise."""
        fig, ax = plt.subplots()
        fa = mpatches.FancyArrowPatch(
            (0, 0), (1, 1), arrowstyle='->',
            connectionstyle='arc3,rad=0.3'
        )
        ax.add_patch(fa)
        plt.close('all')


# ---------------------------------------------------------------------------
# matplotlib.patches - FancyBboxPatch
# ---------------------------------------------------------------------------

class TestFancyBboxPatch:
    def test_fancybbox_basic(self):
        """FancyBboxPatch can be created and added to axes."""
        fig, ax = plt.subplots()
        fb = mpatches.FancyBboxPatch((0.1, 0.1), 0.3, 0.2)
        ax.add_patch(fb)
        assert len(ax.patches) >= 1
        plt.close('all')

    def test_fancybbox_round_style(self):
        """FancyBboxPatch with round boxstyle does not raise."""
        fig, ax = plt.subplots()
        fb = mpatches.FancyBboxPatch((0.1, 0.1), 0.3, 0.2, boxstyle='round,pad=0.05')
        ax.add_patch(fb)
        plt.close('all')

    def test_fancybbox_svg_renders(self):
        """FancyBboxPatch renders to SVG."""
        fig, ax = plt.subplots()
        fb = mpatches.FancyBboxPatch((0.1, 0.1), 0.3, 0.2, facecolor='lightblue')
        ax.add_patch(fb)
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')

    def test_fancybbox_with_color(self):
        """FancyBboxPatch with facecolor/edgecolor does not raise."""
        fig, ax = plt.subplots()
        fb = mpatches.FancyBboxPatch(
            (0.1, 0.1), 0.3, 0.2,
            facecolor='yellow', edgecolor='black', linewidth=2
        )
        ax.add_patch(fb)
        plt.close('all')

    def test_fancybbox_square_style(self):
        """FancyBboxPatch with square boxstyle does not raise."""
        fig, ax = plt.subplots()
        fb = mpatches.FancyBboxPatch((0.1, 0.1), 0.3, 0.2, boxstyle='square')
        ax.add_patch(fb)
        plt.close('all')


# ---------------------------------------------------------------------------
# Figure layout: subplots_adjust, tight_layout
# ---------------------------------------------------------------------------

class TestFigureLayout:
    def test_subplots_adjust_basic(self):
        """subplots_adjust does not raise."""
        fig, axes = plt.subplots(2, 2)
        fig.subplots_adjust(hspace=0.4, wspace=0.4)
        plt.close('all')

    def test_subplots_adjust_all_params(self):
        """subplots_adjust with all params does not raise."""
        fig, axes = plt.subplots(2, 2)
        fig.subplots_adjust(left=0.1, right=0.9, top=0.9, bottom=0.1, hspace=0.4, wspace=0.4)
        plt.close('all')

    def test_plt_subplots_adjust(self):
        """plt.subplots_adjust() wrapper does not raise."""
        fig, axes = plt.subplots(1, 2)
        plt.subplots_adjust(wspace=0.5)
        plt.close('all')

    def test_tight_layout_basic(self):
        """tight_layout does not raise."""
        fig, axes = plt.subplots(2, 2)
        for ax in [axes[0][0], axes[0][1], axes[1][0], axes[1][1]]:
            ax.set_title('Title')
        fig.tight_layout()
        plt.close('all')

    def test_plt_tight_layout(self):
        """plt.tight_layout() does not raise."""
        fig, axes = plt.subplots(1, 3)
        plt.tight_layout()
        plt.close('all')

    def test_tight_layout_with_pad(self):
        """tight_layout with pad kwarg does not raise."""
        fig, ax = plt.subplots()
        ax.set_title('My Plot')
        fig.tight_layout(pad=2.0)
        plt.close('all')

    def test_subplots_adjust_renders_svg(self):
        """Figure with subplots_adjust renders to SVG."""
        fig, axes = plt.subplots(1, 2)
        axes[0].plot([0, 1], [0, 1])
        axes[1].bar([1, 2], [3, 4])
        fig.subplots_adjust(wspace=0.5)
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')


# ---------------------------------------------------------------------------
# prop_cycle / color cycling
# ---------------------------------------------------------------------------

class TestPropCycle:
    def test_default_color_cycle(self):
        """Multiple lines use different colors from default cycle."""
        fig, ax = plt.subplots()
        l1, = ax.plot([0, 1], [0, 1])
        l2, = ax.plot([0, 1], [1, 0])
        # Both lines exist; they may or may not have same color depending on impl
        assert l1 is not None
        assert l2 is not None
        plt.close('all')

    def test_set_prop_cycle_colors(self):
        """set_prop_cycle with color list does not raise."""
        fig, ax = plt.subplots()
        ax.set_prop_cycle(color=['red', 'green', 'blue'])
        l1, = ax.plot([0, 1], [0, 1])
        l2, = ax.plot([0, 1], [1, 0])
        assert l1 is not None
        plt.close('all')

    def test_prop_cycle_wraps_around(self):
        """prop_cycle wraps when more lines than colors."""
        fig, ax = plt.subplots()
        ax.set_prop_cycle(color=['red', 'blue'])
        lines = [ax.plot([i, i+1], [0, 1])[0] for i in range(5)]
        assert len(lines) == 5
        plt.close('all')

    def test_rc_prop_cycle(self):
        """rcParams prop_cycle can be set and used."""
        import matplotlib
        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        plt.close('all')

    def test_prop_cycle_svg_renders(self):
        """Multiple plotted lines with prop_cycle renders to SVG."""
        fig, ax = plt.subplots()
        ax.set_prop_cycle(color=['red', 'green', 'blue'])
        for i in range(3):
            ax.plot([0, 1], [i, i+1])
        svg = fig.to_svg()
        assert len(svg) > 0
        plt.close('all')
