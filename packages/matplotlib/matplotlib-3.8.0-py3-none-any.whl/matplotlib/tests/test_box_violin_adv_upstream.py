"""Tests for box plots and violin plots."""

import pytest
import matplotlib.pyplot as plt


class TestBoxplot:
    def test_boxplot_basic(self):
        """Basic boxplot."""
        fig, ax = plt.subplots()
        data = [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0]
        bp = ax.boxplot(data)
        assert bp is not None
        plt.close('all')

    def test_boxplot_multiple(self):
        """Boxplot with multiple datasets."""
        fig, ax = plt.subplots()
        data = [[1.0, 2.0, 3.0, 4.0], [2.0, 3.0, 5.0, 7.0], [0.0, 1.0, 2.0, 3.0]]
        bp = ax.boxplot(data)
        assert bp is not None
        plt.close('all')

    def test_boxplot_notch(self):
        """Boxplot with notch."""
        fig, ax = plt.subplots()
        data = [1.0, 2.0, 3.0, 4.0, 5.0]
        ax.boxplot(data, notch=True)
        plt.close('all')

    def test_boxplot_labels(self):
        """Boxplot with labels."""
        fig, ax = plt.subplots()
        data = [[1.0, 2.0, 3.0], [2.0, 4.0, 6.0], [0.0, 1.0, 2.0]]
        ax.boxplot(data, labels=['Group A', 'Group B', 'Group C'])
        plt.close('all')

    def test_boxplot_vert_false(self):
        """Horizontal boxplot."""
        fig, ax = plt.subplots()
        data = [1.0, 2.0, 3.0, 4.0, 5.0]
        ax.boxplot(data, vert=False)
        plt.close('all')

    def test_boxplot_whis(self):
        """Boxplot with whisker setting."""
        fig, ax = plt.subplots()
        data = [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0]
        ax.boxplot(data, whis=1.5)
        plt.close('all')

    def test_boxplot_showfliers(self):
        """Boxplot with no fliers."""
        fig, ax = plt.subplots()
        data = [1.0, 2.0, 3.0, 4.0, 100.0]  # 100 is an outlier
        ax.boxplot(data, showfliers=False)
        plt.close('all')

    def test_boxplot_patch_artist(self):
        """Boxplot with patch artist (colored boxes)."""
        fig, ax = plt.subplots()
        data = [[1.0, 2.0, 3.0, 4.0, 5.0], [2.0, 3.0, 4.0, 5.0, 6.0]]
        bp = ax.boxplot(data, patch_artist=True)
        # Color the boxes
        colors = ['lightblue', 'lightgreen']
        for patch, color in zip(bp['boxes'], colors):
            patch.set_facecolor(color)
        plt.close('all')

    def test_boxplot_widths(self):
        """Boxplot with custom widths."""
        fig, ax = plt.subplots()
        data = [[1.0, 2.0, 3.0], [2.0, 4.0, 6.0]]
        ax.boxplot(data, widths=0.3)
        plt.close('all')

    def test_boxplot_positions(self):
        """Boxplot with custom positions."""
        fig, ax = plt.subplots()
        data = [[1.0, 2.0, 3.0], [2.0, 4.0, 6.0], [0.0, 1.0, 2.0]]
        ax.boxplot(data, positions=[1, 3, 5])
        plt.close('all')

    def test_boxplot_meanline(self):
        """Boxplot with mean line."""
        fig, ax = plt.subplots()
        data = [1.0, 2.0, 3.0, 4.0, 5.0]
        ax.boxplot(data, showmeans=True)
        plt.close('all')

    def test_boxplot_return_dict(self):
        """Boxplot returns dict with artists."""
        fig, ax = plt.subplots()
        data = [1.0, 2.0, 3.0, 4.0, 5.0]
        bp = ax.boxplot(data)
        assert 'boxes' in bp
        assert 'medians' in bp
        assert 'whiskers' in bp
        plt.close('all')


class TestViolinPlot:
    def test_violin_basic(self):
        """Basic violin plot."""
        fig, ax = plt.subplots()
        data = [1.0, 2.0, 3.0, 4.0, 5.0, 3.0, 2.0, 4.0, 3.0]
        vp = ax.violinplot(data)
        assert vp is not None
        plt.close('all')

    def test_violin_multiple(self):
        """Violin with multiple datasets."""
        fig, ax = plt.subplots()
        data = [[1.0, 2.0, 3.0, 4.0], [2.0, 3.0, 5.0, 7.0], [0.5, 1.0, 2.5, 4.0]]
        vp = ax.violinplot(data)
        assert vp is not None
        plt.close('all')

    def test_violin_show_mean(self):
        """Violin with mean marker."""
        fig, ax = plt.subplots()
        data = [1.0, 2.0, 3.0, 4.0, 5.0]
        ax.violinplot(data, showmeans=True)
        plt.close('all')

    def test_violin_show_median(self):
        """Violin with median marker."""
        fig, ax = plt.subplots()
        data = [1.0, 2.0, 3.0, 4.0, 5.0]
        ax.violinplot(data, showmedians=True)
        plt.close('all')

    def test_violin_show_extrema(self):
        """Violin with extrema."""
        fig, ax = plt.subplots()
        data = [1.0, 2.0, 3.0, 4.0, 5.0]
        ax.violinplot(data, showextrema=True)
        plt.close('all')

    def test_violin_positions(self):
        """Violin with positions."""
        fig, ax = plt.subplots()
        data = [[1.0, 2.0, 3.0], [2.0, 4.0, 6.0]]
        ax.violinplot(data, positions=[1, 3])
        plt.close('all')

    def test_violin_side_vertical(self):
        """Violin vert parameter."""
        fig, ax = plt.subplots()
        data = [1.0, 2.0, 3.0, 4.0, 5.0]
        ax.violinplot(data, vert=True)
        plt.close('all')

    def test_violin_points(self):
        """Violin with points parameter."""
        fig, ax = plt.subplots()
        data = [1.0, 2.0, 3.0, 4.0, 5.0]
        ax.violinplot(data, points=100)
        plt.close('all')

    def test_violin_widths(self):
        """Violin with width."""
        fig, ax = plt.subplots()
        data = [1.0, 2.0, 3.0, 4.0, 5.0]
        ax.violinplot(data, widths=0.5)
        plt.close('all')


class TestPieChart:
    def test_pie_basic(self):
        """Basic pie chart."""
        fig, ax = plt.subplots()
        sizes = [30, 25, 20, 15, 10]
        wedges, texts = ax.pie(sizes)
        assert wedges is not None
        plt.close('all')

    def test_pie_labels(self):
        """Pie chart with labels."""
        fig, ax = plt.subplots()
        sizes = [40, 30, 20, 10]
        labels = ['A', 'B', 'C', 'D']
        ax.pie(sizes, labels=labels)
        plt.close('all')

    def test_pie_autopct(self):
        """Pie chart with percentage labels."""
        fig, ax = plt.subplots()
        sizes = [40, 30, 20, 10]
        ax.pie(sizes, autopct='%1.1f%%')
        plt.close('all')

    def test_pie_explode(self):
        """Pie chart with exploded slice."""
        fig, ax = plt.subplots()
        sizes = [40, 30, 20, 10]
        explode = [0.1, 0, 0, 0]
        ax.pie(sizes, explode=explode)
        plt.close('all')

    def test_pie_colors(self):
        """Pie chart with colors."""
        fig, ax = plt.subplots()
        sizes = [40, 30, 20, 10]
        colors = ['red', 'blue', 'green', 'yellow']
        ax.pie(sizes, colors=colors)
        plt.close('all')

    def test_pie_shadow(self):
        """Pie chart with shadow."""
        fig, ax = plt.subplots()
        sizes = [40, 30, 20, 10]
        ax.pie(sizes, shadow=True)
        plt.close('all')

    def test_pie_startangle(self):
        """Pie chart with start angle."""
        fig, ax = plt.subplots()
        sizes = [40, 30, 20, 10]
        ax.pie(sizes, startangle=90)
        plt.close('all')

    def test_pie_counterclock(self):
        """Pie chart counterclockwise."""
        fig, ax = plt.subplots()
        sizes = [40, 30, 20, 10]
        ax.pie(sizes, counterclock=True)
        plt.close('all')
