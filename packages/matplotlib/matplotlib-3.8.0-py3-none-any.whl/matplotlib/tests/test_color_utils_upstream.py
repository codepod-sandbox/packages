"""Tests for matplotlib.colors utility functions."""

import pytest
import numpy as np
import matplotlib.colors as mcolors


# ---------------------------------------------------------------------------
# to_rgba / to_rgb / to_hex
# ---------------------------------------------------------------------------

class TestColorConversion:
    def test_to_rgba_name(self):
        """to_rgba('red') returns (1, 0, 0, 1)."""
        rgba = mcolors.to_rgba('red')
        assert rgba[0] == pytest.approx(1.0)
        assert rgba[1] == pytest.approx(0.0)
        assert rgba[2] == pytest.approx(0.0)
        assert rgba[3] == pytest.approx(1.0)

    def test_to_rgba_hex(self):
        """to_rgba('#ff0000') returns (1, 0, 0, 1)."""
        rgba = mcolors.to_rgba('#ff0000')
        assert rgba[0] == pytest.approx(1.0)

    def test_to_rgba_tuple_rgb(self):
        """to_rgba((0.5, 0.5, 0.5)) returns (0.5, 0.5, 0.5, 1)."""
        rgba = mcolors.to_rgba((0.5, 0.5, 0.5))
        assert rgba[0] == pytest.approx(0.5)
        assert rgba[3] == pytest.approx(1.0)

    def test_to_rgba_tuple_rgba(self):
        """to_rgba((1, 0, 0, 0.5)) preserves alpha."""
        rgba = mcolors.to_rgba((1, 0, 0, 0.5))
        assert rgba[3] == pytest.approx(0.5)

    def test_to_rgba_with_alpha(self):
        """to_rgba('blue', alpha=0.3) sets alpha."""
        rgba = mcolors.to_rgba('blue', alpha=0.3)
        assert rgba[3] == pytest.approx(0.3)

    def test_to_rgb(self):
        """to_rgb returns 3-tuple."""
        rgb = mcolors.to_rgb('green')
        assert len(rgb) == 3

    def test_to_hex_red(self):
        """to_hex('red') returns '#ff0000'."""
        h = mcolors.to_hex('red')
        assert h.lower() == '#ff0000'

    def test_to_hex_tuple(self):
        """to_hex((0, 0, 1)) returns '#0000ff'."""
        h = mcolors.to_hex((0, 0, 1))
        assert h.lower() == '#0000ff'

    def test_to_hex_keepalpha(self):
        """to_hex with keep_alpha=True returns 8-char hex."""
        h = mcolors.to_hex((1, 0, 0, 0.5), keep_alpha=True)
        assert len(h) == 9  # '#rrggbbaa'

    def test_is_color_like_true(self):
        """is_color_like('red') is True."""
        assert mcolors.is_color_like('red')

    def test_is_color_like_hex(self):
        """is_color_like('#00ff00') is True."""
        assert mcolors.is_color_like('#00ff00')

    def test_is_color_like_tuple(self):
        """is_color_like((1, 0, 0)) is True."""
        assert mcolors.is_color_like((1, 0, 0))

    def test_is_color_like_false(self):
        """is_color_like('notacolor') is False."""
        assert not mcolors.is_color_like('notacolor')


# ---------------------------------------------------------------------------
# Color names
# ---------------------------------------------------------------------------

class TestColorNames:
    def test_css4_colors_exists(self):
        """mcolors.CSS4_COLORS exists."""
        assert mcolors.CSS4_COLORS is not None
        assert 'red' in mcolors.CSS4_COLORS

    def test_tableau_colors(self):
        """mcolors.TABLEAU_COLORS exists."""
        assert mcolors.TABLEAU_COLORS is not None

    def test_base_colors(self):
        """mcolors.BASE_COLORS exists."""
        assert mcolors.BASE_COLORS is not None
        assert 'r' in mcolors.BASE_COLORS

    def test_xkcd_colors(self):
        """mcolors.XKCD_COLORS exists (or is harmlessly absent)."""
        colors = getattr(mcolors, 'XKCD_COLORS', {})
        assert isinstance(colors, dict)

    def test_c0_to_c9(self):
        """Color cycle C0-C9 can be converted."""
        for i in range(10):
            rgba = mcolors.to_rgba(f'C{i}')
            assert len(rgba) == 4


# ---------------------------------------------------------------------------
# Colormap creation
# ---------------------------------------------------------------------------

class TestColormapCreation:
    def test_linear_segmented_colormap(self):
        """LinearSegmentedColormap can be created."""
        cdict = {
            'red':   [(0.0, 0.0, 0.0), (1.0, 1.0, 1.0)],
            'green': [(0.0, 0.0, 0.0), (1.0, 0.0, 0.0)],
            'blue':  [(0.0, 1.0, 1.0), (1.0, 0.0, 0.0)],
        }
        cmap = mcolors.LinearSegmentedColormap('blue_red', cdict)
        assert cmap is not None
        rgba = cmap(0.5)
        assert len(rgba) == 4

    def test_listed_colormap(self):
        """ListedColormap with list of colors can be created."""
        cmap = mcolors.ListedColormap(['red', 'green', 'blue'])
        assert cmap is not None
        rgba = cmap(0.0)
        assert len(rgba) == 4

    def test_from_list(self):
        """LinearSegmentedColormap.from_list creates gradient colormap."""
        cmap = mcolors.LinearSegmentedColormap.from_list(
            'custom', ['blue', 'white', 'red'])
        assert cmap is not None
        rgba = cmap(0.5)
        assert len(rgba) == 4


# ---------------------------------------------------------------------------
# Special colors
# ---------------------------------------------------------------------------

class TestSpecialColors:
    def test_none_color(self):
        """'none' as a color (transparent) is handled."""
        rgba = mcolors.to_rgba('none')
        assert rgba[3] == pytest.approx(0.0)

    def test_white(self):
        """'white' converts to (1, 1, 1, 1)."""
        rgba = mcolors.to_rgba('white')
        assert rgba[0] == pytest.approx(1.0)
        assert rgba[1] == pytest.approx(1.0)
        assert rgba[2] == pytest.approx(1.0)

    def test_black(self):
        """'black' converts to (0, 0, 0, 1)."""
        rgba = mcolors.to_rgba('black')
        assert rgba[0] == pytest.approx(0.0)
        assert rgba[1] == pytest.approx(0.0)
        assert rgba[2] == pytest.approx(0.0)
