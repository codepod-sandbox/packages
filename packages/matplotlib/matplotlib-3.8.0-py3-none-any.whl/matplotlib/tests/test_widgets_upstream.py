"""Tests for matplotlib.widgets patterns used by LLMs."""

import pytest
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.widgets as widgets


class TestSlider:
    def test_slider_basic(self):
        """Slider widget creation."""
        fig, ax = plt.subplots()
        plt.subplots_adjust(bottom=0.25)
        ax_slider = plt.axes([0.1, 0.1, 0.8, 0.05])
        slider = widgets.Slider(ax_slider, 'Value', 0.0, 1.0, valinit=0.5)
        assert slider is not None
        plt.close('all')

    def test_slider_val(self):
        """slider.val returns current value."""
        fig, ax = plt.subplots()
        ax_slider = plt.axes([0.1, 0.1, 0.8, 0.05])
        slider = widgets.Slider(ax_slider, 'X', 0.0, 10.0, valinit=5.0)
        assert slider.val == 5.0
        plt.close('all')

    def test_slider_on_changed(self):
        """slider.on_changed() registers callback."""
        fig, ax = plt.subplots()
        ax_slider = plt.axes([0.1, 0.1, 0.8, 0.05])
        slider = widgets.Slider(ax_slider, 'X', 0.0, 10.0)
        called = []
        def on_change(val):
            called.append(val)
        slider.on_changed(on_change)
        plt.close('all')

    def test_slider_set_val(self):
        """slider.set_val() updates value."""
        fig, ax = plt.subplots()
        ax_slider = plt.axes([0.1, 0.1, 0.8, 0.05])
        slider = widgets.Slider(ax_slider, 'X', 0.0, 10.0, valinit=0.0)
        slider.set_val(7.0)
        assert slider.val == 7.0
        plt.close('all')

    def test_range_slider(self):
        """RangeSlider widget."""
        fig, ax = plt.subplots()
        ax_slider = plt.axes([0.1, 0.1, 0.8, 0.05])
        slider = widgets.RangeSlider(ax_slider, 'Range', 0.0, 10.0)
        assert slider is not None
        plt.close('all')


class TestButton:
    def test_button_basic(self):
        """Button widget creation."""
        fig, ax = plt.subplots()
        ax_btn = plt.axes([0.4, 0.05, 0.2, 0.075])
        btn = widgets.Button(ax_btn, 'Click me')
        assert btn is not None
        plt.close('all')

    def test_button_on_clicked(self):
        """button.on_clicked() registers callback."""
        fig, ax = plt.subplots()
        ax_btn = plt.axes([0.4, 0.05, 0.2, 0.075])
        btn = widgets.Button(ax_btn, 'Reset')
        clicked = []
        def on_click(event):
            clicked.append(event)
        btn.on_clicked(on_click)
        plt.close('all')


class TestCheckButtons:
    def test_check_buttons_basic(self):
        """CheckButtons widget."""
        fig, ax = plt.subplots()
        ax_check = plt.axes([0.05, 0.4, 0.2, 0.5])
        check = widgets.CheckButtons(ax_check, ['line1', 'line2'], [True, False])
        assert check is not None
        plt.close('all')

    def test_check_buttons_on_clicked(self):
        """CheckButtons callback."""
        fig, ax = plt.subplots()
        ax_check = plt.axes([0.05, 0.4, 0.2, 0.5])
        check = widgets.CheckButtons(ax_check, ['A', 'B'], [True, True])
        def on_check(label):
            pass
        check.on_clicked(on_check)
        plt.close('all')

    def test_check_buttons_get_status(self):
        """CheckButtons.get_status() returns list of bools."""
        fig, ax = plt.subplots()
        ax_check = plt.axes([0.05, 0.4, 0.2, 0.5])
        check = widgets.CheckButtons(ax_check, ['A', 'B'], [True, False])
        status = check.get_status()
        assert status == [True, False]
        plt.close('all')


class TestRadioButtons:
    def test_radio_buttons_basic(self):
        """RadioButtons widget."""
        fig, ax = plt.subplots()
        ax_radio = plt.axes([0.05, 0.4, 0.15, 0.5])
        radio = widgets.RadioButtons(ax_radio, ['A', 'B', 'C'])
        assert radio is not None
        plt.close('all')

    def test_radio_buttons_on_clicked(self):
        """RadioButtons callback."""
        fig, ax = plt.subplots()
        ax_radio = plt.axes([0.05, 0.4, 0.15, 0.5])
        radio = widgets.RadioButtons(ax_radio, ['X', 'Y'])
        def on_radio(label):
            pass
        radio.on_clicked(on_radio)
        plt.close('all')

    def test_radio_buttons_value_selected(self):
        """RadioButtons.value_selected."""
        fig, ax = plt.subplots()
        ax_radio = plt.axes([0.05, 0.4, 0.15, 0.5])
        radio = widgets.RadioButtons(ax_radio, ['A', 'B', 'C'], active=1)
        assert radio.value_selected == 'B'
        plt.close('all')


class TestTextBox:
    def test_textbox_basic(self):
        """TextBox widget."""
        fig, ax = plt.subplots()
        ax_box = plt.axes([0.1, 0.05, 0.8, 0.075])
        tb = widgets.TextBox(ax_box, 'Search', initial='hello')
        assert tb is not None
        plt.close('all')

    def test_textbox_text(self):
        """TextBox.text returns current text."""
        fig, ax = plt.subplots()
        ax_box = plt.axes([0.1, 0.05, 0.8, 0.075])
        tb = widgets.TextBox(ax_box, 'Input', initial='world')
        assert tb.text == 'world'
        plt.close('all')


class TestSpanSelector:
    def test_span_selector_basic(self):
        """SpanSelector widget."""
        fig, ax = plt.subplots()
        ax.plot([1.0, 2.0, 3.0, 4.0, 5.0])
        def on_select(xmin, xmax):
            pass
        span = widgets.SpanSelector(ax, on_select, direction='horizontal')
        assert span is not None
        plt.close('all')

    def test_span_selector_vertical(self):
        """SpanSelector with direction=vertical."""
        fig, ax = plt.subplots()
        ax.plot([1.0, 2.0, 3.0])
        def on_select(ymin, ymax):
            pass
        span = widgets.SpanSelector(ax, on_select, direction='vertical')
        assert span is not None
        plt.close('all')
