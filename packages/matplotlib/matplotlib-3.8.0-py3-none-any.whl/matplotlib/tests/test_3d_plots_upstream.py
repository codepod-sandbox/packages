"""
Upstream tests for 3D plot patterns commonly used by LLMs.
"""

import pytest
import numpy as np
import matplotlib.pyplot as plt

try:
    from mpl_toolkits.mplot3d import Axes3D
    HAS_3D = True
except ImportError:
    HAS_3D = False

pytestmark = pytest.mark.skipif(not HAS_3D, reason="mpl_toolkits.mplot3d not available")


class TestAxes3DBasic:
    """Basic 3D axes creation patterns."""

    def teardown_method(self):
        plt.close('all')

    def test_add_subplot_3d(self):
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        assert ax is not None

    def test_subplot_3d_via_subplots(self):
        fig, ax = plt.subplots(subplot_kw={'projection': '3d'})
        assert ax is not None

    def test_axes3d_type(self):
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        assert isinstance(ax, Axes3D)

    def test_3d_figure_figsize(self):
        fig = plt.figure(figsize=(8, 6))
        ax = fig.add_subplot(111, projection='3d')
        w, h = fig.get_size_inches()
        assert w == 8.0

    def test_3d_set_labels(self):
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        ax.set_xlabel('X')
        ax.set_ylabel('Y')
        ax.set_zlabel('Z')

    def test_3d_set_title(self):
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        ax.set_title('3D Surface')

    def test_3d_set_xlim(self):
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        ax.set_xlim(-5, 5)

    def test_3d_set_ylim(self):
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        ax.set_ylim(-5, 5)

    def test_3d_set_zlim(self):
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        ax.set_zlim(0, 10)


class TestSurfacePlots:
    """Tests for 3D surface plots."""

    def teardown_method(self):
        plt.close('all')

    def test_plot_surface_basic(self):
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        x = np.linspace(-3, 3, 10)
        y = np.linspace(-3, 3, 10)
        X, Y = np.meshgrid(x, y)
        Z = np.sin(X) * np.cos(Y)
        surf = ax.plot_surface(X, Y, Z)
        assert surf is not None

    def test_plot_surface_colormap(self):
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        x = np.linspace(-2, 2, 10)
        y = np.linspace(-2, 2, 10)
        X, Y = np.meshgrid(x, y)
        Z = X ** 2 + Y ** 2
        ax.plot_surface(X, Y, Z, cmap='viridis')

    def test_plot_surface_with_colorbar(self):
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        x = np.linspace(-2, 2, 10)
        y = np.linspace(-2, 2, 10)
        X, Y = np.meshgrid(x, y)
        Z = X ** 2 + Y ** 2
        surf = ax.plot_surface(X, Y, Z, cmap='plasma')
        fig.colorbar(surf, ax=ax)

    def test_plot_wireframe(self):
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        x = np.linspace(-2, 2, 8)
        y = np.linspace(-2, 2, 8)
        X, Y = np.meshgrid(x, y)
        Z = np.sqrt(X ** 2 + Y ** 2)
        ax.plot_wireframe(X, Y, Z, rstride=1, cstride=1)


class TestLine3DPlots:
    """Tests for 3D line plots."""

    def teardown_method(self):
        plt.close('all')

    def test_plot3d_basic(self):
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        t = np.linspace(0, 4 * np.pi, 100)
        ax.plot(np.cos(t), np.sin(t), t)

    def test_plot3d_with_color(self):
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        t = np.linspace(0, 2 * np.pi, 50)
        ax.plot(np.cos(t), np.sin(t), t, color='blue', linewidth=2)

    def test_scatter3d_basic(self):
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        rng = np.random.default_rng(42)
        x = rng.normal(0, 1, 30)
        y = rng.normal(0, 1, 30)
        z = rng.normal(0, 1, 30)
        ax.scatter(x, y, z, c='red', marker='o')

    def test_scatter3d_colored_by_value(self):
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        rng = np.random.default_rng(42)
        x = rng.uniform(0, 1, 50)
        y = rng.uniform(0, 1, 50)
        z = rng.uniform(0, 1, 50)
        ax.scatter(x, y, z, c=z, cmap='viridis')

    def test_bar3d_basic(self):
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        x = [1, 2, 3]
        y = [1, 2, 3]
        z = np.zeros(3)
        dx = dy = np.ones(3) * 0.5
        dz = [3, 5, 2]
        ax.bar3d(x, y, z, dx, dy, dz)

    def test_contour3d(self):
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        x = np.linspace(-3, 3, 15)
        y = np.linspace(-3, 3, 15)
        X, Y = np.meshgrid(x, y)
        Z = np.sin(X) * np.cos(Y)
        ax.contourf(X, Y, Z, zdir='z', offset=-1)


class TestAxes3DViewAngle:
    """Tests for 3D view angle manipulation."""

    def teardown_method(self):
        plt.close('all')

    def test_view_init(self):
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        ax.view_init(elev=30, azim=45)

    def test_view_init_top_down(self):
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        ax.view_init(elev=90, azim=0)

    def test_view_init_side_view(self):
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        ax.view_init(elev=0, azim=0)
