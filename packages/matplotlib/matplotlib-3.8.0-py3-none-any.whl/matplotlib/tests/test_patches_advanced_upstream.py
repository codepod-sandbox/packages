"""Tests for advanced patch patterns used by LLMs."""

import pytest
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches


class TestBasicPatches:
    def test_rectangle(self):
        fig, ax = plt.subplots()
        rect = mpatches.Rectangle((0, 0), 1, 1, color='blue')
        ax.add_patch(rect)
        plt.close('all')

    def test_circle(self):
        fig, ax = plt.subplots()
        circ = mpatches.Circle((0.5, 0.5), 0.3, color='red')
        ax.add_patch(circ)
        plt.close('all')

    def test_ellipse(self):
        fig, ax = plt.subplots()
        ell = mpatches.Ellipse((0.5, 0.5), 0.4, 0.2, angle=45)
        ax.add_patch(ell)
        plt.close('all')

    def test_polygon(self):
        fig, ax = plt.subplots()
        verts = [(0.0, 0.0), (1.0, 0.0), (0.5, 1.0)]
        poly = mpatches.Polygon(verts, color='green')
        ax.add_patch(poly)
        plt.close('all')

    def test_wedge(self):
        fig, ax = plt.subplots()
        wedge = mpatches.Wedge((0.5, 0.5), 0.3, 0, 90, color='orange')
        ax.add_patch(wedge)
        plt.close('all')

    def test_arc(self):
        fig, ax = plt.subplots()
        arc = mpatches.Arc((0.5, 0.5), 0.4, 0.4, angle=0, theta1=0, theta2=90)
        ax.add_patch(arc)
        plt.close('all')

    def test_fancy_bbox_patch(self):
        fig, ax = plt.subplots()
        fb = mpatches.FancyBboxPatch((0.1, 0.1), 0.5, 0.3, boxstyle='round,pad=0.1')
        ax.add_patch(fb)
        plt.close('all')

    def test_fancy_arrow_patch(self):
        fig, ax = plt.subplots()
        fa = mpatches.FancyArrowPatch((0, 0), (1, 1))
        ax.add_patch(fa)
        plt.close('all')


class TestPatchStyling:
    def test_patch_facecolor(self):
        fig, ax = plt.subplots()
        rect = mpatches.Rectangle((0, 0), 1, 1, facecolor='cyan')
        ax.add_patch(rect)
        assert rect.get_facecolor() is not None
        plt.close('all')

    def test_patch_edgecolor(self):
        fig, ax = plt.subplots()
        rect = mpatches.Rectangle((0, 0), 1, 1, edgecolor='black', linewidth=2)
        ax.add_patch(rect)
        assert rect.get_edgecolor() is not None
        plt.close('all')

    def test_patch_alpha(self):
        fig, ax = plt.subplots()
        rect = mpatches.Rectangle((0, 0), 1, 1, alpha=0.5)
        ax.add_patch(rect)
        assert rect.get_alpha() == 0.5
        plt.close('all')

    def test_patch_linewidth(self):
        fig, ax = plt.subplots()
        rect = mpatches.Rectangle((0, 0), 1, 1, linewidth=3)
        ax.add_patch(rect)
        assert rect.get_linewidth() == 3.0
        plt.close('all')

    def test_patch_linestyle(self):
        fig, ax = plt.subplots()
        rect = mpatches.Rectangle((0, 0), 1, 1, linestyle='dashed')
        ax.add_patch(rect)
        plt.close('all')

    def test_patch_visible(self):
        fig, ax = plt.subplots()
        rect = mpatches.Rectangle((0, 0), 1, 1)
        ax.add_patch(rect)
        rect.set_visible(False)
        assert rect.get_visible() is False
        plt.close('all')

    def test_patch_zorder(self):
        fig, ax = plt.subplots()
        rect = mpatches.Rectangle((0, 0), 1, 1, zorder=5)
        ax.add_patch(rect)
        assert rect.get_zorder() == 5
        plt.close('all')


class TestPatchCollections:
    def test_add_multiple_patches(self):
        """Add multiple patches to axes."""
        fig, ax = plt.subplots()
        for i in range(3):
            rect = mpatches.Rectangle((i, 0), 0.8, 1.0, color=f'C{i}')
            ax.add_patch(rect)
        assert len(ax.patches) == 3
        plt.close('all')

    def test_patch_label_legend(self):
        """Patch with label for legend."""
        fig, ax = plt.subplots()
        rect = mpatches.Rectangle((0, 0), 1, 1, color='blue', label='box')
        ax.add_patch(rect)
        ax.legend()
        plt.close('all')

    def test_circle_array(self):
        """Multiple circles at different positions."""
        fig, ax = plt.subplots()
        centers = [(0.2, 0.5), (0.5, 0.5), (0.8, 0.5)]
        for cx, cy in centers:
            ax.add_patch(mpatches.Circle((cx, cy), 0.1, color='red'))
        plt.close('all')


class TestBoxstyles:
    def test_boxstyle_round(self):
        fig, ax = plt.subplots()
        fb = mpatches.FancyBboxPatch((0.1, 0.1), 0.5, 0.3, boxstyle='round')
        ax.add_patch(fb)
        plt.close('all')

    def test_boxstyle_square(self):
        fig, ax = plt.subplots()
        fb = mpatches.FancyBboxPatch((0.1, 0.1), 0.5, 0.3, boxstyle='square')
        ax.add_patch(fb)
        plt.close('all')

    def test_boxstyle_rarrow(self):
        fig, ax = plt.subplots()
        fb = mpatches.FancyBboxPatch((0.1, 0.1), 0.5, 0.3, boxstyle='rarrow')
        ax.add_patch(fb)
        plt.close('all')

    def test_text_bbox(self):
        """Text with bbox uses patch under the hood."""
        fig, ax = plt.subplots()
        ax.text(0.5, 0.5, 'label', bbox=dict(boxstyle='round', fc='white', ec='black'))
        plt.close('all')
