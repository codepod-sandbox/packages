"""Tests for matplotlib.ticker patterns used by LLMs."""

import pytest
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker


class TestLocators:
    def test_auto_locator(self):
        """AutoLocator is the default."""
        fig, ax = plt.subplots()
        ax.plot([1, 2, 3])
        loc = ax.xaxis.get_major_locator()
        assert loc is not None
        plt.close('all')

    def test_set_major_locator(self):
        """ax.xaxis.set_major_locator(MultipleLocator)."""
        fig, ax = plt.subplots()
        ax.plot([1, 10])
        ax.xaxis.set_major_locator(ticker.MultipleLocator(2))
        plt.close('all')

    def test_multiple_locator(self):
        """MultipleLocator ticks at multiples."""
        fig, ax = plt.subplots()
        ax.plot([0, 10])
        ax.xaxis.set_major_locator(ticker.MultipleLocator(5))
        plt.close('all')

    def test_fixed_locator(self):
        """FixedLocator at specified positions."""
        fig, ax = plt.subplots()
        ax.plot([0, 10])
        ax.xaxis.set_major_locator(ticker.FixedLocator([0, 2, 5, 8, 10]))
        plt.close('all')

    def test_max_n_locator(self):
        """MaxNLocator limits number of ticks."""
        fig, ax = plt.subplots()
        ax.plot([0, 100])
        ax.xaxis.set_major_locator(ticker.MaxNLocator(5))
        plt.close('all')

    def test_max_n_locator_integer(self):
        """MaxNLocator(integer=True) for integer ticks."""
        fig, ax = plt.subplots()
        ax.plot([0, 10])
        ax.xaxis.set_major_locator(ticker.MaxNLocator(integer=True))
        plt.close('all')

    def test_linear_locator(self):
        """LinearLocator with numticks."""
        fig, ax = plt.subplots()
        ax.plot([0, 1])
        ax.xaxis.set_major_locator(ticker.LinearLocator(numticks=5))
        plt.close('all')

    def test_log_locator(self):
        """LogLocator for log scale."""
        fig, ax = plt.subplots()
        ax.set_xscale('log')
        ax.plot([1, 1000])
        ax.xaxis.set_major_locator(ticker.LogLocator(base=10))
        plt.close('all')

    def test_null_locator(self):
        """NullLocator removes ticks."""
        fig, ax = plt.subplots()
        ax.plot([1, 2])
        ax.xaxis.set_major_locator(ticker.NullLocator())
        plt.close('all')

    def test_index_locator(self):
        """IndexLocator at base intervals."""
        fig, ax = plt.subplots()
        ax.plot([0, 10])
        ax.xaxis.set_major_locator(ticker.IndexLocator(base=2, offset=0))
        plt.close('all')


class TestFormatters:
    def test_format_str_formatter(self):
        """FormatStrFormatter with format string."""
        fig, ax = plt.subplots()
        ax.plot([1, 2])
        ax.xaxis.set_major_formatter(ticker.FormatStrFormatter('%.2f'))
        plt.close('all')

    def test_scalar_formatter(self):
        """ScalarFormatter is default."""
        fig, ax = plt.subplots()
        ax.plot([1, 2])
        ax.xaxis.set_major_formatter(ticker.ScalarFormatter())
        plt.close('all')

    def test_func_formatter(self):
        """FuncFormatter with custom function."""
        fig, ax = plt.subplots()
        ax.plot([1, 2])
        ax.xaxis.set_major_formatter(ticker.FuncFormatter(lambda x, pos: f'{x:.1f}'))
        plt.close('all')

    def test_fixed_formatter(self):
        """FixedFormatter with label list."""
        fig, ax = plt.subplots()
        ax.plot([0, 5])
        ax.xaxis.set_major_locator(ticker.FixedLocator([0, 1, 2, 3, 4, 5]))
        ax.xaxis.set_major_formatter(ticker.FixedFormatter(['a', 'b', 'c', 'd', 'e', 'f']))
        plt.close('all')

    def test_percent_formatter(self):
        """PercentFormatter displays as percent."""
        fig, ax = plt.subplots()
        ax.plot([0, 1])
        ax.xaxis.set_major_formatter(ticker.PercentFormatter(xmax=1))
        plt.close('all')

    def test_log_formatter(self):
        """LogFormatter for log scale."""
        fig, ax = plt.subplots()
        ax.set_xscale('log')
        ax.plot([1, 1000])
        ax.xaxis.set_major_formatter(ticker.LogFormatter())
        plt.close('all')

    def test_null_formatter(self):
        """NullFormatter removes tick labels."""
        fig, ax = plt.subplots()
        ax.plot([1, 2])
        ax.xaxis.set_major_formatter(ticker.NullFormatter())
        plt.close('all')


class TestTickParams:
    def test_tick_params_axis_both(self):
        """tick_params on both axes."""
        fig, ax = plt.subplots()
        ax.plot([1, 2])
        ax.tick_params(axis='both', which='major', labelsize=8)
        plt.close('all')

    def test_tick_params_direction(self):
        """tick_params with direction=in/out."""
        fig, ax = plt.subplots()
        ax.plot([1, 2])
        ax.tick_params(direction='in')
        plt.close('all')

    def test_tick_params_length_width(self):
        """tick_params with length and width."""
        fig, ax = plt.subplots()
        ax.plot([1, 2])
        ax.tick_params(length=10, width=2)
        plt.close('all')

    def test_tick_params_color(self):
        """tick_params with colors."""
        fig, ax = plt.subplots()
        ax.plot([1, 2])
        ax.tick_params(colors='red', labelcolor='blue')
        plt.close('all')

    def test_tick_params_rotation(self):
        """tick_params with rotation."""
        fig, ax = plt.subplots()
        ax.plot([1, 2])
        ax.tick_params(axis='x', rotation=45)
        plt.close('all')

    def test_minor_ticks(self):
        """Set minor locator."""
        fig, ax = plt.subplots()
        ax.plot([0, 10])
        ax.xaxis.set_minor_locator(ticker.MultipleLocator(1))
        ax.tick_params(which='minor', length=3)
        plt.close('all')
