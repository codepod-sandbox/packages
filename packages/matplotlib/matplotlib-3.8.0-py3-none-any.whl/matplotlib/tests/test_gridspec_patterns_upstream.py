"""
Upstream tests for GridSpec and subplot layout patterns commonly used by LLMs.
"""

import pytest
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec


class TestGridSpecBasic:
    """Basic GridSpec layout patterns."""

    def teardown_method(self):
        plt.close('all')

    def test_gridspec_basic(self):
        fig = plt.figure()
        gs = gridspec.GridSpec(2, 2)
        ax1 = fig.add_subplot(gs[0, 0])
        ax2 = fig.add_subplot(gs[0, 1])
        ax3 = fig.add_subplot(gs[1, 0])
        ax4 = fig.add_subplot(gs[1, 1])
        assert len(fig.axes) == 4

    def test_gridspec_span_columns(self):
        fig = plt.figure()
        gs = gridspec.GridSpec(2, 2)
        ax1 = fig.add_subplot(gs[0, :])  # spans both columns
        ax2 = fig.add_subplot(gs[1, 0])
        ax3 = fig.add_subplot(gs[1, 1])
        assert len(fig.axes) == 3

    def test_gridspec_span_rows(self):
        fig = plt.figure()
        gs = gridspec.GridSpec(2, 2)
        ax1 = fig.add_subplot(gs[:, 0])  # spans both rows
        ax2 = fig.add_subplot(gs[0, 1])
        ax3 = fig.add_subplot(gs[1, 1])
        assert len(fig.axes) == 3

    def test_gridspec_3x3(self):
        fig = plt.figure()
        gs = gridspec.GridSpec(3, 3)
        axes = []
        for i in range(3):
            for j in range(3):
                axes.append(fig.add_subplot(gs[i, j]))
        assert len(fig.axes) == 9

    def test_gridspec_figsize(self):
        fig = plt.figure(figsize=(12, 8))
        gs = gridspec.GridSpec(2, 3)
        for i in range(2):
            for j in range(3):
                fig.add_subplot(gs[i, j])
        assert len(fig.axes) == 6

    def test_gridspec_hspace(self):
        fig = plt.figure()
        gs = gridspec.GridSpec(3, 1, hspace=0.4)
        for i in range(3):
            fig.add_subplot(gs[i])
        assert len(fig.axes) == 3

    def test_gridspec_wspace(self):
        fig = plt.figure()
        gs = gridspec.GridSpec(1, 3, wspace=0.3)
        for j in range(3):
            fig.add_subplot(gs[j])
        assert len(fig.axes) == 3

    def test_gridspec_height_ratios(self):
        fig = plt.figure()
        gs = gridspec.GridSpec(2, 1, height_ratios=[3, 1])
        ax1 = fig.add_subplot(gs[0])
        ax2 = fig.add_subplot(gs[1])
        assert ax1 is not None
        assert ax2 is not None

    def test_gridspec_width_ratios(self):
        fig = plt.figure()
        gs = gridspec.GridSpec(1, 3, width_ratios=[2, 1, 1])
        for j in range(3):
            fig.add_subplot(gs[j])
        assert len(fig.axes) == 3

    def test_figure_add_gridspec(self):
        fig = plt.figure()
        gs = fig.add_gridspec(2, 2)
        ax1 = fig.add_subplot(gs[0, 0])
        ax2 = fig.add_subplot(gs[0, 1])
        ax3 = fig.add_subplot(gs[1, :])
        assert len(fig.axes) == 3


class TestGridSpecSubplotSpec:
    """GridSpec with SubplotSpec patterns."""

    def teardown_method(self):
        plt.close('all')

    def test_subplot_spec_slicing(self):
        fig = plt.figure()
        gs = gridspec.GridSpec(2, 3)
        ax = fig.add_subplot(gs[0, 0:2])  # first row, columns 0-1
        assert ax is not None

    def test_nested_gridspec(self):
        fig = plt.figure()
        outer = gridspec.GridSpec(1, 2)
        inner_gs = gridspec.GridSpecFromSubplotSpec(
            2, 1, subplot_spec=outer[0]
        )
        ax1 = fig.add_subplot(inner_gs[0])
        ax2 = fig.add_subplot(inner_gs[1])
        ax3 = fig.add_subplot(outer[1])
        assert len(fig.axes) == 3

    def test_gridspec_update(self):
        fig = plt.figure()
        gs = gridspec.GridSpec(2, 2)
        gs.update(wspace=0.3, hspace=0.4)
        ax = fig.add_subplot(gs[0, 0])
        assert ax is not None


class TestCommonLayoutPatterns:
    """Common LLM layout patterns using GridSpec."""

    def teardown_method(self):
        plt.close('all')

    def test_main_plot_with_colorbar_column(self):
        """Main plot in left column, colorbar in narrow right column."""
        import numpy as np
        fig = plt.figure(figsize=(8, 6))
        gs = gridspec.GridSpec(1, 2, width_ratios=[20, 1])
        ax_main = fig.add_subplot(gs[0])
        ax_cbar = fig.add_subplot(gs[1])
        data = np.random.rand(10, 10)
        im = ax_main.imshow(data)
        fig.colorbar(im, cax=ax_cbar)

    def test_signal_with_histogram(self):
        """Signal plot on left, histogram on right."""
        import numpy as np
        fig = plt.figure()
        gs = gridspec.GridSpec(1, 2, width_ratios=[3, 1])
        ax_sig = fig.add_subplot(gs[0])
        ax_hist = fig.add_subplot(gs[1])
        data = np.random.randn(100)
        ax_sig.plot(data)
        ax_hist.hist(data, orientation='horizontal')

    def test_dashboard_layout(self):
        """Multi-panel dashboard layout."""
        fig = plt.figure(figsize=(12, 8))
        gs = gridspec.GridSpec(2, 3, figure=fig)
        # Top row: wide plot spanning 2 columns
        ax_top = fig.add_subplot(gs[0, :2])
        ax_tr = fig.add_subplot(gs[0, 2])
        # Bottom row: 3 equal panels
        ax_bl = fig.add_subplot(gs[1, 0])
        ax_bm = fig.add_subplot(gs[1, 1])
        ax_br = fig.add_subplot(gs[1, 2])
        assert len(fig.axes) == 5

    def test_main_and_inset_using_gridspec(self):
        """Main axis with smaller subplot below."""
        fig = plt.figure(figsize=(6, 8))
        gs = gridspec.GridSpec(4, 1)
        ax_main = fig.add_subplot(gs[:3, 0])
        ax_small = fig.add_subplot(gs[3, 0])
        ax_main.plot([1, 2, 3])
        ax_small.plot([3, 2, 1])

    def test_scatter_matrix_layout(self):
        """3x3 grid for scatter matrix."""
        n = 3
        fig = plt.figure(figsize=(8, 8))
        gs = gridspec.GridSpec(n, n, hspace=0.1, wspace=0.1)
        for i in range(n):
            for j in range(n):
                ax = fig.add_subplot(gs[i, j])
                if i == j:
                    ax.hist([1, 2, 3])
                else:
                    ax.scatter([1, 2], [3, 4])
        assert len(fig.axes) == n * n

    def test_gridspec_with_tight_layout(self):
        fig = plt.figure()
        gs = gridspec.GridSpec(2, 2)
        for i in range(2):
            for j in range(2):
                ax = fig.add_subplot(gs[i, j])
                ax.plot([1, 2, 3])
        plt.tight_layout()

    def test_gridspec_constrained_layout(self):
        fig = plt.figure(constrained_layout=True)
        gs = fig.add_gridspec(2, 2)
        for i in range(2):
            for j in range(2):
                fig.add_subplot(gs[i, j])
        assert len(fig.axes) == 4
