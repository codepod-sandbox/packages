"""
Upstream tests for axis limits, margins, invert, and autoscale.
"""

import numpy as np
import pytest
import matplotlib.pyplot as plt


class TestAxisLimits:
    def setup_method(self):
        self.fig, self.ax = plt.subplots()

    def teardown_method(self):
        plt.close('all')

    def test_xlim_set_get(self):
        self.ax.set_xlim(0, 10)
        lo, hi = self.ax.get_xlim()
        assert lo == 0
        assert hi == 10

    def test_ylim_set_get(self):
        self.ax.set_ylim(-5, 5)
        lo, hi = self.ax.get_ylim()
        assert lo == -5
        assert hi == 5

    def test_xlim_tuple(self):
        self.ax.set_xlim((1, 9))
        lo, hi = self.ax.get_xlim()
        assert lo == 1
        assert hi == 9

    def test_ylim_tuple(self):
        self.ax.set_ylim((-3, 3))
        lo, hi = self.ax.get_ylim()
        assert lo == -3
        assert hi == 3

    def test_xlim_left_only(self):
        self.ax.set_xlim(left=2)
        assert self.ax.get_xlim()[0] == 2

    def test_xlim_right_only(self):
        self.ax.set_xlim(right=8)
        assert self.ax.get_xlim()[1] == 8

    def test_ylim_bottom_only(self):
        self.ax.set_ylim(bottom=-1)
        assert self.ax.get_ylim()[0] == -1

    def test_ylim_top_only(self):
        self.ax.set_ylim(top=7)
        assert self.ax.get_ylim()[1] == 7

    def test_axis_equal_string(self):
        # ax.axis('equal'), 'tight', 'off', 'on' should not raise
        self.ax.plot([1, 2], [1, 2])
        self.ax.axis('equal')

    def test_axis_tight(self):
        self.ax.plot([1, 2], [1, 2])
        self.ax.axis('tight')

    def test_axis_off(self):
        self.ax.axis('off')
        assert self.ax.get_visible() is True  # artist visible, axes hidden

    def test_axis_returns_lims(self):
        self.ax.set_xlim(0, 5)
        self.ax.set_ylim(0, 3)
        result = self.ax.axis()
        assert result[0] == 0
        assert result[1] == 5
        assert result[2] == 0
        assert result[3] == 3

    def test_axis_set_lims(self):
        self.ax.axis([1, 2, 3, 4])
        xlo, xhi = self.ax.get_xlim()
        ylo, yhi = self.ax.get_ylim()
        assert xlo == 1
        assert xhi == 2
        assert ylo == 3
        assert yhi == 4

    def test_invert_xaxis(self):
        self.ax.set_xlim(0, 10)
        self.ax.invert_xaxis()
        lo, hi = self.ax.get_xlim()
        assert lo > hi  # inverted

    def test_invert_yaxis(self):
        self.ax.set_ylim(0, 10)
        self.ax.invert_yaxis()
        lo, hi = self.ax.get_ylim()
        assert lo > hi  # inverted

    def test_xaxis_inverted(self):
        self.ax.set_xlim(0, 10)
        assert not self.ax.xaxis_inverted()
        self.ax.invert_xaxis()
        assert self.ax.xaxis_inverted()

    def test_yaxis_inverted(self):
        self.ax.set_ylim(0, 10)
        assert not self.ax.yaxis_inverted()
        self.ax.invert_yaxis()
        assert self.ax.yaxis_inverted()

    def test_set_xbound_get_xbound(self):
        self.ax.set_xbound(-1, 11)
        lo, hi = self.ax.get_xbound()
        assert lo == -1
        assert hi == 11

    def test_set_ybound_get_ybound(self):
        self.ax.set_ybound(-2, 8)
        lo, hi = self.ax.get_ybound()
        assert lo == -2
        assert hi == 8

    def test_margins_symmetric(self):
        self.ax.plot([0, 1])
        self.ax.margins(0.1)

    def test_margins_xy(self):
        self.ax.plot([0, 1])
        self.ax.margins(x=0.05, y=0.15)

    def test_autoscale(self):
        self.ax.plot([1, 2, 3], [4, 5, 6])
        self.ax.autoscale()

    def test_autoscale_axis(self):
        self.ax.plot([1, 2, 3], [4, 5, 6])
        self.ax.autoscale(axis='x')
        self.ax.autoscale(axis='y')
        self.ax.autoscale(axis='both')

    def test_autoscale_enable_false(self):
        self.ax.set_xlim(0, 100)
        self.ax.autoscale(enable=False, axis='x')
        self.ax.plot([1, 2, 3])
        # limits should be unchanged (autoscale disabled)
        assert self.ax.get_xlim()[1] == 100

    def test_set_aspect(self):
        self.ax.set_aspect('equal')
        self.ax.set_aspect('auto')
        self.ax.set_aspect(1.5)

    def test_get_aspect(self):
        self.ax.set_aspect('equal')
        assert self.ax.get_aspect() == 'equal'

    def test_limits_after_plot(self):
        self.ax.plot([0, 1, 2], [0, 4, 2])
        lo, hi = self.ax.get_xlim()
        assert lo <= 0
        assert hi >= 2
        lo, hi = self.ax.get_ylim()
        assert lo <= 0
        assert hi >= 4
