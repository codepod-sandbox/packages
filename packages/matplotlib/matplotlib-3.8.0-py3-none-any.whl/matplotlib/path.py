"""matplotlib.path — Path class for defining arbitrary paths."""


class Path:
    """A series of possibly disconnected, possibly closed, line and curve segments.

    Parameters
    ----------
    vertices : list of (x, y) tuples
        The vertices of the path.
    codes : list of int, optional
        Path codes (MOVETO, LINETO, etc.). If None, all are LINETO
        except the first which is MOVETO.
    """

    # Path code constants (match upstream matplotlib values)
    STOP = 0
    MOVETO = 1
    LINETO = 2
    CURVE3 = 3
    CURVE4 = 4
    CLOSEPOLY = 79

    def __init__(self, vertices, codes=None):
        self.vertices = list(vertices)
        if codes is None:
            codes = [self.MOVETO] + [self.LINETO] * (len(vertices) - 1)
        self.codes = list(codes)

    def __len__(self):
        return len(self.vertices)

    def __repr__(self):
        return f"Path({self.vertices!r}, {self.codes!r})"

    @classmethod
    def unit_circle(cls):
        """Return a Path for the unit circle (approximated with cubic beziers)."""
        import math
        # Use 4 cubic bezier segments to approximate a circle
        k = 0.5522847498  # magic constant for circle approximation
        verts = [
            (1, 0), (1, k), (k, 1), (0, 1),
            (-k, 1), (-1, k), (-1, 0),
            (-1, -k), (-k, -1), (0, -1),
            (k, -1), (1, -k), (1, 0),
            (0, 0),
        ]
        codes = [
            cls.MOVETO, cls.CURVE4, cls.CURVE4, cls.CURVE4,
            cls.CURVE4, cls.CURVE4, cls.CURVE4,
            cls.CURVE4, cls.CURVE4, cls.CURVE4,
            cls.CURVE4, cls.CURVE4, cls.CURVE4,
            cls.CLOSEPOLY,
        ]
        return cls(verts, codes)

    @classmethod
    def unit_rectangle(cls):
        """Return a Path for the unit rectangle (0, 0) to (1, 1)."""
        verts = [(0, 0), (1, 0), (1, 1), (0, 1), (0, 0)]
        codes = [cls.MOVETO, cls.LINETO, cls.LINETO, cls.LINETO, cls.CLOSEPOLY]
        return cls(verts, codes)

    @classmethod
    def make_compound_path(cls, *args):
        """Concatenate multiple paths into one compound path."""
        verts = []
        codes = []
        for path in args:
            verts.extend(path.vertices)
            codes.extend(path.codes)
        return cls(verts, codes)
