"""numpy.lib stub."""
