"""Aggregation, statistics, NaN-aware reductions, set operations."""
import math as _math
import _numpy_native as _native
from _numpy_native import ndarray
from ._helpers import (
    AxisError, _ObjectArray, _copy_into,
    _builtin_range, _builtin_min, _builtin_max,
)
from ._core_types import dtype, _ScalarType, _normalize_dtype
from ._creation import array, asarray, zeros, ones, empty, arange, concatenate, linspace, full

# Keep builtin sum reference before it gets shadowed
_builtin_sum = __builtins__["sum"] if isinstance(__builtins__, dict) else __import__("builtins").sum

__all__ = [
    # Internal helper
    '_dtype_cast',
    # Basic reductions
    'sum', 'prod', 'cumsum', 'cumprod', 'diff', 'ediff1d', 'gradient',
    'trapz', 'trapezoid', 'cumulative_trapezoid',
    # Statistics
    'mean', 'std', 'var', 'median', 'average', 'cov', 'corrcoef',
    # Extrema
    'max', 'min', 'amax', 'amin', 'argmax', 'argmin', 'ptp',
    # NaN-aware
    'nansum', 'nanmean', 'nanstd', 'nanvar', 'nanmin', 'nanmax',
    'nanargmin', 'nanargmax', 'nanprod', 'nancumsum', 'nancumprod',
    'nanmedian', 'nanpercentile', 'nanquantile',
    # Quantile
    'quantile', 'percentile',
    # Boolean
    'all', 'any', 'count_nonzero',
    # Search
    'nonzero', 'flatnonzero', 'argwhere', 'searchsorted',
    # Set operations
    'intersect1d', 'union1d', 'setdiff1d', 'setxor1d', 'in1d', 'isin',
    # Memory
    'may_share_memory', 'shares_memory',
]


def _dtype_cast(result, dtype):
    """Cast result to dtype if dtype is not None."""
    if dtype is not None:
        result = asarray(result).astype(str(dtype) if not isinstance(dtype, str) else dtype)
    return result


def sum(a, axis=None, dtype=None, out=None, keepdims=False, initial=None, where=True):
    if not isinstance(a, ndarray):
        # For plain lists/tuples, convert to array; for other iterables use builtin sum
        if isinstance(a, (list, tuple)):
            a = asarray(a)
        else:
            return _builtin_sum(a)
    if where is not True:
        w = asarray(where).astype("bool").astype("float64")
        a = a * w
    if axis is not None:
        result = a.sum(axis, keepdims)
    else:
        result = a.sum(None, keepdims)
    if dtype is not None:
        result = _dtype_cast(result, dtype)
    if initial is not None:
        result = result + initial
    return result


def prod(a, axis=None, dtype=None, out=None, keepdims=False, initial=None, where=True):
    if not isinstance(a, ndarray):
        a = asarray(a)
    if where is not True:
        w = asarray(where).astype("bool").astype("float64")
        a = a * w + (1.0 - w)
    result = a.prod(axis, keepdims)
    if dtype is not None:
        result = _dtype_cast(result, dtype)
    if initial is not None:
        result = result * initial
    return result


def cumsum(a, axis=None, dtype=None, out=None):
    if isinstance(a, ndarray):
        result = a.cumsum(axis)
    else:
        result = array(a).cumsum(axis)
    return _dtype_cast(result, dtype)


def cumprod(a, axis=None, dtype=None, out=None):
    if isinstance(a, ndarray):
        result = a.cumprod(axis)
    else:
        result = array(a).cumprod(axis)
    return _dtype_cast(result, dtype)


def diff(a, n=1, axis=-1, prepend=None, append=None):
    if not isinstance(a, ndarray):
        a = array(a)
    if axis is not None and axis < 0:
        axis = a.ndim + axis
    if prepend is not None:
        prepend = asarray(prepend)
        if prepend.ndim == 0:
            prepend = array([float(prepend)])
        a = concatenate([prepend, a])
    if append is not None:
        append = asarray(append)
        if append.ndim == 0:
            append = array([float(append)])
        a = concatenate([a, append])
    return _native.diff(a, n, axis)


def mean(a, axis=None, dtype=None, out=None, keepdims=False, where=True):
    from numpy.ma import MaskedArray as _MA
    if isinstance(a, _MA):
        import numpy as _np
        filled = a.filled(0.0)
        not_mask = _np.logical_not(a.mask).astype("float64")
        s = sum(filled * not_mask, axis=axis, keepdims=keepdims)
        c = sum(not_mask, axis=axis, keepdims=keepdims)
        result = s / c
        if out is not None and isinstance(out, _MA):
            _copy_into(out.data, result if isinstance(result, ndarray) else asarray(result))
            return out
        if isinstance(result, ndarray):
            return _MA(result, mask=zeros(result.shape).astype("bool"))
        return result
    if not isinstance(a, ndarray):
        a = asarray(a)
    if a.size == 0:
        import warnings as _w
        _w.warn("Mean of empty slice.", RuntimeWarning, stacklevel=2)
        result = float('nan')
        if out is not None:
            out[()] = result
            return out
        return result
    if where is not True:
        w = asarray(where).astype("bool").astype("float64")
        s = (a * w).sum(axis, keepdims)
        c = w.sum(axis, keepdims)
        result = s / c
    elif axis is not None:
        if isinstance(axis, tuple):
            # Compute n for the tuple axes
            n = 1
            for ax in axis:
                n *= a.shape[ax]
            result = a.sum(axis, False) / n
            if keepdims:
                new_shape = list(a.shape)
                for ax in axis:
                    new_shape[ax] = 1
                result = result.reshape(tuple(new_shape))
        else:
            result = a.mean(axis, keepdims)
    else:
        result = a.mean(None, keepdims)
    if keepdims and not isinstance(result, ndarray):
        result = array([float(result)]).reshape((1,) * a.ndim)
    if dtype is not None:
        result = _dtype_cast(result, dtype)
    if out is not None:
        if isinstance(out, ndarray):
            if out.size == 1:
                out[0] = float(result) if not isinstance(result, ndarray) else float(result.flatten()[0])
            else:
                flat_r = result.flatten() if isinstance(result, ndarray) else array([result])
                for i in range(out.size):
                    out.flatten()[i] = float(flat_r[i])
        return out
    return result


def std(a, axis=None, dtype=None, out=None, ddof=0, keepdims=False, where=True, mean=None, correction=None):
    if correction is not None and ddof != 0:
        raise ValueError("ddof and correction can't be provided simultaneously.")
    if correction is not None:
        ddof = correction
    from numpy.ma import MaskedArray as _MA
    if isinstance(a, _MA):
        v = var(a, axis=axis, ddof=ddof, keepdims=keepdims, where=where, mean=mean)
        import numpy as _np
        if isinstance(v, _MA):
            result = _MA(_np.sqrt(v.data), mask=v.mask)
        else:
            result = _np.sqrt(v) if isinstance(v, ndarray) else _math.sqrt(v)
        if out is not None and isinstance(out, _MA):
            r_arr = result.data if isinstance(result, _MA) else (result if isinstance(result, ndarray) else asarray(result))
            _copy_into(out.data, r_arr)
            return out
        return result
    if isinstance(a, complex) and not isinstance(a, (int, float)):
        return 0.0
    if not isinstance(a, ndarray):
        a = asarray(a)
    if a.size == 0:
        import warnings as _w
        _w.warn("Degrees of freedom <= 0 for slice", RuntimeWarning, stacklevel=2)
        result = float('nan')
        if out is not None:
            if isinstance(out, ndarray) and out.size == 1:
                out[0] = result
            return out
        return result
    import numpy as _np
    result = _np.sqrt(var(a, axis=axis, ddof=ddof, keepdims=keepdims, where=where, mean=mean))
    if dtype is not None:
        result = _dtype_cast(result, dtype)
    if out is not None:
        if isinstance(out, ndarray) and out.size == 1:
            out[0] = float(result) if not isinstance(result, ndarray) else float(result.flatten()[0])
        return out
    if isinstance(a, ndarray) and axis is None and not keepdims and not isinstance(result, ndarray):
        from ._core_types import float64, complex128
        if isinstance(result, complex):
            return complex128(result)
        return float64(result)
    return result


def var(a, axis=None, dtype=None, out=None, ddof=0, keepdims=False, where=True, mean=None, correction=None):
    if correction is not None and ddof != 0:
        raise ValueError("ddof and correction can't be provided simultaneously.")
    if correction is not None:
        ddof = correction
    from numpy.ma import MaskedArray as _MA
    if isinstance(a, _MA):
        import numpy as _np
        filled = a.filled(0.0)
        not_mask = _np.logical_not(a.mask).astype("float64")
        c = sum(not_mask, axis=axis, keepdims=True)
        if mean is not None:
            m = mean.data if isinstance(mean, _MA) else (mean if isinstance(mean, ndarray) else asarray(mean))
        else:
            m = sum(filled * not_mask, axis=axis, keepdims=True) / c
        diff = (filled - m) ** 2
        c_out = sum(not_mask, axis=axis, keepdims=keepdims)
        result = sum(diff * not_mask, axis=axis, keepdims=keepdims) / (c_out - ddof)
        if out is not None and isinstance(out, _MA):
            _copy_into(out.data, result if isinstance(result, ndarray) else asarray(result))
            return out
        if isinstance(result, ndarray):
            return _MA(result, mask=zeros(result.shape).astype("bool"))
        return result
    if isinstance(a, complex) and not isinstance(a, (int, float)):
        # scalar complex: var of single value is 0
        return 0.0
    if not isinstance(a, ndarray):
        a = asarray(a)
    if a.size == 0:
        import warnings as _w
        _w.warn("Degrees of freedom <= 0 for slice", RuntimeWarning, stacklevel=2)
        result = float('nan')
        if out is not None:
            if isinstance(out, ndarray) and out.size == 1:
                out[0] = result
            return out
        return result
    _is_complex = str(a.dtype).startswith("complex")
    def _sq_dev(diff):
        if _is_complex:
            return abs(diff) ** 2
        return diff ** 2
    if where is not True:
        w = asarray(where).astype("bool").astype("float64")
        c_full = w.sum(axis, True)  # keepdims for mean computation
        if mean is not None:
            m = asarray(mean)
        else:
            m = (a * w).sum(axis, True) / c_full
        c_out = w.sum(axis, keepdims)  # match output keepdims
        if ddof == 0:
            result = (_sq_dev(a - m) * w).sum(axis, keepdims) / c_out
        else:
            result = (_sq_dev(a - m) * w).sum(axis, keepdims) / (c_out - ddof)
        if not keepdims and isinstance(result, ndarray) and result.ndim > 0:
            result = result.squeeze()
    elif axis is not None:
        # Compute n for the reduction axes
        if isinstance(axis, int):
            n = a.shape[axis]
        elif isinstance(axis, tuple):
            n = 1
            for ax in axis:
                n *= a.shape[ax]
        else:
            n = a.size
        def _sum_keepdims(arr, ax, kd):
            """Sum with keepdims support for tuple axes."""
            r = arr.sum(ax, False)
            if kd and isinstance(ax, tuple):
                new_shape = list(arr.shape)
                for _ax in ax:
                    new_shape[_ax] = 1
                r = r.reshape(tuple(new_shape))
            elif kd:
                r = arr.sum(ax, True)
                return r
            return r
        if mean is not None:
            m = asarray(mean)
        else:
            m = _sum_keepdims(a, axis, True) / n
        result = _sum_keepdims(_sq_dev(a - m), axis, keepdims) / (n - ddof)
        if not keepdims and isinstance(result, ndarray) and result.ndim == 0:
            result = float(result)
    elif mean is not None:
        m = asarray(mean)
        n = a.size
        result = _sq_dev(a - m).sum() / (n - ddof)
        if isinstance(result, ndarray) and result.ndim == 0:
            result = float(result)
    elif _is_complex:
        m = a.sum(None, True) / a.size
        result = _sq_dev(a - m).sum() / (a.size - ddof)
        if isinstance(result, ndarray) and result.ndim == 0:
            result = float(result)
    else:
        result = a.var(None, ddof, keepdims)
    if dtype is not None:
        result = _dtype_cast(result, dtype)
    if out is not None:
        if isinstance(out, ndarray) and out.size == 1:
            out[0] = float(result) if not isinstance(result, ndarray) else float(result.flatten()[0])
        return out
    return result


def nansum(a, axis=None, dtype=None, out=None, keepdims=False, initial=None, where=True):
    if not isinstance(a, ndarray):
        a = array(a)
    if where is not True:
        w = asarray(where).astype("bool").astype("float64")
        a = a * w
    result = _native.nansum(a, axis, keepdims)
    if dtype is not None:
        result = _dtype_cast(result, dtype)
    if initial is not None:
        result = result + initial
    return result


def nanmean(a, axis=None, dtype=None, out=None, keepdims=False, where=True):
    if not isinstance(a, ndarray):
        a = array(a)
    if where is not True:
        w = asarray(where).astype("bool").astype("float64")
        s = (a * w).sum(axis, keepdims)
        c = w.sum(axis, keepdims)
        result = s / c
    else:
        result = _native.nanmean(a, axis, keepdims)
    if dtype is not None:
        result = _dtype_cast(result, dtype)
    return result


def nanstd(a, axis=None, dtype=None, out=None, ddof=0, keepdims=False, where=True):
    if not isinstance(a, ndarray):
        a = array(a)
    if where is not True:
        import numpy as _np
        result = _np.sqrt(nanvar(a, axis=axis, ddof=ddof, keepdims=keepdims, where=where))
    else:
        result = _native.nanstd(a, axis, ddof, keepdims)
    if dtype is not None:
        result = _dtype_cast(result, dtype)
    return result


def nanvar(a, axis=None, dtype=None, out=None, ddof=0, keepdims=False, where=True):
    if not isinstance(a, ndarray):
        a = array(a)
    if where is not True:
        w = asarray(where).astype("bool").astype("float64")
        c = w.sum(axis, True)
        m = (a * w).sum(axis, True) / c
        if ddof == 0:
            result = ((a - m) ** 2 * w).sum(axis, keepdims) / c
        else:
            result = ((a - m) ** 2 * w).sum(axis, keepdims) / (c - ddof)
        if not keepdims and isinstance(result, ndarray) and result.ndim > 0:
            result = result.squeeze()
    else:
        result = _native.nanvar(a, axis, ddof, keepdims)
    if dtype is not None:
        result = _dtype_cast(result, dtype)
    return result


def nanmin(a, axis=None, out=None, keepdims=False):
    if not isinstance(a, ndarray):
        a = array(a)
    return _native.nanmin(a, axis, keepdims)


def nanmax(a, axis=None, out=None, keepdims=False):
    if not isinstance(a, ndarray):
        a = array(a)
    return _native.nanmax(a, axis, keepdims)


def nanargmin(a, axis=None, out=None):
    if not isinstance(a, ndarray):
        a = array(a)
    return _native.nanargmin(a, axis)


def nanargmax(a, axis=None, out=None):
    if not isinstance(a, ndarray):
        a = array(a)
    return _native.nanargmax(a, axis)


def nanprod(a, axis=None, dtype=None, out=None, keepdims=False, initial=None, where=True):
    if not isinstance(a, ndarray):
        a = array(a)
    if where is not True:
        w = asarray(where).astype("bool").astype("float64")
        a = a * w + (1.0 - w)
    result = _native.nanprod(a, axis, keepdims)
    if dtype is not None:
        result = _dtype_cast(result, dtype)
    if initial is not None:
        result = result * initial
    return result


def nancumsum(a, axis=None, dtype=None, out=None):
    if not isinstance(a, ndarray):
        a = array(a)
    return _native.nancumsum(a, axis)


def nancumprod(a, axis=None, dtype=None, out=None):
    if not isinstance(a, ndarray):
        a = array(a)
    return _native.nancumprod(a, axis)


def _apply_keepdims(result, a, axis):
    """Expand reduced axis back to size-1 when keepdims=True."""
    if isinstance(result, ndarray):
        shape = list(a.shape)
        shape[axis] = 1
        return result.reshape(shape)
    else:
        # scalar result - wrap in array with expanded dims
        shape = [1] * a.ndim
        return array([float(result)]).reshape(shape)


def quantile(a, q, axis=None, out=None, overwrite_input=False, method="linear", keepdims=False):
    if not isinstance(a, ndarray):
        a = array(a)
    if isinstance(q, (list, tuple, ndarray)):
        q_list = q.tolist() if isinstance(q, ndarray) else list(q)
        results = [_native.quantile(a, float(qi), axis) for qi in q_list]
        import numpy as _np
        return array(results) if axis is None else _np.stack(results)
    result = _native.quantile(a, float(q), axis)
    if keepdims and axis is not None:
        result = _apply_keepdims(result, a, axis)
    return result


def percentile(a, q, axis=None, out=None, overwrite_input=False, method="linear", keepdims=False):
    if not isinstance(a, ndarray):
        a = array(a)
    if isinstance(q, (list, tuple, ndarray)):
        q_list = q.tolist() if isinstance(q, ndarray) else list(q)
        results = [_native.percentile(a, float(qi), axis) for qi in q_list]
        import numpy as _np
        return array(results) if axis is None else _np.stack(results)
    result = _native.percentile(a, float(q), axis)
    if keepdims and axis is not None:
        result = _apply_keepdims(result, a, axis)
    return result


def median(a, axis=None, out=None, overwrite_input=False, keepdims=False):
    if not isinstance(a, ndarray):
        a = array(a)
    result = _native.quantile(a, 0.5, axis)
    if keepdims and axis is not None:
        result = _apply_keepdims(result, a, axis)
    return result


def cov(m, y=None, rowvar=True, bias=False, ddof=None, fweights=None, aweights=None):
    if not isinstance(m, ndarray):
        m = array(m)
    _ddof = ddof if ddof is not None else (0 if bias else 1)
    if y is not None:
        if not isinstance(y, ndarray):
            y = array(y)
        return _native.cov(m, y, rowvar, _ddof)
    return _native.cov(m, None, rowvar, _ddof)


def corrcoef(x, y=None, rowvar=True):
    if not isinstance(x, ndarray):
        x = array(x)
    if y is not None:
        if not isinstance(y, ndarray):
            y = array(y)
        return _native.corrcoef(x, y, rowvar)
    return _native.corrcoef(x, None, rowvar)


def average(a, axis=None, weights=None, returned=False, keepdims=False):
    """Compute the weighted average along the specified axis."""
    a = asarray(a)
    if weights is None:
        avg = mean(a, axis=axis)
        if returned:
            if axis is None:
                return avg, float(a.size)
            return avg, full(avg.shape, float(a.shape[axis]))
        return avg
    weights = asarray(weights)
    wsum = sum(a * weights, axis=axis)
    wt = sum(weights, axis=axis)
    avg = wsum / wt
    if returned:
        return avg, wt
    return avg


def _nan_quantile_impl(a, q, axis):
    """Helper for nanmedian/nanpercentile/nanquantile with axis support."""
    a = asarray(a)
    if axis is None:
        flat = a.flatten()
        n = flat.size
        vals = []
        for i in range(n):
            v = flat[i]
            if v == v:
                vals.append(v)
        if len(vals) == 0:
            return float('nan')
        vals.sort()
        idx = q * (len(vals) - 1)
        lo = int(idx)
        hi = lo + 1
        if hi >= len(vals):
            return vals[lo]
        frac = idx - lo
        return vals[lo] * (1 - frac) + vals[hi] * frac
    # With axis: apply along axis manually
    # Move target axis to last, then iterate over other dims
    # Simplified: just handle 2D case
    if a.ndim == 1:
        return _nan_quantile_impl(a, q, None)
    results = []
    if axis == 0:
        for j in range(a.shape[1]):
            col = array([a[i][j] for i in range(a.shape[0])])
            results.append(_nan_quantile_impl(col, q, None))
    else:
        for i in range(a.shape[0]):
            results.append(_nan_quantile_impl(a[i], q, None))
    return array(results)


def nanmedian(a, axis=None, out=None, overwrite_input=False, keepdims=False):
    """Compute the median along the specified axis, ignoring NaNs."""
    a = asarray(a)
    if axis is not None:
        # For axis support, fall back to sorting approach
        return _nan_quantile_impl(a, 0.5, axis)
    # Flatten, filter NaNs, compute median of remaining
    flat = a.flatten()
    n = flat.size
    vals = []
    for i in range(n):
        v = flat[i]
        if v == v:  # not NaN
            vals.append(v)
    if len(vals) == 0:
        return float('nan')
    vals.sort()
    mid = len(vals) // 2
    if len(vals) % 2 == 0:
        return (vals[mid - 1] + vals[mid]) / 2.0
    return vals[mid]


def nanpercentile(a, q, axis=None, out=None, overwrite_input=False, method="linear", keepdims=False):
    """Compute the qth percentile, ignoring NaNs."""
    return _nan_quantile_impl(asarray(a), q / 100.0, axis)


def nanquantile(a, q, axis=None, out=None, overwrite_input=False, method="linear", keepdims=False):
    """Compute the qth quantile, ignoring NaNs."""
    return _nan_quantile_impl(asarray(a), q, axis)


def ediff1d(ary, to_end=None, to_begin=None):
    """The differences between consecutive elements of an array."""
    ary = asarray(ary).flatten()
    n = ary.size
    diffs = []
    if to_begin is not None:
        if isinstance(to_begin, (int, float)):
            diffs.append(float(to_begin))
        else:
            tb = asarray(to_begin).flatten()
            for i in range(tb.size):
                diffs.append(tb[i])
    for i in range(1, n):
        diffs.append(ary[i] - ary[i - 1])
    if to_end is not None:
        if isinstance(to_end, (int, float)):
            diffs.append(float(to_end))
        else:
            te = asarray(to_end).flatten()
            for i in range(te.size):
                diffs.append(te[i])
    return array(diffs)


def max(a, axis=None, out=None, keepdims=False, where=True):
    if not isinstance(a, ndarray):
        a = asarray(a)
    if where is not True:
        w = asarray(where).astype("bool")
        fill_val = float('-inf')
        flat_a = a.flatten().tolist()
        flat_w = w.flatten().tolist()
        masked = [v if m else fill_val for v, m in zip(flat_a, flat_w)]
        a = array(masked).reshape(a.shape)
    if axis is not None:
        return a.max(axis, keepdims)
    return a.max(None, keepdims)


amax = max


def min(a, axis=None, out=None, keepdims=False, where=True):
    if not isinstance(a, ndarray):
        a = asarray(a)
    if where is not True:
        w = asarray(where).astype("bool")
        fill_val = float('inf')
        flat_a = a.flatten().tolist()
        flat_w = w.flatten().tolist()
        masked = [v if m else fill_val for v, m in zip(flat_a, flat_w)]
        a = array(masked).reshape(a.shape)
    if axis is not None:
        return a.min(axis, keepdims)
    return a.min(None, keepdims)


amin = min


def argmax(a, axis=None, out=None, keepdims=False):
    if not isinstance(a, ndarray):
        a = asarray(a)
    return a.argmax(axis)


def argmin(a, axis=None, out=None, keepdims=False):
    if not isinstance(a, ndarray):
        a = asarray(a)
    return a.argmin(axis)


def ptp(a, axis=None):
    if not isinstance(a, ndarray):
        a = asarray(a)
    return a.max(axis) - a.min(axis)


def argwhere(a):
    if not isinstance(a, ndarray):
        a = asarray(a)
    # Rust argwhere only handles float64; cast integer/bool arrays
    dt = str(a.dtype)
    if dt in ("int32", "int64", "int8", "int16", "uint8", "uint16", "uint32", "uint64", "bool"):
        a = a.astype("float64")
    return _native.argwhere(a)


def nonzero(a):
    if isinstance(a, _ObjectArray):
        indices = []
        for i, v in enumerate(a._data):
            if bool(v):
                indices.append(i)
        return (array(indices, dtype="int64"),) if indices else (array([], dtype="int64"),)
    if not isinstance(a, ndarray):
        a = asarray(a)
    if a.ndim == 0:
        raise ValueError("Calling nonzero on 0d arrays is not allowed. Use np.atleast_1d(a).nonzero() instead.")
    # Rust nonzero only handles float64; cast integer/bool arrays
    dt = str(a.dtype)
    if dt in ("int32", "int64", "int8", "int16", "uint8", "uint16", "uint32", "uint64", "bool"):
        a = a.astype("float64")
    return _native.nonzero(a)


def count_nonzero(a, axis=None, *, keepdims=False):
    if not isinstance(a, ndarray):
        a = asarray(a)
    # Empty tuple axis means element-wise (no reduction)
    if isinstance(axis, tuple) and len(axis) == 0:
        return a.astype("bool")
    # Validate axis
    if axis is not None and not isinstance(axis, (int, tuple)):
        if isinstance(axis, ndarray):
            raise TypeError("axis must be an integer or a tuple of integers")
        raise TypeError("'{}' object cannot be interpreted as an integer".format(type(axis).__name__))
    if isinstance(axis, tuple):
        # Check for duplicate axes
        normed = []
        for ax in axis:
            n = ax if ax >= 0 else ax + a.ndim
            if n in normed:
                raise ValueError("duplicate value in 'axis'")
            if n < 0 or n >= a.ndim:
                raise AxisError(ax, a.ndim)
            normed.append(n)
    elif isinstance(axis, int):
        n = axis if axis >= 0 else axis + a.ndim
        if n < 0 or n >= a.ndim:
            raise AxisError(axis, a.ndim)
    # Rust count_nonzero only handles float64; cast integer/bool arrays
    dt = str(a.dtype)
    if dt in ("int32", "int64", "int8", "int16", "uint8", "uint16", "uint32", "uint64", "bool"):
        a = a.astype("float64")
    if axis is None:
        result = _native.count_nonzero(a)
        if keepdims:
            return array([float(result)]).reshape((1,) * a.ndim).astype("int64")
        return result
    # Build a boolean mask (nonzero -> 1.0, zero -> 0.0), then sum along axis
    flat = a.flatten().tolist()
    def _is_nonzero(v):
        if isinstance(v, tuple):  # complex (re, im) representation
            return v[0] != 0.0 or v[1] != 0.0
        return v != 0.0
    mask_data = [1.0 if _is_nonzero(v) else 0.0 for v in flat]
    mask = array(mask_data).reshape(a.shape)
    result = mask.sum(axis, keepdims)
    # Convert to integer values
    if isinstance(result, ndarray):
        return result.astype("int64")
    return int(result)


def flatnonzero(a):
    """Return indices of non-zero elements in the flattened array."""
    a = asarray(a).flatten()
    indices_list = []
    for i in range(len(a)):
        if float(a[i]) != 0.0:
            indices_list.append(i)
    return array(indices_list)


def searchsorted(a, v, side="left", sorter=None):
    if not isinstance(a, ndarray):
        a = asarray(a)
    scalar_v = not isinstance(v, (ndarray, list, tuple))
    if not isinstance(v, ndarray):
        v = array([v]) if scalar_v else asarray(v)
    result = _native.searchsorted(a, v, side)
    if scalar_v and isinstance(result, ndarray) and result.size == 1:
        return int(float(result.flatten()[0]))
    return result


def gradient(f, *varargs, axis=None, edge_order=1):
    if not isinstance(f, ndarray):
        f = array(f)
    if f.ndim == 1:
        # 1D case: single spacing
        spacing = float(varargs[0]) if varargs else 1.0
        return _native.gradient(f, spacing)
    # nD case
    if axis is not None:
        # gradient along specific axis/axes
        if isinstance(axis, int):
            ax = axis
            if ax < 0:
                ax = f.ndim + ax
            sp = float(varargs[0]) if varargs else 1.0
            result = _native.gradient(f, sp)
            if isinstance(result, (list, tuple)):
                return result[ax]
            return result
        # multiple axes
        results = []
        for i, ax in enumerate(axis):
            sp = float(varargs[i]) if i < len(varargs) else 1.0
            grads = _native.gradient(f, sp)
            if isinstance(grads, (list, tuple)):
                a = ax
                if a < 0:
                    a = f.ndim + a
                results.append(grads[a])
            else:
                results.append(grads)
        return results
    # All axes
    if len(varargs) == 0:
        return _native.gradient(f, 1.0)
    elif len(varargs) == 1:
        return _native.gradient(f, float(varargs[0]))
    else:
        # Different spacing per axis
        results = []
        for i in range(f.ndim):
            sp = float(varargs[i]) if i < len(varargs) else 1.0
            grads = _native.gradient(f, sp)
            if isinstance(grads, (list, tuple)):
                results.append(grads[i])
            else:
                results.append(grads)
        return results


def trapz(y, x=None, dx=1.0, axis=-1):
    """Integrate along the given axis using the composite trapezoidal rule."""
    y = asarray(y)
    if y.ndim == 1:
        n = y.size
        if x is not None:
            x = asarray(x).flatten()
            total = 0.0
            for i in range(1, n):
                total += (x[i] - x[i-1]) * (y[i] + y[i-1]) / 2.0
            return total
        else:
            total = 0.0
            for i in range(1, n):
                total += dx * (y[i] + y[i-1]) / 2.0
            return total
    # For multi-dim, apply along specified axis
    if axis == -1:
        axis = y.ndim - 1
    if y.ndim == 2:
        results = []
        if axis == 0:
            for j in range(y.shape[1]):
                col = array([y[i][j] for i in range(y.shape[0])])
                results.append(trapz(col, dx=dx))
        else:
            for i in range(y.shape[0]):
                results.append(trapz(y[i], dx=dx))
        return array(results)
    # General nD case
    if axis < 0:
        axis = y.ndim + axis
    # Move target axis to last, flatten leading dims, apply trapz per lane
    import numpy as _np
    y_moved = _np.moveaxis(y, axis, -1)
    result_shape = list(y_moved.shape[:-1])
    n_lane = y_moved.shape[-1]
    lead = 1
    for s in result_shape:
        lead *= s
    y_flat = y_moved.reshape((lead, n_lane))
    flat_results = []
    y_list = y_flat.tolist()
    for i in range(lead):
        row = array(y_list[i])
        if x is not None:
            flat_results.append(float(trapz(row, x=asarray(x), dx=dx)))
        else:
            flat_results.append(float(trapz(row, dx=dx)))
    if not result_shape:
        return float(flat_results[0])
    return array(flat_results).reshape(result_shape)


trapezoid = trapz


def cumulative_trapezoid(y, x=None, dx=1.0, axis=-1, initial=None):
    """Cumulatively integrate y(x) using the trapezoidal rule."""
    y = asarray(y)
    if y.ndim == 1:
        n = y.size
        result = []
        if initial is not None:
            result.append(float(initial))
        if x is not None:
            x = asarray(x).flatten()
            for i in range(1, n):
                result.append((result[-1] if result else 0.0) + (x[i] - x[i-1]) * (y[i] + y[i-1]) / 2.0)
        else:
            for i in range(1, n):
                result.append((result[-1] if result else 0.0) + dx * (y[i] + y[i-1]) / 2.0)
        return array(result)
    # For multi-dim, apply along specified axis
    import numpy as _np
    if axis == -1:
        axis = y.ndim - 1
    if axis < 0:
        axis = y.ndim + axis
    y_moved = _np.moveaxis(y, axis, -1)
    result_shape = list(y_moved.shape[:-1])
    n_lane = y_moved.shape[-1]
    lead = 1
    for s in result_shape:
        lead *= s
    y_flat = y_moved.reshape((lead, n_lane))
    y_list = y_flat.tolist()
    flat_results = []
    for i in range(lead):
        row = array(y_list[i])
        cum = cumulative_trapezoid(row, x=x, dx=dx, axis=-1, initial=initial)
        flat_results.append(cum.tolist())
    out_lane = len(flat_results[0])
    result_flat = []
    for row in flat_results:
        result_flat.extend(row)
    out = array(result_flat).reshape(result_shape + [out_lane])
    return _np.moveaxis(out, -1, axis)


def intersect1d(ar1, ar2, assume_unique=False, return_indices=False):
    if not isinstance(ar1, ndarray):
        ar1 = array(ar1)
    if not isinstance(ar2, ndarray):
        ar2 = array(ar2)
    if not return_indices:
        return _native.intersect1d(ar1, ar2)
    # Find intersection with indices
    flat1 = ar1.flatten().tolist()
    flat2 = ar2.flatten().tolist()
    s1 = set(flat1)
    s2 = set(flat2)
    common = sorted(s1 & s2)
    ind1 = [flat1.index(v) for v in common]
    ind2 = [flat2.index(v) for v in common]
    return array(common), array(ind1), array(ind2)


def union1d(ar1, ar2):
    if not isinstance(ar1, ndarray):
        ar1 = array(ar1)
    if not isinstance(ar2, ndarray):
        ar2 = array(ar2)
    return _native.union1d(ar1, ar2)


def setdiff1d(ar1, ar2, assume_unique=False):
    if not isinstance(ar1, ndarray):
        ar1 = array(ar1)
    if not isinstance(ar2, ndarray):
        ar2 = array(ar2)
    return _native.setdiff1d(ar1, ar2)


def setxor1d(ar1, ar2, assume_unique=False):
    """Return sorted, unique values that are in only one of the input arrays."""
    if not isinstance(ar1, ndarray):
        ar1 = array(ar1)
    if not isinstance(ar2, ndarray):
        ar2 = array(ar2)
    import numpy as _np
    u1 = _np.unique(ar1)
    u2 = _np.unique(ar2)
    # Elements in ar1 but not ar2, plus elements in ar2 but not ar1
    diff1 = setdiff1d(u1, u2)
    diff2 = setdiff1d(u2, u1)
    return _np.sort(concatenate([diff1, diff2]))


def isin(element, test_elements, assume_unique=False, invert=False):
    if not isinstance(element, ndarray):
        element = array(element)
    if not isinstance(test_elements, ndarray):
        test_elements = array(test_elements)
    result = _native.isin(element, test_elements)
    if invert:
        import numpy as _np
        return _np.logical_not(result)
    return result


in1d = isin


def all(a, axis=None, out=None, keepdims=False, where=True):
    if not isinstance(a, ndarray):
        a = asarray(a)
    if where is not True:
        w = asarray(where).astype("bool")
        # Masked elements become True (identity for AND)
        mask_f = w.astype("float64")
        a = a * mask_f + (1.0 - mask_f)
    if axis is None:
        return a.all()
    # Reduce along specific axis: all elements nonzero iff min != 0
    m = a.min(axis, keepdims)
    if not isinstance(m, ndarray):
        return bool(m != 0.0)
    flat = m.flatten().tolist()
    result = [v != 0.0 for v in flat]
    return array(result).reshape(m.shape)


def any(a, axis=None, out=None, keepdims=False, where=True):
    if not isinstance(a, ndarray):
        a = asarray(a)
    if where is not True:
        w = asarray(where).astype("bool")
        # Masked elements become False (identity for OR / 0.0)
        mask_f = w.astype("float64")
        a = a * mask_f
    if axis is None:
        return a.any()
    # Reduce along specific axis: any element nonzero iff max != 0
    m = a.max(axis, keepdims)
    if not isinstance(m, ndarray):
        return bool(m != 0.0)
    flat = m.flatten().tolist()
    result = [v != 0.0 for v in flat]
    return array(result).reshape(m.shape)


def may_share_memory(a, b, max_work=None):
    """Check if arrays may share memory (conservative)."""
    return shares_memory(a, b, max_work=max_work)


def shares_memory(a, b, max_work=None):
    """Check if arrays share memory via ArcArray buffer pointer equality."""
    if a is b:
        return True
    if isinstance(a, ndarray) and isinstance(b, ndarray) and hasattr(a, '_shares_memory_with'):
        return a._shares_memory_with(b)
    return False
